"""Support ``python -m gxl_paperclip`` (same behavior as the ``paperclip`` console script)."""

from __future__ import annotations

import sys

from gxl_paperclip.cli import main

if __name__ == "__main__":
    sys.exit(main())
