"""The :class:`PaperclipClient` — transport + typed methods for Paperclip.

All HTTP talk lives here. The CLI layer builds a client with resolved auth and
calls typed methods. Third-party code can do the same without importing
anything from ``cli.py``.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shlex
from collections.abc import Iterator, Sequence
from typing import Any
from urllib.parse import urlparse

import requests

from .. import __version__
from .. import config as _config
from .auth import APIKeyAuth, AuthStrategy, BearerAuth, FileCredentialsAuth
from .errors import (
    AuthError,
    NetworkError,
    NotFoundError,
    PaperclipError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
)
from .models import (
    ExecuteResult,
    HealthStatus,
    MapEvent,
    MapProgressEvent,
    MapResultEvent,
    ResultData,
    ResultRow,
    _papers_from_payload,
)


__all__ = ["PaperclipClient"]

log = logging.getLogger("gxl_paperclip")

_DEFAULT_TIMEOUT = 120.0
_SLOW_TIMEOUT = float(os.getenv("PAPERCLIP_SLOW_COMMAND_TIMEOUT_SECONDS", "300"))
_MAP_TIMEOUT = float(os.getenv("PAPERCLIP_MAP_TIMEOUT_SECONDS", "1500"))
_EXHAUSTIVE_MAP_TIMEOUT = float(
    os.getenv("PAPERCLIP_EXHAUSTIVE_MAP_TIMEOUT_SECONDS", "7500")
)
_SLOW_COMMANDS = frozenset({"ask-image", "map", "reduce"})
_RESULT_ID_RE = re.compile(r"\b([smr]_[0-9a-f]{4,})\b")


def _shell_join(args: Sequence[str]) -> str:
    """Join argv tokens into a shell-quoted string.

    The backend's ``/api/cli/execute`` endpoint parses ``raw`` as if it were
    the tail of a shell command, so we must quote arguments with spaces,
    wildcards, etc.
    """
    return shlex.join(list(args))


def _is_exhaustive_map_args(args: Sequence[str]) -> bool:
    """Return whether argv explicitly selects the exhaustive extraction worker."""
    tokens = list(args)
    for index, token in enumerate(tokens):
        if token == "--worker" and index + 1 < len(tokens):
            return tokens[index + 1].strip().lower() == "exhaustive-extraction"
        if token.startswith("--worker="):
            return token.split("=", 1)[1].strip().lower() == "exhaustive-extraction"
    return False


def _not_none(value: Any) -> bool:
    return value is not None and value is not False


class PaperclipClient:
    """Python client for the Paperclip service.

    Example::

        from gxl_paperclip import PaperclipClient, APIKeyAuth

        client = PaperclipClient(auth=APIKeyAuth("pk_..."))
        result = client.search("protein design", limit=10, source="pmc")
        print(result.output)
    """

    def __init__(
        self,
        auth: AuthStrategy,
        *,
        base_url: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
        user_agent: str | None = None,
        session: requests.Session | None = None,
    ) -> None:
        if auth is None:
            raise ValueError(
                "auth is required; pass APIKeyAuth(...), BearerAuth(...), or FileCredentialsAuth()"
            )
        self._auth = auth
        self._base_url = (base_url or _config.get_base_url()).rstrip("/")
        self._timeout = timeout
        self._session = session
        self._mcp_call_id = 0

        self._user_agent = user_agent or f"gxl-paperclip/{__version__}"

        self.results = _ResultsAPI(self)
        self.papers = _PapersAPI(self)
        self.repos = _ReposAPI(self)
        self.library = _LibraryAPI(self)

    # ------------------------------------------------------------------ classmethods

    @classmethod
    def from_env(
        cls,
        *,
        base_url: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
        user_agent: str | None = None,
        session: requests.Session | None = None,
    ) -> PaperclipClient:
        """Build a client using environment-provided credentials.

        Resolution order:

        1. ``PAPERCLIP_BEARER_TOKEN`` env var → :class:`BearerAuth`.
        2. ``PAPERCLIP_API_KEY`` env var → :class:`APIKeyAuth`.
        3. ``~/.paperclip/credentials.json`` → :class:`FileCredentialsAuth`.

        Raises :class:`AuthError` if none of the above apply.
        """
        bearer = os.getenv("PAPERCLIP_BEARER_TOKEN", "").strip()
        if bearer:
            return cls(
                auth=BearerAuth(bearer),
                base_url=base_url,
                timeout=timeout,
                user_agent=user_agent,
                session=session,
            )

        api_key = os.getenv("PAPERCLIP_API_KEY", "").strip()
        if api_key:
            return cls(
                auth=APIKeyAuth(api_key),
                base_url=base_url,
                timeout=timeout,
                user_agent=user_agent,
                session=session,
            )
        try:
            file_auth = FileCredentialsAuth()
        except AuthError:
            raise AuthError(
                "No PAPERCLIP_API_KEY env var and no credentials at "
                "~/.paperclip/credentials.json. Set PAPERCLIP_API_KEY or run "
                "`paperclip login`."
            )
        return cls(
            auth=file_auth,
            base_url=base_url,
            timeout=timeout,
            user_agent=user_agent,
            session=session,
        )

    # ------------------------------------------------------------------ properties

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def auth(self) -> AuthStrategy:
        return self._auth

    # ------------------------------------------------------------------ transport

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json", "User-Agent": self._user_agent}
        h.update(self._auth.apply())
        # Trusted per-request long-running cap override. Only forwarded when BOTH
        # the requested cap and the internal secret are present in the env — the
        # server ignores the cap unless the secret matches MCP_INTERNAL_SECRET,
        # so this is a no-op for ordinary users.
        long_cap = os.getenv("PAPERCLIP_LONG_CAP")
        secret = os.getenv("PAPERCLIP_INTERNAL_SECRET")
        if long_cap and secret:
            h["X-Paperclip-Long-Cap"] = long_cap
            h["X-Internal-Auth"] = secret
        return h

    def _request(self, method: str, url: str, **kwargs: Any) -> requests.Response:
        sess = self._session

        def send() -> requests.Response:
            if sess is not None:
                return sess.request(method, url, **kwargs)
            return requests.request(method, url, **kwargs)

        try:
            response = send()
            if response.status_code == 401 and isinstance(
                self._auth, FileCredentialsAuth
            ):
                headers = dict(kwargs.get("headers") or {})
                stale_authorization = headers.get("Authorization")
                headers.update(self._auth.refresh(stale_authorization))
                kwargs["headers"] = headers
                response = send()
            return response
        except requests.Timeout as exc:
            raise RequestTimeoutError(f"Request timed out: {method} {url}") from exc
        except requests.ConnectionError as exc:
            raise NetworkError("Could not reach the Paperclip server.") from exc

    def _check_response(self, resp: requests.Response, *, allow_404: bool = False) -> None:
        status = resp.status_code
        if 200 <= status < 300:
            return
        if status in (401, 403):
            raise AuthError(f"Authentication failed (HTTP {status}).")
        if status == 429:
            detail = None
            try:
                detail = resp.json().get("detail")
            except Exception:
                pass
            raise RateLimitError(detail or "Too many requests — please wait before making more. Contact support@gxl.ai to request more quota.")
        if status == 404:
            if allow_404:
                return
            detail = None
            try:
                detail = resp.json().get("detail")
            except Exception:
                pass
            raise NotFoundError(detail or f"Resource not found: {resp.url}")
        body = ""
        try:
            body = resp.text[:500]
        except Exception:
            pass
        # Include response body in error message for better debugging
        message = f"Server returned HTTP {status}"
        if body:
            message += f": {body}"
        raise ServerError(message, status_code=status, body=body)

    def _upload_headers(self) -> dict[str, str]:
        """Auth + UA headers without Content-Type (let requests set multipart boundary)."""
        h = {"User-Agent": self._user_agent}
        h.update(self._auth.apply())
        return h

    def _upload_multipart(
        self,
        path: str,
        files: list[tuple[str, tuple[str, bytes, str]]],
        *,
        data: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """POST multipart/form-data to ``{base_url}{path}``.

        ``files`` uses the requests format: ``[(field, (filename, data, mime))]``.
        ``data`` carries any additional form fields (e.g. ``folder_path``).
        """
        url = f"{self._base_url}{path}"
        to = timeout if timeout is not None else _SLOW_TIMEOUT
        resp = self._request(
            "POST",
            url,
            files=files,
            data=data or {},
            headers=self._upload_headers(),
            timeout=to,
        )
        self._check_response(resp)
        try:
            return resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc

    def upload_document(
        self,
        filename: str,
        file_bytes: bytes,
        *,
        folder_path: str = "",
        content_type: str = "application/octet-stream",
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Upload a single file to the user's clipboard via ``/api/user/upload``.

        Works for PDFs (parsed) and raw artifacts such as ``.json``/``.csv``/
        ``.md`` (stored verbatim). Returns the server's upload response dict.
        """
        files = [("file", (filename, file_bytes, content_type))]
        return self._upload_multipart(
            "/api/user/upload",
            files,
            data={"folder_path": folder_path},
            timeout=timeout,
        )

    def _resolve_timeout(self, timeout: float | None, *, command: str | None = None) -> float:
        if timeout is not None:
            return float(timeout)
        if command == "map":
            return _MAP_TIMEOUT
        if command and command in _SLOW_COMMANDS:
            return _SLOW_TIMEOUT
        return self._timeout

    def _is_local_server(self) -> bool:
        host = urlparse(self._base_url).hostname or ""
        return host in ("localhost", "127.0.0.1")

    def _post(
        self,
        command: str,
        args: Sequence[str] | None = None,
        *,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Send a command to ``/api/cli/execute`` (REST) or ``/papers`` or ``/mcp`` (MCP).

        * Local server → always uses REST (needed for multi-backend routing).
        * Remote + API-key auth → hits the MCP path directly.
        * Remote + OAuth auth → tries REST first; falls back to MCP on HTTP 404.
        """
        raw = _shell_join(args) if args else ""
        resolved_timeout = self._resolve_timeout(timeout, command=command)

        if self._auth.uses_api_key and not self._is_local_server():
            full_command = f"{command} {raw}".strip() if raw else command
            return self._post_mcp(full_command, timeout=resolved_timeout)

        url = f"{self._base_url}/api/cli/execute"
        resp = self._request(
            "POST",
            url,
            json={"command": command, "raw": raw},
            headers=self._headers(),
            timeout=resolved_timeout,
        )
        if resp.status_code == 404:
            full_command = f"{command} {raw}".strip() if raw else command
            return self._post_mcp(full_command, timeout=resolved_timeout)
        self._check_response(resp)
        try:
            data = resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc
        if data is None:
            raise ServerError("Server returned null response (possible unhandled command).")
        return _execute_result_from_rest(data)

    def _hydrate_result_data(self, result: ExecuteResult) -> ExecuteResult:
        """Attach missing or fuller structured data from the result registry."""
        current = result.result_data if isinstance(result.result_data, dict) else None
        inline = result.raw.get("result_data")
        if current is None and isinstance(inline, dict):
            current = inline
            result.result_data = inline
        if not result.result_id:
            return result

        current_papers = result.papers
        count_hint = None
        if isinstance(current, dict):
            count_hint = current.get("count")
        if count_hint is None:
            count_hint = result.raw.get("count") or result.raw.get("result_count")
        try:
            expected_count = int(count_hint) if count_hint is not None else None
        except (TypeError, ValueError):
            expected_count = None
        needs_fuller = current is None or bool(
            isinstance(current, dict) and current.get("truncated")
        )
        if expected_count is not None and expected_count > len(current_papers):
            needs_fuller = True
        if not needs_fuller:
            return result

        try:
            saved = self.results.get(result.result_id)
        except (NotFoundError, NetworkError, ServerError, PaperclipError):
            return result
        rd = saved.raw.get("result_data")
        if isinstance(rd, dict) and len(_papers_from_payload(rd)) >= len(current_papers):
            result.result_data = rd
        return result

    def _post_mcp(self, full_command: str, *, timeout: float) -> ExecuteResult:
        """Call the MCP JSON-RPC endpoint (``/papers`` for API key, ``/mcp`` for OAuth)."""
        self._mcp_call_id += 1

        # Routing:
        #   * API-key auth → ``/papers`` (the API-key middleware runs there).
        #   * Hostnames that begin with ``mcp.`` → ``/papers`` (prod direct-MCP subdomain).
        #   * Everything else → ``/mcp`` (OAuth-wrapped path on the unified origin).
        host = urlparse(self._base_url).hostname or ""
        if host.startswith("mcp."):
            url = f"{self._base_url}/papers"
        else:
            url = f"{self._base_url}/mcp"
        payload = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "paperclip",
                "arguments": {
                    "command": full_command,
                    "description": full_command[:80],
                    "skip_truncation": True,
                },
            },
            "id": self._mcp_call_id,
        }
        resp = self._request(
            "POST",
            url,
            json=payload,
            headers=self._headers(),
            timeout=timeout,
        )
        self._check_response(resp)
        try:
            data = resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc
        if "error" in data:
            err = data["error"]
            if isinstance(err, dict):
                msg = err.get("message", "Unknown MCP error")
                code = err.get("code")
            else:
                msg = str(err)
                code = None
            raise ServerError(
                f"{msg} (code: {code})" if code is not None else msg,
                status_code=resp.status_code,
            )
        result = data.get("result", {}) or {}
        texts: list[str] = []
        for block in result.get("content", []) or []:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(block.get("text", ""))
        output_text = "\n".join(texts)
        result_id = None
        m = _RESULT_ID_RE.search(output_text)
        if m:
            result_id = m.group(1)
        return ExecuteResult(
            output=output_text,
            exit_code=0,
            result_id=result_id,
            raw=data,
        )

    def _stream_map(
        self,
        args: Sequence[str],
        *,
        timeout: float | None = None,
    ) -> Iterator[MapEvent]:
        """Yield :class:`MapProgressEvent` / :class:`MapResultEvent` as the map runs."""
        raw = _shell_join(args) if args else ""
        resolved_timeout = (
            _EXHAUSTIVE_MAP_TIMEOUT
            if timeout is None and _is_exhaustive_map_args(args)
            else self._resolve_timeout(timeout, command="map")
        )

        # A direct MCP hostname has no REST streaming endpoint. Unified
        # paperclip hosts do, including API-key auth, and must use it for large
        # maps so progress heartbeats keep proxies/load balancers alive beyond
        # their idle request timeout.
        host = urlparse(self._base_url).hostname or ""
        if self._auth.uses_api_key and host.startswith("mcp."):
            full_command = f"map {raw}".strip() if raw else "map"
            result = self._post_mcp(full_command, timeout=resolved_timeout)
            yield MapResultEvent(
                output=result.output,
                result_id=result.result_id,
                elapsed_ms=result.elapsed_ms,
                exit_code=result.exit_code,
            )
            return

        url = f"{self._base_url}/api/cli/execute?stream=1"
        resp = self._request(
            "POST",
            url,
            json={"command": "map", "raw": raw},
            headers=self._headers(),
            timeout=resolved_timeout,
            stream=True,
        )
        self._check_response(resp)
        content_type = resp.headers.get("content-type", "") if resp.headers else ""
        if "ndjson" not in content_type and "stream" not in content_type:
            # Server returned a non-streaming JSON response — normalise into
            # a single result event.
            try:
                data = resp.json()
            except ValueError:
                yield MapResultEvent(output=resp.text, exit_code=0)
                return
            yield MapResultEvent(
                output=data.get("output", ""),
                result_id=data.get("result_id"),
                elapsed_ms=data.get("elapsed_ms"),
                exit_code=int(data.get("exit_code", 0) or 0),
            )
            return

        try:
            for line in resp.iter_lines(decode_unicode=True):
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    log.debug("Skipping non-JSON streaming line: %r", line)
                    continue
                kind = data.get("type")
                if kind == "progress":
                    yield MapProgressEvent(
                        total=int(data.get("total", 0) or 0),
                        completed=int(data.get("completed", 0) or 0),
                        failed=int(data.get("failed", 0) or 0),
                        elapsed_s=float(data.get("elapsed_s", 0) or 0.0),
                        run_id=data.get("run_id"),
                    )
                elif kind == "result":
                    yield MapResultEvent(
                        output=data.get("output", ""),
                        result_id=data.get("result_id"),
                        elapsed_ms=data.get("elapsed_ms"),
                        exit_code=int(data.get("exit_code", 0) or 0),
                    )
        except requests.RequestException as exc:
            raise NetworkError("Map stream was interrupted.") from exc

    # ------------------------------------------------------------------ typed methods

    def search(
        self,
        query: str,
        *,
        limit: int | None = None,
        source: str | None = None,
        exact: bool = False,
        since: str | None = None,
        sort: str | None = None,
        author: str | None = None,
        journal: str | None = None,
        year: int | str | None = None,
        type: str | None = None,  # noqa: A002 - matches CLI flag name
        category: str | None = None,
        mode: str | None = None,
        min_embedding_similarity: float | None = None,
        min_bm25_score: float | None = None,
        all: bool = False,  # noqa: A002 - matches CLI flag name
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Search the Paperclip corpus.

        ``None`` / ``False`` kwargs are omitted from the command line, deferring
        to whatever default the server applies.

        ``min_embedding_similarity`` sets a minimum Qdrant cosine similarity for
        the vector leg; ``min_bm25_score`` sets a minimum OpenSearch BM25 score for
        the lexical leg. They are separate because the two scores are on
        different scales, and they filter results within ``limit`` rather than
        widening retrieval.

        Each bounds only its own leg. Under the default hybrid ranking both
        legs run, so passing just one still returns unfiltered hits from the
        other; pass both, or pair one with a matching ``ranking``, to bound
        every result. Neither is supported with regex or analogical ranking.
        A vector threshold is also incompatible with date sorting. If the
        backend needed to evaluate a floor cannot be consulted, the search
        fails instead of returning results that bypassed that floor.
        """
        args: list[str] = []
        if all:
            args.append("--all")
        if exact:
            args.append("-e")
        args.append(query)
        if limit is not None:
            args += ["-n", str(limit)]
        if source is not None:
            args += ["-s", source]
        if since is not None:
            args += ["--since", since]
        if sort is not None:
            args += ["--sort", sort]
        if author is not None:
            args += ["--author", author]
        if journal is not None:
            args += ["--journal", journal]
        if year is not None:
            args += ["--year", str(year)]
        if type is not None:
            args += ["--type", type]
        if category is not None:
            args += ["--category", category]
        if mode is not None:
            args += ["-m", mode]
        if min_embedding_similarity is not None:
            args += ["--min-embedding-similarity", str(min_embedding_similarity)]
        if min_bm25_score is not None:
            args += ["--min-bm25-score", str(min_bm25_score)]
        return self._hydrate_result_data(self._post("search", args, timeout=timeout))

    def lookup(
        self,
        field: str,
        value: str,
        *,
        limit: int | None = None,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Look up papers by metadata field (doi, pmc, pmid, author, title, ...)."""
        args: list[str] = [field, value]
        if limit is not None:
            args += ["-n", str(limit)]
        return self._hydrate_result_data(self._post("lookup", args, timeout=timeout))

    def sql(
        self,
        query: str,
        *,
        source: str | None = None,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Run a read-only SQL query against the ``documents`` table."""
        args: list[str] = [query]
        if source is not None:
            args += ["--source", source]
        return self._post("sql", args, timeout=timeout)

    def map_(
        self,
        question: str,
        *,
        from_results: str,
        timeout: float | None = None,
    ) -> Iterator[MapEvent]:
        """Run ``question`` against every paper in a prior search's result set.

        Yields :class:`MapProgressEvent` while the map runs and a final
        :class:`MapResultEvent`. The API-key path can't stream and emits only
        the result event.
        """
        args = ["--from", from_results, question]
        return self._stream_map(args, timeout=timeout)

    def reduce(
        self,
        question: str,
        *,
        from_map: str,
        strategy: str | None = None,
        columns: Sequence[str] | None = None,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Synthesize a prior ``map`` result set into a single answer.

        ``from_map`` is the ``m_*`` result_id returned by :meth:`map_`. Pass
        ``strategy`` (e.g. ``"summarize"``, ``"table"``, ``"themes"``) and
        ``columns`` (for the ``table`` strategy) to shape the synthesis; both
        default to the server's behaviour when omitted.
        """
        args = ["--from", from_map]
        if strategy is not None:
            args += ["--strategy", strategy]
        if columns:
            args += ["--columns", ",".join(columns)]
        args.append(question)
        return self._post("reduce", args, timeout=timeout)

    def pull(
        self,
        target: str,
        dest: str | None = None,
        *,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Download a paper or single file.

        Phase 1 matches today's CLI behaviour: the response is the formatted
        text body the server returns. ``ExecuteResult.download_url`` is
        populated when the server produced a signed URL, but streaming binary
        bytes to disk is not handled by the SDK yet.
        """
        args: list[str] = [target]
        if dest is not None:
            args.append(dest)
        return self._post("pull", args, timeout=timeout)

    def ask_image(
        self,
        path: str,
        question: str | None = None,
        *,
        fn: str | None = None,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Analyse a paper figure with Gemini vision."""
        args: list[str] = [path]
        if fn is not None:
            args += ["--fn", fn]
        if question is not None:
            args.append(question)
        return self._post("ask-image", args, timeout=timeout)

    def bash(
        self,
        script: str,
        *,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Execute an arbitrary server-side pipeline (``search | grep ...``)."""
        return self._post("bash", [script], timeout=timeout)

    def health(self, *, timeout: float | None = None) -> HealthStatus:
        """Check that the server is reachable and auth works.

        Internally calls the server's ``status`` command.
        """
        try:
            result = self._post("status", None, timeout=timeout)
        except PaperclipError as exc:
            return HealthStatus(reachable=False, output=str(exc), exit_code=1)
        return HealthStatus(
            reachable=True,
            output=result.output,
            exit_code=result.exit_code,
            elapsed_ms=result.elapsed_ms,
        )

    def list_paper_repos(self, *, timeout: float | None = None) -> list[dict[str, Any]]:
        """List paper repositories (``GET /api/paper-repos/``).

        Requires Bearer auth from ``paperclip login``. API-key authentication is
        not supported for this endpoint yet.
        """
        if self._auth.uses_api_key:
            raise PaperclipError(
                "list_paper_repos requires OAuth (run `paperclip login`). "
                "API-key access to /api/paper-repos is not available yet."
            )
        url = f"{self._base_url}/api/paper-repos/"
        to = timeout if timeout is not None else 30.0
        resp = self._request("GET", url, headers=self._headers(), timeout=to)
        self._check_response(resp)
        try:
            body = resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc
        repos = body.get("repos", [])
        if not isinstance(repos, list):
            raise ServerError("Unexpected response shape for paper repos.")
        out: list[dict[str, Any]] = []
        for r in repos:
            if not isinstance(r, dict):
                continue
            out.append(
                {
                    "name": r.get("name", ""),
                    "description": r.get("description") or "",
                    "paper_count": int(r.get("paper_count") or 0),
                    "branch_count": int(r.get("branch_count") or 0),
                    "active_branch": r.get("active_branch") or "main",
                    "created_at": r.get("created_at") or "",
                }
            )
        return out

    def execute(
        self,
        command: str,
        args: Sequence[str] | None = None,
        *,
        timeout: float | None = None,
    ) -> ExecuteResult:
        """Low-level escape hatch: invoke any server command with a list of argv tokens.

        Prefer the typed methods (``search``, ``lookup``, ``sql``...) where
        available. Use ``execute`` for commands without a typed wrapper —
        ``sed``, ``awk``, ``sort``, ``cut``, ``tr``, ``jq``, and any new
        server-side command.
        """
        return self._post(command, list(args or []), timeout=timeout)

    def stream(
        self,
        command: str,
        args: Sequence[str] | None = None,
        *,
        timeout: float | None = None,
    ) -> Iterator[MapEvent]:
        """Streaming equivalent of :meth:`execute`.

        Only ``map`` streams today; calling this with any other command raises
        :class:`ValueError`. The CLI uses this for its ``paperclip map`` path,
        where argv is forwarded verbatim rather than split into typed kwargs.
        """
        if command != "map":
            raise ValueError(
                f"stream() only supports 'map' today, got {command!r}; "
                "use execute() for non-streaming commands."
            )
        return self._stream_map(list(args or []), timeout=timeout)


# ---------------------------------------------------------------- sub-namespaces


class _ResultsAPI:
    """``client.results`` — list and fetch saved search/lookup/sql/map results."""

    def __init__(self, client: PaperclipClient) -> None:
        self._c = client

    def list(self, *, limit: int | None = None, timeout: float | None = None) -> list[ResultRow]:
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        url = f"{self._c._base_url}/api/cli/results"
        resp = self._c._request(
            "GET",
            url,
            headers=self._c._headers(),
            params=params,
            timeout=timeout if timeout is not None else 10,
        )
        self._c._check_response(resp)
        try:
            rows = resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc
        return [
            ResultRow(
                result_id=r.get("result_id", ""),
                command=r.get("command"),
                raw_input=r.get("raw_input"),
                latency_ms=r.get("latency_ms"),
                created_at=r.get("created_at"),
                raw=r,
            )
            for r in rows
        ]

    def get(self, result_id: str, *, timeout: float | None = None) -> ResultData:
        url = f"{self._c._base_url}/api/cli/results/{result_id}"
        resp = self._c._request(
            "GET",
            url,
            headers=self._c._headers(),
            timeout=timeout if timeout is not None else 10,
        )
        if resp.status_code == 404:
            raise NotFoundError(f"Result {result_id} not found.")
        self._c._check_response(resp)
        try:
            data = resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc
        return ResultData(
            result_id=data.get("result_id", result_id),
            output=data.get("output", ""),
            command=data.get("command"),
            raw_input=data.get("raw_input"),
            latency_ms=data.get("latency_ms"),
            created_at=data.get("created_at"),
            raw=data,
        )

    def page(
        self, identifier: str, *, cursor: int = 0, limit: int = 500,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        if not 1 <= limit <= 500:
            raise ValueError("result page limit must be between 1 and 500")
        url = f"{self._c._base_url}/api/cli/results/{identifier}/page"
        resp = self._c._request(
            "GET", url, headers=self._c._headers(),
            params={"cursor": cursor, "limit": limit},
            timeout=timeout if timeout is not None else 30,
        )
        if resp.status_code == 404:
            raise NotFoundError(
                "Cohort export is unavailable: the server does not support paged "
                f"result bundles, or result {identifier} was not found."
            )
        self._c._check_response(resp)
        try:
            return resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc

    def import_bundle(
        self, papers: list[dict[str, Any]], *, provenance: dict[str, Any],
        save_as: str | None = None, timeout: float | None = None,
    ) -> dict[str, Any]:
        url = f"{self._c._base_url}/api/cli/results/import"
        resp = self._c._request(
            "POST", url, headers=self._c._headers(),
            json={"papers": papers, "provenance": provenance, "save_as": save_as},
            timeout=timeout if timeout is not None else 120,
        )
        if resp.status_code in (404, 405):
            raise NotFoundError(
                "Cohort reload is unavailable because the server does not support "
                "bundle imports."
            )
        self._c._check_response(resp)
        try:
            return resp.json()
        except ValueError as exc:
            raise ServerError("Invalid JSON response from server.") from exc


class _PapersAPI:
    """``client.papers.*`` — typed wrappers over the bash-proxy file utilities."""

    def __init__(self, client: PaperclipClient) -> None:
        self._c = client

    def cat(self, path: str, *, timeout: float | None = None) -> ExecuteResult:
        return self._c.execute("cat", [path], timeout=timeout)

    def head(
        self,
        path: str,
        *,
        lines: int | None = None,
        timeout: float | None = None,
    ) -> ExecuteResult:
        args: list[str] = []
        if lines is not None:
            args += ["-n", str(lines)]
        args.append(path)
        return self._c.execute("head", args, timeout=timeout)

    def tail(
        self,
        path: str,
        *,
        lines: int | None = None,
        timeout: float | None = None,
    ) -> ExecuteResult:
        args: list[str] = []
        if lines is not None:
            args += ["-n", str(lines)]
        args.append(path)
        return self._c.execute("tail", args, timeout=timeout)

    def ls(self, path: str, *, timeout: float | None = None) -> ExecuteResult:
        return self._c.execute("ls", [path], timeout=timeout)

    def grep(
        self,
        pattern: str,
        path: str,
        *,
        ignore_case: bool = False,
        extended: bool = False,
        boolean: bool = False,
        timeout: float | None = None,
    ) -> ExecuteResult:
        args: list[str] = []
        if boolean:
            args.append("--bool")
        if ignore_case:
            args.append("-i")
        if extended:
            args.append("-E")
        args += [pattern, path]
        return self._c.execute("grep", args, timeout=timeout)

    def scan(
        self,
        path: str,
        patterns: Sequence[str],
        *,
        timeout: float | None = None,
    ) -> ExecuteResult:
        args = [path, *patterns]
        return self._c.execute("scan", args, timeout=timeout)


class _ReposAPI:
    """``client.repos.*`` — paper repository management via REST API."""

    def __init__(self, client: PaperclipClient) -> None:
        self._c = client

    def _request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request and return parsed JSON."""
        url = f"{self._c.base_url}{path}"
        to = timeout if timeout is not None else 30.0
        resp = self._c._request(
            method, url, json=json, params=params, headers=self._c._headers(), timeout=to
        )
        self._c._check_response(resp)
        try:
            return resp.json()
        except ValueError as exc:
            from .errors import ServerError

            raise ServerError("Invalid JSON response from server.") from exc

    def list_repos(self, *, timeout: float | None = None) -> list[dict[str, Any]]:
        """List all repos for the user. Returns list of repo dicts."""
        data = self._request("GET", "/api/paper-repos/", timeout=timeout)
        return data.get("repos", [])

    def get_repo_by_name(self, name: str, *, timeout: float | None = None) -> dict[str, Any] | None:
        """Get repo detail by name. Returns None if not found."""
        try:
            return self._request("GET", f"/api/paper-repos/by-name/{name}", timeout=timeout)
        except NotFoundError:
            return None

    def create_repo(
        self,
        name: str,
        description: str | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Create a new repo. Returns the created repo."""
        return self._request(
            "POST",
            "/api/paper-repos/",
            json={"name": name, "description": description},
            timeout=timeout,
        )

    def patch_repo(
        self,
        repo_id: str,
        *,
        active_branch: str | None = None,
        description: str | None = None,
        is_public: bool | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Update repo settings."""
        body: dict[str, Any] = {}
        if active_branch is not None:
            body["active_branch"] = active_branch
        if description is not None:
            body["description"] = description
        if is_public is not None:
            body["is_public"] = is_public
        return self._request("PATCH", f"/api/paper-repos/{repo_id}", json=body, timeout=timeout)

    def add_papers(
        self,
        repo_id: str,
        items: list[dict[str, Any]],
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Add papers to a repo. Each item: {paper_id: str, title?: str, doi?: str}."""
        return self._request(
            "POST",
            f"/api/paper-repos/{repo_id}/papers",
            json={"items": items, "branch": branch},
            timeout=timeout,
        )

    def remove_paper(
        self,
        repo_id: str,
        entry_id: str,
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Remove a paper entry from a repo."""
        params: dict[str, Any] = {}
        if branch:
            params["branch"] = branch
        return self._request(
            "DELETE",
            f"/api/paper-repos/{repo_id}/papers/{entry_id}",
            params=params,
            timeout=timeout,
        )

    def annotate_paper(
        self,
        repo_id: str,
        entry_id: str,
        note: str,
        *,
        lines: str | None = None,
        source_locations: list[dict[str, str]] | None = None,
        branch: str | None = None,
        doi: str | None = None,
        cited_by_count: int | None = None,
        s2_id: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Add annotation to a paper entry. Optionally update metadata fields."""
        body: dict[str, Any] = {"append_annotation": {"note": note}}
        if lines:
            body["append_annotation"]["lines"] = lines
        if source_locations:
            body["append_annotation"]["source_locations"] = source_locations
        if doi is not None:
            body["doi"] = doi
        if cited_by_count is not None:
            body["cited_by_count"] = cited_by_count
        if s2_id is not None:
            body["s2_id"] = s2_id
        params: dict[str, Any] = {}
        if branch:
            params["branch"] = branch
        return self._request(
            "PATCH",
            f"/api/paper-repos/{repo_id}/papers/{entry_id}",
            json=body,
            params=params,
            timeout=timeout,
        )

    def commit(
        self,
        repo_id: str,
        message: str,
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Create a commit."""
        return self._request(
            "POST",
            f"/api/paper-repos/{repo_id}/commits",
            json={"message": message, "branch": branch},
            timeout=timeout,
        )

    def list_commits(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        page: int = 1,
        per_page: int = 50,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """List commits for a repo."""
        params: dict[str, Any] = {"page": page, "per_page": per_page}
        if branch:
            params["branch"] = branch
        return self._request(
            "GET",
            f"/api/paper-repos/{repo_id}/commits",
            params=params,
            timeout=timeout,
        )

    def create_branch(
        self,
        repo_id: str,
        name: str,
        *,
        from_branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Create a new branch."""
        return self._request(
            "POST",
            f"/api/paper-repos/{repo_id}/branches",
            json={"name": name, "from_branch": from_branch},
            timeout=timeout,
        )

    def list_folders(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """List organizational folders in a repo branch."""
        params: dict[str, Any] = {}
        if branch:
            params["branch"] = branch
        return self._request(
            "GET",
            f"/api/paper-repos/{repo_id}/folders",
            params=params,
            timeout=timeout,
        )

    def mkdir(
        self,
        repo_id: str,
        path: str,
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Create an (empty) folder in the active branch's organizational tree."""
        return self._request(
            "POST",
            f"/api/paper-repos/{repo_id}/folders",
            json={"path": path, "branch": branch},
            timeout=timeout,
        )

    def rmdir(
        self,
        repo_id: str,
        path: str,
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Remove an empty folder from the active branch's organizational tree."""
        return self._request(
            "DELETE",
            f"/api/paper-repos/{repo_id}/folders",
            json={"path": path, "branch": branch},
            timeout=timeout,
        )

    def merge_branches(
        self,
        repo_id: str,
        source: str,
        target: str,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Merge source branch into target."""
        return self._request(
            "POST",
            f"/api/paper-repos/{repo_id}/merge",
            json={"source": source, "target": target},
            timeout=timeout,
        )

    def get_status(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Get repo status."""
        params: dict[str, Any] = {}
        if branch:
            params["branch"] = branch
        return self._request(
            "GET",
            f"/api/paper-repos/{repo_id}/status",
            params=params,
            timeout=timeout,
        )

    def get_diff(
        self,
        repo_id: str,
        ref_a: str,
        ref_b: str,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Get diff between two refs."""
        return self._request(
            "GET",
            f"/api/paper-repos/{repo_id}/diff",
            params={"ref_a": ref_a, "ref_b": ref_b},
            timeout=timeout,
        )

    def export(
        self,
        repo_id: str,
        format: str,
        *,
        branch: str | None = None,
        timeout: float | None = None,
    ) -> bytes:
        """Export repo to bibtex/ris/markdown/csv. Returns raw bytes."""
        url = f"{self._c.base_url}/api/paper-repos/{repo_id}/export"
        params: dict[str, Any] = {"format": format}
        if branch:
            params["branch"] = branch
        to = timeout if timeout is not None else 30.0
        resp = self._c._request(
            "GET",
            url,
            params=params,
            headers=self._c._headers(),
            timeout=to,
        )
        self._c._check_response(resp)
        return resp.content

    # ── Citation counts (internal OpenAlex) ─────────────────────

    def lookup_citation_counts(
        self,
        paper_ids: list[str],
        dois: dict[str, str] | None = None,
        *,
        resolve_dois: bool = True,
        timeout: float | None = None,
    ) -> dict:
        """Look up citation counts + DOIs from the internal OpenAlex database.

        Returns {"counts": {pid: int}, "dois": {pid: doi}}.
        When resolve_dois=True (default), the backend resolves DOIs from the
        papers DB so the caller doesn't need to fetch them separately.
        """
        return self._request(
            "POST",
            "/api/paper-repos/citations/lookup",
            json={"paper_ids": paper_ids, "dois": dois, "resolve_dois": resolve_dois},
            timeout=timeout,
        )

    # ── Command history ──────────────────────────────────────────

    def list_history(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        session_id: str | None = None,
        tool_name: str | None = None,
        page: int = 1,
        per_page: int = 50,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """List command history for a repo, optionally scoped to a branch."""
        params: dict[str, Any] = {"page": page, "per_page": per_page}
        if branch:
            params["branch"] = branch
        if session_id:
            params["session_id"] = session_id
        if tool_name:
            params["tool_name"] = tool_name
        return self._request(
            "GET",
            f"/api/paper-repos/{repo_id}/history",
            params=params,
            timeout=timeout,
        )

    def record_command(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        command: str,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        document_ids: list[str] | None = None,
        result_summary: str | None = None,
        result_id: str | None = None,
        session_id: str | None = None,
        exit_code: int = 0,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Record a command in the repo's history, tagged to a branch."""
        body: dict[str, Any] = {
            "command": command,
            "tool_name": tool_name,
            "arguments": arguments or {},
            "document_ids": document_ids or [],
            "exit_code": exit_code,
        }
        if branch:
            body["branch"] = branch
        if session_id:
            body["session_id"] = session_id
        if result_summary:
            body["result_summary"] = result_summary
        if result_id:
            body["result_id"] = result_id
        return self._request(
            "POST",
            f"/api/paper-repos/{repo_id}/history",
            json=body,
            timeout=timeout,
        )


class _LibraryAPI:
    """``client.library.*`` — personal library management via REST API."""

    def __init__(self, client: PaperclipClient) -> None:
        self._c = client

    def _request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request and return parsed JSON."""
        url = f"{self._c.base_url}{path}"
        to = timeout if timeout is not None else 30.0
        resp = self._c._request(
            method, url, json=json, params=params, headers=self._c._headers(), timeout=to
        )
        self._c._check_response(resp)
        try:
            return resp.json()
        except ValueError as exc:
            from .errors import ServerError

            raise ServerError("Invalid JSON response from server.") from exc

    def list_papers(
        self,
        *,
        page: int = 1,
        per_page: int = 50,
        search: str | None = None,
        sort_by: str = "created_at",
        sort_dir: str = "desc",
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """List papers in the user's library."""
        params: dict[str, Any] = {
            "page": page,
            "per_page": per_page,
            "sort_by": sort_by,
            "sort_dir": sort_dir,
        }
        if search:
            params["search"] = search
        return self._request("GET", "/api/library/", params=params, timeout=timeout)

    def get_paper(self, paper_id: str, *, timeout: float | None = None) -> dict[str, Any] | None:
        """Get a single paper from the library. Returns None if not found."""
        try:
            return self._request("GET", f"/api/library/{paper_id}", timeout=timeout)
        except NotFoundError:
            return None

    def update_paper(
        self,
        paper_id: str,
        updates: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Update paper metadata."""
        return self._request("PATCH", f"/api/library/{paper_id}", json=updates, timeout=timeout)

    def delete_paper(self, paper_id: str, *, timeout: float | None = None) -> None:
        """Delete a paper from the library."""
        url = f"{self._c.base_url}/api/library/{paper_id}"
        to = timeout if timeout is not None else 30.0
        resp = self._c._request("DELETE", url, headers=self._c._headers(), timeout=to)
        self._c._check_response(resp, allow_404=True)

    def bulk_delete(self, paper_ids: list[str], *, timeout: float | None = None) -> int:
        """Bulk delete papers. Returns count deleted."""
        result = self._request(
            "POST",
            "/api/library/bulk-delete",
            json={"ids": paper_ids},
            timeout=timeout,
        )
        return result.get("deleted", 0)

    def add_papers(self, items: list[dict], *, timeout: float | None = None) -> dict:
        """Add papers to the personal library.

        Returns {"added": [...], "skipped": [...], "total": N}
        """
        return self._request(
            "POST",
            "/api/library/papers",
            json={"items": items},
            timeout=timeout,
        )

    def upload_pdfs(
        self,
        files: list[tuple[str, bytes]],
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Upload PDF files for import. Returns ``{"job_id": ..., "status": ...}``.

        Each element is ``(filename, pdf_bytes)``.  The server processes them
        asynchronously; poll with :meth:`poll_import_job`.
        """
        multipart = [
            ("files", (name, data, "application/pdf"))
            for name, data in files
        ]
        return self._c._upload_multipart(
            "/api/library/import/pdf", multipart, timeout=timeout
        )

    def get_import_job_status(
        self,
        job_id: str,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Check the status of an import job."""
        return self._request(
            "GET",
            f"/api/library/import/jobs/{job_id}",
            timeout=timeout,
        )

    def poll_import_job(
        self,
        job_id: str,
        *,
        on_progress: Any | None = None,
        timeout_s: float = 900,
    ) -> dict[str, Any]:
        """Poll an import job until completed or failed.

        ``on_progress`` is called as ``on_progress(processed, total)`` on
        each poll when ``total > 0``.  Returns the final result dict.

        Raises :class:`ServerError` on failure or timeout.
        """
        import time as _time

        deadline = _time.monotonic() + timeout_s
        delay = 0.8

        while _time.monotonic() < deadline:
            status = self.get_import_job_status(job_id)

            total = int(status.get("total") or 0)
            processed = int(status.get("processed") or 0)
            if total > 0 and on_progress is not None:
                on_progress(processed, total)

            if status.get("status") == "completed":
                result = status.get("result")
                if result is None:
                    raise ServerError("Import finished without result data.")
                return result

            if status.get("status") == "failed":
                detail = (status.get("error_detail") or "").strip()
                raise ServerError(detail or "Import failed.")

            _time.sleep(delay)
            delay = min(delay * 1.15, 5.0)

        raise RequestTimeoutError(
            "PDF import is taking longer than expected. "
            "Check your library shortly or try again."
        )


# ---------------------------------------------------------------- helpers


def _execute_result_from_rest(data: dict[str, Any]) -> ExecuteResult:
    """Translate the server's ExecuteResponse JSON into an :class:`ExecuteResult`."""
    result_data = data.get("result_data")
    if not isinstance(result_data, dict):
        result_data = None
    return ExecuteResult(
        output=data.get("output", "") or "",
        exit_code=int(data.get("exit_code", 0) or 0),
        elapsed_ms=data.get("elapsed_ms"),
        result_id=data.get("result_id"),
        download_url=data.get("download_url"),
        download_filename=data.get("download_filename"),
        cwd=data.get("cwd"),
        result_data=result_data,
        raw=data,
    )
