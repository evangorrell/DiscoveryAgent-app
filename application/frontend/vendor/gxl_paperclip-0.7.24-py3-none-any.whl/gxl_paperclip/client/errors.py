"""Exception hierarchy raised by the Paperclip SDK.

All SDK errors derive from :class:`PaperclipError` so callers can catch them
generically with ``except PaperclipError`` or handle specific failure modes
with the more specific subclasses.
"""

from __future__ import annotations


class PaperclipError(Exception):
    """Base class for all Paperclip SDK errors."""


class AuthError(PaperclipError):
    """Authentication failed: missing, invalid, or expired credentials."""


class RateLimitError(PaperclipError):
    """The server returned HTTP 429 — too many requests."""


class NotFoundError(PaperclipError):
    """Requested resource was not found (HTTP 404)."""


class ServerError(PaperclipError):
    """The server returned an unexpected non-success response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class RequestTimeoutError(PaperclipError):
    """The HTTP request timed out."""


class NetworkError(PaperclipError):
    """Could not reach the Paperclip server (DNS, connection refused, etc.)."""
