"""Typed result objects returned by :class:`PaperclipClient` methods."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Union


def _papers_from_payload(data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Extract the papers list from a structured search/lookup payload."""
    if not isinstance(data, dict):
        return []
    papers = data.get("papers")
    if papers is None:
        papers = data.get("results")
    if isinstance(papers, list):
        return papers
    return []


@dataclass
class ExecuteResult:
    """Result of a Paperclip command.

    Mirrors every field the server's ``ExecuteResponse`` can populate so callers
    always have access to the same data the CLI renders.

    Use :attr:`output` for the same formatted text the CLI prints (may be a
    truncated preview). Use :attr:`papers` for the full structured hit list up
    to the requested ``limit``.
    """

    output: str = ""
    exit_code: int = 0
    elapsed_ms: int | None = None
    result_id: str | None = None
    download_url: str | None = None
    download_filename: str | None = None
    cwd: str | None = None
    result_data: dict[str, Any] | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def papers(self) -> list[dict[str, Any]]:
        """Structured search/lookup hits (full list up to ``limit``).

        Empty when the command did not return paper metadata (e.g. ``grep``).
        """
        return list(_papers_from_payload(self.result_data))

    @property
    def count(self) -> int:
        """Number of structured hits in :attr:`papers`."""
        papers = self.papers
        if papers:
            return len(papers)
        if isinstance(self.result_data, dict):
            total = self.result_data.get("count")
            if total is not None:
                try:
                    return int(total)
                except (TypeError, ValueError):
                    pass
        return 0


@dataclass
class MapProgressEvent:
    """Progress update emitted while a ``map`` command is running."""

    total: int = 0
    completed: int = 0
    failed: int = 0
    elapsed_s: float = 0.0
    run_id: str | None = None


@dataclass
class MapResultEvent:
    """Final result emitted at the end of a ``map`` command."""

    output: str = ""
    result_id: str | None = None
    elapsed_ms: int | None = None
    exit_code: int = 0


MapEvent = Union[MapProgressEvent, MapResultEvent]  # noqa: UP007 - runtime alias, Python 3.8/3.9 can't evaluate `|`


@dataclass
class ResultRow:
    """One entry returned by ``results.list()``."""

    result_id: str
    command: str | None = None
    raw_input: str | None = None
    latency_ms: int | None = None
    created_at: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class ResultData:
    """Full saved result returned by ``results.get(result_id)``."""

    result_id: str
    output: str = ""
    command: str | None = None
    raw_input: str | None = None
    latency_ms: int | None = None
    created_at: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class HealthStatus:
    """Server reachability report returned by :meth:`PaperclipClient.health`."""

    reachable: bool
    output: str = ""
    exit_code: int = 0
    elapsed_ms: int | None = None

    @property
    def healthy(self) -> bool:
        return self.reachable and self.exit_code == 0
