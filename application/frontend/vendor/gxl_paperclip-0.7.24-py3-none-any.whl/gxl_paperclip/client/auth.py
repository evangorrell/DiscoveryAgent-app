"""Authentication strategies for :class:`PaperclipClient`.

The SDK does not manage interactive OAuth login. Use :class:`APIKeyAuth` for
most programmatic access; :class:`BearerAuth` lets you plug in a token obtained
elsewhere; :class:`FileCredentialsAuth` reuses credentials written by
``paperclip login`` at ``~/.paperclip/credentials.json``.
"""

from __future__ import annotations

import threading
from collections.abc import Callable

from .credentials import Credentials
from .errors import AuthError


class _AuthBase:
    """Shared base so typed methods can accept any strategy."""

    uses_api_key: bool = False

    def apply(self) -> dict[str, str]:  # pragma: no cover - overridden
        raise NotImplementedError


class APIKeyAuth(_AuthBase):
    """Authenticate with a Paperclip API key.

    The key is sent as an ``X-API-Key`` header and, for MCP-routed commands,
    triggers the ``/papers`` path where the API-key middleware runs.
    """

    uses_api_key = True

    def __init__(self, api_key: str) -> None:
        if not api_key or not isinstance(api_key, str):
            raise ValueError("api_key must be a non-empty string")
        self._api_key = api_key

    def apply(self) -> dict[str, str]:
        return {"X-API-Key": self._api_key}


class BearerAuth(_AuthBase):
    """Authenticate with a pre-obtained bearer token.

    ``token`` may be a string or a zero-argument callable returning a string.
    Using a callable lets you refresh the token externally without rebuilding
    the client.
    """

    uses_api_key = False

    def __init__(self, token: str | Callable[[], str]) -> None:
        if not token:
            raise ValueError("token must be a non-empty string or callable")
        self._token = token

    def apply(self) -> dict[str, str]:
        tok = self._token() if callable(self._token) else self._token
        if not tok:
            raise AuthError("BearerAuth token provider returned an empty token")
        return {"Authorization": f"Bearer {tok}"}


class FileCredentialsAuth(_AuthBase):
    """Authenticate using credentials written by ``paperclip login``.

    Reads ``~/.paperclip/credentials.json`` and transparently refreshes the
    Firebase ID token via the server's ``/api/oauth/token`` endpoint. Raises
    :class:`AuthError` if no credentials exist or refresh fails.
    """

    uses_api_key = False

    def __init__(self, credentials: Credentials | None = None) -> None:
        creds = credentials or Credentials.load()
        if creds is None:
            raise AuthError(
                "No credentials found at ~/.paperclip/credentials.json. "
                "Run `paperclip login` first, or use APIKeyAuth instead."
            )
        self._creds: Credentials = creds
        self._refresh_lock = threading.Lock()

    def apply(self) -> dict[str, str]:
        try:
            token = self._creds.get_id_token()
        except Exception as exc:  # pragma: no cover - runtime network errors
            raise AuthError(f"Could not refresh ID token: {exc}") from exc
        return {"Authorization": f"Bearer {token}"}

    def refresh(self, stale_authorization: str | None = None) -> dict[str, str]:
        """Force one synchronized refresh after the server rejects a token."""
        with self._refresh_lock:
            current = (
                f"Bearer {self._creds.id_token}" if self._creds.id_token else None
            )
            if stale_authorization and current != stale_authorization:
                return {"Authorization": current} if current else self.apply()
            self._creds.id_token_expires_at = 0
            return self.apply()

    def invalidate(self) -> None:
        """Delete the stored credentials (e.g. after a 401).

        Used by the CLI to force an interactive re-login. SDK callers typically
        don't need this.
        """
        Credentials.delete()


AuthStrategy = _AuthBase
