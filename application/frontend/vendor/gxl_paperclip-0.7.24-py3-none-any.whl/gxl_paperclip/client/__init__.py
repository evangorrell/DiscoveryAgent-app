"""Paperclip Python SDK.

Programmatic access to the Paperclip service. Everything you need to script
against Paperclip lives here: the client, auth strategies, typed exceptions,
and result models.
"""

from __future__ import annotations

from .auth import APIKeyAuth, AuthStrategy, BearerAuth, FileCredentialsAuth
from .client import PaperclipClient
from .errors import (
    AuthError,
    NetworkError,
    NotFoundError,
    PaperclipError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
)
from .models import (
    ExecuteResult,
    HealthStatus,
    MapEvent,
    MapProgressEvent,
    MapResultEvent,
    ResultData,
    ResultRow,
)

__all__ = [
    "PaperclipClient",
    # Auth
    "APIKeyAuth",
    "AuthStrategy",
    "BearerAuth",
    "FileCredentialsAuth",
    # Errors
    "AuthError",
    "NetworkError",
    "NotFoundError",
    "PaperclipError",
    "RateLimitError",
    "RequestTimeoutError",
    "ServerError",
    # Models
    "ExecuteResult",
    "HealthStatus",
    "MapEvent",
    "MapProgressEvent",
    "MapResultEvent",
    "ResultData",
    "ResultRow",
]
