"""Credential storage and token refresh.

Stores an OAuth refresh token in ~/.paperclip/credentials.json.

Exchanges it for short-lived ID tokens via the Paperclip server's
``/api/oauth/token`` endpoint (which owns the Firebase relationship).
"""

from __future__ import annotations

import json
import logging
import os
import stat
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import requests

from .. import config

logger = logging.getLogger(__name__)

_TOKEN_REFRESH_MARGIN = 300  # refresh 5 min before expiry


@dataclass
class Credentials:
    refresh_token: str
    email: str = ""
    uid: str = ""
    id_token: str = ""
    id_token_expires_at: float = 0.0
    created_at: str = ""

    # ---- persistence ----

    @classmethod
    def load(cls, path: Path | None = None) -> Credentials | None:
        path = path or config.CREDENTIALS_FILE
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text())
            return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
        except Exception as exc:
            logger.warning("Failed to load credentials: %s", exc)
            return None

    def save(self, path: Path | None = None) -> None:
        path = path or config.CREDENTIALS_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2) + "\n")
        try:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            logger.warning(
                "Could not restrict permissions on %s — "
                "credentials file may be readable by other users",
                path,
            )

    @classmethod
    def delete(cls, path: Path | None = None) -> bool:
        path = path or config.CREDENTIALS_FILE
        if path.exists():
            path.unlink()
            return True
        return False

    # ---- token refresh ----

    @property
    def id_token_valid(self) -> bool:
        return bool(self.id_token) and time.time() < (
            self.id_token_expires_at - _TOKEN_REFRESH_MARGIN
        )

    def get_id_token(self) -> str:
        """Return a valid ID token, refreshing via the server if needed."""
        if self.id_token_valid:
            return self.id_token

        base_url = config.get_base_url()
        try:
            resp = requests.post(
                f"{base_url}/api/oauth/token",
                json={
                    "grant_type": "refresh_token",
                    "refresh_token": self.refresh_token,
                },
                timeout=15,
            )
        except requests.RequestException as err:
            raise RuntimeError("Could not reach the server. Please try again.") from err
        if resp.status_code != 200:
            raise RuntimeError("Token refresh failed. Try logging in again: paperclip login")
        body = resp.json()

        self.id_token = body["id_token"]
        self.id_token_expires_at = time.time() + int(body.get("expires_in", 3600))
        if body.get("refresh_token"):
            self.refresh_token = body["refresh_token"]

        self.save()
        return self.id_token
