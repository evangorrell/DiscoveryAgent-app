"""Deterministic pre-render QA for Paperclip meta-analysis artifacts."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any

from .analysis_contracts import validate_analysis
from .compile_verified import (
    CHARACTERISTIC_FIELDS,
    QUALITY_FIELDS,
    load_schema,
    missing_fields,
    validate_effect,
)


def load_json(path: Path) -> Any:
    if not path.exists():
        raise ValueError(f"missing required artifact: {path.name}")
    return json.loads(path.read_text())


def require_rows(path: Path) -> list[dict[str, Any]]:
    data = load_json(path)
    if not isinstance(data, list) or not all(isinstance(row, dict) for row in data):
        raise ValueError(f"{path.name} must be a JSON array of objects")
    return data


def run_checks(directory: Path, schema_path: Path) -> dict[str, Any]:
    criticals: list[str] = []
    warnings: list[str] = []
    try:
        effects = require_rows(directory / "effects.json")
        contexts = require_rows(directory / "contexts.json")
        characteristics = require_rows(directory / "study_characteristics.json")
        quality = require_rows(directory / "quality_assessments.json")
        analysis = load_json(directory / "analysis.json")
        search_log = load_json(directory / "search_log.json")
        audit = load_json(directory / "extraction_audit.json")
        protocol = load_json(directory / "protocol.json")
        synthesis = load_json(directory / "synthesis.json")
        prisma = load_json(directory / "prisma_checklist.json")
        schema = load_schema(schema_path)
    except (ValueError, json.JSONDecodeError) as exc:
        return {"status": "fail", "criticals": [str(exc)], "warnings": []}

    effect_ids: list[str] = []
    effect_docs: set[str] = set()
    for index, effect in enumerate(effects):
        errors = validate_effect(effect, schema)
        if errors:
            criticals.append(f"effects[{index}]: {'; '.join(errors)}")
        if not effect.get("paperclip_doc_id") or not effect.get("paperclip_lines"):
            criticals.append(f"effects[{index}]: missing doc ID or line pin")
        if effect.get("verified") is not True:
            criticals.append(f"effects[{index}]: not marked verified")
        effect_ids.append(str(effect.get("effect_id") or ""))
        effect_docs.add(str(effect.get("paperclip_doc_id") or ""))

        lo, estimate, hi = (
            effect.get("ci_lower"),
            effect.get("effect_size"),
            effect.get("ci_upper"),
        )
        if lo is not None and estimate is not None and hi is not None:
            half_left = float(estimate) - float(lo)
            half_right = float(hi) - float(estimate)
            if math.isclose(half_left, half_right, rel_tol=0, abs_tol=1e-10) and math.isclose(
                half_left * 100, round(half_left * 100), abs_tol=1e-10
            ):
                warnings.append(f"{effect.get('effect_id')}: suspicious round symmetric CI")

    duplicates = [key for key, count in Counter(effect_ids).items() if key and count > 1]
    if duplicates:
        criticals.append(f"duplicate effect_id values: {duplicates[:20]}")

    context_docs = {str(row.get("paperclip_doc_id") or "") for row in contexts}
    characteristic_docs = {str(row.get("paperclip_doc_id") or "") for row in characteristics}
    quality_docs = {str(row.get("paperclip_doc_id") or "") for row in quality}
    for label, rows in (
        ("context", contexts),
        ("study characteristics", characteristics),
        ("quality assessment", quality),
    ):
        counts = Counter(str(row.get("paperclip_doc_id") or "") for row in rows)
        duplicate_docs = [doc for doc, count in counts.items() if doc and count > 1]
        if duplicate_docs:
            criticals.append(f"duplicate {label} rows for papers: {duplicate_docs[:20]}")
    for label, docs in (
        ("context", context_docs),
        ("study characteristics", characteristic_docs),
        ("quality assessment", quality_docs),
    ):
        missing = sorted(effect_docs - docs)
        if missing:
            criticals.append(f"{label} missing for effect-bearing papers: {missing[:20]}")
    for index, assessment in enumerate(quality):
        missing = missing_fields(assessment, QUALITY_FIELDS)
        if missing:
            criticals.append(f"quality_assessments[{index}] missing fields {missing}")
    for index, study in enumerate(characteristics):
        missing = missing_fields(study, CHARACTERISTIC_FIELDS)
        if missing:
            criticals.append(f"study_characteristics[{index}] missing fields {missing}")

    if not isinstance(analysis, dict):
        criticals.append("analysis.json must be an object")
        analysis = {}
    contract = validate_analysis(analysis, effects)
    criticals.extend(f"analysis contract: {error}" for error in contract.errors)
    groups: list[Any]
    if contract.analysis_type == "pairwise":
        raw_groups = analysis.get("outcome_groups")
        if isinstance(raw_groups, list):
            groups = raw_groups
        else:
            criticals.append("analysis.outcome_groups must be an array")
            groups = []
    else:
        groups = []
    selected_ids: list[str] = []
    seen_units: set[tuple[str, str]] = set()
    for group in groups:
        name = str(group.get("name") or "")
        studies = group.get("studies") or []
        if not name or not isinstance(studies, list) or not studies:
            criticals.append("outcome group missing name or study rows")
            continue
        pool = group.get("pooled_combined")
        required_pool_fields = (
            "k",
            "pooled_reml",
            "ci_lower_kh",
            "ci_upper_kh",
            "pooled_dl",
            "ci_lower_dl",
            "ci_upper_dl",
            "I_squared",
            "tau_squared_reml",
            "prediction_interval",
        )
        if not isinstance(pool, dict) or any(
            pool.get(field) is None for field in required_pool_fields
        ):
            criticals.append(f"{name}: pooled_combined is incomplete")
        elif pool.get("k") != len(studies):
            criticals.append(f"{name}: pooled k does not match study rows")
        elif not (
            float(pool["ci_lower_kh"]) <= float(pool["pooled_reml"]) <= float(pool["ci_upper_kh"])
        ):
            criticals.append(f"{name}: pooled REML estimate lies outside KH CI")
        if len(studies) >= 3 and len(group.get("leave_one_out") or []) != len(studies):
            criticals.append(f"{name}: leave-one-out result count mismatch")
        if len(studies) >= 10 and not isinstance(group.get("egger_test"), dict):
            criticals.append(f"{name}: Egger assessment missing for k>=10")
        for study in studies:
            effect_id = str(study.get("effect_id") or "")
            selected_ids.append(effect_id)
            unit = str(study.get("independent_unit_id") or "")
            key = (name, unit)
            if unit and key in seen_units:
                criticals.append(f"{name}: duplicate independent_unit_id in primary model: {unit}")
            seen_units.add(key)
            if effect_id not in effect_ids:
                criticals.append(f"{name}: unknown selected effect_id {effect_id}")
        grade = group.get("grade") or {}
        if grade.get("reviewed") is not True or not isinstance(
            grade.get("domain_rationales"), dict
        ):
            criticals.append(f"{name}: preliminary GRADE was not reviewed with domain rationales")
    if contract.analysis_type != "pairwise":
        selected_ids = list(contract.selected_effect_ids)

    compiled = len(effects)
    selected = len(selected_ids)
    if analysis.get("n_effects_extracted") != compiled:
        criticals.append("analysis.n_effects_extracted must equal compiled effects")
    if analysis.get("n_effects_compiled_verified") != compiled:
        criticals.append("analysis.n_effects_compiled_verified must equal compiled effects")
    if analysis.get("n_effects_selected_primary_pooling") != selected:
        criticals.append("analysis primary selection count does not match study rows")
    selection = analysis.get("selection_accounting") or {}
    accounted = sum(
        int(selection.get(field, 0) or 0)
        for field in (
            "effects_selected_primary_pooling",
            "effects_secondary_or_sensitivity",
            "effects_excluded_explicit",
            "effects_excluded_missing_variance",
        )
    )
    if accounted != compiled:
        criticals.append(f"analysis selection accounting {accounted} != {compiled}")

    flow = search_log.get("evidence_flow") if isinstance(search_log, dict) else None
    if not isinstance(flow, dict):
        criticals.append("search_log.evidence_flow is missing")
    else:
        prisma_fields = (
            "records_found_total",
            "records_deduplicated",
            "papers_screened_title_abstract",
            "papers_screened_full_text",
            "papers_full_text_excluded",
            "papers_included",
            "raw_numeric_candidates_inspected",
        )
        missing_flow = [field for field in prisma_fields if field not in flow]
        if missing_flow:
            criticals.append("evidence flow missing canonical fields: " + ", ".join(missing_flow))
        else:
            found = int(flow["records_found_total"])
            deduplicated = int(flow["records_deduplicated"])
            screened = int(flow["papers_screened_title_abstract"])
            full_text = int(flow["papers_screened_full_text"])
            full_text_excluded = int(flow["papers_full_text_excluded"])
            included = int(flow["papers_included"])
            if not (found >= deduplicated >= screened >= full_text >= included >= 0):
                criticals.append("evidence flow PRISMA counts are not monotonic")
            if full_text_excluded + included > full_text:
                criticals.append("evidence flow full-text excluded + included exceeds assessed")
        submitted = int(flow.get("effect_claims_submitted_total", -1))
        removed = int(flow.get("effect_claims_removed", -1))
        active = int(flow.get("effect_claims_active", -1))
        ok = int(flow.get("effect_claims_ok", -1))
        failed = int(flow.get("effect_claims_x", -1))
        pending = int(flow.get("effect_claims_pending", -1))
        if submitted != active + removed:
            criticals.append("evidence flow: submitted != active + removed")
        if active != ok + failed + pending:
            criticals.append("evidence flow: active != OK + X + pending")
        if pending != 0 or failed != 0:
            criticals.append("evidence flow has active [?] or [X] claims")
        if int(flow.get("effects_compiled", -1)) != compiled:
            criticals.append("evidence flow compiled count mismatch")
        if int(flow.get("effects_selected_primary_pooling", -1)) != selected:
            criticals.append("evidence flow primary selection count mismatch")
        if int(flow.get("effects_secondary_or_sensitivity", -1)) != int(
            selection.get("effects_secondary_or_sensitivity", 0) or 0
        ):
            criticals.append("evidence flow secondary selection count mismatch")
        excluded_expected = int(selection.get("effects_excluded_explicit", 0) or 0) + int(
            selection.get("effects_excluded_missing_variance", 0) or 0
        )
        if int(flow.get("effects_excluded_from_pooling", -1)) != excluded_expected:
            criticals.append("evidence flow excluded selection count mismatch")

    if not isinstance(audit, dict):
        criticals.append("extraction_audit.json must be an object")
    else:
        rate = audit.get("concordance_rate")
        if not isinstance(rate, (int, float)) or float(rate) < 0.90:
            criticals.append("dual-extraction concordance is missing or below 90%")
        ci_check = audit.get("ci_integrity_check")
        if not isinstance(ci_check, dict):
            criticals.append("CI integrity check result is missing")
        elif int(ci_check.get("flagged", 0)) != int(ci_check.get("corrected", 0)) + int(
            ci_check.get("set_to_null", 0)
        ) + int(ci_check.get("source_verified", 0)):
            criticals.append("CI integrity review candidates are unresolved")

    if not isinstance(protocol, dict) or not all(
        protocol.get(field)
        for field in ("eligibility", "outcome_selection_rules", "dependency_rules")
    ):
        criticals.append("protocol missing eligibility/outcome_selection_rules/dependency_rules")
    if not isinstance(search_log, dict) or not search_log.get("queries"):
        criticals.append("search log contains no reproducible queries")
    elif any(
        not isinstance(query, dict)
        or not all(
            query.get(field) is not None
            for field in ("source", "query", "wave", "reason", "records_found")
        )
        for query in search_log["queries"]
    ):
        criticals.append("search queries require source/query/wave/reason/records_found")
    if not isinstance(search_log, dict) or not search_log.get("saturation_rounds"):
        criticals.append("search log contains no saturation assessment")
    if not isinstance(synthesis, dict) or synthesis.get("format") != "manuscript":
        criticals.append("synthesis.json is not the canonical manuscript shape")
    elif (
        not isinstance(synthesis.get("abstract"), dict)
        or not all(
            synthesis["abstract"].get(field)
            for field in ("background", "methods", "results", "conclusions")
        )
        or not isinstance(synthesis.get("introduction"), list)
        or not synthesis["introduction"]
        or not isinstance(synthesis.get("methods"), list)
        or not synthesis["methods"]
        or not isinstance(synthesis.get("results"), dict)
        or not isinstance(synthesis["results"].get("sections"), list)
        or not synthesis["results"]["sections"]
        or not isinstance(synthesis.get("discussion"), dict)
        or not isinstance(synthesis["discussion"].get("sections"), list)
        or not synthesis["discussion"]["sections"]
        or not isinstance(synthesis.get("conclusions"), str)
        or not synthesis["conclusions"].strip()
        or not isinstance(synthesis.get("key_findings"), list)
        or not synthesis["key_findings"]
        or not isinstance(synthesis.get("references"), list)
        or not synthesis["references"]
    ):
        criticals.append("synthesis.json manuscript sections have invalid shapes")
    else:
        reference_docs = {
            str(reference.get("doc_id") or "")
            for reference in synthesis["references"]
            if isinstance(reference, dict)
        }
        missing_references = sorted(effect_docs - reference_docs)
        if missing_references:
            criticals.append(
                f"synthesis references missing effect papers: {missing_references[:20]}"
            )
    if not isinstance(prisma, dict) or not prisma:
        criticals.append("prisma_checklist.json is empty or malformed")
    else:
        prisma_items = prisma.get("items")
        if not isinstance(prisma_items, list) or len(prisma_items) < 27:
            criticals.append("PRISMA checklist does not contain all 27 items")
        elif any(
            not isinstance(item, dict)
            or item.get("status") not in {"addressed", "not_applicable"}
            or (item.get("status") == "not_applicable" and not item.get("note"))
            for item in prisma_items
        ):
            criticals.append("PRISMA checklist has missing/invalid item statuses")

    result = {
        "status": "fail" if criticals else "pass",
        "criticals": criticals,
        "warnings": warnings,
        "counts": {
            "effects_compiled": compiled,
            "effects_selected_primary_pooling": selected,
            "effect_bearing_papers": len(effect_docs),
            "outcome_groups": len(groups),
        },
    }
    state_path = directory / "analysis_project.json"
    if state_path.is_file() and (
        (directory / "analysis").is_dir() or (directory / "analysis.json").is_file()
    ):
        try:
            from gxl_paperclip.analysis_project import (
                AnalysisProjectStore,
                validate_current_execution,
            )

            execution = validate_current_execution(AnalysisProjectStore().load(directory))
        except Exception as exc:  # noqa: BLE001 - convert state/runtime errors into QA output
            result["criticals"].append(f"managed analysis execution: {exc}")
        else:
            result["analysis_execution_sha256"] = execution["execution_sha256"]
            result["analysis_sha256"] = execution["analysis_sha256"]
            result["criticals"].extend(
                f"managed analysis execution: {error}" for error in execution["errors"]
            )
        result["status"] = "fail" if result["criticals"] else "pass"
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", nargs="?", default=".")
    parser.add_argument("--schema", default="effect.schema.json")
    args = parser.parse_args(argv)
    directory = Path(args.directory)
    result = run_checks(directory, Path(args.schema))
    (directory / "data_qa.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
