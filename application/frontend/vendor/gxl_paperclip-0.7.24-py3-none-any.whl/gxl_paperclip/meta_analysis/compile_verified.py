"""Compile a verified Paperclip repo into validated meta-analysis artifacts."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

from gxl_paperclip.cli import repo
from gxl_paperclip.cli.claim_ids import stable_claim_id
from gxl_paperclip.meta_analysis.precision import (
    PRECISION_ABS_TOLERANCE,
    PRECISION_REL_TOLERANCE,
    PrecisionDerivationError,
    derive_precision,
)

CHARACTERISTIC_FIELDS = (
    "study_id",
    "title",
    "year",
    "study_design",
    "population",
    "intervention",
    "comparator",
    "outcomes_reported",
)
QUALITY_FIELDS = ("tool", "domains", "overall", "rationale")
ARM_COUNT_FIELDS = (
    ("arm_1_events", "arm_1_denominator", "arm_1_n"),
    ("arm_2_events", "arm_2_denominator", "arm_2_n"),
)


def missing_fields(value: dict[str, Any], fields: tuple[str, ...]) -> list[str]:
    return [
        field
        for field in fields
        if field not in value
        or value[field] is None
        or value[field] == ""
        or value[field] == []
        or value[field] == {}
    ]


def load_schema(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ValueError(f"effect schema not found: {path}")
    schema = json.loads(path.read_text())
    if not isinstance(schema, dict):
        raise ValueError("effect schema must be a JSON object")
    return schema


def validate_effect(claim: dict[str, Any], schema: dict[str, Any]) -> list[str]:
    errors = [f"missing {field!r}" for field in schema.get("required", []) if field not in claim]
    for field, rules in schema.get("properties", {}).items():
        if field not in claim or not isinstance(rules, dict):
            continue
        value = claim[field]
        if "const" in rules and value != rules["const"]:
            errors.append(f"{field} must equal {rules['const']!r}")
        if "enum" in rules and value not in rules["enum"]:
            errors.append(f"{field} must be one of {rules['enum']!r}")
        allowed = rules.get("type")
        allowed = [allowed] if isinstance(allowed, str) else (allowed or [])
        validators = {
            "string": lambda x: isinstance(x, str),
            "number": lambda x: isinstance(x, (int, float))
            and not isinstance(x, bool)
            and math.isfinite(float(x)),
            "integer": lambda x: isinstance(x, int) and not isinstance(x, bool),
            "object": lambda x: isinstance(x, dict),
            "array": lambda x: isinstance(x, list),
            "boolean": lambda x: isinstance(x, bool),
            "null": lambda x: x is None,
        }
        if allowed and not any(validators.get(kind, lambda _x: False)(value) for kind in allowed):
            errors.append(f"{field} has invalid type")
        if rules.get("minLength") and isinstance(value, str) and not value.strip():
            errors.append(f"{field} must be non-empty")

    lo, estimate, hi = (
        claim.get("ci_lower"),
        claim.get("effect_size"),
        claim.get("ci_upper"),
    )
    if lo is not None and estimate is not None and hi is not None:
        if float(lo) >= float(hi):
            errors.append("ci_lower must be less than ci_upper")
        if not float(lo) <= float(estimate) <= float(hi):
            errors.append("CI does not contain effect_size")
    errors.extend(_validate_estimand_and_arm_counts(claim))
    errors.extend(_validate_precision_provenance(claim))
    return errors


def _is_integer(value: object) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
        and float(value).is_integer()
    )


def _validate_estimand_and_arm_counts(claim: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if claim.get("estimand_type") == "within_arm" and claim.get("comparative_effect") is True:
        errors.append("comparative_effect cannot be true when estimand_type is 'within_arm'")

    for events_field, denominator_field, arm_n_field in ARM_COUNT_FIELDS:
        events_present = claim.get(events_field) is not None
        denominator_present = claim.get(denominator_field) is not None
        if events_present and not denominator_present:
            errors.append(f"{denominator_field} is required when {events_field} is supplied")
        events: Any = claim.get(events_field)
        denominator: Any = claim.get(denominator_field)
        if events_present and (not _is_integer(events) or float(events) < 0):
            errors.append(f"{events_field} must be a non-negative integer")
        if denominator_present and (not _is_integer(denominator) or float(denominator) <= 0):
            errors.append(f"{denominator_field} must be a positive integer")
        if (
            events_present
            and denominator_present
            and _is_integer(events)
            and _is_integer(denominator)
            and float(events) > float(denominator)
        ):
            errors.append(f"{events_field} cannot exceed {denominator_field}")
        arm_n: Any = claim.get(arm_n_field)
        if arm_n is not None and (not _is_integer(arm_n) or float(arm_n) <= 0):
            errors.append(f"{arm_n_field} must be a positive integer")
    return errors


def _has_derived_precision(claim: dict[str, Any]) -> bool:
    source = str(claim.get("precision_source") or "").strip().lower()
    return (
        claim.get("variance_estimated") is True
        or "derived" in source
        or isinstance(claim.get("derived_interval"), dict)
    )


def _nonempty(value: object) -> bool:
    return value not in (None, "", [], {})


def _close(left: object, right: object) -> bool:
    return (
        isinstance(left, (int, float))
        and not isinstance(left, bool)
        and isinstance(right, (int, float))
        and not isinstance(right, bool)
        and math.isfinite(float(left))
        and math.isfinite(float(right))
        and math.isclose(
            float(left),
            float(right),
            rel_tol=PRECISION_REL_TOLERANCE,
            abs_tol=PRECISION_ABS_TOLERANCE,
        )
    )


def _validate_precision_provenance(claim: dict[str, Any]) -> list[str]:
    if not _has_derived_precision(claim):
        return []

    errors: list[str] = []
    if claim.get("variance_estimated") is not True:
        errors.append("derived precision requires variance_estimated=true")
    for field in ("variance_method", "variance_formula"):
        if not isinstance(claim.get(field), str) or not str(claim[field]).strip():
            errors.append(f"derived precision requires non-empty {field}")
    if not isinstance(claim.get("variance_inputs"), dict) or not claim["variance_inputs"]:
        errors.append("derived precision requires non-empty variance_inputs")
    if not _nonempty(claim.get("variance_source_lines")):
        errors.append("derived precision requires non-empty variance_source_lines")
    if errors:
        return errors

    try:
        result = derive_precision(claim)
    except PrecisionDerivationError as exc:
        return [f"derived precision cannot be recomputed: {exc}"]

    expected_formula = result["provenance"]["variance_formula"]
    if claim["variance_formula"].strip() != expected_formula:
        errors.append("variance_formula does not match the selected variance_method")
    if not _close(claim.get("effect_size"), result["value"]):
        errors.append("derived effect_size does not match recomputed value")

    claimed_se = claim.get("se")
    interval = claim.get("derived_interval")
    has_claimed_precision = claimed_se is not None or isinstance(interval, dict)
    if not has_claimed_precision:
        errors.append("derived precision must include se or derived_interval")
    if claimed_se is not None and not _close(claimed_se, result["se"]):
        errors.append("derived se does not match recomputed value")

    expected_interval = result["interval"]
    if isinstance(interval, dict):
        for key in ("lower", "upper"):
            if not _close(interval.get(key), expected_interval[key]):
                errors.append(f"derived_interval.{key} does not match recomputed value")
        confidence = interval.get("confidence_level")
        if confidence is not None and not _close(confidence, expected_interval["confidence_level"]):
            errors.append("derived_interval.confidence_level must be 0.95")

    if claimed_se is not None and claim.get("ci_lower") is not None:
        if not _close(claim["ci_lower"], expected_interval["lower"]):
            errors.append("derived ci_lower does not match recomputed value")
    if claimed_se is not None and claim.get("ci_upper") is not None:
        if not _close(claim["ci_upper"], expected_interval["upper"]):
            errors.append("derived ci_upper does not match recomputed value")

    inputs = claim.get("variance_inputs")
    if isinstance(inputs, dict):
        for field, value in inputs.items():
            if field in claim and claim[field] is not None and claim[field] != value:
                errors.append(f"variance_inputs.{field} conflicts with top-level {field}")
    return errors


def parse_claim(note: str) -> dict[str, Any]:
    if "{" not in note:
        raise ValueError("claim is not structured JSON")
    parsed = json.loads(note[note.index("{") :])
    if not isinstance(parsed, dict):
        raise ValueError("claim JSON is not an object")
    return parsed


def uniquify_effect_id(
    effect_id: str,
    doc_id: str,
    claim_id: str,
    seen: set[str],
) -> tuple[str, str | None]:
    """Return a unique effect_id, renaming on collision instead of failing compile.

    Prefer ``{doc_id}#…`` namespacing, then a stable ``__{claim_id}`` suffix.
    """
    original = effect_id
    if not original or original not in seen:
        return original, None

    candidate = original
    if not candidate.startswith(f"{doc_id}#"):
        candidate = f"{doc_id}#{candidate}"
        if candidate not in seen:
            return candidate, f"renamed duplicate effect_id {original!r} -> {candidate!r}"

    suffix = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in claim_id)[-32:]
    suffix = suffix or "dup"
    base = candidate
    candidate = f"{base}__{suffix}"
    index = 2
    while candidate in seen:
        candidate = f"{base}__{suffix}_{index}"
        index += 1
    return candidate, f"renamed duplicate effect_id {original!r} -> {candidate!r}"


def compile_repo(
    status: dict[str, Any],
    verification: dict[str, Any],
    schema: dict[str, Any],
) -> tuple[dict[str, list[dict]], list[str], list[str]]:
    artifacts: dict[str, list[dict]] = {
        "effects.json": [],
        "contexts.json": [],
        "study_characteristics.json": [],
        "quality_assessments.json": [],
    }
    errors: list[str] = []
    repairs: list[str] = []
    effect_ids: set[str] = set()

    for doc_id, paper in status.get("papers", {}).items():
        annotations = paper.get("annotations") or []
        if not annotations and paper.get("note"):
            annotations = [{"note": paper["note"], "lines": None}]
        raw = verification.get(doc_id) or []
        verdicts = [raw] if isinstance(raw, dict) else raw
        verdicts = [v for v in verdicts if isinstance(v, dict)]
        by_id = {str(v["claim_id"]): v for v in verdicts if v.get("claim_id")}
        paper_has_effect = False
        paper_has_context = False
        paper_context_count = 0

        for index, annotation in enumerate(annotations):
            note = str(annotation.get("note") or "")
            claim_id = stable_claim_id(doc_id, note, annotation)
            verdict = by_id.get(claim_id)
            if verdict is None and index < len(verdicts):
                candidate = verdicts[index]
                if candidate.get("claim") == note:
                    verdict = candidate
            if verdict is None or verdict.get("supported") is None:
                errors.append(f"{doc_id} {claim_id}: claim is unverified [?]")
                continue
            if verdict.get("supported") is not True:
                errors.append(f"{doc_id} {claim_id}: active claim failed [X]")
                continue

            try:
                claim = parse_claim(note)
            except (ValueError, json.JSONDecodeError) as exc:
                errors.append(f"{doc_id} {claim_id}: {exc}")
                continue
            claim.update(
                {
                    "paperclip_doc_id": doc_id,
                    "paperclip_lines": annotation.get("lines"),
                    "claim_id": claim_id,
                    "verified": True,
                }
            )

            if claim.get("type") == "effect":
                paper_has_effect = True
                effect_id = str(claim.get("effect_id") or "")
                unique_id, repair = uniquify_effect_id(effect_id, doc_id, claim_id, effect_ids)
                if repair:
                    claim["effect_id_original"] = effect_id
                    claim["effect_id"] = unique_id
                    repairs.append(f"{doc_id}: {repair}")
                claim_errors = validate_effect(claim, schema)
                if not claim.get("paperclip_lines"):
                    claim_errors.append("missing paperclip_lines")
                if claim_errors:
                    errors.append(
                        f"{doc_id} {unique_id or effect_id or claim_id}: " + "; ".join(claim_errors)
                    )
                else:
                    effect_ids.add(str(claim["effect_id"]))
                    artifacts["effects.json"].append(claim)
            elif claim.get("type") == "context":
                paper_has_context = True
                paper_context_count += 1
                if not claim.get("paperclip_lines"):
                    errors.append(f"{doc_id}: context claim missing paperclip_lines")
                artifacts["contexts.json"].append(claim)
                for key, filename in (
                    ("study_characteristics", "study_characteristics.json"),
                    ("quality_assessment", "quality_assessments.json"),
                ):
                    value = claim.get(key)
                    if isinstance(value, dict):
                        required = (
                            CHARACTERISTIC_FIELDS
                            if key == "study_characteristics"
                            else QUALITY_FIELDS
                        )
                        missing = missing_fields(value, required)
                        if missing:
                            errors.append(f"{doc_id}: {key} missing fields {missing}")
                        artifacts[filename].append({"paperclip_doc_id": doc_id, **value})
                    else:
                        errors.append(f"{doc_id}: context missing {key} object")
            else:
                errors.append(f"{doc_id} {claim_id}: unknown claim type {claim.get('type')!r}")
        if paper_has_effect and not paper_has_context:
            errors.append(f"{doc_id}: effect-bearing paper has no context claim")
        if paper_context_count > 1:
            errors.append(f"{doc_id}: expected one context claim, found {paper_context_count}")
    return artifacts, errors, repairs


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default=".")
    parser.add_argument("--schema", default="effect.schema.json")
    args = parser.parse_args(argv)
    schema = load_schema(Path(args.schema))
    verification = repo.load_server_verification() or repo.load_verification() or {}
    artifacts, errors, repairs = compile_repo(repo.get_status(), verification, schema)
    if errors:
        print(f"FAIL: {len(errors)} problem(s):", file=sys.stderr)
        for error in errors[:100]:
            print(f"  - {error}", file=sys.stderr)
        return 1
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for filename, rows in artifacts.items():
        (output / filename).write_text(json.dumps(rows, indent=2) + "\n")
        print(f"Wrote {filename}: {len(rows)} records")
    if repairs:
        print(f"Repaired {len(repairs)} duplicate effect_id(s):")
        for repair in repairs[:100]:
            print(f"  - {repair}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
