"""Export every source-verified structured claim without imposing an analysis shape."""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import uuid
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from gxl_paperclip.cli import repo
from gxl_paperclip.cli.claim_ids import stable_claim_id
from gxl_paperclip.meta_analysis.cards import (
    CARD_MODEL_VERSION,
    CARD_TYPES,
    canonical_card_type,
    card_model_metadata,
    dynamic_record_type,
    normalize_finding_card,
    validate_card_payload,
)

VERIFIED_FINDINGS_SCHEMA_VERSION = 1
VERIFIED_FINDINGS_FILENAME = "verified_findings.json"
GENERATOR = "gxl_paperclip.meta_analysis.export_verified"


def _parse_payload(note: str) -> dict[str, Any]:
    if "{" not in note:
        raise ValueError("claim is not structured JSON")
    try:
        payload = json.loads(note[note.index("{") :])
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"claim JSON is invalid: {exc.msg} (line {exc.lineno}, column {exc.colno})"
        ) from exc
    if not isinstance(payload, dict):
        raise ValueError("claim JSON must be an object")
    return payload


def _verdicts(value: object) -> list[Mapping[str, Any]]:
    if isinstance(value, Mapping):
        return [value]
    if isinstance(value, list):
        return [item for item in value if isinstance(item, Mapping)]
    return []


def _matching_verdict(
    doc_id: str,
    note: str,
    annotation: Mapping[str, Any],
    index: int,
    verification: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    verdicts = _verdicts(verification.get(doc_id))
    claim_id = stable_claim_id(doc_id, note, dict(annotation))
    for verdict in verdicts:
        if str(verdict.get("claim_id") or "") == claim_id:
            return verdict
    if index < len(verdicts) and verdicts[index].get("claim") == note:
        return verdicts[index]
    return None


def _nonempty(value: object) -> bool:
    return value not in (None, "", [], {})


def _line_locations(
    paper_id: str,
    annotation: Mapping[str, Any],
    verdict: Mapping[str, Any],
    payload: Mapping[str, Any],
) -> list[dict[str, Any]]:
    locations: list[dict[str, Any]] = []
    seen: set[str] = set()

    def add(origin: str, value: object) -> None:
        if not _nonempty(value):
            return
        marker = json.dumps([origin, value], sort_keys=True, default=str)
        if marker in seen:
            return
        seen.add(marker)
        locations.append({"paper_id": paper_id, "origin": origin, "lines": value})

    add("annotation.lines", annotation.get("lines"))
    add("annotation.source_locations", annotation.get("source_locations"))
    add("verification.lines", verdict.get("lines"))
    add("verification.source_locations", verdict.get("source_locations"))

    def walk(value: object, path: str) -> None:
        if isinstance(value, Mapping):
            for key, item in value.items():
                child = f"{path}.{key}" if path else str(key)
                normalized = str(key).casefold()
                if "line" in normalized or normalized in {
                    "source_location",
                    "source_locations",
                }:
                    add(f"raw_payload.{child}", item)
                walk(item, child)
        elif isinstance(value, list):
            for item_index, item in enumerate(value):
                walk(item, f"{path}.{item_index}")

    walk(payload, "")
    return locations


def _explicit_metadata(payload: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): value
        for key, value in payload.items()
        if any(token in str(key).casefold() for token in ("relationship", "missing", "ambigu"))
    }


def _finite_numbers(value: object, path: str = "raw_payload") -> list[str]:
    errors: list[str] = []
    if isinstance(value, bool) or value is None:
        return errors
    if isinstance(value, (int, float)):
        if not math.isfinite(float(value)):
            errors.append(f"{path} must contain only finite numeric values")
    elif isinstance(value, Mapping):
        for key, item in value.items():
            errors.extend(_finite_numbers(item, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            errors.extend(_finite_numbers(item, f"{path}[{index}]"))
    return errors


def _numeric(value: object) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
    )


def _ci_errors(value: object, path: str = "raw_payload") -> list[str]:
    errors: list[str] = []
    if isinstance(value, Mapping):
        pairs: list[tuple[str, str]] = []
        if "ci_lower" in value and "ci_upper" in value:
            pairs.append(("ci_lower", "ci_upper"))
        if (
            "lower" in value
            and "upper" in value
            and any(token in path.casefold() for token in ("ci", "confidence", "interval"))
        ):
            pairs.append(("lower", "upper"))
        for lower_key, upper_key in pairs:
            lower, upper = value.get(lower_key), value.get(upper_key)
            if lower is None or upper is None:
                continue
            if _numeric(lower) and _numeric(upper) and float(lower) >= float(upper):
                errors.append(f"{path}.{lower_key} must be less than {path}.{upper_key}")
        for key, item in value.items():
            errors.extend(_ci_errors(item, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            errors.extend(_ci_errors(item, f"{path}[{index}]"))
    return errors


def _event_denominator_errors(
    value: object,
    path: str = "raw_payload",
) -> list[str]:
    errors: list[str] = []
    if isinstance(value, Mapping):
        for key, events in value.items():
            normalized = str(key).casefold()
            if normalized == "events":
                denominator_keys = ("denominator", "sample_size", "n")
            elif normalized.endswith("_events"):
                prefix = str(key)[: -len("_events")]
                denominator_keys = (
                    f"{prefix}_denominator",
                    f"{prefix}_sample_size",
                    f"{prefix}_n",
                )
            else:
                continue
            denominator = next(
                (value[name] for name in denominator_keys if name in value),
                None,
            )
            if (
                denominator is not None
                and _numeric(events)
                and _numeric(denominator)
                and float(events) > float(denominator)
            ):
                errors.append(f"{path}.{key} cannot exceed its explicit denominator")
        for key, item in value.items():
            errors.extend(_event_denominator_errors(item, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            errors.extend(_event_denominator_errors(item, f"{path}[{index}]"))
    return errors


def validate_finding(finding: Mapping[str, Any]) -> list[str]:
    """Apply only universal integrity checks to one exported finding."""
    normalized = normalize_finding_card(finding)
    errors: list[str] = []
    for key in (
        "finding_id",
        "claim_id",
        "card_type",
        "record_type",
        "paper_id",
        "verified_status",
    ):
        if not isinstance(normalized.get(key), str) or not str(normalized[key]).strip():
            errors.append(f"{key} must be a non-empty string")
    if normalized.get("card_type") not in CARD_TYPES:
        errors.append("card_type must identify a universal guided card type")
    if normalized.get("finding_id") != normalized.get("claim_id"):
        errors.append("finding_id and claim_id must identify the same stable claim")
    if normalized.get("verified_status") != "verified":
        errors.append("verified_status must equal 'verified'")
    locations = normalized.get("source_locations")
    if not isinstance(locations, list) or not locations:
        errors.append("source_locations must contain at least one source line/location")
    elif not all(
        isinstance(item, Mapping)
        and item.get("paper_id") == normalized.get("paper_id")
        and _nonempty(item.get("lines"))
        for item in locations
    ):
        errors.append("every source location must contain matching paper_id and lines")
    payload = normalized.get("raw_payload")
    if not isinstance(payload, Mapping):
        errors.append("raw_payload must be an object")
        return errors
    errors.extend(validate_card_payload(payload, str(normalized.get("card_type"))))
    errors.extend(_finite_numbers(payload))
    errors.extend(_ci_errors(payload))
    errors.extend(_event_denominator_errors(payload))
    return errors


def normalize_verified_findings(value: object) -> object:
    """Return an import-compatible envelope with canonical broad card types."""
    if not isinstance(value, Mapping):
        return value
    normalized = dict(value)
    findings = value.get("findings")
    if isinstance(findings, list):
        normalized["findings"] = [
            normalize_finding_card(finding) if isinstance(finding, Mapping) else finding
            for finding in findings
        ]
    normalized.setdefault("card_model", card_model_metadata())
    return normalized


def validate_verified_findings(value: object) -> list[str]:
    """Validate a complete flexible verified-findings artifact."""
    if not isinstance(value, Mapping):
        return ["verified_findings.json must contain an object"]
    normalized = normalize_verified_findings(value)
    assert isinstance(normalized, Mapping)
    errors: list[str] = []
    if normalized.get("schema_version") != VERIFIED_FINDINGS_SCHEMA_VERSION:
        errors.append(f"schema_version must equal {VERIFIED_FINDINGS_SCHEMA_VERSION}")
    if normalized.get("generator") != GENERATOR:
        errors.append("generator does not identify the universal verified exporter")
    card_model = normalized.get("card_model")
    if not isinstance(card_model, Mapping):
        errors.append("card_model must describe the universal card envelope")
    else:
        if card_model.get("version") != CARD_MODEL_VERSION:
            errors.append(f"card_model.version must equal {CARD_MODEL_VERSION}")
        declared_types = card_model.get("card_types")
        if (
            not isinstance(declared_types, list)
            or not all(isinstance(item, str) for item in declared_types)
            or set(declared_types) != set(CARD_TYPES)
        ):
            errors.append("card_model.card_types must contain every universal card type")
    findings = normalized.get("findings")
    if not isinstance(findings, list) or not all(
        isinstance(finding, Mapping) for finding in findings
    ):
        errors.append("findings must be an array of objects")
        return errors
    seen: set[str] = set()
    for index, finding in enumerate(findings):
        identifier = str(finding.get("claim_id") or f"row-{index + 1}")
        for error in validate_finding(finding):
            errors.append(f"{identifier}: {error}")
        if identifier in seen:
            errors.append(f"duplicate claim_id {identifier!r}")
        seen.add(identifier)
    return errors


def export_verified_findings(
    status: Mapping[str, Any],
    verification: Mapping[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    """Build an analysis-agnostic projection of every ``[OK]`` JSON claim."""
    errors: list[str] = []
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()
    papers = status.get("papers")
    if not isinstance(papers, Mapping):
        papers = {}
    for doc_id, paper in papers.items():
        if not isinstance(paper, Mapping):
            continue
        annotations = paper.get("annotations")
        if not isinstance(annotations, list):
            annotations = []
        if not annotations and paper.get("note"):
            annotations = [{"note": paper["note"], "lines": paper.get("lines")}]
        for index, annotation_value in enumerate(annotations):
            if not isinstance(annotation_value, Mapping):
                continue
            note = str(annotation_value.get("note") or "")
            verdict = _matching_verdict(
                str(doc_id),
                note,
                annotation_value,
                index,
                verification,
            )
            if verdict is None or verdict.get("supported") is not True:
                continue
            claim_id = stable_claim_id(str(doc_id), note, dict(annotation_value))
            if claim_id in seen:
                errors.append(f"{doc_id} {claim_id}: duplicate claim_id")
                continue
            seen.add(claim_id)
            try:
                payload = _parse_payload(note)
            except ValueError as exc:
                errors.append(f"{doc_id} {claim_id}: {exc}")
                continue
            locations = _line_locations(
                str(doc_id),
                annotation_value,
                verdict,
                payload,
            )
            card_type = canonical_card_type(payload)
            finding: dict[str, Any] = {
                "finding_id": claim_id,
                "claim_id": claim_id,
                "card_type": card_type,
                "record_type": dynamic_record_type(payload, card_type=card_type),
                "paper_id": str(doc_id),
                "source_locations": locations,
                "verified_status": "verified",
                "raw_payload": payload,
            }
            finding.update(_explicit_metadata(payload))
            finding = normalize_finding_card(finding)
            finding_errors = validate_finding(finding)
            if finding_errors:
                errors.extend(f"{doc_id} {claim_id}: {error}" for error in finding_errors)
            else:
                findings.append(finding)
    card_counts = {
        card_type: sum(finding["card_type"] == card_type for finding in findings)
        for card_type in CARD_TYPES
    }
    legacy_normalizations = {
        legacy_type: sum(finding.get("legacy_card_type") == legacy_type for finding in findings)
        for legacy_type in ("paper_context", "patient_group")
    }
    artifact = {
        "schema_version": VERIFIED_FINDINGS_SCHEMA_VERSION,
        "generator": GENERATOR,
        "card_model": card_model_metadata(),
        "export_metadata": {
            "card_counts": card_counts,
            "legacy_card_type_normalizations": legacy_normalizations,
        },
        "repo": {
            "name": status.get("name") or status.get("repo"),
            "branch": status.get("active_branch"),
        },
        "findings": findings,
    }
    errors.extend(error for error in validate_verified_findings(artifact) if error not in errors)
    return artifact, errors


def _atomic_write(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, ensure_ascii=False, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def write_verified_findings(
    output_dir: Path | str,
    *,
    status: Mapping[str, Any] | None = None,
    verification: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Export current repo verification and atomically write the artifact."""
    current_status = status if status is not None else repo.get_status()
    current_verification = (
        verification
        if verification is not None
        else repo.load_server_verification() or repo.load_verification() or {}
    )
    artifact, errors = export_verified_findings(
        current_status,
        current_verification,
    )
    if errors:
        raise ValueError("; ".join(errors))
    output = Path(output_dir).expanduser().resolve() / VERIFIED_FINDINGS_FILENAME
    _atomic_write(output, artifact)
    return artifact


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default=".")
    args = parser.parse_args(argv)
    try:
        artifact = write_verified_findings(args.output_dir)
    except ValueError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"Wrote {VERIFIED_FINDINGS_FILENAME}: {len(artifact['findings'])} verified findings")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
