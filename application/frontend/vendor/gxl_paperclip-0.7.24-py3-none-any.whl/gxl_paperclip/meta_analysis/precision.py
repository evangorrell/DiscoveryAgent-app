"""Deterministic, provenance-preserving precision derivations.

Only formulas whose required inputs are explicit are supported.  The helpers
never impute a standard deviation, correlation, event count, or continuity
correction.
"""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import Any

CONFIDENCE_LEVEL = 0.95
NORMAL_95_Z = 1.959963984540054
PRECISION_ABS_TOLERANCE = 1e-9
PRECISION_REL_TOLERANCE = 1e-6

RISK_DIFFERENCE_METHOD = "independent_two_proportion_risk_difference"
LOG_RISK_RATIO_METHOD = "independent_log_risk_ratio_no_zero_correction"
MEAN_DIFFERENCE_WELCH_METHOD = "independent_mean_difference_welch"
MEAN_DIFFERENCE_POOLED_METHOD = "independent_mean_difference_pooled"
PAIRED_CHANGE_SD_METHOD = "paired_mean_change_change_sd"
PAIRED_CHANGE_CORRELATION_METHOD = "paired_mean_change_pre_post_correlation"

FORMULAS = {
    RISK_DIFFERENCE_METHOD: ("p1 - p2; variance = p1*(1-p1)/n1 + p2*(1-p2)/n2"),
    LOG_RISK_RATIO_METHOD: ("log((e1/n1)/(e2/n2)); variance = 1/e1 - 1/n1 + 1/e2 - 1/n2"),
    MEAN_DIFFERENCE_WELCH_METHOD: ("mean1 - mean2; variance = sd1^2/n1 + sd2^2/n2"),
    MEAN_DIFFERENCE_POOLED_METHOD: (
        "mean1 - mean2; pooled_variance = "
        "((n1-1)*sd1^2 + (n2-1)*sd2^2)/(n1+n2-2); "
        "variance = pooled_variance*(1/n1 + 1/n2)"
    ),
    PAIRED_CHANGE_SD_METHOD: "mean_change; variance = change_score_sd^2/n",
    PAIRED_CHANGE_CORRELATION_METHOD: (
        "mean_change; change_score_variance = baseline_sd^2 + followup_sd^2 "
        "- 2*correlation*baseline_sd*followup_sd; "
        "variance = change_score_variance/n"
    ),
}

_METHOD_ALIASES = {
    "risk_difference": RISK_DIFFERENCE_METHOD,
    "rd": RISK_DIFFERENCE_METHOD,
    RISK_DIFFERENCE_METHOD: RISK_DIFFERENCE_METHOD,
    "log_risk_ratio": LOG_RISK_RATIO_METHOD,
    "log_rr": LOG_RISK_RATIO_METHOD,
    LOG_RISK_RATIO_METHOD: LOG_RISK_RATIO_METHOD,
    "welch": MEAN_DIFFERENCE_WELCH_METHOD,
    "mean_difference_welch": MEAN_DIFFERENCE_WELCH_METHOD,
    MEAN_DIFFERENCE_WELCH_METHOD: MEAN_DIFFERENCE_WELCH_METHOD,
    "pooled": MEAN_DIFFERENCE_POOLED_METHOD,
    "mean_difference_pooled": MEAN_DIFFERENCE_POOLED_METHOD,
    MEAN_DIFFERENCE_POOLED_METHOD: MEAN_DIFFERENCE_POOLED_METHOD,
    "paired_change_sd": PAIRED_CHANGE_SD_METHOD,
    PAIRED_CHANGE_SD_METHOD: PAIRED_CHANGE_SD_METHOD,
    "paired_change_correlation": PAIRED_CHANGE_CORRELATION_METHOD,
    PAIRED_CHANGE_CORRELATION_METHOD: PAIRED_CHANGE_CORRELATION_METHOD,
}


class PrecisionDerivationError(ValueError):
    """Raised when a requested derivation is incomplete, ambiguous, or unsafe."""


def canonical_variance_method(value: object) -> str:
    """Return the canonical method name, rejecting missing or unknown methods."""
    if not isinstance(value, str) or not value.strip():
        raise PrecisionDerivationError("variance_method must be explicitly selected")
    method = _METHOD_ALIASES.get(value.strip().lower())
    if method is None:
        supported = ", ".join(sorted(FORMULAS))
        raise PrecisionDerivationError(
            f"unsupported variance_method {value!r}; supported methods: {supported}"
        )
    return method


def _number(value: object, name: str) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
    ):
        raise PrecisionDerivationError(f"{name} must be a finite number")
    return float(value)


def _integer(value: object, name: str, *, minimum: int) -> int:
    number = _number(value, name)
    if not number.is_integer() or number < minimum:
        comparator = "positive" if minimum == 1 else f">= {minimum}"
        raise PrecisionDerivationError(f"{name} must be an integer {comparator}")
    return int(number)


def _source_lines(value: object) -> list[str]:
    if value is None:
        return []
    values: Sequence[object]
    if isinstance(value, str):
        values = [value]
    elif isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
        values = value
    else:
        raise PrecisionDerivationError(
            "variance_source_lines must be a source-line string or list of strings"
        )
    lines: list[str] = []
    for item in values:
        if not isinstance(item, str) or not item.strip():
            raise PrecisionDerivationError(
                "variance_source_lines must contain only non-empty strings"
            )
        normalized = item.strip()
        if normalized not in lines:
            lines.append(normalized)
    return lines


def _result(
    *,
    value: float,
    variance: float,
    method: str,
    inputs: dict[str, int | float],
    assumptions: list[str],
    source_lines: object,
    interval_scale: str,
) -> dict[str, Any]:
    if not math.isfinite(variance) or variance < 0:
        raise PrecisionDerivationError("derived variance must be finite and non-negative")
    se = math.sqrt(variance)
    margin = NORMAL_95_Z * se
    return {
        "value": value,
        "se": se,
        "interval": {
            "confidence_level": CONFIDENCE_LEVEL,
            "lower": value - margin,
            "upper": value + margin,
            "scale": interval_scale,
        },
        "provenance": {
            "precision_source": "derived_from_reported_inputs",
            "variance_estimated": True,
            "variance_method": method,
            "variance_formula": FORMULAS[method],
            "variance_inputs": inputs,
            "variance_assumptions": assumptions,
            "variance_source_lines": _source_lines(source_lines),
            "zero_event_policy": (
                "reject either-arm zero events; no continuity correction"
                if method == LOG_RISK_RATIO_METHOD
                else "not applicable"
            ),
        },
    }


def derive_risk_difference(
    *,
    arm_1_events: object,
    arm_1_denominator: object,
    arm_2_events: object,
    arm_2_denominator: object,
    source_lines: object = None,
) -> dict[str, Any]:
    """Derive an independent two-proportion risk difference and normal CI."""
    e1, n1, e2, n2 = _validated_binary_inputs(
        arm_1_events,
        arm_1_denominator,
        arm_2_events,
        arm_2_denominator,
    )
    p1, p2 = e1 / n1, e2 / n2
    return _result(
        value=p1 - p2,
        variance=p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2,
        method=RISK_DIFFERENCE_METHOD,
        inputs={
            "arm_1_events": e1,
            "arm_1_denominator": n1,
            "arm_2_events": e2,
            "arm_2_denominator": n2,
        },
        assumptions=[
            "the two arms are independent",
            "the interval uses the uncorrected normal approximation",
        ],
        source_lines=source_lines,
        interval_scale="risk_difference",
    )


def derive_log_risk_ratio(
    *,
    arm_1_events: object,
    arm_1_denominator: object,
    arm_2_events: object,
    arm_2_denominator: object,
    source_lines: object = None,
) -> dict[str, Any]:
    """Derive a log risk ratio; zero-event arms are rejected without correction."""
    e1, n1, e2, n2 = _validated_binary_inputs(
        arm_1_events,
        arm_1_denominator,
        arm_2_events,
        arm_2_denominator,
    )
    if e1 == 0 or e2 == 0:
        raise PrecisionDerivationError(
            "log risk ratio requires nonzero events in both arms; "
            "continuity corrections are not applied"
        )
    value = math.log((e1 / n1) / (e2 / n2))
    variance = 1 / e1 - 1 / n1 + 1 / e2 - 1 / n2
    return _result(
        value=value,
        variance=variance,
        method=LOG_RISK_RATIO_METHOD,
        inputs={
            "arm_1_events": e1,
            "arm_1_denominator": n1,
            "arm_2_events": e2,
            "arm_2_denominator": n2,
        },
        assumptions=[
            "the two arms are independent",
            "both arms have at least one event",
            "no continuity correction is used",
            "the interval uses the normal approximation on the log scale",
        ],
        source_lines=source_lines,
        interval_scale="log_risk_ratio",
    )


def _validated_binary_inputs(
    arm_1_events: object,
    arm_1_denominator: object,
    arm_2_events: object,
    arm_2_denominator: object,
) -> tuple[int, int, int, int]:
    e1 = _integer(arm_1_events, "arm_1_events", minimum=0)
    n1 = _integer(arm_1_denominator, "arm_1_denominator", minimum=1)
    e2 = _integer(arm_2_events, "arm_2_events", minimum=0)
    n2 = _integer(arm_2_denominator, "arm_2_denominator", minimum=1)
    if e1 > n1:
        raise PrecisionDerivationError("arm_1_events cannot exceed arm_1_denominator")
    if e2 > n2:
        raise PrecisionDerivationError("arm_2_events cannot exceed arm_2_denominator")
    return e1, n1, e2, n2


def derive_mean_difference(
    *,
    arm_1_mean: object,
    arm_1_sd: object,
    arm_1_n: object,
    arm_2_mean: object,
    arm_2_sd: object,
    arm_2_n: object,
    method: str,
    source_lines: object = None,
) -> dict[str, Any]:
    """Derive an independent mean difference with explicitly selected variance."""
    canonical = canonical_variance_method(method)
    if canonical not in (MEAN_DIFFERENCE_WELCH_METHOD, MEAN_DIFFERENCE_POOLED_METHOD):
        raise PrecisionDerivationError("mean difference method must be 'welch' or 'pooled'")
    mean1 = _number(arm_1_mean, "arm_1_mean")
    mean2 = _number(arm_2_mean, "arm_2_mean")
    sd1 = _number(arm_1_sd, "arm_1_sd")
    sd2 = _number(arm_2_sd, "arm_2_sd")
    if sd1 < 0 or sd2 < 0:
        raise PrecisionDerivationError("arm standard deviations cannot be negative")
    n1 = _integer(arm_1_n, "arm_1_n", minimum=2)
    n2 = _integer(arm_2_n, "arm_2_n", minimum=2)
    if canonical == MEAN_DIFFERENCE_WELCH_METHOD:
        variance = sd1**2 / n1 + sd2**2 / n2
        assumptions = [
            "the two arms are independent",
            "arm-specific standard deviations are used (Welch variance)",
            "the interval uses the normal approximation",
        ]
    else:
        pooled_variance = ((n1 - 1) * sd1**2 + (n2 - 1) * sd2**2) / (n1 + n2 - 2)
        variance = pooled_variance * (1 / n1 + 1 / n2)
        assumptions = [
            "the two arms are independent",
            "the arms share a common variance (pooled variance selected explicitly)",
            "the interval uses the normal approximation",
        ]
    return _result(
        value=mean1 - mean2,
        variance=variance,
        method=canonical,
        inputs={
            "arm_1_mean": mean1,
            "arm_1_sd": sd1,
            "arm_1_n": n1,
            "arm_2_mean": mean2,
            "arm_2_sd": sd2,
            "arm_2_n": n2,
        },
        assumptions=assumptions,
        source_lines=source_lines,
        interval_scale="mean_difference",
    )


def derive_paired_mean_change(
    *,
    mean_change: object,
    n: object,
    change_score_sd: object | None = None,
    baseline_sd: object | None = None,
    followup_sd: object | None = None,
    correlation: object | None = None,
    method: str,
    source_lines: object = None,
) -> dict[str, Any]:
    """Derive paired-change precision from an explicit SD or full correlation inputs."""
    canonical = canonical_variance_method(method)
    value = _number(mean_change, "mean_change")
    sample_size = _integer(n, "n", minimum=2)
    if canonical == PAIRED_CHANGE_SD_METHOD:
        if change_score_sd is None:
            raise PrecisionDerivationError(
                "paired change-score derivation requires explicit change_score_sd"
            )
        sd_change = _number(change_score_sd, "change_score_sd")
        if sd_change < 0:
            raise PrecisionDerivationError("change_score_sd cannot be negative")
        inputs: dict[str, int | float] = {
            "mean_change": value,
            "change_score_sd": sd_change,
            "n": sample_size,
        }
        variance = sd_change**2 / sample_size
        assumptions = [
            "change_score_sd is reported or otherwise explicitly approved",
            "the interval uses the normal approximation",
        ]
    elif canonical == PAIRED_CHANGE_CORRELATION_METHOD:
        missing = [
            name
            for name, item in (
                ("baseline_sd", baseline_sd),
                ("followup_sd", followup_sd),
                ("change_score_correlation", correlation),
            )
            if item is None
        ]
        if missing:
            raise PrecisionDerivationError(
                "paired correlation derivation requires " + ", ".join(missing)
            )
        before_sd = _number(baseline_sd, "baseline_sd")
        after_sd = _number(followup_sd, "followup_sd")
        corr = _number(correlation, "change_score_correlation")
        if before_sd < 0 or after_sd < 0:
            raise PrecisionDerivationError("paired standard deviations cannot be negative")
        if not -1 <= corr <= 1:
            raise PrecisionDerivationError("change_score_correlation must be between -1 and 1")
        change_variance = before_sd**2 + after_sd**2 - 2 * corr * before_sd * after_sd
        if change_variance < -PRECISION_ABS_TOLERANCE:
            raise PrecisionDerivationError("paired inputs imply a negative change variance")
        change_variance = max(0.0, change_variance)
        variance = change_variance / sample_size
        inputs = {
            "mean_change": value,
            "baseline_sd": before_sd,
            "followup_sd": after_sd,
            "change_score_correlation": corr,
            "n": sample_size,
        }
        assumptions = [
            "baseline and follow-up values are paired within the same participants",
            "the reported correlation applies to the supplied standard deviations",
            "the interval uses the normal approximation",
        ]
    else:
        raise PrecisionDerivationError(
            "paired mean change method must select explicit change SD "
            "or pre/post correlation inputs"
        )
    return _result(
        value=value,
        variance=variance,
        method=canonical,
        inputs=inputs,
        assumptions=assumptions,
        source_lines=source_lines,
        interval_scale="mean_change",
    )


def derive_precision(effect: Mapping[str, Any]) -> dict[str, Any]:
    """Recompute precision from an effect's explicit method and variance inputs."""
    method = canonical_variance_method(effect.get("variance_method"))
    raw_inputs = effect.get("variance_inputs")
    if raw_inputs is None:
        inputs: Mapping[str, Any] = effect
    elif isinstance(raw_inputs, Mapping):
        inputs = raw_inputs
    else:
        raise PrecisionDerivationError("variance_inputs must be an object")
    source_lines = effect.get("variance_source_lines")

    if method == RISK_DIFFERENCE_METHOD:
        return derive_risk_difference(
            arm_1_events=inputs.get("arm_1_events"),
            arm_1_denominator=inputs.get("arm_1_denominator"),
            arm_2_events=inputs.get("arm_2_events"),
            arm_2_denominator=inputs.get("arm_2_denominator"),
            source_lines=source_lines,
        )
    if method == LOG_RISK_RATIO_METHOD:
        return derive_log_risk_ratio(
            arm_1_events=inputs.get("arm_1_events"),
            arm_1_denominator=inputs.get("arm_1_denominator"),
            arm_2_events=inputs.get("arm_2_events"),
            arm_2_denominator=inputs.get("arm_2_denominator"),
            source_lines=source_lines,
        )
    if method in (MEAN_DIFFERENCE_WELCH_METHOD, MEAN_DIFFERENCE_POOLED_METHOD):
        return derive_mean_difference(
            arm_1_mean=inputs.get("arm_1_mean"),
            arm_1_sd=inputs.get("arm_1_sd"),
            arm_1_n=inputs.get("arm_1_n"),
            arm_2_mean=inputs.get("arm_2_mean"),
            arm_2_sd=inputs.get("arm_2_sd"),
            arm_2_n=inputs.get("arm_2_n"),
            method=method,
            source_lines=source_lines,
        )

    mean_change = inputs.get("mean_change", effect.get("effect_size"))
    sample_size = inputs.get("n", inputs.get("change_score_n", effect.get("n")))
    if method == PAIRED_CHANGE_SD_METHOD:
        return derive_paired_mean_change(
            mean_change=mean_change,
            n=sample_size,
            change_score_sd=inputs.get("change_score_sd"),
            method=method,
            source_lines=source_lines,
        )
    return derive_paired_mean_change(
        mean_change=mean_change,
        n=sample_size,
        baseline_sd=inputs.get("baseline_sd", inputs.get("arm_1_sd")),
        followup_sd=inputs.get("followup_sd", inputs.get("arm_2_sd")),
        correlation=inputs.get("change_score_correlation"),
        method=method,
        source_lines=source_lines,
    )


def has_usable_precision(effect: Mapping[str, Any]) -> bool:
    """Return whether an effect has a complete reported or derived precision value."""
    ci_lower, ci_upper = effect.get("ci_lower"), effect.get("ci_upper")
    if (
        isinstance(ci_lower, (int, float))
        and not isinstance(ci_lower, bool)
        and isinstance(ci_upper, (int, float))
        and not isinstance(ci_upper, bool)
        and math.isfinite(float(ci_lower))
        and math.isfinite(float(ci_upper))
        and float(ci_lower) < float(ci_upper)
    ):
        return True
    se = effect.get("se")
    return (
        isinstance(se, (int, float))
        and not isinstance(se, bool)
        and math.isfinite(float(se))
        and float(se) > 0
    )
