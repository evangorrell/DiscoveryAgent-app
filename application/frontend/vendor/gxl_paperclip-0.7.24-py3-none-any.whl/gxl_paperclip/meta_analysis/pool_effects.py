"""Deterministic random-effects pooling for verified Paperclip effects."""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from collections.abc import Callable
from pathlib import Path
from typing import Any

_T975 = {
    1: 12.706,
    2: 4.303,
    3: 3.182,
    4: 2.776,
    5: 2.571,
    6: 2.447,
    7: 2.365,
    8: 2.306,
    9: 2.262,
    10: 2.228,
    11: 2.201,
    12: 2.179,
    13: 2.160,
    14: 2.145,
    15: 2.131,
    16: 2.120,
    17: 2.110,
    18: 2.101,
    19: 2.093,
    20: 2.086,
    21: 2.080,
    22: 2.074,
    23: 2.069,
    24: 2.064,
    25: 2.060,
    26: 2.056,
    27: 2.052,
    28: 2.048,
    29: 2.045,
    30: 2.042,
}


def t975(df: int) -> float:
    if df <= 0:
        return 1.96
    return _T975.get(df, 1.96 if df >= 120 else 2.0)


def scale_functions(measure: str) -> tuple[Callable[[float], float], Callable[[float], float], str]:
    name = measure.lower()
    if any(token in name for token in ("difference", "delta", "uplift", "change", "reduction")):
        return float, float, "raw"
    if name in {"rr", "or", "hr"} or any(token in name for token in ("ratio", "odds", "hazard")):
        return math.log, math.exp, "log"
    if any(token in name for token in ("proportion", "rate", "accuracy", "pass@", "f1")):

        def logit(value: float) -> float:
            value = min(1 - 1e-8, max(1e-8, value))
            return math.log(value / (1 - value))

        def inv_logit(value: float) -> float:
            if value >= 0:
                return 1 / (1 + math.exp(-value))
            exp_value = math.exp(value)
            return exp_value / (1 + exp_value)

        return logit, inv_logit, "logit"
    return float, float, "raw"


def canonical_measure(measure: str) -> str:
    """Collapse equivalent measure labels without conflating distinct scales."""
    name = measure.strip().lower().replace("-", " ").replace("_", " ")
    if name == "hr" or "hazard ratio" in name:
        return "hazard_ratio"
    if name == "rr" or "risk ratio" in name or "relative risk" in name:
        return "risk_ratio"
    if name == "or" or "odds ratio" in name:
        return "odds_ratio"
    return "_".join(name.split())


def transformed_effect(
    effect: dict[str, Any],
) -> tuple[float, float, Callable[[float], float], str]:
    estimate = float(effect["effect_size"])
    measure = str(effect["effect_measure"])
    transform, backtransform, scale = scale_functions(measure)
    percent_scale = scale == "logit" and (
        "%" in measure or "percent" in measure.lower() or "percentage" in measure.lower()
    )
    lo, hi = effect.get("ci_lower"), effect.get("ci_upper")
    raw_se = effect.get("se")
    if percent_scale and 1 < estimate <= 100:
        estimate /= 100
        lo = float(lo) / 100 if lo is not None else None
        hi = float(hi) / 100 if hi is not None else None
        raw_se = float(raw_se) / 100 if raw_se is not None else None
    if scale == "logit" and not 0 <= estimate <= 1:
        raise ValueError(
            "bounded proportion/rate/accuracy must use the 0-1 scale; "
            "use a delta/difference measure for percentage points"
        )
    if scale == "log" and estimate <= 0:
        raise ValueError("ratio measures must be positive")
    theta = transform(estimate)
    if lo is not None and hi is not None:
        se = abs(transform(float(hi)) - transform(float(lo))) / (2 * 1.96)
    elif raw_se is not None:
        raw_se = float(raw_se)
        if scale == "log":
            se = raw_se / max(abs(estimate), 1e-12)
        elif scale == "logit":
            se = raw_se / max(estimate * (1 - estimate), 1e-12)
        else:
            se = raw_se
    elif effect.get("n") is not None and scale == "logit":
        n = float(effect["n"])
        if n <= 0:
            raise ValueError("n must be positive")
        events = min(n, max(0.0, estimate * n))
        corrected = (events + 0.5) / (n + 1.0)
        theta = transform(corrected)
        se = math.sqrt(1 / (n * corrected) + 1 / (n * (1 - corrected)))
    else:
        raise ValueError("missing CI/SE or usable n")
    if not math.isfinite(theta) or not math.isfinite(se) or se <= 0:
        raise ValueError("non-finite estimate or standard error")
    return theta, se, backtransform, scale


def weighted_mean(
    values: list[float], variances: list[float], tau2: float
) -> tuple[float, list[float]]:
    weights = [1 / (variance + tau2) for variance in variances]
    total = sum(weights)
    return (
        sum(weights[i] * values[i] for i in range(len(values))) / total,
        weights,
    )


def reml_tau2(values: list[float], variances: list[float]) -> float:
    if len(values) < 2:
        return 0.0

    def score(tau2: float) -> float:
        mean, weights = weighted_mean(values, variances, tau2)
        sum_w = sum(weights)
        return sum((weights[i] ** 2) * ((values[i] - mean) ** 2) for i in range(len(values))) - (
            sum_w - sum(w * w for w in weights) / sum_w
        )

    if score(0.0) <= 0:
        return 0.0
    high = max(1.0, max(values) - min(values)) ** 2
    while score(high) > 0 and high < 1e8:
        high *= 2
    low = 0.0
    for _ in range(80):
        mid = (low + high) / 2
        if score(mid) > 0:
            low = mid
        else:
            high = mid
    return (low + high) / 2


def dl_tau2(values: list[float], variances: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    weights = [1 / variance for variance in variances]
    mean = sum(weights[i] * values[i] for i in range(len(values))) / sum(weights)
    q = sum(weights[i] * (values[i] - mean) ** 2 for i in range(len(values)))
    c = sum(weights) - sum(w * w for w in weights) / sum(weights)
    return max(0.0, (q - (len(values) - 1)) / c) if c > 0 else 0.0


def pool_core(values: list[float], variances: list[float], tau2: float) -> dict[str, float]:
    mean, weights = weighted_mean(values, variances, tau2)
    df = len(values) - 1
    q_re = sum(weights[i] * (values[i] - mean) ** 2 for i in range(len(values)))
    kh_factor = max(1.0, q_re / df) if df > 0 else 1.0
    se = math.sqrt(kh_factor / sum(weights))
    critical = t975(df)
    return {
        "mean": mean,
        "se": se,
        "ci_lower": mean - critical * se,
        "ci_upper": mean + critical * se,
    }


def heterogeneity(values: list[float], variances: list[float], tau2: float) -> dict[str, float]:
    if len(values) < 2:
        return {"q": 0.0, "q_df": 0, "i2": 0.0, "tau2": tau2}
    mean, weights = weighted_mean(values, variances, 0.0)
    q = sum(weights[i] * (values[i] - mean) ** 2 for i in range(len(values)))
    df = len(values) - 1
    return {
        "q": q,
        "q_df": df,
        "i2": max(0.0, (q - df) / q * 100) if q > 0 else 0.0,
        "tau2": tau2,
    }


def egger_test(values: list[float], standard_errors: list[float]) -> dict[str, Any] | None:
    if len(values) < 10:
        return None
    x = [1 / se for se in standard_errors]
    y = [values[i] / standard_errors[i] for i in range(len(values))]
    n = len(x)
    mean_x, mean_y = sum(x) / n, sum(y) / n
    ss_x = sum((item - mean_x) ** 2 for item in x)
    if ss_x == 0:
        return {
            "estimable": False,
            "p_value": None,
            "reason": "all standard errors are identical",
        }
    slope = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(len(x))) / ss_x
    intercept = mean_y - slope * mean_x
    residuals = [y[i] - (intercept + slope * x[i]) for i in range(len(x))]
    residual_var = sum(item * item for item in residuals) / max(1, n - 2)
    se_intercept = math.sqrt(residual_var * (1 / n + mean_x * mean_x / ss_x))
    z = intercept / se_intercept if se_intercept else 0.0
    return {
        "estimable": True,
        "intercept": intercept,
        "se": se_intercept,
        "p_value": math.erfc(abs(z) / math.sqrt(2)),
    }


def grade_summary(k: int, i2: float, egger: dict | None) -> dict[str, Any]:
    downgrades: list[str] = []
    if k < 5:
        downgrades.append("imprecision: fewer than 5 independent units")
    if i2 > 75:
        downgrades.append("inconsistency: I² > 75%")
    if egger and egger.get("p_value") is not None and egger["p_value"] < 0.05:
        downgrades.append("publication bias: Egger p < 0.05")
    certainty = ("high", "moderate", "low", "very_low")[min(3, len(downgrades))]
    return {
        "certainty": certainty,
        "method": "deterministic preliminary GRADE; review against study quality",
        "downgrades": downgrades,
    }


def study_row(effect: dict[str, Any], theta: float, se: float) -> dict[str, Any]:
    return {
        "effect_id": effect["effect_id"],
        "label": effect.get("study_label")
        or effect.get("first_author_year")
        or effect["paperclip_doc_id"],
        "doc_id": effect["paperclip_doc_id"],
        "lines": effect["paperclip_lines"],
        "effect_size": effect["effect_size"],
        "ci_lower": effect.get("ci_lower"),
        "ci_upper": effect.get("ci_upper"),
        "theta": theta,
        "se": se,
        "independent_unit_id": effect.get("independent_unit_id")
        or effect.get("cohort_id")
        or effect["paperclip_doc_id"],
    }


def unit_id(effect: dict[str, Any]) -> str:
    return str(
        effect.get("independent_unit_id")
        or effect.get("cohort_id")
        or effect.get("paperclip_doc_id")
        or ""
    )


def primary_preference(effect: dict[str, Any]) -> tuple:
    """Prefer CI-backed, then SE/n-backed, then larger n, then stable id."""
    has_ci = (
        1
        if effect.get("ci_lower") is not None and effect.get("ci_upper") is not None
        else 0
    )
    has_se = 1 if effect.get("se") is not None else 0
    try:
        n = float(effect["n"]) if effect.get("n") is not None else -1.0
    except (TypeError, ValueError):
        n = -1.0
    has_n = 1 if n > 0 else 0
    return (has_ci, has_se, has_n, n, str(effect.get("effect_id") or ""))


def demote_correlated_primaries(
    effects: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    """Keep one primary per (outcome_group, independent_unit); demote the rest.

    Mutates demoted rows in place to ``analysis_role=secondary``. Returns
    (kept_primary, demoted, repair messages).
    """
    by_key: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for effect in effects:
        by_key[(str(effect.get("outcome_group") or ""), unit_id(effect))].append(effect)

    kept: list[dict[str, Any]] = []
    demoted: list[dict[str, Any]] = []
    repairs: list[str] = []
    for (outcome, unit), rows in sorted(by_key.items()):
        if not unit or len(rows) == 1:
            kept.extend(rows)
            continue
        ranked = sorted(rows, key=primary_preference, reverse=True)
        winner = ranked[0]
        kept.append(winner)
        for loser in ranked[1:]:
            loser["analysis_role"] = "secondary"
            loser["demotion_reason"] = (
                f"correlated_independent_unit:{unit}"
                f"|outcome:{outcome}"
                f"|kept:{winner.get('effect_id')}"
            )
            demoted.append(loser)
            repairs.append(
                f"{outcome}: demoted {loser.get('effect_id')!r} to secondary "
                f"(shares independent_unit_id {unit!r} with "
                f"{winner.get('effect_id')!r})"
            )
    return kept, demoted, repairs


def pool_group(name: str, effects: list[dict[str, Any]]) -> tuple[dict, list[str]]:
    errors: list[str] = []
    measures = {canonical_measure(str(effect.get("effect_measure"))) for effect in effects}
    if len(measures) != 1:
        return {}, [f"{name}: mixed effect measures {sorted(measures)}"]
    transformed: list[tuple[dict, float, float, Callable[[float], float], str]] = []
    for effect in effects:
        try:
            theta, se, backtransform, scale = transformed_effect(effect)
            transformed.append((effect, theta, se, backtransform, scale))
        except (TypeError, ValueError, OverflowError) as exc:
            errors.append(f"{effect.get('effect_id')}: {exc}")
    if not transformed:
        return {}, errors

    units: dict[str, list[str]] = defaultdict(list)
    for effect, *_ in transformed:
        units[unit_id(effect)].append(str(effect["effect_id"]))
    duplicates = {unit: ids for unit, ids in units.items() if unit and len(ids) > 1}
    if duplicates:
        # build_analysis should already demote these; keep a hard guard.
        errors.append(
            f"{name}: multiple primary effects share independent units: {duplicates}; "
            "mark alternatives analysis_role=secondary/exclude"
        )
        return {}, errors

    values = [row[1] for row in transformed]
    ses = [row[2] for row in transformed]
    variances = [se * se for se in ses]
    backtransform = transformed[0][3]
    tau_reml = reml_tau2(values, variances)
    tau_dl = dl_tau2(values, variances)
    reml = pool_core(values, variances, tau_reml)
    dl = pool_core(values, variances, tau_dl)
    hetero = heterogeneity(values, variances, tau_reml)
    egger = egger_test(values, ses)
    prediction_se = math.sqrt(tau_reml + reml["se"] ** 2)
    pred_critical = t975(max(1, len(values) - 2))

    leave_one_out = []
    if len(values) >= 3:
        for index, row in enumerate(transformed):
            sub_values = values[:index] + values[index + 1 :]
            sub_vars = variances[:index] + variances[index + 1 :]
            sub_tau = reml_tau2(sub_values, sub_vars)
            sub = pool_core(sub_values, sub_vars, sub_tau)
            leave_one_out.append(
                {
                    "omitted_effect_id": row[0]["effect_id"],
                    "pooled": backtransform(sub["mean"]),
                    "ci_lower": backtransform(sub["ci_lower"]),
                    "ci_upper": backtransform(sub["ci_upper"]),
                }
            )

    studies = [study_row(effect, theta, se) for effect, theta, se, *_ in transformed]
    group = {
        "name": name,
        "effect_measure": next(iter(measures)),
        "scale": transformed[0][4],
        "k": len(values),
        "studies": studies,
        "pooled_combined": {
            "k": len(values),
            "pooled_reml": backtransform(reml["mean"]),
            "ci_lower_kh": backtransform(reml["ci_lower"]),
            "ci_upper_kh": backtransform(reml["ci_upper"]),
            "knapp_hartung_used": True,
            "pooled_dl": backtransform(dl["mean"]),
            "ci_lower_dl": backtransform(dl["ci_lower"]),
            "ci_upper_dl": backtransform(dl["ci_upper"]),
            "prediction_interval": [
                backtransform(reml["mean"] - pred_critical * prediction_se),
                backtransform(reml["mean"] + pred_critical * prediction_se),
            ],
            "Q": hetero["q"],
            "Q_df": hetero["q_df"],
            "I_squared": hetero["i2"],
            "tau_squared_reml": hetero["tau2"],
            "egger_p_value": egger.get("p_value") if egger else None,
            "leave_one_out": leave_one_out,
        },
        "egger_test": egger,
        "leave_one_out": leave_one_out,
        "grade": grade_summary(len(values), hetero["i2"], egger),
    }
    return group, errors


def build_analysis(
    effects: list[dict[str, Any]],
    characteristics: list[dict[str, Any]],
    quality: list[dict[str, Any]],
) -> tuple[dict[str, Any], list[str], list[str], list[dict[str, Any]]]:
    # Work on shallow copies so callers can persist demotions without surprising
    # shared-mutability bugs when the same dicts are reused in tests.
    effects = [dict(row) for row in effects]
    primary = [row for row in effects if row.get("analysis_role", "primary") == "primary"]
    secondary = [row for row in effects if row.get("analysis_role") == "secondary"]
    excluded = [row for row in effects if row.get("analysis_role") == "exclude"]
    primary, demoted, repairs = demote_correlated_primaries(primary)
    secondary = secondary + demoted
    groups: dict[tuple[str, str], list[dict]] = defaultdict(list)
    missing_variance_ids: list[str] = []
    errors: list[str] = []
    for effect in primary:
        try:
            transformed_effect(effect)
        except (TypeError, ValueError, OverflowError) as exc:
            if "missing CI/SE or usable n" in str(exc):
                missing_variance_ids.append(str(effect.get("effect_id")))
            else:
                errors.append(f"{effect.get('effect_id')}: {exc}")
            continue
        groups[
            (
                str(effect["outcome_group"]),
                canonical_measure(str(effect.get("effect_measure"))),
            )
        ].append(effect)

    outcome_groups: list[dict] = []
    selected = 0
    measures_by_outcome: dict[str, set[str]] = defaultdict(set)
    for outcome, measure in groups:
        measures_by_outcome[outcome].add(measure)
    for (outcome, measure), rows in sorted(groups.items()):
        name = (
            f"{outcome} [{measure}]"
            if len(measures_by_outcome[outcome]) > 1
            else outcome
        )
        group, group_errors = pool_group(name, rows)
        errors.extend(group_errors)
        if group:
            selected += group["k"]
            outcome_groups.append(group)

    selection = {
        "verified_effects_available": len(effects),
        "effects_selected_primary_pooling": selected,
        "effects_secondary_or_sensitivity": len(secondary),
        "effects_excluded_explicit": len(excluded),
        "effects_excluded_missing_variance": len(missing_variance_ids),
        "effects_demoted_correlated_primary": len(demoted),
        "demoted_correlated_primary_ids": [
            str(row.get("effect_id")) for row in demoted
        ],
        "excluded_effect_ids_missing_variance": missing_variance_ids,
        "explicit_exclusion_reasons": dict(
            sorted(
                {
                    reason: sum(
                        row.get("exclusion_reason", "unspecified") == reason for row in excluded
                    )
                    for reason in {row.get("exclusion_reason", "unspecified") for row in excluded}
                }.items()
            )
        ),
    }
    accounted = selected + len(secondary) + len(excluded) + len(missing_variance_ids)
    if accounted != len(effects):
        errors.append(f"selection accounting mismatch: {accounted} != {len(effects)}")
    return (
        {
            "n_effects_extracted": len(effects),
            "n_effects_compiled_verified": len(effects),
            "n_effects_selected_primary_pooling": selected,
            "selection_accounting": selection,
            "study_characteristics": characteristics,
            "quality_assessments": quality,
            "outcome_groups": outcome_groups,
        },
        errors,
        repairs,
        effects,
    )


def load_rows(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text())
    if not isinstance(data, list) or not all(isinstance(row, dict) for row in data):
        raise ValueError(f"{path} must contain a JSON array of objects")
    return data


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", nargs="?", default=".")
    args = parser.parse_args(argv)
    directory = Path(args.directory)
    analysis, errors, repairs, repaired_effects = build_analysis(
        load_rows(directory / "effects.json"),
        load_rows(directory / "study_characteristics.json"),
        load_rows(directory / "quality_assessments.json"),
    )
    if errors:
        print(f"FAIL: {len(errors)} pooling problem(s):", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
        return 1
    # Persist demotions so Stage 1 artifacts stay consistent with analysis.json.
    if repairs:
        (directory / "effects.json").write_text(
            json.dumps(repaired_effects, indent=2) + "\n"
        )
        print(f"Updated effects.json: demoted {len(repairs)} correlated primary row(s)")
    (directory / "analysis.json").write_text(json.dumps(analysis, indent=2) + "\n")
    print(
        f"Wrote analysis.json: {len(analysis['outcome_groups'])} groups, "
        f"{analysis['n_effects_selected_primary_pooling']} primary effects"
    )
    if repairs:
        print(f"Repaired {len(repairs)} correlated primary unit(s):")
        for repair in repairs[:100]:
            print(f"  - {repair}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
