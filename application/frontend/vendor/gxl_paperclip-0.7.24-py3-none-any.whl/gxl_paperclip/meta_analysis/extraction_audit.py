#!/usr/bin/env python3
"""Deterministically compare two independent structured extractions."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


def _claim_objects(value: Any) -> list[dict]:
    if isinstance(value, str):
        try:
            return _claim_objects(json.loads(value))
        except (json.JSONDecodeError, TypeError):
            return []
    if isinstance(value, list):
        claims: list[dict] = []
        for item in value:
            claims.extend(_claim_objects(item))
        return claims
    if not isinstance(value, dict):
        return []
    if value.get("type") in {"effect", "context"}:
        return [value]
    if isinstance(value.get("claim"), dict):
        return [value["claim"]]
    for key in ("claims", "effects", "results", "output"):
        if key in value:
            return _claim_objects(value[key])
    return []


def _close(first: Any, second: Any, tolerance: float = 0.05) -> bool:
    if first is None and second is None:
        return True
    if not isinstance(first, (int, float)) or not isinstance(second, (int, float)):
        return False
    scale = max(abs(float(first)), 1e-12)
    return abs(float(second) - float(first)) / scale <= tolerance


def _ci_review_candidate(effect: dict) -> bool:
    lower = effect.get("ci_lower")
    upper = effect.get("ci_upper")
    estimate = effect.get("effect_size")
    if (
        not isinstance(lower, (int, float))
        or not isinstance(upper, (int, float))
        or not isinstance(estimate, (int, float))
    ):
        return False
    left = float(estimate) - float(lower)
    right = float(upper) - float(estimate)
    if not math.isclose(left, right, rel_tol=1e-6, abs_tol=1e-9):
        return False
    return any(
        math.isclose(abs(left), width, rel_tol=1e-6, abs_tol=1e-9)
        for width in (0.06, 0.08, 0.10, 0.12, 0.14)
    )


def build_audit(
    first_data: Any, second_data: Any, ci_resolutions: dict[str, str] | None = None
) -> dict:
    first = {
        str(item["effect_id"]): item
        for item in _claim_objects(first_data)
        if item.get("type") == "effect" and item.get("effect_id")
    }
    second = {
        str(item["effect_id"]): item
        for item in _claim_objects(second_data)
        if item.get("type") == "effect" and item.get("effect_id")
    }
    discrepancies: list[dict] = []
    concordant = 0
    all_ids = sorted(set(first) | set(second))
    for effect_id in all_ids:
        left = first.get(effect_id)
        right = second.get(effect_id)
        before = len(discrepancies)
        if left is None or right is None:
            discrepancies.append(
                {
                    "effect_id": effect_id,
                    "field": "presence",
                    "first": left is not None,
                    "second": right is not None,
                    "resolution": None,
                }
            )
            continue
        for field in ("effect_size", "ci_lower", "ci_upper"):
            if not _close(left.get(field), right.get(field)):
                discrepancies.append(
                    {
                        "effect_id": effect_id,
                        "field": field,
                        "first": left.get(field),
                        "second": right.get(field),
                        "resolution": None,
                    }
                )
        if left.get("outcome_group") != right.get("outcome_group"):
            discrepancies.append(
                {
                    "effect_id": effect_id,
                    "field": "outcome_group",
                    "first": left.get("outcome_group"),
                    "second": right.get("outcome_group"),
                    "resolution": None,
                }
            )
        if len(discrepancies) == before:
            concordant += 1

    papers = sorted(
        {
            str(item.get("paperclip_doc_id") or str(item["effect_id"]).split("#", 1)[0])
            for item in first.values()
        }
    )
    flagged = sorted(
        effect_id for effect_id, effect in first.items() if _ci_review_candidate(effect)
    )
    resolutions = ci_resolutions or {}
    resolution_counts = {
        action: sum(1 for effect_id in flagged if resolutions.get(effect_id) == action)
        for action in ("corrected", "set_to_null", "source_verified")
    }
    return {
        "papers_sampled": papers,
        "effects_compared": len(all_ids),
        "concordance_rate": concordant / len(all_ids) if all_ids else 0.0,
        "discrepancies": discrepancies,
        "ci_integrity_check": {
            "flagged": len(flagged),
            "flagged_effect_ids": flagged,
            **resolution_counts,
        },
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--first", type=Path, required=True)
    parser.add_argument("--second", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("extraction_audit.json"))
    parser.add_argument("--ci-resolutions", type=Path)
    args = parser.parse_args(argv)
    resolutions = json.loads(args.ci_resolutions.read_text()) if args.ci_resolutions else None
    audit = build_audit(
        json.loads(args.first.read_text()),
        json.loads(args.second.read_text()),
        resolutions,
    )
    args.output.write_text(json.dumps(audit, indent=2) + "\n")
    print(
        f"Compared {audit['effects_compared']} effects; "
        f"concordance={audit['concordance_rate']:.1%}; "
        f"CI review candidates={audit['ci_integrity_check']['flagged']}"
    )
    ci = audit["ci_integrity_check"]
    resolved = ci["corrected"] + ci["set_to_null"] + ci["source_verified"]
    return 0 if audit["concordance_rate"] >= 0.90 and resolved == ci["flagged"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
