"""Deterministic validators for canonical managed-analysis results.

These validators deliberately check semantic invariants that JSON Schema cannot
express conveniently: effect traceability, selection accounting, finite
numbers, interval ordering, and type-specific model diagnostics.
"""

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

ANALYSIS_TYPES = ("pairwise", "network", "meta_regression")
_SELECTION_FIELDS = (
    "effects_selected_primary_pooling",
    "effects_secondary_or_sensitivity",
    "effects_excluded_explicit",
    "effects_excluded_missing_variance",
)


@dataclass
class ValidationReport:
    """Machine-readable analysis-contract validation result."""

    analysis_type: str | None
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    selected_effect_ids: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "analysis_type": self.analysis_type,
            "errors": self.errors,
            "warnings": self.warnings,
            "selected_effect_ids": self.selected_effect_ids,
        }


def _is_number(value: object) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
    )


def _analysis_type(value: Mapping[str, Any]) -> str | None:
    declared = value.get("analysis_type", value.get("type"))
    if declared is None and isinstance(value.get("outcome_groups"), list):
        # pool_effects predates the explicit discriminator. Its canonical shape
        # remains supported as pairwise output.
        return "pairwise"
    if not isinstance(declared, str):
        return None
    normalized = declared.strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "pairwise_meta_analysis": "pairwise",
        "network_meta_analysis": "network",
        "nma": "network",
        "metaregression": "meta_regression",
    }
    return aliases.get(normalized, normalized)


def _check_finite(value: object, path: str, errors: list[str]) -> None:
    if isinstance(value, float) and not math.isfinite(value):
        errors.append(f"{path} must be finite")
    elif isinstance(value, Mapping):
        for key, child in value.items():
            _check_finite(child, f"{path}.{key}", errors)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _check_finite(child, f"{path}[{index}]", errors)


def _check_intervals(value: object, path: str, errors: list[str]) -> None:
    if isinstance(value, Mapping):
        for lower_name, upper_name in (
            ("ci_lower", "ci_upper"),
            ("ci_lower_kh", "ci_upper_kh"),
            ("ci_lower_dl", "ci_upper_dl"),
            ("lower", "upper"),
        ):
            lower, upper = value.get(lower_name), value.get(upper_name)
            if lower is None and upper is None:
                continue
            if not _is_number(lower) or not _is_number(upper):
                errors.append(f"{path}.{lower_name}/{upper_name} must be finite numeric bounds")
            else:
                assert isinstance(lower, (int, float))
                assert isinstance(upper, (int, float))
                if float(lower) > float(upper):
                    errors.append(f"{path}.{lower_name} must not exceed {upper_name}")
                    continue
                point_names = (
                    ("pooled_reml",)
                    if lower_name == "ci_lower_kh"
                    else ("pooled_dl",)
                    if lower_name == "ci_lower_dl"
                    else ("estimate", "effect_size", "pooled")
                )
                point = next(
                    (value.get(name) for name in point_names if value.get(name) is not None),
                    None,
                )
                if _is_number(point):
                    assert isinstance(point, (int, float))
                    if not float(lower) <= float(point) <= float(upper):
                        errors.append(
                            f"{path}.{point_names[0]} must lie inside {lower_name}/{upper_name}"
                        )
        prediction = value.get("prediction_interval")
        if prediction is not None:
            if (
                not isinstance(prediction, list)
                or len(prediction) != 2
                or not all(_is_number(item) for item in prediction)
            ):
                errors.append(f"{path}.prediction_interval must have two finite bounds")
            elif float(prediction[0]) > float(prediction[1]):
                errors.append(f"{path}.prediction_interval bounds are reversed")
        for key, child in value.items():
            _check_intervals(child, f"{path}.{key}", errors)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _check_intervals(child, f"{path}[{index}]", errors)


def _effect_ids(effects: Sequence[Mapping[str, Any]] | None, errors: list[str]) -> set[str]:
    if effects is None:
        return set()
    ids: list[str] = []
    for index, effect in enumerate(effects):
        effect_id = effect.get("effect_id")
        if not isinstance(effect_id, str) or not effect_id.strip():
            errors.append(f"effects[{index}].effect_id must be a non-empty string")
        else:
            ids.append(effect_id)
    duplicates = sorted({effect_id for effect_id in ids if ids.count(effect_id) > 1})
    if duplicates:
        errors.append(f"source effects contain duplicate effect IDs: {duplicates}")
    return set(ids)


def _ids_from_row(row: Mapping[str, Any], path: str, errors: list[str]) -> list[str]:
    values: list[str] = []
    if "effect_id" in row:
        effect_id = row.get("effect_id")
        if not isinstance(effect_id, str) or not effect_id.strip():
            errors.append(f"{path}.effect_id must be a non-empty string")
        else:
            values.append(effect_id)
    if "effect_ids" in row:
        effect_ids = row.get("effect_ids")
        if (
            not isinstance(effect_ids, list)
            or not effect_ids
            or not all(isinstance(item, str) and item.strip() for item in effect_ids)
        ):
            errors.append(f"{path}.effect_ids must be a non-empty string array")
        else:
            values.extend(effect_ids)
    return values


def _validate_selection(
    analysis: Mapping[str, Any],
    source_ids: set[str],
    selected_ids: list[str],
    errors: list[str],
) -> None:
    selection = analysis.get("selection_accounting")
    if not isinstance(selection, Mapping):
        errors.append("analysis.selection_accounting must be an object")
        return
    compiled = analysis.get(
        "n_effects_compiled_verified",
        selection.get("verified_effects_available"),
    )
    if not isinstance(compiled, int) or isinstance(compiled, bool) or compiled < 0:
        errors.append("analysis.n_effects_compiled_verified must be a non-negative integer")
        return
    if source_ids and compiled != len(source_ids):
        errors.append("analysis.n_effects_compiled_verified does not match the supplied effects")
    selected_count = analysis.get(
        "n_effects_selected_primary_pooling",
        selection.get("effects_selected_primary_pooling"),
    )
    if not isinstance(selected_count, int) or isinstance(selected_count, bool):
        errors.append("analysis.n_effects_selected_primary_pooling must be a non-negative integer")
    elif selected_count < 0:
        errors.append("analysis.n_effects_selected_primary_pooling must be a non-negative integer")
    elif selected_count != len(set(selected_ids)):
        errors.append("primary selection count does not match unique effect IDs in model results")

    counts: list[int] = []
    for name in _SELECTION_FIELDS:
        count = selection.get(name)
        if not isinstance(count, int) or isinstance(count, bool) or count < 0:
            errors.append(f"analysis.selection_accounting.{name} must be a non-negative integer")
        else:
            counts.append(count)
    if len(counts) == len(_SELECTION_FIELDS) and sum(counts) != compiled:
        errors.append(f"analysis selection accounting totals {sum(counts)}, expected {compiled}")
    selection_selected = selection.get("effects_selected_primary_pooling")
    if isinstance(selected_count, int) and selection_selected != selected_count:
        errors.append("top-level and selection-accounting primary counts disagree")

    unknown = sorted(set(selected_ids) - source_ids) if source_ids else []
    if unknown:
        errors.append(f"analysis references unknown effect IDs: {unknown}")


def _validate_pairwise(
    analysis: Mapping[str, Any],
    errors: list[str],
) -> list[str]:
    groups = analysis.get("outcome_groups")
    if not isinstance(groups, list):
        errors.append("pairwise analysis.outcome_groups must be an array")
        return []
    selected: list[str] = []
    for index, group in enumerate(groups):
        path = f"analysis.outcome_groups[{index}]"
        if not isinstance(group, Mapping):
            errors.append(f"{path} must be an object")
            continue
        if not isinstance(group.get("name"), str) or not str(group["name"]).strip():
            errors.append(f"{path}.name must be a non-empty string")
        studies = group.get("studies")
        if not isinstance(studies, list):
            errors.append(f"{path}.studies must be an array")
            continue
        k = group.get("k")
        if not isinstance(k, int) or isinstance(k, bool) or k != len(studies):
            errors.append(f"{path}.k must equal the number of study rows")
        for study_index, study in enumerate(studies):
            study_path = f"{path}.studies[{study_index}]"
            if not isinstance(study, Mapping):
                errors.append(f"{study_path} must be an object")
                continue
            selected.extend(_ids_from_row(study, study_path, errors))
            if not _is_number(study.get("effect_size")):
                errors.append(f"{study_path}.effect_size must be finite")
            if not _is_number(study.get("se")) or float(study["se"]) <= 0:
                errors.append(f"{study_path}.se must be a positive finite number")

        pool = group.get("pooled_combined")
        if not isinstance(pool, Mapping):
            errors.append(f"{path}.pooled_combined must be an object")
            continue
        required_numbers = (
            "pooled_reml",
            "ci_lower_kh",
            "ci_upper_kh",
            "pooled_dl",
            "ci_lower_dl",
            "ci_upper_dl",
            "Q",
            "Q_df",
            "I_squared",
            "tau_squared_reml",
        )
        for name in required_numbers:
            if not _is_number(pool.get(name)):
                errors.append(f"{path}.pooled_combined.{name} must be finite")
        if pool.get("k") != len(studies):
            errors.append(f"{path}.pooled_combined.k must equal the number of studies")
        if _is_number(pool.get("I_squared")) and not 0 <= float(pool["I_squared"]) <= 100:
            errors.append(f"{path}.pooled_combined.I_squared must be between 0 and 100")
        if _is_number(pool.get("tau_squared_reml")) and float(pool["tau_squared_reml"]) < 0:
            errors.append(f"{path}.pooled_combined.tau_squared_reml cannot be negative")
        if len(studies) >= 3:
            leave_one_out = group.get("leave_one_out")
            if not isinstance(leave_one_out, list) or len(leave_one_out) != len(studies):
                errors.append(f"{path}.leave_one_out must contain one result per study")
        if len(studies) >= 10 and not isinstance(group.get("egger_test"), Mapping):
            errors.append(f"{path}.egger_test is required when k >= 10")
    return selected


def _network_structure(
    analysis: Mapping[str, Any],
) -> tuple[object, object, object]:
    network = analysis.get("network")
    container = network if isinstance(network, Mapping) else analysis
    treatments = container.get("treatments", container.get("nodes"))
    comparisons = container.get("comparisons", container.get("edges"))
    estimates = analysis.get(
        "relative_effects",
        analysis.get("treatment_effects", analysis.get("network_estimates")),
    )
    return treatments, comparisons, estimates


def _validate_network(
    analysis: Mapping[str, Any],
    errors: list[str],
) -> list[str]:
    treatments, comparisons, estimates = _network_structure(analysis)
    if (
        not isinstance(treatments, list)
        or len(treatments) < 3
        or not all(isinstance(item, str) and item.strip() for item in treatments)
    ):
        errors.append("network analysis requires at least three named treatments")
    if not isinstance(comparisons, list) or not comparisons:
        errors.append("network analysis requires direct comparisons")
        comparisons = []
    selected: list[str] = []
    for index, row in enumerate(comparisons):
        path = f"analysis.network.comparisons[{index}]"
        if not isinstance(row, Mapping):
            errors.append(f"{path} must be an object")
            continue
        selected.extend(_ids_from_row(row, path, errors))
        left = row.get("treatment_a", row.get("from"))
        right = row.get("treatment_b", row.get("to"))
        if not isinstance(left, str) or not isinstance(right, str) or left == right:
            errors.append(f"{path} requires two distinct treatment names")
    if not isinstance(estimates, list) or not estimates:
        errors.append("network analysis requires relative_effects")
    else:
        for index, row in enumerate(estimates):
            path = f"analysis.relative_effects[{index}]"
            if not isinstance(row, Mapping):
                errors.append(f"{path} must be an object")
                continue
            if not _is_number(row.get("estimate")):
                errors.append(f"{path}.estimate must be finite")

    diagnostics = analysis.get("diagnostics")
    if not isinstance(diagnostics, Mapping):
        errors.append("network analysis.diagnostics must be an object")
    else:
        if not isinstance(diagnostics.get("converged"), bool):
            errors.append("network diagnostics.converged must be boolean")
        elif diagnostics.get("converged") is not True:
            errors.append("network diagnostics report that the model did not converge")
        connectivity = diagnostics.get("connected")
        if connectivity is None and isinstance(diagnostics.get("connectivity"), Mapping):
            connectivity = diagnostics["connectivity"].get("connected")
        if not isinstance(connectivity, bool):
            errors.append("network diagnostics must report boolean connectivity")
        elif connectivity is not True:
            errors.append("network diagnostics report a disconnected treatment graph")
        inconsistency = diagnostics.get("inconsistency")
        if not isinstance(inconsistency, Mapping):
            errors.append("network diagnostics.inconsistency must be an object")
    return selected


def _validate_meta_regression(
    analysis: Mapping[str, Any],
    errors: list[str],
) -> list[str]:
    selected_raw = analysis.get("selected_effect_ids", analysis.get("effect_ids"))
    selected: list[str] = []
    if (
        not isinstance(selected_raw, list)
        or not selected_raw
        or not all(isinstance(item, str) and item.strip() for item in selected_raw)
    ):
        errors.append("meta-regression selected_effect_ids must be a non-empty string array")
    else:
        selected.extend(selected_raw)
    coefficients = analysis.get("coefficients")
    if not isinstance(coefficients, list) or not coefficients:
        errors.append("meta-regression coefficients must be a non-empty array")
    else:
        for index, coefficient in enumerate(coefficients):
            path = f"analysis.coefficients[{index}]"
            if not isinstance(coefficient, Mapping):
                errors.append(f"{path} must be an object")
                continue
            term = coefficient.get("term", coefficient.get("covariate"))
            if not isinstance(term, str) or not term.strip():
                errors.append(f"{path}.term must be a non-empty string")
            for name in ("estimate", "se", "ci_lower", "ci_upper"):
                if not _is_number(coefficient.get(name)):
                    errors.append(f"{path}.{name} must be finite")
            if _is_number(coefficient.get("se")) and float(coefficient["se"]) <= 0:
                errors.append(f"{path}.se must be positive")
    diagnostics = analysis.get("diagnostics")
    if not isinstance(diagnostics, Mapping):
        errors.append("meta-regression diagnostics must be an object")
    else:
        if not isinstance(diagnostics.get("converged"), bool):
            errors.append("meta-regression diagnostics.converged must be boolean")
        elif diagnostics.get("converged") is not True:
            errors.append("meta-regression diagnostics report that the model did not converge")
        k = diagnostics.get("k")
        if not isinstance(k, int) or isinstance(k, bool) or k != len(set(selected)):
            errors.append("meta-regression diagnostics.k must match selected effect IDs")
        residual_tau2 = diagnostics.get("residual_tau2")
        if not _is_number(residual_tau2):
            errors.append(
                "meta-regression diagnostics.residual_tau2 must be finite and non-negative"
            )
        else:
            assert isinstance(residual_tau2, (int, float))
            if float(residual_tau2) < 0:
                errors.append(
                    "meta-regression diagnostics.residual_tau2 must be finite and non-negative"
                )
        degrees_of_freedom = diagnostics.get("degrees_of_freedom")
        if not _is_number(degrees_of_freedom):
            errors.append("meta-regression diagnostics.degrees_of_freedom must be finite")
        else:
            assert isinstance(degrees_of_freedom, (int, float))
            if float(degrees_of_freedom) <= 0:
                errors.append("meta-regression diagnostics.degrees_of_freedom must be positive")
    return selected


def validate_analysis(
    analysis: object,
    effects: Sequence[Mapping[str, Any]] | None = None,
    *,
    expected_type: str | None = None,
) -> ValidationReport:
    """Validate a canonical analysis object against its source effects."""
    if not isinstance(analysis, Mapping):
        return ValidationReport(None, ["analysis.json must contain a JSON object"])
    analysis_type = _analysis_type(analysis)
    report = ValidationReport(analysis_type)
    if analysis_type not in ANALYSIS_TYPES:
        report.errors.append("analysis_type must be one of: " + ", ".join(ANALYSIS_TYPES))
        return report
    if expected_type is not None and analysis_type != expected_type:
        report.errors.append(
            f"analysis type {analysis_type!r} does not match specification {expected_type!r}"
        )

    _check_finite(analysis, "analysis", report.errors)
    _check_intervals(analysis, "analysis", report.errors)
    source_ids = _effect_ids(effects, report.errors)
    if analysis_type == "pairwise":
        selected = _validate_pairwise(analysis, report.errors)
    elif analysis_type == "network":
        selected = _validate_network(analysis, report.errors)
    else:
        selected = _validate_meta_regression(analysis, report.errors)
    if len(selected) != len(set(selected)):
        report.errors.append("model results reference a selected effect ID more than once")
    report.selected_effect_ids = sorted(set(selected), key=str.casefold)
    _validate_selection(analysis, source_ids, selected, report.errors)
    return report


def validate_analysis_file(
    path: Path | str,
    effects_path: Path | str | None = None,
    *,
    expected_type: str | None = None,
) -> ValidationReport:
    """Load and validate analysis JSON and an optional effects artifact."""
    target = Path(path)
    try:
        analysis = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return ValidationReport(None, [f"cannot read {target}: {exc}"])
    effects: list[Mapping[str, Any]] | None = None
    if effects_path is not None:
        source = Path(effects_path)
        try:
            raw_effects = json.loads(source.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            return ValidationReport(None, [f"cannot read {source}: {exc}"])
        if not isinstance(raw_effects, list) or not all(
            isinstance(item, Mapping) for item in raw_effects
        ):
            return ValidationReport(None, [f"{source} must contain an array of objects"])
        effects = raw_effects
    return validate_analysis(analysis, effects, expected_type=expected_type)
