"""Universal card-model helpers for guided evidence extraction."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

CARD_MODEL_VERSION = 1
CARD_TYPES = (
    "source_context",
    "analysis_unit",
    "finding",
    "definition",
    "relationship",
    "assessment",
)
LEGACY_CARD_TYPE_ALIASES = {
    "paper_context": "source_context",
    "patient_group": "analysis_unit",
}


def _label(value: object) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    return value.strip().casefold().replace("-", "_").replace(" ", "_")


def normalize_card_type(value: object) -> str | None:
    """Return a canonical broad card type, including legacy aliases."""
    normalized = _label(value)
    if normalized is None:
        return None
    normalized = LEGACY_CARD_TYPE_ALIASES.get(normalized, normalized)
    return normalized if normalized in CARD_TYPES else None


def original_card_type(payload: Mapping[str, Any]) -> str | None:
    """Return the broad type label as supplied by an extractor."""
    for key in ("card_type", "type"):
        value = _label(payload.get(key))
        if normalize_card_type(value) is not None:
            return value
    return None


def canonical_card_type(payload: Mapping[str, Any]) -> str:
    """Classify a payload without rejecting legacy untyped structured claims."""
    for key in ("card_type", "type"):
        normalized = normalize_card_type(payload.get(key))
        if normalized is not None:
            return normalized
    # Claims created before the card model used project-specific ``type`` values
    # such as ``effect`` or ``manufacturing_observation``. They are findings,
    # while their original discriminator remains the dynamic record type.
    return "finding"


def dynamic_record_type(
    payload: Mapping[str, Any],
    *,
    card_type: str | None = None,
) -> str:
    """Return the project-defined subtype/category without fixing its vocabulary."""
    canonical = card_type or canonical_card_type(payload)
    for key in ("record_type", "category"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            normalized = normalize_card_type(value)
            if normalized is None or normalized != canonical:
                return value.strip()
    if canonical == "analysis_unit":
        value = payload.get("unit_type")
        if isinstance(value, str) and value.strip():
            return value.strip()
    if canonical == "assessment":
        value = payload.get("assessment_type")
        if isinstance(value, str) and value.strip():
            return value.strip()
    supplied_type = payload.get("type")
    if isinstance(supplied_type, str) and supplied_type.strip():
        if normalize_card_type(supplied_type) is None:
            return supplied_type.strip()
    return canonical


def assessment_provenance(payload: Mapping[str, Any]) -> dict[str, Any] | None:
    """Copy explicit reviewer/Claude provenance without inventing missing fields."""
    value = payload.get("assessment_provenance")
    return dict(value) if isinstance(value, Mapping) else None


def has_explicit_assessment_source_support(payload: Mapping[str, Any]) -> bool:
    """Whether an assessment explicitly identifies support reported by a source."""
    provenance = assessment_provenance(payload) or {}
    for container in (provenance, payload):
        if container.get("source_supported") is True:
            return True
        for key in ("source_support", "source_evidence"):
            if container.get(key) not in (None, "", [], {}):
                return True
    return False


def normalize_finding_card(finding: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize a verified-finding row for backward-compatible guided imports."""
    normalized = dict(finding)
    payload = finding.get("raw_payload")
    payload = payload if isinstance(payload, Mapping) else {}
    supplied: object = finding.get("card_type")
    if normalize_card_type(supplied) is None:
        supplied = finding.get("record_type")
    if normalize_card_type(supplied) is None:
        supplied = original_card_type(payload)
    canonical = normalize_card_type(supplied) or canonical_card_type(payload)
    normalized["card_type"] = canonical

    record_type = finding.get("record_type")
    if (
        not isinstance(record_type, str)
        or not record_type.strip()
        or normalize_card_type(record_type) is not None
    ):
        record_type = dynamic_record_type(payload, card_type=canonical)
    normalized["record_type"] = str(record_type)

    supplied_label = _label(supplied)
    payload_label = original_card_type(payload)
    legacy_label = next(
        (
            label
            for label in (payload_label, supplied_label)
            if label in LEGACY_CARD_TYPE_ALIASES
        ),
        None,
    )
    if legacy_label is not None:
        normalized["legacy_card_type"] = legacy_label

    if canonical == "assessment":
        provenance = assessment_provenance(payload)
        if provenance is not None:
            normalized["assessment_provenance"] = provenance
        source_supported = has_explicit_assessment_source_support(payload)
        normalized["source_fact_status"] = (
            "explicit_source_support" if source_supported else "reviewer_judgment"
        )
        normalized["verification_scope"] = (
            "source_supported_assessment"
            if source_supported
            else "assessment_provenance_only"
        )
    else:
        normalized.setdefault("source_fact_status", "source_reported")
        normalized.setdefault("verification_scope", "source_supported_card")
    return normalized


def card_model_metadata() -> dict[str, Any]:
    """Return stable export metadata describing the universal card envelope."""
    return {
        "version": CARD_MODEL_VERSION,
        "card_types": list(CARD_TYPES),
        "legacy_type_aliases": dict(LEGACY_CARD_TYPE_ALIASES),
        "record_type_policy": "project_defined",
        "assessment_policy": (
            "assessment is reviewer or Claude judgment; source support must be explicit "
            "and assessment provenance is preserved"
        ),
    }


def validate_card_payload(payload: Mapping[str, Any], card_type: str) -> list[str]:
    """Validate only universal semantics for special broad card types."""
    errors: list[str] = []
    explicit_card_type = payload.get("card_type")
    if explicit_card_type is not None and normalize_card_type(explicit_card_type) is None:
        errors.append("card_type must identify a universal guided card type")
    data = payload.get("data")
    if data is not None and not isinstance(data, Mapping):
        errors.append("card data must be an object when present")
    project_data = data if isinstance(data, Mapping) else payload
    if card_type == "analysis_unit":
        unit_type = payload.get("unit_type", project_data.get("unit_type"))
        legacy_unit = original_card_type(payload) == "patient_group"
        if not legacy_unit and (not isinstance(unit_type, str) or not unit_type.strip()):
            errors.append("analysis_unit requires a dynamic non-empty unit_type")
        count = payload.get("count", project_data.get("count"))
        if count is not None and (
            not isinstance(count, int) or isinstance(count, bool) or count < 0
        ):
            errors.append("analysis_unit count must be a non-negative integer when present")
        relationships = payload.get("relationships")
        if relationships is not None and not (
            isinstance(relationships, list)
            and all(isinstance(item, Mapping) for item in relationships)
        ):
            errors.append("analysis_unit relationships must be an array of objects")
        for key in ("parent_unit_id", "subset_of"):
            value = payload.get(key, project_data.get(key))
            if value is not None and (not isinstance(value, str) or not value.strip()):
                errors.append(f"analysis_unit {key} must be a non-empty string when present")
    if card_type == "assessment":
        provenance = assessment_provenance(payload)
        if provenance is None:
            errors.append("assessment requires assessment_provenance")
        else:
            assessor = provenance.get("assessor")
            if not isinstance(assessor, str) or not assessor.strip():
                errors.append("assessment_provenance.assessor must be a non-empty string")
            basis = (
                provenance.get("basis")
                or provenance.get("method")
                or provenance.get("rationale")
            )
            if not isinstance(basis, str) or not basis.strip():
                errors.append(
                    "assessment_provenance must preserve a non-empty basis, method, or rationale"
                )
    return errors
