# Example-only network meta-analysis skeleton.
# This file is intentionally blocked by the managed runner unless runtime.json
# declares an installed Rscript executable and the exact required packages.
library(netmeta)
library(jsonlite)

stop(
  "Descriptor example only: adapt treatment orientation and diagnostics to the finalized spec."
)
