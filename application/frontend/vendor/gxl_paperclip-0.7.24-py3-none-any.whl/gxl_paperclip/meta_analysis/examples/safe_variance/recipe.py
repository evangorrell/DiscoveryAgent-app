"""Example-only delegation to Paperclip's deterministic precision derivations."""

from __future__ import annotations

from typing import Any

from gxl_paperclip.meta_analysis.precision import derive_precision


def derive_with_provenance(effect: dict[str, Any]) -> dict[str, Any]:
    """Derive precision only when one supported formula has complete inputs."""
    result = derive_precision(effect)
    return {
        "effect_id": effect["effect_id"],
        "se": result["se"],
        "ci_lower": result["interval"]["lower"],
        "ci_upper": result["interval"]["upper"],
        **result["provenance"],
    }
