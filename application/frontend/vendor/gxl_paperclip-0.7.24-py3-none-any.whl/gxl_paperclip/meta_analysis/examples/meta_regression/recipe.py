"""Example-only weighted meta-regression using NumPy."""

from __future__ import annotations

import math
from typing import Any

import numpy as np


def build_meta_regression(effects: list[dict[str, Any]], covariates: list[str]) -> dict[str, Any]:
    """Fit a weighted linear model after all selection decisions are frozen."""
    x = np.asarray(
        [[1.0] + [float(row["covariates"][name]) for name in covariates] for row in effects]
    )
    y = np.asarray([float(row["effect_size"]) for row in effects])
    variance = np.asarray([float(row["se"]) ** 2 for row in effects])
    w = np.diag(1 / variance)
    information = x.T @ w @ x
    covariance = np.linalg.inv(information)
    beta = covariance @ x.T @ w @ y
    residuals = y - x @ beta
    degrees_of_freedom = len(effects) - len(beta)
    if degrees_of_freedom <= 0:
        raise ValueError("meta-regression requires positive residual degrees of freedom")
    dispersion = float((residuals.T @ w @ residuals) / degrees_of_freedom)
    covariance = covariance * max(1.0, dispersion)
    terms = ["intercept", *covariates]
    coefficients = []
    for index, term in enumerate(terms):
        estimate = float(beta[index])
        se = math.sqrt(float(covariance[index, index]))
        coefficients.append(
            {
                "term": term,
                "estimate": estimate,
                "se": se,
                "ci_lower": estimate - 1.96 * se,
                "ci_upper": estimate + 1.96 * se,
            }
        )
    ids = [str(row["effect_id"]) for row in effects]
    count = len(ids)
    return {
        "analysis_type": "meta_regression",
        "n_effects_compiled_verified": count,
        "n_effects_selected_primary_pooling": count,
        "selection_accounting": {
            "verified_effects_available": count,
            "effects_selected_primary_pooling": count,
            "effects_secondary_or_sensitivity": 0,
            "effects_excluded_explicit": 0,
            "effects_excluded_missing_variance": 0,
        },
        "selected_effect_ids": ids,
        "covariates": covariates,
        "coefficients": coefficients,
        "diagnostics": {
            "converged": True,
            "k": count,
            "degrees_of_freedom": degrees_of_freedom,
            "residual_tau2": 0.0,
            "weighted_residual_dispersion": dispersion,
        },
    }
