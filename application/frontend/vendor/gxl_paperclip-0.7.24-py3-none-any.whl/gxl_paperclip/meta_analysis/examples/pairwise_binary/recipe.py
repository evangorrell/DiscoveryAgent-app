"""Example-only inverse-variance binary RR/OR recipe using NumPy."""

from __future__ import annotations

import math
from typing import Any

import numpy as np


def build_binary_analysis(effects: list[dict[str, Any]], measure: str = "risk_ratio") -> dict:
    """Return a small canonical pairwise fixture from explicit 2x2 arm counts."""
    if measure not in {"risk_ratio", "odds_ratio"}:
        raise ValueError("measure must be risk_ratio or odds_ratio")
    theta: list[float] = []
    variances: list[float] = []
    studies: list[dict[str, Any]] = []
    for row in effects:
        a = float(row["arm_1_events"]) + 0.5
        b = float(row["arm_1_denominator"]) - float(row["arm_1_events"]) + 0.5
        c = float(row["arm_2_events"]) + 0.5
        d = float(row["arm_2_denominator"]) - float(row["arm_2_events"]) + 0.5
        estimate = (a / (a + b)) / (c / (c + d))
        variance = 1 / a - 1 / (a + b) + 1 / c - 1 / (c + d)
        if measure == "odds_ratio":
            estimate = (a * d) / (b * c)
            variance = 1 / a + 1 / b + 1 / c + 1 / d
        log_effect = math.log(estimate)
        se = math.sqrt(variance)
        theta.append(log_effect)
        variances.append(variance)
        studies.append(
            {
                "effect_id": row["effect_id"],
                "effect_size": estimate,
                "ci_lower": math.exp(log_effect - 1.96 * se),
                "ci_upper": math.exp(log_effect + 1.96 * se),
                "theta": log_effect,
                "se": se,
                "independent_unit_id": row["independent_unit_id"],
            }
        )
    weights = 1 / np.asarray(variances)
    mean = float(np.average(np.asarray(theta), weights=weights))
    se_mean = float(math.sqrt(1 / np.sum(weights)))
    q = float(np.sum(weights * (np.asarray(theta) - mean) ** 2))
    df = max(0, len(theta) - 1)
    pooled = {
        "k": len(studies),
        "pooled_reml": math.exp(mean),
        "ci_lower_kh": math.exp(mean - 1.96 * se_mean),
        "ci_upper_kh": math.exp(mean + 1.96 * se_mean),
        "knapp_hartung_used": False,
        "pooled_dl": math.exp(mean),
        "ci_lower_dl": math.exp(mean - 1.96 * se_mean),
        "ci_upper_dl": math.exp(mean + 1.96 * se_mean),
        "prediction_interval": [
            math.exp(mean - 1.96 * se_mean),
            math.exp(mean + 1.96 * se_mean),
        ],
        "Q": q,
        "Q_df": df,
        "I_squared": max(0.0, (q - df) / q * 100) if q else 0.0,
        "tau_squared_reml": 0.0,
    }
    count = len(effects)
    return {
        "analysis_type": "pairwise",
        "n_effects_compiled_verified": count,
        "n_effects_selected_primary_pooling": count,
        "selection_accounting": {
            "verified_effects_available": count,
            "effects_selected_primary_pooling": count,
            "effects_secondary_or_sensitivity": 0,
            "effects_excluded_explicit": 0,
            "effects_excluded_missing_variance": 0,
        },
        "outcome_groups": [
            {
                "name": str(effects[0]["outcome_group"]),
                "effect_measure": measure,
                "scale": "log",
                "k": count,
                "studies": studies,
                "pooled_combined": pooled,
                "egger_test": None,
                "leave_one_out": [],
            }
        ],
    }
