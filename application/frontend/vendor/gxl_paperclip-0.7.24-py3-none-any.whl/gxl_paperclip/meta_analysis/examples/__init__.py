"""Optional package-backed reference recipes for managed analyses.

Examples illustrate API and data-shape choices. They are explicitly not
statistical correctness contracts; canonical outputs are validated separately.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from gxl_paperclip.analysis_project.store import sha256_file

REQUIRED_DESCRIPTOR_FIELDS = (
    "id",
    "example_only",
    "compatible_analysis_types",
    "assumptions",
    "required_fields",
    "packages",
    "limitations",
    "do_not_use_when",
)


def examples_root() -> Path:
    return Path(__file__).resolve().parent


def validate_example_descriptor(value: object, *, source: str = "example.json") -> list[str]:
    """Validate safety and disclosure metadata for an example recipe."""
    if not isinstance(value, Mapping):
        return [f"{source} must contain a JSON object"]
    errors: list[str] = []
    for field in REQUIRED_DESCRIPTOR_FIELDS:
        if field not in value:
            errors.append(f"{source}: missing {field}")
    if value.get("example_only") is not True:
        errors.append(f"{source}: example_only must be true")
    if value.get("correctness_contract") not in (None, False):
        errors.append(f"{source}: examples cannot be correctness contracts")
    compatible = value.get("compatible_analysis_types")
    if (
        not isinstance(compatible, list)
        or not compatible
        or not all(item in {"pairwise", "network", "meta_regression"} for item in compatible)
    ):
        errors.append(f"{source}: compatible_analysis_types is invalid")
    for field in (
        "assumptions",
        "required_fields",
        "packages",
        "limitations",
        "do_not_use_when",
    ):
        item = value.get(field)
        if not isinstance(item, list) or not all(
            isinstance(entry, str) and entry.strip() for entry in item
        ):
            errors.append(f"{source}: {field} must be a string array")
    language = value.get("language", "python")
    if language not in {"python", "r", "descriptor"}:
        errors.append(f"{source}: language must be python, r, or descriptor")
    entrypoint = value.get("entrypoint")
    if language in {"python", "r"} and (not isinstance(entrypoint, str) or not entrypoint.strip()):
        errors.append(f"{source}: executable examples require entrypoint")
    return errors


def load_example_descriptors() -> dict[str, dict[str, Any]]:
    """Load and validate every bundled example descriptor."""
    descriptors: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    for path in sorted(examples_root().glob("*/example.json")):
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"{path}: {exc}")
            continue
        descriptor_errors = validate_example_descriptor(
            value, source=str(path.relative_to(examples_root()))
        )
        errors.extend(descriptor_errors)
        if not descriptor_errors:
            example_id = str(value["id"])
            if example_id in descriptors:
                errors.append(f"duplicate example id: {example_id}")
            else:
                value["_directory"] = str(path.parent)
                descriptors[example_id] = value
    if errors:
        raise ValueError("; ".join(errors))
    return descriptors


def _atomic_json(path: Path, value: object) -> None:
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def record_example_use(
    topic_dir: Path | str,
    example_id: str,
    *,
    deviations: list[str],
) -> dict[str, Any]:
    """Record an example only after the analysis specification is finalized."""
    topic = Path(topic_dir).expanduser().resolve()
    bundle = topic / "analysis"
    spec_path = bundle / "analysis_spec.json"
    runtime_path = bundle / "runtime.json"
    methods_path = bundle / "methods.md"
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    runtime = json.loads(runtime_path.read_text(encoding="utf-8"))
    if not isinstance(spec, dict) or not (
        spec.get("finalized") is True or spec.get("status") in {"final", "finalized", "approved"}
    ):
        raise ValueError("finalize analysis_spec.json before selecting an example")
    if (
        spec.get("schema_version") != 1
        or spec.get("analysis_type") not in {"pairwise", "network", "meta_regression"}
        or not isinstance(spec.get("inputs"), (list, dict))
        or not spec.get("inputs")
        or not isinstance(spec.get("outputs"), dict)
    ):
        raise ValueError("validate and finalize analysis_spec.json before selecting an example")
    if not isinstance(runtime, dict):
        raise ValueError("runtime.json must contain an object")
    if not isinstance(deviations, list) or not all(
        isinstance(item, str) and item.strip() for item in deviations
    ):
        raise ValueError("deviations must be a string array (empty is allowed)")
    descriptors = load_example_descriptors()
    if example_id not in descriptors:
        raise ValueError(f"unknown analysis example: {example_id}")
    descriptor = descriptors[example_id]
    if spec.get("analysis_type") not in descriptor["compatible_analysis_types"]:
        raise ValueError(f"example {example_id} is incompatible with {spec.get('analysis_type')!r}")
    required_packages = set(descriptor["packages"])
    declarations = runtime.get("packages")
    if not isinstance(declarations, list):
        raise ValueError("runtime.packages must be declared before selecting examples")
    declared_packages = {
        item if isinstance(item, str) else item.get("name")
        for item in declarations
        if isinstance(item, (str, dict))
    }
    missing = sorted(required_packages - declared_packages)
    if missing:
        raise ValueError(f"example {example_id} requires undeclared runtime packages: {missing}")
    if descriptor.get("language") == "r":
        executable = str(runtime.get("executable", ""))
        if runtime.get("language") != "r" or "rscript" not in Path(executable).name.lower():
            raise ValueError(
                "R examples remain blocked until runtime.json declares language=r, "
                "an Rscript executable, and all required packages"
            )
        resolved = (
            executable
            if Path(executable).is_absolute() and Path(executable).is_file()
            else shutil.which(executable)
        )
        if not resolved:
            raise ValueError("the declared Rscript executable is not present")
        quoted = ",".join(json.dumps(name) for name in sorted(required_packages))
        probe = (
            f"p<-c({quoted});"
            "if(any(!vapply(p,requireNamespace,logical(1),quietly=TRUE)))quit(status=2)"
        )
        checked = subprocess.run(
            [resolved, "-e", probe],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if checked.returncode != 0:
            raise ValueError("one or more declared R example packages are not present")

    examples = runtime.setdefault("examples", [])
    if not isinstance(examples, list):
        raise ValueError("runtime.examples must be an array")
    examples[:] = [
        item for item in examples if not isinstance(item, dict) or item.get("id") != example_id
    ]
    examples.append({"id": example_id, "deviations": deviations, "example_only": True})
    runtime["analysis_spec_sha256"] = sha256_file(spec_path)
    _atomic_json(runtime_path, runtime)

    methods = methods_path.read_text(encoding="utf-8") if methods_path.is_file() else ""
    marker = f"## Reference example: {example_id}"
    if marker not in methods:
        deviation_text = "\n".join(f"- {item}" for item in deviations) or "- None recorded."
        methods = (
            methods.rstrip()
            + f"\n\n{marker}\n"
            + "Used as an example only, not as a correctness contract.\n\n"
            + "Deviations:\n"
            + deviation_text
            + "\n"
        )
        methods_path.write_text(methods, encoding="utf-8")
    return descriptor


__all__ = [
    "REQUIRED_DESCRIPTOR_FIELDS",
    "examples_root",
    "load_example_descriptors",
    "record_example_use",
    "validate_example_descriptor",
]
