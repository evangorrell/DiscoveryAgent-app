"""Example-only continuous MD/SMD recipe using NumPy."""

from __future__ import annotations

import math
from typing import Any

import numpy as np


def continuous_effect(row: dict[str, Any], measure: str) -> tuple[float, float]:
    n1, n2 = float(row["arm_1_n"]), float(row["arm_2_n"])
    mean_difference = float(row["arm_1_mean"]) - float(row["arm_2_mean"])
    sd1, sd2 = float(row["arm_1_sd"]), float(row["arm_2_sd"])
    if measure == "mean_difference":
        return mean_difference, sd1 * sd1 / n1 + sd2 * sd2 / n2
    if measure != "standardized_mean_difference":
        raise ValueError("measure must be mean_difference or standardized_mean_difference")
    pooled_sd = math.sqrt(((n1 - 1) * sd1 * sd1 + (n2 - 1) * sd2 * sd2) / (n1 + n2 - 2))
    raw_d = mean_difference / pooled_sd
    correction = 1 - 3 / (4 * (n1 + n2) - 9)
    hedges_g = correction * raw_d
    variance = (n1 + n2) / (n1 * n2) + hedges_g * hedges_g / (2 * (n1 + n2 - 2))
    return hedges_g, variance


def build_continuous_analysis(
    effects: list[dict[str, Any]], measure: str = "mean_difference"
) -> dict:
    estimates: list[float] = []
    variances: list[float] = []
    studies: list[dict[str, Any]] = []
    for row in effects:
        estimate, variance = continuous_effect(row, measure)
        se = math.sqrt(variance)
        estimates.append(estimate)
        variances.append(variance)
        studies.append(
            {
                "effect_id": row["effect_id"],
                "effect_size": estimate,
                "ci_lower": estimate - 1.96 * se,
                "ci_upper": estimate + 1.96 * se,
                "theta": estimate,
                "se": se,
                "independent_unit_id": row["independent_unit_id"],
            }
        )
    weights = 1 / np.asarray(variances)
    mean = float(np.average(np.asarray(estimates), weights=weights))
    se_mean = float(math.sqrt(1 / np.sum(weights)))
    q = float(np.sum(weights * (np.asarray(estimates) - mean) ** 2))
    df = max(0, len(studies) - 1)
    lower, upper = mean - 1.96 * se_mean, mean + 1.96 * se_mean
    count = len(studies)
    return {
        "analysis_type": "pairwise",
        "n_effects_compiled_verified": count,
        "n_effects_selected_primary_pooling": count,
        "selection_accounting": {
            "verified_effects_available": count,
            "effects_selected_primary_pooling": count,
            "effects_secondary_or_sensitivity": 0,
            "effects_excluded_explicit": 0,
            "effects_excluded_missing_variance": 0,
        },
        "outcome_groups": [
            {
                "name": str(effects[0]["outcome_group"]),
                "effect_measure": measure,
                "scale": "raw",
                "k": count,
                "studies": studies,
                "pooled_combined": {
                    "k": count,
                    "pooled_reml": mean,
                    "ci_lower_kh": lower,
                    "ci_upper_kh": upper,
                    "knapp_hartung_used": False,
                    "pooled_dl": mean,
                    "ci_lower_dl": lower,
                    "ci_upper_dl": upper,
                    "prediction_interval": [lower, upper],
                    "Q": q,
                    "Q_df": df,
                    "I_squared": max(0.0, (q - df) / q * 100) if q else 0.0,
                    "tau_squared_reml": 0.0,
                },
                "egger_test": None,
                "leave_one_out": [],
            }
        ],
    }
