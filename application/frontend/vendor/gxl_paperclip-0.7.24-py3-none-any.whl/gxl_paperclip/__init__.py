"""Paperclip — Paper CLI for Preprints + PMC.

Also the entry point for the Python SDK:

    from gxl_paperclip import PaperclipClient, APIKeyAuth

    client = PaperclipClient(auth=APIKeyAuth("pk_..."))
    print(client.search("protein design", limit=5).output)
"""

__version__: str = "0.0.0"
try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("gxl-paperclip")
except Exception:
    pass

from .client import (
    APIKeyAuth,
    AuthError,
    AuthStrategy,
    BearerAuth,
    ExecuteResult,
    FileCredentialsAuth,
    HealthStatus,
    MapEvent,
    MapProgressEvent,
    MapResultEvent,
    NetworkError,
    NotFoundError,
    PaperclipClient,
    PaperclipError,
    RateLimitError,
    RequestTimeoutError,
    ResultData,
    ResultRow,
    ServerError,
)

__all__ = [
    "__version__",
    "PaperclipClient",
    # Auth
    "APIKeyAuth",
    "AuthStrategy",
    "BearerAuth",
    "FileCredentialsAuth",
    # Errors
    "AuthError",
    "NetworkError",
    "NotFoundError",
    "PaperclipError",
    "RateLimitError",
    "RequestTimeoutError",
    "ServerError",
    # Models
    "ExecuteResult",
    "HealthStatus",
    "MapEvent",
    "MapProgressEvent",
    "MapResultEvent",
    "ResultData",
    "ResultRow",
]
