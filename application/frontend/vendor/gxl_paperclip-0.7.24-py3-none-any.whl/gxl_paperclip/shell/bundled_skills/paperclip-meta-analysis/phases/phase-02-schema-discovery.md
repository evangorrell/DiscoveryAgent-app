> ### Internal subroutine · Map-Based Schema Discovery · User stage: Question
> - **Consumes:** draft scope/eligibility, `source_readiness.json`, and a small
>   representative discovery set.
> - **Produces:** durable schema-discovery map manifests,
>   `schema_discovery.json`, and a Claude-authored
>   `schema_optimization.candidate.json`.
> - **Precondition:** enough source access exists to inspect representative
>   papers; final Question approval is not required yet.
> - **Next:** present the discovered collection design at the Question
>   checkpoint. After approval, generate the project extraction schema and run
>   the separate Evidence pilot.

## Phase 2a: Discover the Project Schema with Map

Schema discovery and evidence extraction use two different forms:

1. `schema-discovery.schema.json` is fixed and reusable. It records candidate
   fields/options, original wording, exact source paths/lines, ambiguity, scope,
   and rationale.
2. `extraction_schema.json` is generated later for this project. It records the
   actual study findings required by the approved question and outputs.

Never use an unconstrained free-text map as the standard schema-discovery
artifact. Free text may be used for optional brainstorming, but it cannot
support schema approval because paths, line ranges, labels, and option
provenance may be missing or inconsistent.

### Select a small representative discovery set

Choose approximately 3–8 papers spanning the likely variation:

- simple and dense papers;
- primary studies, real-world evidence, trials, reviews used for discovery,
  and any other relevant source roles;
- major products/methods, populations, outcomes, analysis units, definitions,
  timepoints, units, and missingness patterns;
- terminology and categorical variation;
- papers expected to contain edge cases.

The set is for designing the form, not proving evidence saturation. Record why
each paper was selected and whether its content is focal evidence, background,
or discovery-only.

### Run structured schema discovery

Use one map worker per paper and the bundled discovery schema:

```bash
paperclip map --worker structured-extraction --tag <slug>-schema-discovery \
  --output_schema "$(cat schema-discovery.schema.json)" \
  -j 8 \
  "This is schema discovery, not final evidence extraction. Apply the draft \
scope. Propose only fields/options relevant to the project. Preserve original \
wording and attach the exact absolute readable path and exact line range to \
every source example. Put background-only or out-of-scope concepts in \
out_of_scope_observations. Do not infer image-only evidence."
```

Every paper returns one strict discovery object. A candidate field or
categorical option without a current-paper source example is not eligible for
approval. The map manifest freezes the worker, model, prompt, discovery-schema
hash, code revision, and packet provenance.

Schema discovery runs papers in parallel. It does not mutate a repo and it does
not produce verified findings.

### Merge discoveries without pretending completeness

Claude combines the paper-level observations into
`schema_discovery.json` and authors `schema_optimization.candidate.json`.
This is scientific normalization, not a text concatenation:

- merge obvious spelling, punctuation, abbreviation, generic/brand, and case
  variants while preserving every `as_reported` value;
- do not promote products, diseases, methods, or outcomes mentioned only as
  background into focal options;
- keep distinct meanings separate even when wording is similar;
- preserve conflicting definitions, denominator rules, grading systems,
  analysis units, and timepoints as explicit ambiguities;
- deduplicate source examples but retain more than one when they demonstrate
  meaningful variation;
- record which proposed fields and options appeared in how many discovery
  papers;
- treat the LLM's list as provisional. It is never guaranteed comprehensive.

### Use bounded, open, and hybrid vocabularies deliberately

Each candidate field selects a vocabulary policy:

- **bounded:** a small stable list needed for analysis or validation, such as
  value status, setting, effect unit, or a protocol-defined grade grouping;
- **open:** free-form source identities that cannot be enumerated safely, such
  as detailed product names, outcome names, assays, cohort labels, or
  complications;
- **hybrid:** a small stable broad family plus an open normalized/detail field.

For open-ended identities, require both the source wording and a normalized
value when normalization is useful:

```json
{
  "outcome_family": "toxicity",
  "outcome_as_reported": "immune effector cell-associated enterocolitis",
  "outcome_id": "iec_associated_enterocolitis"
}
```

For a bounded option not seen during discovery, use `other` plus sourced
`other_detail`. Never force an unseen concept into the nearest known option.
Log new scaled labels in `schema_observations.json`; obvious aliases may be
approved mechanically, while changed scientific grouping is material.

### Question checkpoint

Present:

- proposed categories and fields in plain language;
- required versus optional fields;
- bounded/open/hybrid vocabulary decisions;
- proposed options/aliases and their source examples;
- excluded background-only discoveries;
- unresolved scope and normalization choices;
- planned analyses/visualizations that depend on each field.

> **CHECKPOINT — ASK THE USER:** Approve the provisional collection/schema
> design, request changes, narrow/expand scope, or stop. The map result is
> evidence for the proposal, not user approval. After approval, generate
> `extraction_schema.json`; do not lock it until the separate representative
> extraction pilot passes.
