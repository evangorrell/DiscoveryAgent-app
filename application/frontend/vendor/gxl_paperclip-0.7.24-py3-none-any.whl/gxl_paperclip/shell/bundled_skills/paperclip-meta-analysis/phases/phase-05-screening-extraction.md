> ### Internal subroutine · Pilot, Screening, and Extraction · User stage: Evidence
> - **Consumes:** approved `protocol.json`, `collection_spec.json`,
>   `planned_outputs.json`, the Phase-3 extraction instructions, and
>   locked `extraction_schema.json`, and deduplicated Phase-4 candidate waves.
> - **Produces:** a representative pilot summary; user-approved material
>   revisions; durable schema-valid paper outputs; deterministic
>   `repo_staging.json`; line-pinned repo claims; `search_log.json`; and
>   `extraction_audit.json`.
> - **Precondition:** Question approval exists. Extraction does not mutate the
>   repo. One orchestrator owns repo staging/addition and final verification.
> - **Next:** Phase 6 only after all scaled workers join and saturation/coverage
>   are documented.

## Phase 5: Representative Pilot, Screening, and Extraction

The fixed order is:

```text
representative structured pilot
→ temporary exhaustive-worker comparison and contract validation
→ AskUserQuestion for material revisions
→ rerun pilot until approved and passing
→ show final generated schema + pilot changes
→ AskUserQuestion for explicit final-schema approval
→ lock optimized schema and categorical options
→ scaled screen/extract waves
→ coverage/gap search loop
→ join all workers
→ repo-stage → repo-add → verification/export
```

Never launch the full corpus before a representative pilot is bound to the
current approved collection schema and output plan.

This pilot tests the project extraction schema generated from Stage-1
map-based schema discovery. It is not a second free-text schema-discovery map.
If the pilot reveals a materially missing category, field, vocabulary policy,
relationship, or normalization boundary, return to the Question checkpoint,
revise the proposal, and regenerate the project schema.

### 5a. Full-text eligibility screening

Apply `protocol.json` to each deduplicated candidate. The screening task reads
the full paper in the same one-turn full-paper reader runtime used by ordinary
maps and returns one protocol-grounded decision:

```bash
paperclip map --worker eligibility-screen --tag <slug>-sweep \
  --output_schema '{"decision":"yes|no|uncertain","reason":"protocol-grounded reason"}' \
  -j 32 \
  "Read the full paper. Apply protocol.json exactly. Return one decision and reason."
```

Resolve `uncertain` before extraction. Log one exclusion reason per excluded
full text. Do not replace project-specific eligibility with generic
"meta-analysis only", "RCT only", or "peer-reviewed only" rules.

### 5b. Select a representative pilot

Choose a small but diverse set that spans as many of these as applicable:

- source and study/document designs;
- major collection categories and analysis-unit types;
- expected effectiveness, survival, safety, population, manufacturing,
  methods, or other project-defined domains;
- terminology, definition, timepoint, denominator, and grading variation;
- missing/ambiguous cases;
- both simple and dense papers.

Run the one-turn structured worker and the existing exhaustive worker on the
same pilot papers. This temporary comparison is a migration test, not permanent
double extraction. Compare stable records/claims, individually sourced values,
source paths/lines, relationships, missingness, ambiguity, visual exclusions,
category coverage, runtime, model calls, fallback rate, and verifier pass rate.
Record:

```json
{
  "papers": [],
  "coverage": {},
  "ambiguities": [],
  "validation": {"status": "pass"},
  "independent_agreement": {
    "status": "pass",
    "field_recall": 0.0,
    "value_agreement": 0.0,
    "source_location_agreement": 0.0,
    "verifier_pass_rate": 0.0,
    "runtime_seconds": {},
    "model_calls": {},
    "fallback_rate": 0.0
  }
}
```

Pilot completion requires passing contract validation and independent
agreement. A plausible-looking extraction is not enough.

Generate the deterministic comparison artifact:

```bash
python3 guided_analysis.py pilot-compare \
  --dir <topic_dir> \
  --structured-manifest <structured-pilot-manifest.json> \
  --exhaustive-manifest <exhaustive-pilot-manifest.json> \
  --json
```

`pilot_comparison.json` reports field-instance recall independent of LLM record
IDs, normalized value agreement, exact source-path/line agreement, exact
record-ID agreement as a separate diagnostic, verifier pass rates when
supplied, runtime, model calls, fallback rate, and every material difference.
Review differences rather than averaging them away.

### 5c. Review pilot revisions with the user

Classify pilot findings:

- **mechanical:** obvious spelling/case/punctuation aliases that do not change
  meaning;
- **material:** changed category meaning, normalized-group membership,
  hierarchy, definition, timepoint, denominator, grading system, required
  field, relationship, scope, or planned output.

Mechanical aliases may be added while preserving original labels. Batch all
material choices into one concise explanation of their Evidence/Results
impact.

> **CHECKPOINT — ASK THE USER:** Use `AskUserQuestion` to approve the proposed
> material revisions, choose among alternatives, keep the current contract, or
> stop. Apply only the explicit answer. Claude manages private lifecycle steps;
> never ask the user to run a helper command.

Any material revision reopens Question approval, invalidates the schema lock,
and marks the pilot stale.
Update `protocol_draft.json`, `collection_spec.json`, or
`planned_outputs.json` as appropriate, reapprove privately after the user's
answer, and rerun the representative pilot. Do not scale until the exact
approved plan has `pilot_status:"ready_for_scale"`. Then regenerate and run
the deterministic schema generators, but do not run `schema-lock` yet.

### Final schema approval before lock

After the final pilot passes, make the exact generated artifacts available to
the user:

- `schema_optimization.json`;
- `extraction_schema.json`;
- `fallback_claim_schema.json`; and
- the pilot summary and a human-readable schema revision summary.

Present in plain language:

- categories and repeatable record types;
- every required field and important optional field;
- bounded, open, and hybrid vocabulary choices;
- categorical options and how unseen labels are handled;
- per-value source-location and numeric-consistency rules;
- changes made since Question approval and why;
- pilot coverage, agreement, fallback decisions, unresolved limitations, and
  expected downstream analyses/visualizations;
- exact local paths so the user can inspect the raw JSON.

A passing validator, plausible pilot, or unchanged diff is not approval.

> **CHECKPOINT — ASK THE USER:** Offer explicit choices to approve and lock the
> exact final schema, revise it and rerun the pilot, or stop. Record the answer,
> schema revision, and exact schema/registry hashes in the pilot approval
> record. Only an explicit approve-and-lock answer authorizes private
> `schema-lock`.

After explicit approval, run:

```bash
python3 guided_analysis.py schema-lock --dir <topic_dir> --json
```

Never begin scaled extraction with an unapproved, stale, or unlocked schema.

### 5d. Verified visual-evidence policy

Apply this policy identically in pilot and scaled extraction:

- Exact values in readable article text, readable text tables, or text-based
  supplements are eligible for line-pinned repo cards.
- Values visible only in figures, plots, screenshots, scanned pages, or
  image-based tables are **not added to the verified repo**.
- A figure/table caption cannot verify a number visible only inside an image.
- Record each omitted desired value as `missing_visual_evidence` in the
  extraction ambiguity/gap ledger.
- If the identical value also appears in readable source lines, extract from
  those lines normally.

Image tools may help discover that a result exists. They do not convert
image-only pixels into verified findings. Keep image-derived values outside
`verified_findings.json` until a separate visual-verification contract records
the source image, exact region, independent agreement, and verification scope.

### 5e. Scaled locked-schema extraction

After the pilot passes and `schema-lock` succeeds, run extraction in waves with
the one-turn full-paper worker:

```bash
paperclip map --worker structured-extraction --tag <slug>-included \
  --output_schema "$(cat <topic_dir>/extraction_schema.json)" \
  -j 32 \
  "Read every source in the canonical evidence packet. Return one complete \
paper object conforming exactly to the locked schema. Preserve original labels \
and attach exact path/line locations to every value. Record image-only desired \
evidence under missing_visual_evidence; never infer it."
```

The worker gets one canonical packet containing line-numbered main text,
readable tables, and readable text supplements. It has no tools, makes one
Claude call, and never mutates the repo. Its durable task record contains raw
output, strict-schema status, model/prompt/schema/code provenance, packet hash,
per-path content hashes, included paths, omitted paths, and visual inventory.

One bounded correction call is allowed only when the first output is malformed
or schema-invalid. A persistent invalid/truncated answer, missing readable
packet, or size overflow returns `fallback_required`; it is never mislabeled as
successful. Resume interrupted maps and rerun only unfinished tasks.

### 5f. Dense-paper fallback and explicit repo staging

The default is one complete paper-level schema. Do not preemptively split all
papers. When a task returns `fallback_required`, or when the representative
comparison shows that a measured paper class falls below the approved
field/value/location agreement threshold, use the existing
`exhaustive-extraction` worker for only those papers. It may read the paper
gradually with tools and, if needed, use non-overlapping project categories
such as:

1. `source-context/units`
2. `effectiveness`
3. `survival`
4. `safety`
5. `manufacturing/population`

```bash
paperclip map --worker exhaustive-extraction --from <fallback-paper-list> \
  --claim_schema "$(cat <topic_dir>/fallback_claim_schema.json)" \
  -j 8 \
  "Return every in-scope locked category record with per-value source paths \
and lines. Do not mutate a repo. Preserve coverage and ambiguity notes."
```

Category names are project-specific. Fallback tasks must retain the locked
field definitions/options, original labels, exact source path/lines, and visual
exclusion policy. They do not authorize a schema change. If fallback evidence
reveals a material missing field/category/option, reopen the pilot instead of
quietly mutating the lock. Dense splitting is internal; do not ask the user to
manage it.

Before returning fallback claims, re-read every cited value from the exact
final absolute path/range. Never copy a section-local line number and relabel it
as a global `content.lines` line.

`fallback_claim_schema.json` is deterministically generated and locked beside
the paper schema. It represents one category record. `repo-stage` merges
multiple fallback records/shards back into one complete paper object and
validates that object against the parent locked schema.

Once every paper has a valid output or a schema-valid fallback replacement,
download durable map manifests and run the private non-mutating staging step
with every structured and fallback manifest:

```bash
python3 guided_analysis.py repo-stage \
  --dir <topic_dir> \
  --manifest <structured-map-manifest.json> \
  --manifest <exhaustive-fallback-manifest.json> \
  --json
```

`repo-stage` rechecks the current lock, map schema hash, task success, each
paper object, every field value, every path/line pin, and evidence-packet
inclusion. It then writes `repo_staging.json`, converting each sourced value to
one universal `finding` claim and each source note to `source_context`.
Extractor judgments, ambiguities, and visual gaps remain outside repo
verification. Any failed or fallback-required task blocks `ready_to_add`.

Only after staging passes:

```bash
python3 guided_analysis.py repo-add \
  --dir <topic_dir> \
  --repo <slug> \
  --json
```

`repo-add` is a separate idempotent persistence step. It adds papers and staged
claims with stable IDs and all path-aware source locations. It does not commit.
If addition fails, rerun `repo-add`; do not pay Claude to re-extract the paper.
The next step is the separate Phase-6 `paperclip repo commit`.

### 5g. Independent audit

Independently re-extract a representative sample after scaling. Compare:

- eligible card count and stable IDs;
- exact source values/units and readable line pins;
- categories, definitions, and analysis-unit relationships;
- missing/ambiguous fields;
- visual-only exclusions;
- any analysis-critical precision inputs.

Write `extraction_audit.json` with sampled papers, category/card concordance,
resolved discrepancies, visual-evidence gaps, and any project-specific
integrity checks. Material disagreements reopen the relevant contract and
pilot; they are not averaged away.

### 5h. Coverage and saturation loop

After each joined wave:

1. deduplicate new records against the master set;
2. update coverage by source, design, category, analysis-unit type, population
   or setting, definition, and planned output;
3. list `missing_visual_evidence` separately from absent/unreported evidence;
4. identify thin categories, missing source types, new aliases, landmark
   citations, and unresolved relations;
5. return to Phase 4 for targeted gap queries;
6. screen/extract only genuinely new papers.

Stop when marginal yield is low and no plausible material gap remains, or when
a hard source/access boundary is reached and disclosed. A target number of
papers/cards is not a saturation rule.

Maintain one reconciled `search_log.json.evidence_flow`, including:

- `records_found_total`
- `records_deduplicated`
- `papers_screened_title_abstract`
- `papers_screened_full_text`
- `papers_full_text_excluded`
- `papers_included`
- `raw_numeric_candidates_inspected`
- submitted, removed, active, OK, X, and pending structured-card counts
- exported verified-card count

Before Phase 6, every search/extraction worker and dense-paper shard must have
joined. One orchestrator then performs the verification drain.
