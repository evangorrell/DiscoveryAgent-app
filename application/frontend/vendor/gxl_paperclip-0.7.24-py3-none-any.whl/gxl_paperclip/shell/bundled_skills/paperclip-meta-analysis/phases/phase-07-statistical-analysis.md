> ### Internal subroutine · Generated Analysis · User stage: Results
> - **Consumes:** frozen `verified_findings.json`,
>   `evidence_proposal.json`, `harmonization_map.json`,
>   `evidence_review.json`, `planned_outputs.json`, and optional
>   `analysis_inputs.json`. Explicit legacy imports use their approved compiler
>   projections.
> - **Produces:** a generated, tested package under `analysis/` and validated
>   root `analysis.json`.
> - **Precondition:** the user explicitly approved proceeding from Evidence to
>   Results and Claude privately froze Evidence.
> - **Gate:** package preflight, generated tests, execution, frozen-input hash
>   checks, and the selected result contract all pass.
> - **Next:** managed result validation, then Phase 9 synthesis.

## Phase 7: Generated Package-Backed Analysis

Results never begin from an inferred approval. Once Results is open, generate
analysis code tailored to the approved question, evidence, readiness findings,
and desired outputs.

### 7a. Decide what the evidence supports

Read `evidence_review.json.analysis_readiness.outputs` and
`visualization_readiness.outputs` before designing models. For each requested
output:

- use the requested inferential method only when required fields, independent
  units, precision, comparisons, and assumptions are present;
- use a declared descriptive fallback when allowed;
- otherwise return a transparent unsupported/not-ready result with blockers.

Do not fabricate precision, denominators, correlations, comparison arms,
sample independence, or harmonized meaning. If source-backed Evidence is
wrong or incomplete, explicitly reopen Evidence rather than repairing it in
analysis code.

### 7b. Generate the managed package

Create:

```text
analysis/
├── analysis_spec.json
├── methods.md
├── runtime.json
├── <generated entrypoint>.py or .R
└── <generated tests>.py or .R
```

`analysis_spec.json` freezes:

- finalized analysis/output type and estimands;
- every approved input path and SHA-256;
- selected/descriptive/excluded card IDs and exact accounting;
- expected outputs and result contract;
- deterministic seed.

`methods.md` records:

- why each requested output is supported, downgraded, or blocked;
- grouping, dependency, overlap, missingness, and precision rules;
- transformations/model/diagnostic choices where applicable;
- sensitivity analyses and deviations;
- links from analysis rows back to verified card IDs/source locations.

`runtime.json` declares the installed local runtime, entrypoint, source hash,
generated tests, packages/import allowlist, seed, and timeout. Paperclip
validates declared dependencies; it does not install them automatically.

### 7c. Generated code is the default

The generated package is the primary path. Do not use a universal pooling
script or a bundled recipe as the default implementation. Generate code/tests
for the actual approved data and output contract.

Bundled pairwise, network, meta-regression, and variance recipes are
**examples only**. They are not correctness contracts and are **never selected
by default**. Consult an example only after `analysis_spec.json` is finalized.
When used, freeze the spec hash and record the example ID and every deviation
in `runtime.json` and `methods.md`.

### 7d. Preserve traceability and independence

Every selected analysis row must name its source card/finding ID and retain its
source document/location binding. Account for every verified in-scope finding
as selected, descriptive, duplicate, excluded, or unresolved with a reason.

Never treat correlated cohorts, repeated timepoints, subgroups, duplicate
reports, shared controls, model/dataset reruns, batches, or review/primary
overlap as independent merely because they are separate cards.

For legacy pairwise results, preserve canonical selection accounting and
array-shaped `outcome_groups`. For dynamic projects, use the project-selected
result contract and keep unsupported planned outputs explicit.

### 7e. Run privately and validate

Claude runs the private helper preflight, generated tests, and execution. Users
are not shown or asked to type helper commands.

The runner must:

1. validate finalized spec, approved input hashes, source/test hashes, runtime,
   imports, and packages;
2. run generated tests before the entrypoint;
3. reject mutation of frozen Evidence;
4. validate output against the selected result contract;
5. record execution, diagnostics, methods, runtime/package, input, source/test,
   and output hashes;
6. copy the validated managed result to root `analysis.json`.

Do not hand-edit `analysis.json` to force a pass. Analysis-code/method changes
use a Results revision and rerun. Evidence-value, classification, or
harmonization changes reopen Evidence and invalidate the prior execution.

### 7f. Interpretation review

Check:

- direction, units, null/reference values, and transformed scales;
- selected versus descriptive versus excluded accounting;
- dependence and duplicate handling;
- uncertainty and prediction intervals only when supported;
- heterogeneity/moderators only at defensible sample sizes;
- robustness/sensitivity diagnostics;
- quality/certainty rationale with reviewer provenance;
- every planned output's ready/fallback/blocked disposition.

Remain in this subroutine until managed result validation passes for the
current frozen Evidence and Results revision.
