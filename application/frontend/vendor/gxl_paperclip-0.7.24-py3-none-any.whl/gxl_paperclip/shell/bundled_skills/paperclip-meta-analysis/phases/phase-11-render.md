> ### Internal subroutine · Iterative Report Authoring · User stage: Results
> - **Consumes:** frozen Evidence, current managed `analysis.json`/execution,
>   `synthesis.json`, `prisma_checklist.json`, protocol/search records, and the
>   current Results revision binding.
> - **Produces:** agent-authored `report_spec.json`, `dashboard_spec.json`, and
>   self-contained `index.html`; optional `card_direct.jpg`; fixed
>   `render_qa.json`; and immutable prior Results archives.
> - **Precondition:** data/methodological gates pass for the current execution.
> - **Gate:** fixed render QA passes and hashes match every current report/QA
>   artifact.
> - **Next:** Results `AskUserQuestion` checkpoint. Publication is never an
>   automatic consequence of QA.

## Phase 11: Iterative Agent-Authored Report

Claude remains the author of the report specification and final HTML. The
release renderer is a normalization/design reference, never the final HTML
writer. The fixed `render_qa.py` is the executable render contract and is never
weakened or hand-replaced.

### 11a. Author report_spec.json

Use the bundled report contract/example. Record:

```json
{
  "schema_version": 1,
  "audience": "The intended readers",
  "tldr": ["Primary conclusion", "Most important limitation"],
  "section_order": [
    "question",
    "tldr",
    "evidence",
    "results",
    "limitations",
    "methods",
    "provenance",
    "references"
  ],
  "labels": {
    "project_identifier": "Human-readable label"
  },
  "figure_inventory": [
    {
      "id": "stable-figure-id",
      "label": "Human-readable figure label",
      "source_artifacts": ["analysis.json", "verified_findings.json"],
      "visible": true
    }
  ],
  "visibility": {
    "question": true,
    "methods": true,
    "provenance": true
  },
  "provenance_notes": [
    "Every source-backed value links to exact readable source lines."
  ]
}
```

The spec controls audience, TLDR, section order, labels, visible content,
figure inventory, and provenance messaging. It must distinguish:

- source-reported verified findings;
- Claude/reviewer assessments and proposal decisions;
- managed analysis results;
- unsupported/missing evidence, including `missing_visual_evidence`.

### 11b. Author dashboard_spec.json

Use human-readable labels for every displayed normalized identifier. Declare
only figures supported by populated data. Optional figure ordering may place
listed populated figures first; unlisted populated charts still follow.
Omitting an optional chart does not authorize hiding a material result.

Useful static figures include evidence flow, coverage, forest/interval tables,
risk/quality summaries, networks, timelines, subgroup/moderator results, and
readiness/gap summaries when the corresponding artifacts support them.

### 11c. Author index.html

The agent always writes the final `index.html`. It must be:

- fully self-contained with inline CSS and no external runtime dependencies;
- static and sandbox-safe: no scripts, inline handlers, iframes, or
  `javascript:` URLs;
- readable as a journal/review report rather than a BI dashboard;
- complete at load time: no empty table/SVG/chart shells;
- faithful to `report_spec.json` ordering, labels, visibility, and figures;
- explicit about supported, descriptive-fallback, blocked, and missing outputs;
- clear about reviewer judgment versus verified source statements.

For every source-backed value, link the label to:

```text
https://citations.gxl.ai/papers/<doc_id>#L<lines>
```

Use a DOI fallback only when no Paperclip document ID exists. Never create a
source citation for an image-only number. Report `missing_visual_evidence` as a
limitation/gap without displaying the unverified value.

The report should include, as applicable:

- question/scope and concise TLDR;
- Evidence flow, coverage, and inclusion/exclusion summary;
- key verified findings and context;
- managed analyses and uncertainty/diagnostics;
- descriptive outputs and unsupported requested outputs;
- quality/applicability and decision provenance;
- contradictions, boundary conditions, and limitations;
- methods, protocol deviations, and PRISMA;
- references with exact source lines.

### 11d. Run fixed render QA

Fetch the release-matched reference/QA scripts fresh into the run directory.
Read normalization/renderer code for field handling and static chart patterns,
then run the unmodified QA script:

```bash
python3 render_qa.py <topic_dir>
```

The fixed gate checks at least:

- no empty declared tables/SVG/charts;
- no JavaScript or sandbox-stripped content;
- citations and exact-line anchors;
- no leaked `None`, `NaN`, or `undefined`;
- required title/references/report sections;
- declared figure population;
- artifact size;
- hashes for `index.html`, `report_spec.json`, `data_qa.json`, and optional
  synthesis/dashboard artifacts.

Repair the agent-authored report and rerun the same fixed gate until
`render_qa.json.status == "pass"`. Never hand-write a passing QA file.

### 11e. Preview and review

Claude validates/opens the local preview privately. Preview is nonblocking by
default and never uploads.

> **CHECKPOINT — ASK THE USER:** Summarize what changed and present the current
> preview. Use `AskUserQuestion` with plain-language choices to accept, request
> report changes, reopen Evidence, stop, or publish. Do not ask the user to type
> revision/preview/publish helper commands.

For report changes, Claude privately archives the current revision before
editing. The archive is `revisions/results-vN/`, never overwritten, and
includes analysis spec/methods/execution references, synthesis, report spec,
dashboard spec, HTML, and QA records. Then:

1. revise only the requested report/synthesis artifacts;
2. preserve frozen Evidence and valid managed execution for report-only edits;
3. rerun fixed data/render QA as applicable;
4. preview again;
5. return to `AskUserQuestion`.

If the requested change alters source Evidence, classification, harmonization,
or analysis inputs, reopen Evidence instead. That invalidates the Evidence
freeze and managed execution; regenerate Results after new approval.

> **CHECKPOINT — READY FOR REVIEW:** A QA pass means ready for review only. It
> is not publish approval and never uploads. Continue to Phase 12 only after the
> user explicitly chooses publish.
