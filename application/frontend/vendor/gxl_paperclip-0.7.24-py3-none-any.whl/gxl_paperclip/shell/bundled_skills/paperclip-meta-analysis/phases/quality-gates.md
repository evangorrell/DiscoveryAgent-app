> ### Internal subroutine · Fixed Quality Gates · User stage: Results
> - **Consumes:** repo, approved/frozen artifacts, managed analysis execution,
>   and the current Results revision's report artifacts.
> - **Produces:** `data_qa.json` and a documented manual-gate decision.
> - **When:** data QA follows the Phase-10 inventory; fixed render QA runs after
>   every agent-authored report revision.
> - **Next:** a pass means **ready for review**, not uploaded. Continue the
>   Phase-11 preview/revision loop; only helper validation followed by explicit
>   public `paperclip upload`
>   may upload.

## Quality Gates

### Executable data gate (mandatory)

For guided projects, run the lifecycle/source validators plus generated
package tests against frozen `verified_findings.json`,
`evidence_proposal.json`, `evidence_review.json`, and any
`analysis_inputs.json`. The card/evidence gates enforce canonical card types,
stable provenance, complete proposal coverage, assessment/decision provenance,
hash bindings, traceable copied values, dynamic input requirements, and
managed-result contracts.

Explicit imported legacy/pairwise projects also run the release-matched
validator downloaded in Phase 6:

```bash
cd <topic_dir>
python3 data_qa.py . --schema effect.schema.json
```

It writes `data_qa.json` and must exit 0 with `status:"pass"`. Do not hand-write
this file. On that legacy path the validator enforces:

- effect schema, finite values, CI ordering, unique IDs, verification and pins;
- context, study-characteristics, and quality coverage for every effect paper;
- quality tool/domain/overall/rationale presence;
- one independent unit per primary outcome model;
- canonical array-shaped `outcome_groups` and effect-ID traceability;
- compiled/selected/excluded selection arithmetic;
- evidence-flow submitted/active/OK/X/?/compiled/selected arithmetic;
- zero active `[?]` and `[X]`;
- ≥90% dual-extraction concordance and a recorded CI-integrity check;
- protocol selection/dependency fields, search queries, and saturation log;
- reviewed per-outcome GRADE domain rationales;
- canonical manuscript synthesis and non-empty PRISMA checklist.

Warnings such as suspicious round symmetric CIs require source review and a
recorded resolution even when the script exits 0.

### Manual methodological gates

Executable checks cannot decide substantive appropriateness. Confirm:

- [ ] Stage-1 schema determination used the bundled structured discovery schema
  with `map`; free-text brainstorming was not treated as the approval artifact.
- [ ] Every approved discovered field/option has current-paper original wording,
  an absolute readable source path, and a canonical line/range.
- [ ] Open-world products, detailed outcomes, cohorts, assays, and complications
  use open or hybrid vocabularies rather than a falsely comprehensive enum.
- [ ] Background-only concepts were not promoted into focal project options.
- [ ] After the representative pilot, the user received the exact final schema
  files, a plain-language revision summary, and inspectable paths, then
  explicitly chose approve-and-lock before `schema-lock` or scaling.
- [ ] Search scale is justified by the field, planned outputs, observed
  category/unit coverage, and marginal yield—not a universal card quota.
- [ ] Every protocol-eligible verifiable source was searched with explicit `-s`;
  every source-specific omission is justified.
- [ ] Search/extraction alternated in logged waves until marginal yield was low
  and no plausible outcome/population/intervention/citation gap remained, or a
  hard stop was reached with residual gaps disclosed.
- [ ] Every included paper was screened in full text; every full-text exclusion
  has one protocol-grounded reason.
- [ ] Scaled extraction used the current locked optimized schema and categorical
  registry; every map manifest records matching schema/model/prompt/code
  provenance.
- [ ] `repo_staging.json` reconciles all successful structured and exhaustive
  fallback outputs, has no unresolved blockers, and its add counts match the
  repo before verification.
- [ ] Every verified numeric value appears in readable source lines or a
  text-based supplement. Figure-only and image-table values are recorded as
  `missing_visual_evidence`, not represented as line-verified findings.
- [ ] Every normalized numeric/integer value matches digits or unambiguous
  number words in its own `as_reported` source wording (allowing only explicit
  percent/proportion ×100 conversion); no value borrows a different number
  from the same passage.
- [ ] Outcome direction, unit, comparator, time point, and measure were
  harmonized without changing reported values.
- [ ] Correlated effects, duplicate cohorts, review/primary overlap, repeated
  time points, and subgroups follow `dependency_rules`.
- [ ] Heterogeneity is interpreted for every group, especially I² > 50%.
- [ ] Egger is interpreted only at k≥10; leave-one-out is present at k≥3.
- [ ] Both REML–KH and DL results are reported and material discrepancies noted.
- [ ] Preliminary GRADE was reviewed against actual quality assessments and has
  rationales for risk of bias, inconsistency, indirectness, imprecision, and
  publication bias.
- [ ] Every Claude/reviewer assessment and proposal decision retains provenance;
  reviewer-only judgment is not presented as source-reported evidence.
- [ ] The synthesis distinguishes robust findings, fragile findings,
  contradictions/boundary conditions, and limitations without overclaiming.
- [ ] PRISMA 2020 items are addressed and flow counts agree with evidence flow.

The cross-file consistency reference is **Phase 8e**.

### Render gate (mandatory after Phase 11)

- [ ] The agent authored a self-contained `index.html` using the release
  renderer code as reference.
- [ ] `render_qa.py <topic_dir>` exits 0 and
  `render_qa.json.status == "pass"`.
- [ ] Every rendered study/effect links to `citations.gxl.ai#L<lines>` or a DOI
  fallback; no empty declared figure is present.

Any failed gate blocks Phase 12 upload.
