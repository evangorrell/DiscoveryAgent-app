> ### Internal subroutine · Explicit Versioned Publish · User stage: Results
> - **Consumes:** frozen Evidence approval/hashes, current managed execution,
>   current Results revision binding, valid `report_spec.json`, current passing
>   data/render QA hashes, and the exact publish inventory.
> - **Produces:** versioned artifacts plus `publish_manifest.json` at
>   `/clipboard/analyses/<slug>/v<results_revision>/`, and a local published
>   status/manifest hash record.
> - **Precondition:** the current preview was reviewed and all fixed gates pass.
>   A QA pass alone is not publication approval.
> - **Next:** none. A later version starts with
>   `python3 guided_analysis.py revise results --reason "<reason>"`.

## Phase 12: Explicit Versioned Publish

Publishing is an explicit agent-controlled sequence. Preview, report review,
and passing QA never start it. Only after the user approves publication through
`AskUserQuestion` does Claude run these private/internal steps:

```bash
python3 guided_analysis.py publish --dry-run --json
python3 guided_analysis.py publish --json
# Run the exact upload_command returned above. It uses the existing public
# generic uploader, with publish_manifest.json last:
paperclip upload <exact-upload_files> --into analyses/<slug>/v<results_revision>
python3 guided_analysis.py publish --record-uploaded --json
```

These commands are instructions for Claude, never the user. `--dry-run`
performs every gate and prints the exact inventory/destination without writing
or networking. The second helper invocation writes the deterministic
`publish_manifest.json` and returns an executable `upload_command`; it does not
upload. Claude runs that exact standard `paperclip upload` command, checks that
every file succeeded, and only then uses `--record-uploaded` to bind the local
published status to the manifest hash. If upload fails, do not record success.

Before preparing any upload, the helper revalidates:

1. approved Question and frozen Evidence hashes;
2. current successful package-backed execution and root/nested result hashes;
3. current Results revision binding;
4. `data_qa.json` execution/result bindings;
5. valid `report_spec.json`;
6. `render_qa.json.status == "pass"` and its current report/QA hashes.

The public uploader transfers the exact helper-returned files to
`analyses/<slug>/v<results_revision>` with `publish_manifest.json` last. The
final helper step records destination, version, artifact hashes, manifest hash,
and published status. Repeating a recorded publication is idempotent. Changing
artifacts after that version was published is blocked until a new Results
revision is explicitly opened; version folders are never overwritten.

Confirm with:

```bash
paperclip ls /clipboard/analyses/<slug>/v<results_revision>/
```

Report the repo name/SHA, reconciled Evidence counts, managed execution hash,
Results revision, publish manifest hash, and versioned clipboard path. Final
active `[?]`/`[X]` counts must be zero; do not describe a partial verification
or partial upload as published.
