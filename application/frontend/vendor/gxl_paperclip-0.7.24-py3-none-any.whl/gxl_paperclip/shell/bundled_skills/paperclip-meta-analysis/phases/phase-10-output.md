> ### Internal subroutine · Output Inventory · User stage: Results
> - **Consumes:** no new evidence; inventories Question, frozen Evidence, and
>   current managed Results artifacts.
> - **Produces:** no artifact and rewrites nothing.
> - **Gate:** every required file exists in `<topic_dir>` and uses the canonical contracts below.
> - **Next:** `quality-gates.md`, then `phase-11-render.md`.

## Phase 10: Output Inventory

All run artifacts use relative paths under one `<topic_dir>`. Missing or
inconsistent files are fixed by returning to their owning phase; never recreate
frozen evidence/statistics from memory here.

### Required artifacts and ownership

| File | Owning phase | Write path |
|---|---:|---|
| `protocol.json` | 2 | protocol generation + logged deviations |
| `search_log.json` | 4–8 | search/screen/verification/selection ledger |
| `extraction_audit.json` | 5d | independent re-extraction + CI audit |
| `collection_spec.json` | 2/5 | approved dynamic collection contract |
| `planned_outputs.json` | 2 | approved output intent |
| `verified_findings.json` | 6 | universal exporter only |
| `evidence_proposal.json` | 8 | Claude classification with provenance |
| `harmonization_map.json` | 5/8 | final hash-bound fixed map |
| `harmonization_queue.json` | 5/8 | optional unknown-label queue |
| `analysis_inputs.json` | 7 | optional analysis-specific rows |
| `effects.json` | 6/8 | imported legacy compiler path only |
| `contexts.json` | 6 | imported legacy compiler path only |
| `study_characteristics.json` | 6 | imported legacy compiler path only |
| `quality_assessments.json` | 6 | imported legacy compiler path only |
| `analysis.json` | 7 | validated output of `python3 guided_analysis.py run` |
| `synthesis.json` | 9 | manuscript synthesis |
| `prisma_checklist.json` | 9 | PRISMA reporting checklist |

The pre-render quality gate subsequently creates `data_qa.json`. Phase 11 then
creates `dashboard_spec.json`, `index.html`, and `render_qa.json`. None are
Phase-10 inventory prerequisites.

### Canonical contracts

For guided projects, `verified_findings.json` is the canonical evidence
inventory. Its fixed envelope carries canonical `card_type`, dynamic
`record_type`, stable IDs, source locations, verification scope, unchanged raw
payload, card-model/export metadata, and assessment provenance. The Evidence
artifacts classify every card, preserve original labels, and bind analysis rows
to exact source cards.

The files below are canonical only for an explicit imported legacy/pairwise
project:

`effects.json` is an array of effect-schema objects enriched by the compiler
with `paperclip_doc_id`, `paperclip_lines`, `claim_id`, and `verified:true`.
It includes primary, secondary, and explicitly excluded verified effects; it is
not merely the primary model subset.

`contexts.json` is an array of verified `type:"context"` claims. The compiler
derives the two one-row-per-paper arrays `study_characteristics.json` and
`quality_assessments.json` from the corresponding nested context objects.

`analysis.json` follows Phase 7 exactly:

- `outcome_groups` is an array, never a name-keyed object.
- each group has non-empty `studies[]`, `pooled_combined`, and `grade`;
- each study has `effect_id`, `doc_id`, `lines`, and `independent_unit_id`;
- `n_effects_extracted == n_effects_compiled_verified == len(effects.json)`;
- `n_effects_selected_primary_pooling` equals all primary group study rows; and
- `selection_accounting` reconciles every compiled effect.

`search_log.json` must include:

```json
{
  "search_date": "YYYY-MM-DD",
  "sources": ["pmc", "medrxiv"],
  "queries": [
    {
      "source": "pmc",
      "query": "...",
      "wave": 1,
      "reason": "initial | thin_outcome | missing_population | citation_lead",
      "records_found": 0
    }
  ],
  "papers_screened": [
    {
      "doc_id": "PMC...",
      "stage": "title_abstract | full_text",
      "decision": "include | exclude",
      "reason": "protocol-grounded reason",
      "overlap_parent": null
    }
  ],
  "removed_unverified_effects": [],
  "verification_gate_summary": {},
  "saturation_rounds": [],
  "protocol_deviations": [],
  "harmonization_summary": {},
  "evidence_flow": {
    "records_found_total": 0,
    "records_deduplicated": 0,
    "papers_screened_title_abstract": 0,
    "papers_screened_full_text": 0,
    "papers_full_text_excluded": 0,
    "papers_included": 0,
    "raw_numeric_candidates_inspected": 0,
    "effect_claims_submitted_total": 0,
    "effect_claims_removed": 0,
    "effect_claims_active": 0,
    "effect_claims_ok": 0,
    "effect_claims_x": 0,
    "effect_claims_pending": 0,
    "effects_compiled": 0,
    "effects_selected_primary_pooling": 0,
    "effects_secondary_or_sensitivity": 0,
    "effects_excluded_from_pooling": 0
  }
}
```

`synthesis.json` is written only in Phase 9 and uses that phase's one canonical
manuscript schema: `format:"manuscript"`, object `abstract`, paragraph-array
`introduction`, section-array `methods`, `results.sections[]`,
`discussion.sections[]`, plural `conclusions`, object-array `key_findings`, and
line-linked `references[]`. Phase 10 does not define an alternate shape.

`extraction_audit.json` includes sampled papers, compared effect count,
`concordance_rate`, resolved discrepancies, and `ci_integrity_check`.

### Optional renderer additions

Optional analyses may be added only when supported by real data and linked to
source `doc_id` + `lines`: subgroup tables, meta-regression, cumulative/temporal
analysis, dose-response, network results, funnel/trim-and-fill, L'Abbé,
Galbraith, GRADE SoF, and risk-of-bias traffic lights. Empty declared figures
fail render QA.

### Inventory check

```bash
python3 - <<'PY'
from pathlib import Path
required = [
  "protocol.json", "search_log.json", "extraction_audit.json",
  "analysis.json", "synthesis.json", "prisma_checklist.json",
]
if Path("verified_findings.json").is_file():
    required += [
      "collection_spec.json", "planned_outputs.json",
      "verified_findings.json", "evidence_proposal.json",
      "harmonization_map.json", "evidence_review.json",
    ]
else:
    required += [
      "effects.json", "contexts.json", "study_characteristics.json",
      "quality_assessments.json",
    ]
missing = [name for name in required if not Path(name).is_file()]
if missing:
    raise SystemExit("missing required artifacts: " + ", ".join(missing))
print("artifact inventory: pass")
PY
```

Then run the executable quality gates.
