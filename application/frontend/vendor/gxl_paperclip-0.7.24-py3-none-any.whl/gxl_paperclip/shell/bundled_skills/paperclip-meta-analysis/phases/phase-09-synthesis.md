> ### Internal subroutine · Synthesis · User stage: Results
> - **Consumes:** frozen `verified_findings.json`, `evidence_proposal.json`,
>   `evidence_review.json`, optional `analysis_inputs.json`, managed
>   `analysis.json` (Phase 7), `protocol.json`, and the complete
>   `search_log.json`, plus current managed execution hashes. Explicit imported
>   legacy projects additionally use their compiler projections. Read them from
>   disk.
> - **Produces:** **`synthesis.json`** (abstract → introduction → methods → results → discussion → conclusion as flowing prose, plus structured arrays) and **`prisma_checklist.json`**.
> - **Precondition:** `python3 guided_analysis.py validate-results` passes for the
>   current Results revision.
> - **Next:** `phase-10-output.md` (confirm all output files) → `quality-gates.md` → `phase-11-render.md`.

## Phase 9: Synthesis — write as a research paper

Write `synthesis.json` as a **structured research paper**, not bullet points. This is the human-readable narrative of the meta-analysis — it should read like a publishable manuscript. The `index.html` report (Phase 11) renders this directly, so the quality of writing matters.

**Inputs:**
- `verified_findings.json` (all canonical cards and unchanged raw payloads)
- `evidence_proposal.json` + `evidence_review.json` (classification,
  harmonization/readiness, and reviewer-decision provenance)
- optional `analysis_inputs.json` (analysis-specific traceable rows)
- `analysis.json` (re-pooled with harmonized groups)
- `protocol.json` (pre-registered methods and deviations)
- complete `search_log.json` (queries, screening/evidence flow, verification,
  saturation, harmonization, and PRISMA counts)

Use `source_context`, `analysis_unit`, `finding`, `definition`, and
`relationship` cards for source-reported narrative. Keep `assessment` cards and
proposal classifications attributed to Claude/reviewers. Do not present a
reviewer judgment as a source statement merely because its source basis was
line-pinned. `effects.json`, `contexts.json`, `study_characteristics.json`, and
`quality_assessments.json` are inputs only for explicit imported legacy paths.

The harmonization summary tells you the story the data wants to tell — contradictions become discussion points, converging themes become key findings, temporal patterns become trend analyses.

**Write `synthesis.json` with these sections as flowing prose paragraphs (not bullet lists):**

```json
{
  "format": "manuscript",
  "slug": "<slug>",
  "title": "<full title>",
  "date_compiled": "<date>",
  "repo": "<slug>",
  "repo_sha": "<sha>",
  "pico": { "population": "", "intervention": "", "comparator": "", "outcomes": "" },

  "abstract": {
    "background": "1-2 sentences: why this question matters, what's known.",
    "methods": "1-2 sentences: what you did (systematic search of N papers, extracted N effects, random-effects pooling).",
    "results": "2-3 sentences: the key numbers — primary outcome pooled estimate with CI, secondary outcomes, harms.",
    "conclusions": "1-2 sentences: the clinical/practical bottom line."
  },

  "introduction": [
    {"text": "Paragraph 1: scientific context and what prior reviews found."},
    {"text": "Paragraph 2: gap and prespecified question."}
  ],
  "methods": [
    {"heading": "Search and selection", "text": "Initial + extraction-informed waves, sources, query count, dates, protocol eligibility and deviations."},
    {"heading": "Extraction and verification", "text": "Raw candidates → JSON claims → exact-line source verification → dual-extraction audit."},
    {"heading": "Statistical analysis", "text": "Dependency selection, REML/DL, Knapp–Hartung, prediction intervals, leave-one-out, Egger and certainty."}
  ],
  "results": {
    "sections": [
      {"heading": "Evidence flow", "text": "Records → screening → claims → OK/X/? → compiled → selected, with exact reconciled counts.", "figures": [{"type": "prisma"}]},
      {"heading": "<outcome>", "text": "Pooled estimate, CI, k, I², robustness, evidence strength and boundary conditions.", "figures": [{"type": "forest", "outcome": "<outcome>", "caption": "..."}]}
    ]
  },
  "discussion": {
    "sections": [
      {"heading": "Principal findings", "text": "Interpretation and comparison with prior work."},
      {"heading": "Boundary conditions and heterogeneity", "text": "Why results differ across settings/subgroups."},
      {"heading": "Strengths and limitations", "text": "Bias, indirectness, imprecision, missing evidence and review limitations."}
    ]
  },
  "conclusions": "1-2 paragraphs: practical recommendations, what is settled, what remains uncertain, and studies needed.",
  "key_findings": [
    {"finding": "...", "outcome": "...", "certainty": "high | moderate | low | very_low", "rationale": "..."}
  ],
  "clinical_implications": [ "..." ],
  "boundary_conditions": [ "..." ],
  "limitations": [ "..." ],
  "references": [
    {"doc_id": "PMC...", "citation": "...", "lines": "L45-L52", "doi": "..."}
  ]
}
```

**Writing guidance:**
- Write in third person, past tense ("The pooled analysis included..."), like a journal article.
- Every quantitative claim must cite the specific pooled estimate, CI, and k (e.g., "RR 0.58, 95% CI 0.46–0.75, k=11").
- Express evidence strength in plain language — don't just say "moderate GRADE." Say "supported by 11 studies with consistent direction, though I²=66% suggests severity-dependent heterogeneity."
- The discussion should explain WHY results differ across subgroups, not just state that they do.
- Keep the exact array/object section shape above. `key_findings` uses objects,
  not bare strings; `conclusions` is plural; references carry source IDs and
  lines. The renderer and Phase 10 both use this one canonical contract.

Write `prisma_checklist.json` as an object with `version:"PRISMA 2020"` and an
`items` array. Each of the 27 items records `{item, section, status, note}`;
`status` is `addressed`, `not_applicable` (with rationale), or `missing`.
Quality gates require no `missing` item.

