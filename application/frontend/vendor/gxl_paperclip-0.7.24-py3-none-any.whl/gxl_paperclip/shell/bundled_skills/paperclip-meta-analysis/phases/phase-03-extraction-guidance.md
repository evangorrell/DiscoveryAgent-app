> ### Internal subroutine · Extraction Guidance · User stage: Evidence
> - **Consumes:** approved `protocol.json`, `collection_spec.json`,
>   `planned_outputs.json`, `schema_discovery.json`, and
>   `schema_optimization.candidate.json`.
> - **Produces:** `schema_optimization.json`, generated
>   `extraction_schema.json`, project-specific extraction instructions, and a
>   representative pilot input. It does not impose universal medical/effect
>   columns.
> - **When to read:** immediately before Phase 5 and before every pilot rerun.
> - **Next:** Phase 4 search, then Phase 5 pilot and scaled extraction.

## Phase 3: Dynamic Extraction Guidance

The approved `collection_spec.json`, `planned_outputs.json`, and source-pinned
schema-discovery observations define what the project needs to collect and
produce. The bundled discovery schema is only a reusable design form; never use
it as the project evidence schema. Claude converts the approved project
proposal into a minimal paper-level extraction schema:

- one array per project-specific category;
- project-specific categories and fields;
- definitions and aliases;
- required versus optional status;
- exact primitive value types;
- approved categorical options and their meanings; and
- a per-value `source_locations` array containing both source path and exact
  `L#` or `L#-L#` range.

Do not inject a standard PICO, medical-outcome, effect-size, or ML benchmark
column set. A CAR-T review, osteoporosis comparison, manufacturing-flow review,
and ML evidence synthesis may legitimately collect different payloads.

### Choose bounded, open, or hybrid fields

Do not ask an LLM to invent a supposedly comprehensive enum for an open-world
concept.

- Use **bounded categorical options** only for a small stable set needed by the
  protocol, analysis, or validation, such as value status, evidence setting,
  effect unit, or an approved grade grouping.
- Use **open strings** for detailed products, outcomes, cohorts, assays,
  complications, methods, or other identities that cannot be enumerated
  safely.
- Use a **hybrid** when broad families are stable but details are open. For
  example, preserve `outcome_family:"toxicity"` together with
  `outcome_as_reported` and an open `outcome_id`.

Every normalized identity also preserves the original source wording. A
product field should normally retain both `product_as_reported` and either an
approved bounded ID or an open normalized ID. Never promote a product/outcome
mentioned only as background into a focal option.

Do not flatten every discovered field into one generic outcome record. Preserve
the approved project categories and links among them. When relevant to the
question, separately represent:

- source/study identity and design;
- exact cohorts, arms, analysis units, counts, parents, and subgroups;
- product/intervention identity and original wording;
- findings/outcomes and original wording;
- event counts, exact outcome denominators, denominator status, timepoints,
  units, and missingness;
- uncertainty with CI bounds, level/type, p/q-values, or other reported
  precision;
- toxicity type, grade, and grading system;
- statistical method separately from adjustment/model level;
- both sides of a direct comparison rather than forcing it into one setting;
- definitions and relationships needed to interpret findings.

These are conditional design concerns, not universal required columns. Include
them only when discovery evidence and approved outputs require them.

### Optimize categorical options and lock the schema

Claude authors `schema_optimization.json` from the approved collection/output
contracts and representative pilot evidence. Each field records an ID, label,
definition, category, value type, required flag, and decision provenance. Each
categorical option records:

```json
{
  "id": "canonical_snake_case_id",
  "label": "Readable label",
  "definition": "What belongs in this option",
  "aliases": ["approved obvious alias"],
  "source_examples": [
    {
      "as_reported": "original paper wording",
      "source_locations": [
        {"path": "/papers/PMC1/content.lines", "lines": "L120-L121"}
      ]
    }
  ],
  "decision_provenance": {
    "actor": "user or claude",
    "decision": "Why this option is present"
  }
}
```

For bounded fields, include `other` when unseen valid values are possible.
Selecting `other` requires `other_detail`, itself preserving the original
wording and exact location. Open fields do not need an artificial `other`
bucket. Never silently expand a bounded enum during scaled extraction.

Claude validates and generates the complete Draft-07 extraction schema:

```bash
python3 guided_analysis.py schema-optimize \
  --dir <topic_dir> \
  --input <topic_dir>/schema_optimization.candidate.json \
  --json
```

`extraction_schema.json` is generated, not hand-written. It returns one object
per paper, with stable record IDs and every individual value wrapped with its
own `source_locations`. Values from different parts of a paper therefore keep
different path/line references even when they occur in the same record.

Use the generated schema for the pilot. After the exact approved pilot passes,
regenerate if needed and lock the bytes before scaled extraction:

```bash
python3 guided_analysis.py schema-lock --dir <topic_dir> --json
```

The lock binds the optimized registry, generated schema, approved collection
contract, planned outputs, and passing pilot. A material field/option change
invalidates the lock and requires a new representative pilot.

## Build extraction instructions

For each generated category:

1. quote the approved definition and aliases;
2. state which fields are required for that category and which are optional;
3. state allowed missing statuses;
4. preserve explicit relationships with project-specific relationship fields;
5. require every factual value—not just every record—to have one or more exact
   source locations; and
6. explain which desired outputs in `planned_outputs.json` need the category.

Extract reported values exactly. Preserve booleans, nested objects, arrays,
counts, denominators, uncertainty, missingness, and ambiguity when the source
reports them. Do not fabricate precision, force a comparative shape, equate a
generic sample size with an outcome-specific denominator, or drop a record
because it is not currently analyzable.

For every numeric/integer sourced value, `as_reported` must contain the digits
or unambiguous number words supporting that exact value. A
percent/proportion ×100 conversion is allowed; borrowing another number from
the same passage is not. Deterministic repo staging rejects numeric values that
contradict their own `as_reported` text before any LLM verifier runs.

### Image-only values are not verified source claims

A table is eligible when its exact values appear in `content.lines`, a readable
section/table file, or a text-based supplement. A screenshot, scanned table,
plot, or other image is not readable line evidence under the current verifier.

- Do not add a value found only in a figure or image-based table to the paper
  repo.
- Do not cite a figure caption as support for a number visible only inside the
  image.
- Record the item as `missing_visual_evidence` in extraction ambiguities and
  the later evidence-gap review.
- If the same exact value also appears in readable source lines, extract it
  from those lines normally.

Image tools may be used to discover that evidence exists, but image-derived
numbers remain outside `verified_findings.json` until a separate image
verification contract records the source image, exact region, independent
agreement, and verification scope.

The extraction envelope must preserve the **original source label** separately
from any provisional/approved `normalized_id`. Never rewrite the reported
wording in place. The initial normalizations are pilot hypotheses: use them to
look for naming diversity and meaning conflicts, not to force heterogeneous
definitions into one group.

Prepare deterministic lookup instructions for the pilot and scale:

1. exact/case/punctuation/spelling aliases already approved may map
   automatically;
2. all other mappings require an explicit row in `harmonization_map.json`;
3. an LLM may propose a normalized ID, relation, rationale, material impact,
   and source examples, but the fixed map alone applies normalized IDs; and
4. unknown labels map to the locked `other` option, preserve original wording
   in `other_detail`, enter `schema_observations.json`, and later enter
   `harmonization_queue.json` when scientific grouping is relevant.

Claude records an observed scaled label without mutating the lock:

```bash
python3 guided_analysis.py schema-observe \
  --dir <topic_dir> \
  --document-id <doc_id> \
  --field <field_id> \
  --as-reported "<original wording>" \
  --source <path> <L#-L#> \
  --json
```

## Stable paper-level records and later repo claims

The extraction worker returns one schema-valid paper object, not a stream of
repo cards. Each category array contains stable paper-local `record_id` values.
Each individual field carries its own source path/lines:

```json
{
  "document_id": "DOC123",
  "project_defined_category": [
    {
      "record_id": "DOC123:reported_item:facet",
      "data": {
        "project_specific_field": {
          "value": 42,
          "as_reported": "42%",
          "source_locations": [
            {"path": "/papers/DOC123/content.lines", "lines": "L45-L46"}
          ]
        }
      }
    }
  ],
  "source_notes": [],
  "extractor_notes": [],
  "ambiguities": [],
  "missing_visual_evidence": []
}
```

This is illustrative structure; `extraction_schema.json` determines the actual
categories and fields. Stable record IDs are deterministic from source identity
and distinguishing project facets; never use random IDs.

After extraction, deterministic `repo-stage` validates the locked schema again
and converts every individually sourced value into a universal `finding` claim.
Source notes become `source_context` claims. Extractor judgments, ambiguities,
and visual-evidence gaps remain in the Evidence ledger and are not submitted to
source verification. `repo-add` adds the staged claims. `paperclip repo commit`
is a separate later step that verifies every claim against every cited readable
source path.

### Analysis units are dynamic

When the project has an analysis-unit category, its optimized schema gives the
unit a stable record ID and project-specific unit type. A count means the
reported count for that exact unit, not a universal patient denominator.
Represent parent/subset relations using project-specific sourced fields. The
same generated pattern supports an osteoporosis treatment arm, an ML
model/dataset/run, or a manufacturing batch. Do not add patient-specific fields
to unrelated projects.

### Assessments are judgments, not automatically source facts

Create `assessment` cards after source verification, while building
`evidence_proposal.json` / `evidence_review.json`; do not add reviewer-only
assessments to the paper repo or ask the source verifier to confirm the
reviewer's judgment. Preserve who made the judgment and its basis:

```json
{
  "type": "assessment",
  "card_id": "DOC123#quality_review",
  "category": "project_defined_quality_review",
  "data": {
    "judgment": "moderate concern",
    "applies_to_card_id": "DOC123#source"
  },
  "assessment_provenance": {
    "assessor": "Claude",
    "method": "Project-approved review rubric",
    "source_support": []
  }
}
```

An assessment may cover quality, applicability, duplicate identity, exclusion,
or readiness, but these are examples rather than fixed categories. Empty
`source_support` means reviewer judgment only. It must not be described as a
source-reported verified fact. When a source passage explicitly reports a
limitation or methodological fact, preserve that passage in a source-backed
`source_context`, `definition`, or `finding` card; the later assessment cites
that card as its basis. The source verifier validates the source card, never the
reviewer judgment.

## Missing, ambiguous, and related evidence

- Use only approved `missing_status_choices`.
- Record source ambiguity instead of resolving it from memory.
- Preserve explicit links such as shared cohort, repeated timepoint, duplicate
  report, arm membership, model/dataset relation, or manufacturing-stage flow.
- Minor label variation is normalized through approved fixed-map aliases while
  preserving the original label.
- Material ambiguity that could change scope, definitions, denominators,
  timepoints, grading systems, hierarchy, grouping, precision, or extraction
  structure is batched for user review during the pilot. Present only those
  material choices and explain the affected analysis/visualization.

Adding a new obvious alias to an unchanged normalized concept is mechanical and
does not by itself require a pilot rerun. Changing a concept's meaning,
normalized-group membership, hierarchy, definition, timepoint, denominator,
grading system, or collection structure is material and uses the existing
collection-spec pilot invalidation/rerun flow.

## Analysis intent is not collection censorship

`planned_outputs.json` guides completeness checks; it does not authorize
discarding verified findings. Collect all in-scope categories approved by the
user. Later, Claude classifies every verified finding in
`evidence_proposal.json` as selected, descriptive, duplicate, excluded, or
unresolved, with a reason and traceable copied values.

Imported legacy/pairwise projects may continue to use the shipped
`effect.schema.json` and `compile_verified.py`. New guided projects use the
optimized/locked paper-level extraction schema, deterministic repo staging,
and universal `export_verified.py`.

