> ### Internal subroutine · Comprehensive Literature Search · User stage: Evidence
> - **Consumes:** `protocol.json` (Phase 2) for scope/eligibility; the PICO/MISO framework (Phase 1).
> - **Produces:** the **paper repo** (`paperclip repo init <slug>`) that holds the corpus for the rest of the run, an initial deduplicated candidate wave (papers tagged under `<slug>-sweep`), and the first entries of **`search_log.json`** (search passes, reproducible query strings). Papers are NOT yet added to the repo — that happens in Phase 5c. Phase 5f re-enters this phase for extraction-informed gap-search waves.
> - **Precondition:** Question was explicitly approved and canonical
>   `protocol.json` exists. Pick the `<slug>` now; publication later uses it.
> - **Next:** `phase-05-screening-extraction.md` (pilot first, then scaled
>   protocol screening and extraction).

## Phase 4: Comprehensive Literature Search

**First, create the paper repo for this corpus.** It is the data-curation
deliverable and the evidence foundation for any later meta-analysis. Use a short
topic slug — versioned Results publication later uses the same slug:
```bash
paperclip repo init <slug> "<the meta-analysis / review question>"   # auto-checks out
```
Run all searches under one shared tag so results collate into a single working set you can screen in one pass:
```bash
paperclip search -s <source> "<query>" --tag <slug>-sweep --limit 50
```
For concurrency safety, you may pin the repo with `export PAPERCLIP_REPO=<slug>`.

Use Paperclip extensively. There is NO query limit — be thorough. The goal is to find EVERY relevant published study with quantitative data on this topic.

**Medical topics — target source types:**
- Meta-analyses and systematic reviews (primary targets for effect size extraction)
- Large RCTs and pivotal trials (extract their reported effect sizes directly)
- Observational cohort studies with pooled or adjusted effect estimates
- Network meta-analyses (extract pairwise and network estimates)
- Individual participant data meta-analyses
- Dose-response analyses

**ML/AI topics — target source types:**
- Survey papers and benchmark comparisons (primary targets)
- Original method papers with evaluation tables (extract accuracy, perplexity, speedup directly)
- Ablation studies and scaling experiments (extract per-condition results)
- Reproduction/replication studies (independent verification)
- Industry technical reports and blog posts with quantitative results
- Competition/leaderboard papers

You should aim for 30-50+ search queries across all passes. Read the full text of every paper that might contain extractable effect sizes. A peer-reviewed meta-analysis team would search 3+ databases and screen hundreds of records — you have access to millions of papers and should leverage that scale.

### Search is iterative: alternate search and extraction in waves

Do **not** treat the query list below as a one-time search that is frozen before any paper is read. Preserve the protocol, but refine retrieval as extraction reveals the vocabulary and coverage of the field:

1. Run an initial family of broad queries in parallel.
2. Join those searches and deduplicate by corpus ID + DOI/title before assigning papers.
3. Screen/extract that candidate wave in Phase 5.
4. Use Phase 5f's coverage tally to identify thin outcomes, missing populations/interventions/comparators, safety gaps, newly learned synonyms, landmark citations, and unextracted underlying studies.
5. Return here and run targeted gap queries in parallel.
6. Deduplicate new hits against the master record set, then screen/extract only genuinely new papers.
7. Repeat until the Phase 5f saturation criteria are met.

The join/dedup barrier occurs **per wave**, not once for the entire review. Search workers return candidate IDs and query logs; they do not independently decide eligibility or add evidence claims. Query refinement is allowed and must be logged. Changing eligibility, outcome definitions, or comparison direction after seeing results requires a dated `protocol.json` deviation with rationale.

### Search strategy (run ALL of these, and add more as needed):

**Pass 1 — Broad topic sweeps:**
Run each pass for every eligible source listed under "Full Paperclip toolkit";
`<source>` is required and must be replaced (for example, `pmc` or `arxiv`).
```bash
paperclip search -s <source> "meta-analysis [full PICO topic]" --limit 100
paperclip search -s <source> "systematic review [full PICO topic]" --limit 100
paperclip search -s <source> "pooled analysis [core topic]" --limit 50
```

**Pass 2 — Outcome-specific queries** (one per major outcome domain):
```bash
paperclip search -s <source> "meta-analysis [topic] [outcome 1]" --limit 50
paperclip search -s <source> "meta-analysis [topic] [outcome 2]" --limit 50
# ... for each outcome you identified
```

**Pass 3 — Intervention/exposure-specific:**
```bash
paperclip search -s <source> "meta-analysis [specific drug/exposure name] [outcome]" --limit 50
# For each specific intervention or exposure variant
```

**Pass 4 — Population-specific:**
```bash
paperclip search -s <source> "meta-analysis [topic] [population subgroup]" --limit 50
# Children, elderly, pregnant, specific comorbidities, etc.
```

**Pass 5 — Costs and failure modes:**
- Medical:
```bash
paperclip search -s <source> "meta-analysis [intervention] adverse events safety" --limit 50
paperclip search -s <source> "meta-analysis [intervention] side effects harms" --limit 50
```
- ML/AI:
```bash
paperclip search -s arxiv "[method] computational cost efficiency" --limit 50
paperclip search -s arxiv "[method] failure cases limitations" --limit 50
paperclip search -s arxiv "[method] robustness out-of-distribution" --limit 50
```

**Pass 6 — Methodological variants:**
```bash
paperclip search -s <source> "network meta-analysis [topic]" --limit 50
paperclip search -s <source> "individual participant data meta-analysis [topic]" --limit 50
paperclip search -s <source> "dose-response meta-analysis [topic]" --limit 50
paperclip search -s <source> "umbrella review [topic]" --limit 50
```

**Pass 7 — Synonym and terminology coverage:**
```bash
# Run additional queries using alternative terminology, abbreviations, 
# MeSH terms, brand names vs generic names, etc.
```

**Pass 8 — Gap-filling:** After initial extraction, identify any outcome groups with thin coverage and run targeted searches for those specific outcomes.

**Pass 9 — Primary study extraction:**
- Medical (individual RCTs/trials) — **run each query across published + preprint sources** (`-s trials*` is temporarily disabled — it fails verification; find the trial's published report on `pmc`/`medrxiv` instead):
```bash
paperclip search -s pmc      "[intervention] [outcome] randomized controlled trial" --limit 100
paperclip search -s medrxiv  "[intervention] [outcome] randomized controlled trial" --limit 50   # newest clinical evidence
paperclip search -s pmc      "[intervention] [outcome] phase 3 trial" --limit 50
paperclip search -s pmc      "[trial name e.g. ZUMA-7 CARTITUDE] results" --limit 30              # pivotal trials as PUBLISHED papers (verifiable)
# (paperclip searches "..." "..." batches these in parallel)
```
- ML/AI (original method papers with evaluation) — arxiv-first:
```bash
paperclip search -s arxiv "[benchmark] [model] accuracy results" --limit 100
paperclip search -s arxiv "[method] [benchmark] state of the art" --limit 50
paperclip search -s arxiv "[benchmark] leaderboard evaluation" --limit 50
paperclip search -s abstracts "[benchmark] [model] score" --limit 50   # broad recall
```

**Pass 10 — Conference and recent publications:**
```bash
paperclip search -s <source> "[topic] 2024 2025" --limit 100
paperclip search -s <source> "[topic] preprint" --limit 50
```

**Pass 11 — High-quality reviews and authoritative sources:**
- Medical:
```bash
paperclip search -s pmc "Cochrane [topic]" --limit 50
paperclip search -s pmc "GRADE [topic] certainty evidence" --limit 50
```
- ML/AI:
```bash
paperclip search -s arxiv "[topic] survey comprehensive" --limit 50
paperclip search -s arxiv "[topic] benchmark comparison leaderboard" --limit 50
paperclip search -s arxiv "[topic] papers with code" --limit 50
```

**Pass 12 — Grey literature and broad recall:**

- Medical — **broaden recall with the abstract corpus** (regulatory `-s fda*` and `-s trials*` are temporarily DISABLED because their documents fail verification — see the source list under "Full Paperclip toolkit"; get pivotal-trial/regulatory numbers from the trial's PMC publication instead):
```bash
paperclip search -s abstracts "[intervention] [outcome]" --limit 50        # broad recall, abstract-only corpus
paperclip search -s pmc "[intervention] [outcome] registry real-world" --limit 50   # real-world/registry evidence as PUBLISHED papers (verifiable)
```
- ML/AI:
```bash
paperclip search -s arxiv "[method] technical report" --limit 30
paperclip search -s arxiv "[method] workshop paper" --limit 30
paperclip search -s arxiv "[method] [benchmark] preprint 2024 2025" --limit 50
paperclip search -s arxiv "[method] industry evaluation deployment" --limit 20
```

Note any studies with no published results or partial reporting — these suggest potential publication bias and should be reported in the synthesis.

### Full Paperclip toolkit

Paperclip has many more tools beyond `search` and `cat`. **Run `paperclip skill` to see the full documentation** — it covers all commands below and more. Use all of them:
- `paperclip searches "q1" "q2" "q3"` — parallel batch searching (much faster than sequential)
- `paperclip map --from SEARCH_ID "extract pooled OR, CI, I-squared"` — LLM reader across results (extracts from many papers at once without reading each individually)
- `paperclip grep` / `paperclip scan` — find tables and results sections without reading full text
- `paperclip ask-image` — discover/image-triage potential evidence only; values
  visible only in figures or image tables remain `missing_visual_evidence` and
  are not added to the verified repo
- `paperclip lookup doi <doi>` — find a specific paper by DOI, author, or journal
- `paperclip sql` — run structured queries against the corpus database
- `-s` source flag is REQUIRED on every search command. **⚠️ ONLY search sources whose documents the verification gate can resolve.** Every effect you pool must pass `paperclip repo commit` verification, and verification currently works ONLY for these sources — **use exactly these and no others:**
  - **Medical / clinical topics:** `-s pmc` (published full text) · `-s medrxiv` (medical preprints — **do NOT skip; newest clinical evidence lands here**) · `-s biorxiv` (mechanistic / preclinical) · `-s abstracts` (broad recall, abstract-only).
  - **ML / AI topics:** `-s arxiv` (primary) · `-s pmc` (applied/biomedical ML) · `-s abstracts` for breadth.
  - **🚫 DO NOT search `-s fda`, `-s fda/eu`, `-s fda/jp`, or any `-s trials*` registry.** These are temporarily unusable: their documents can be searched and read but **cannot be verified** (the verifier returns "Document not found" for `fda_…`/`tri_…` ids), so every effect from them fails the gate and is dropped. Pulling from them only wastes effort and inflates `[X]`. For pivotal-trial and regulatory numbers, extract the effect from the trial's **peer-reviewed PMC publication** instead (which verifies) — e.g. cite the ZUMA-7/CARTITUDE NEJM/Lancet/JCO paper via `-s pmc`, not the FDA review or the registry entry.
  - The goal within these verifiable sources is still **comprehensive coverage**: hit `pmc` + `medrxiv` + `biorxiv` + `abstracts` (medical) or `arxiv` + `pmc` + `abstracts` (ML). Run `paperclip search --help` for the full list, but restrict yourself to the verifiable subset above until this note is removed.

In particular, `map` is essential for large-scale extraction — instead of reading 50 papers one by one, search → then `map --from <search_id> "for each paper, extract the primary outcome effect size, 95% CI, and sample size"` to batch-extract across all results.

### Deduplication
Track all papers by DOI and PMCID across all search passes. Maintain a master list.

### Reproducible search strings

After completing the Paperclip search, generate equivalent search strings for standard databases so readers can reproduce the search independently:

**Medical:**
- **PubMed/MEDLINE**: Use MeSH terms + free-text synonyms with Boolean operators. Example: `("GLP-1 receptor agonists"[MeSH] OR "glucagon-like peptide-1"[tw] OR liraglutide[tw] OR semaglutide[tw]) AND ("cardiovascular diseases"[MeSH] OR "MACE"[tw])`
- **Embase**: Equivalent Emtree terms + free text
- **Cochrane CENTRAL**: Simplified version for trial registry

**ML/AI:**
- **Semantic Scholar**: API query with field-of-study filters
- **arXiv**: Category-scoped search (cs.CL, cs.LG, cs.CV, etc.) with date ranges
- **Papers With Code**: Method/benchmark keyword search

These strings should cover the same conceptual scope as the Paperclip queries. They do not need to be run (Paperclip coverage is broader), but their availability makes the search reproducible.

