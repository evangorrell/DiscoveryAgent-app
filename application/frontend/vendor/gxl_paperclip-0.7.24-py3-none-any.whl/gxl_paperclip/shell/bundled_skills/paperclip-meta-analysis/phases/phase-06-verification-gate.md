> ### Internal subroutine · Verification Gate and Compile · User stage: Evidence
> - **Consumes:** locked-schema `repo_staging.json`, added repo claims, and
>   `search_log.json` from Phase 5.
> - **Produces:** `verified_findings.json` exclusively through the shipped
>   universal exporter; reconciles `search_log.json.evidence_flow`.
> - **Precondition:** every extractor has joined and finished adding claims.
> - **Gate:** zero active `[?]`/`[X]`; exporter exits 0; every retained
>   structured claim is parseable, line-pinned, and server-verified.
> - **Next:** audit variance/precision provenance, then run
>   `phase-08-harmonization.md`. Statistical analysis is not allowed yet.

## Phase 6: Verification Gate and Universal Export

The fixed order is **extract → repo-stage → repo-add → verify every active
claim → export → variance audit → harmonize → evidence review → explicit
analyze → statistical run**.
Never pool from memory, raw `repo status` text, or a partial verified subset.

### 6a. Reconcile claims

Run `paperclip repo status` and compare it with `repo_staging.json`. Paper
count, claim count, stable IDs, schema/packet hashes, and path-scoped locations
must reconcile. Do not manually recreate a missing claim; repair/rerun
`repo-add` so persistence remains idempotent and auditable.

For an explicit manual correction only, retain structured JSON and exact
readable evidence lines:

```bash
paperclip repo add <doc_id> --json '{"type":"finding","card_id":"...","category":"project_defined","data":{"project_field":"reported value"},"relationships":[]}' --lines L45-L52
```

A source-fact card without readable source content or a precise path/line pin cannot
pass the source gate. Remove it from active repo claims and log it under
`removed_unverified_cards`; never leave it active and silently omit it.
Assessment cards separately preserve assessor/method provenance. Verification
confirms only explicit source support, not Claude/reviewer judgment.

### 6b. Drain verification

Phase 5's extraction workers did not mutate the repo. After all durable maps,
fallback merges, `repo-stage`, and `repo-add` finish, the one orchestrator
performs the verification commit:

```bash
paperclip repo commit -j 8 -m "Final verification sweep"
paperclip repo status
paperclip repo info <slug>
```

- There is no "verify the first 1,000" mode. If 5,000 effect claims were added,
  all 5,000 must resolve.
- `[?]` means unfinished. `[X]` means fix the line/value and re-commit, or
  explicitly remove and log the claim.
- Do not pool, cite, or report an active `[X]`.
- Record pre/post-gate counts by outcome in `verification_gate_summary`.

Use one stable summary shape in `search_log.json`:

```json
{
  "verification_gate_summary": {
    "repo_commit_sha": "",
    "claims_before": {"ok": 0, "x": 0, "pending": 0},
    "claims_after": {"ok": 0, "x": 0, "pending": 0},
    "effect_claims_ok_by_outcome": {},
    "corrected_claim_ids": [],
    "removed_claims": [{"claim_id": "", "reason": ""}]
  }
}
```

#### Parallel verification at scale

`repo commit` verifies concurrently across papers and across claims within each
paper. Stable `claim_id` keys prevent out-of-order responses from attaching a
verdict to the wrong annotation.

Path-aware `source_locations` keep identical line numbers in main text and
different supplements distinct. The verifier receives the cited path/ranges
plus bounded context from each readable source.

- `-j/--jobs` or `PAPERCLIP_VERIFY_JOBS` controls paper/batch fan-out (default 8).
- `PAPERCLIP_VERIFY_CLAIM_JOBS` controls same-paper claim fan-out (default 4,
  maximum 25 per backend request). Omitted MCP `--max-concurrent` also defaults
  to 4.
- `PAPERCLIP_VERIFY_CLAIM_BATCH` bounds claims serialized into one same-paper
  request (default 25). Large structured papers are verified in stable-ID
  batches so command/gateway size limits cannot force hundreds of sequential
  legacy calls.
- Transient 429/5xx/network failures retry with jitter and are never persisted
  as false `[X]` verdicts.
- Extraction workers never write the repo. Use exactly one orchestrator
  `repo-add`/committer role. `repo-add` is idempotent, and multiple whole-repo
  committers would redundantly sweep the same claims and waste capacity.
- Do not commit while `repo-add` is incomplete. Re-commit only
  after correcting genuine `[X]` claims or recovering from an interrupted
  verification request; already verified claims are skipped.

The client admission budget is
`VERIFY_JOBS × max(VERIFY_BATCH, VERIFY_CLAIM_JOBS)`. Defaults are
`8 × max(12, 4) = 96`, exactly `PAPERCLIP_VERIFY_MAX_INFLIGHT`; therefore
requesting `-j` above 8 is clamped unless an operator deliberately changes that
budget. Actual per-request verifier fan-out defaults to 4.

Each map/verify HTTP request also consumes one backend long-running slot:
ordinary users default to 8 concurrent requests, `@gxl.ai` users to 32, and
trusted internal callers may lift the request cap to at most 64. These request
caps are separate from a single map's `-j` subagent concurrency.

### 6c. Export the verified evidence store (mandatory)

Download the exact universal exporter served with the installed Paperclip
release. Overwrite stale local copies:

```bash
cd <topic_dir>
BASE="${PAPERCLIP_BASE_URL:-https://paperclip.gxl.ai}"
for f in guided_analysis.py export_verified.py data_qa.py; do
  curl -fsSL "$BASE/skills/scripts/$f" -o "$f"
done

python3 export_verified.py --output-dir .
```

`export_verified.py` is the guided workflow source of truth. It:

1. reads the active repo and authoritative server-merged verification store;
2. aligns verdicts by stable `claim_id` (legacy positional fallback requires an
   exact claim-text match);
3. preserves every `[OK]` structured claim with stable claim/finding ID,
   canonical broad `card_type`, dynamic project `record_type`, paper ID, every
   source location/line, verification scope, and raw payload unchanged;
4. retains explicit relationships, missingness, and ambiguity metadata;
5. normalizes legacy `paper_context` → `source_context` and `patient_group` →
   `analysis_unit` for import while preserving the original payload and
   recording normalization metadata;
6. preserves assessment provenance and labels reviewer-only judgments
   separately from assessments with explicit source support;
7. enforces only universal integrity: parseable JSON, stable unique IDs,
   source lines, recursively finite numbers, explicit CI ordering, and
   events not exceeding an explicit denominator; and
8. atomically emits `verified_findings.json` with card-model version, allowed
   broad types, counts, and legacy-normalization counts.

It does **not** require one arm shape, events whenever a denominator is
present, generic `n` equal to an outcome-specific denominator, comparative
structure, context completeness, or analysis-specific fields.

`compile_verified.py` remains available only for explicit imported
legacy/pairwise projects. It is not the guided workflow source of truth and
must never be used to discard flexible verified findings.

Do **not** use this diagnostic shortcut as the compiler:

```bash
paperclip repo claims --verified-only --type effect
```

That command is useful for progress counts and inspection, but redirecting it
to `verified_findings.json` bypasses stable-ID, source-line, numeric, and
universal integrity checks.

### 6d. Reconcile the evidence-flow ledger

Update `search_log.json.evidence_flow` from repo/compiler facts:

```json
{
  "records_found_total": 0,
  "records_deduplicated": 0,
  "papers_screened_title_abstract": 0,
  "papers_screened_full_text": 0,
  "papers_full_text_excluded": 0,
  "papers_included": 0,
  "raw_numeric_candidates_inspected": 0,
  "effect_claims_submitted_total": 0,
  "effect_claims_removed": 0,
  "effect_claims_active": 0,
  "effect_claims_ok": 0,
  "effect_claims_x": 0,
  "effect_claims_pending": 0,
  "effects_compiled": 0,
  "effects_selected_primary_pooling": 0,
  "effects_secondary_or_sensitivity": 0,
  "effects_excluded_from_pooling": 0
}
```

Required arithmetic:

- submitted = active + removed
- active = OK + X + pending
- X = 0 and pending = 0 before compile
- exported = `len(verified_findings.json.findings)` = all OK structured claims

`effects_selected_primary_pooling` and downstream selection fields remain zero
until Phase 7; update them after pooling. If the equations do not reconcile,
investigate stale verification, malformed claims, duplicates, or removals.

### 6e. Checkpoint

Do not continue until all hold:

- [ ] Every extractor joined; one final commit completed.
- [ ] `repo_staging.json.ready_to_add` was true and staged/add counts reconcile.
- [ ] `paperclip repo info <slug>` reports `0 unverified [?]`.
- [ ] Every active `[X]` was corrected or removed/logged.
- [ ] `export_verified.py` exited 0.
- [ ] `verified_findings.json` exists and was not hand-written.
- [ ] Every exported card has stable ID, canonical broad card type, dynamic
  project record type, paper ID, all source locations, verification scope, and
  unchanged raw payload.
- [ ] Every assessment preserves assessor/method provenance and is not
  described as a source-reported fact unless source support is explicit.
- [ ] Export count equals all server-merged `[OK]` structured claims.
- [ ] Evidence-flow arithmetic reconciles; no numeric target was used to leave
  claims unresolved.

If any check fails, remain in Phase 6.
