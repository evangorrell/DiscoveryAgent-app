> ### Internal subroutine · Evidence Classification and Harmonization · User stage: Evidence
> - **Consumes:** `collection_spec.json`, `planned_outputs.json`,
>   `verified_findings.json`, search/audit records, and approved
>   project definitions.
> - **Produces:** `evidence_proposal.json`, `harmonization_queue.json` when
>   needed, final hash-bound `harmonization_map.json`, optional proposed
>   analysis-input design, and refreshed `evidence_review.json`.
> - **Precondition:** all scaled workers/shards joined and Phase 6 export passed.
> - **Gate:** every verified card is classified; material harmonization is
>   user-approved; readiness and visual-evidence gaps are explicit.
> - **Next:** Evidence `AskUserQuestion` checkpoint. Statistical analysis is not
>   allowed before the user explicitly chooses Results.

## Phase 8: Evidence Classification and Harmonization

This subroutine runs **before any generated analysis**. It must not consume
`analysis.json` or use statistical output to decide how Evidence should be
grouped.

### 8a. Audit precision, completeness, and provenance

For every verified finding relevant to a planned output, determine:

- exact reported value, unit/scale, definition, timepoint, population/unit,
  comparator/reference, denominator, and uncertainty fields when applicable;
- whether precision is reported, safely derivable from complete explicit
  inputs, or missing;
- source card/location and relationship to analysis units;
- dependency/overlap/duplicate risks;
- missing/ambiguous fields and materiality.

Never infer an unreported SD, correlation, continuity correction, denominator,
comparison, or effective sample size. Keep non-analyzable verified findings in
the Evidence inventory with an explicit descriptive/excluded/unresolved reason.

Carry every image-only desired value as `missing_visual_evidence`. Do not
promote a caption or visually read number into verified Evidence.

### 8b. Build evidence_proposal.json

Classify every verified card exactly once as:

- `selected`
- `descriptive`
- `duplicate`
- `excluded`
- `unresolved`

Each proposal row retains the verified card ID and unchanged copied values,
records a rationale, and attributes the decision to Claude/reviewer provenance.
Source verification does not verify this judgment.

Use `planned_outputs.json` to explain readiness, not to censor collection.
Cards that do not enter an inferential model can still support descriptive
tables, context, limitations, or future work.

### 8c. Queue and decide harmonization

Preserve every original source label. Obvious case/punctuation/spelling aliases
may use `automatic_obvious` only when meaning is unchanged. All other proposed
mappings go to `harmonization_queue.json` with:

- source label and examples;
- proposed normalized ID;
- exact/alias/hierarchy/distinct relation;
- rationale and material impact;
- affected cards and requested outputs;
- source definitions or unresolved conflict.

Material mappings include changed meaning, normalized-group membership,
hierarchy, definition, timepoint, denominator, grading system, comparison, or
analysis grouping.

> **CHECKPOINT — ASK THE USER:** Batch material harmonization choices into a
> concise plain-language `AskUserQuestion`. Show practical effects on analyses
> and visualizations. Apply only explicit user answers. Do not ask the user to
> edit map files or run helper commands.

Unresolved labels remain unchanged. Never force unlike concepts together to
increase sample size.

### 8d. Finalize harmonization_map.json

The final map is deterministic and hash-bound to:

- current material `collection_spec.json` schema hash;
- current `verified_findings.json` hash;
- current `evidence_proposal.json` hash;
- current queue/hash when a queue exists.

Each decision records status (`automatic_obvious`, `user_approved`, or
`unresolved`), relation, original/normalized IDs, rationale, revision type, and
decision provenance. A material map change reopens Evidence review; it cannot
be made downstream in analysis code.

### 8e. Reconcile Evidence

Confirm:

1. every exported verified card has one proposal classification;
2. selected + descriptive + duplicate + excluded + unresolved equals exported;
3. no unknown label is silently normalized;
4. all material map decisions have explicit user provenance;
5. analysis-unit relationships and duplicate/overlap decisions are complete;
6. variance/precision status is explicit for every analysis-relevant finding;
7. `missing_visual_evidence` is counted separately from absent/unreported data;
8. search/screen/verification/export counts reconcile;
9. planned analyses/visualizations each have ready, descriptive-fallback, or
   blocked status with reasons.

Refresh deterministic `evidence_review.json`. It must summarize:

- source/design/category/unit coverage and marginal yield;
- proposal classification counts;
- harmonization decisions and unresolved queue;
- quality/applicability/duplicate assessments with provenance;
- analysis and visualization readiness by requested output;
- missing fields, precision blockers, source limitations, and
  `missing_visual_evidence`;
- recommended next choices.

> **CHECKPOINT — ASK THE USER:** Present Evidence in plain language and use
> `AskUserQuestion` to revise Evidence, proceed to Results, or stop. Passing
> export/readiness gates does not authorize analysis. Remain in Evidence until
> the user explicitly chooses Results; Claude then records that choice through
> the private helper.
