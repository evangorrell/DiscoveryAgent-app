> ### Internal subroutine · Research Question Decomposition · User stage: Question
> - **Consumes:** the user's topic / question (`$ARGUMENTS`, see `00-overview.md`).
> - **Produces:** a decomposed PICO/MISO framework + archetype classification.
>   This is in-context reasoning captured in `protocol_draft.json` by the next
>   subroutine.
> - **Precondition:** requested deliverable confirmed (data curation or full
>   meta-analysis) per `00-overview.md`.
> - **Next:** `phase-02-protocol-viability.md`, then
>   `phase-02-schema-discovery.md` before the Question checkpoint.

## Phase 1: Research Question Decomposition

Parse the user's prompt into a structured framework appropriate for the
domain. PICO/PECO and MISO below are examples, not the only permitted
project-specific framework:

**Medical — PICO/PECO framework:**
```
Population:     [who — age, condition, setting]
Intervention/Exposure: [what — drug, behavior, risk factor]
Comparator:     [vs what — placebo, no exposure, alternative]
Outcome:        [what is measured — mortality, disease incidence, biomarker]
```

**ML/AI — MISO framework (Model/method, Input/task, Setting, Outcome):**
```
Model/Method:   [what — LoRA, RAG, chain-of-thought, specific architecture]
Input/Task:     [applied to what — NLP benchmarks, code generation, image classification]
Setting:        [under what conditions — model size, dataset size, compute budget, domain]
Outcome:        [what is measured — accuracy delta, speedup, perplexity, cost reduction]
```

Classify a useful project archetype when one applies:
- **Intervention PICO** (medical): drug/treatment vs comparator → OR, RR, HR, MD, SMD
- **Exposure PECO** (medical): risk factor/behavior → OR, HR with exposure levels
- **Prevalence/Rate** (medical): epidemiological estimation → pooled proportions, incidence rates, IRR
- **Method comparison** (ML): method A vs method B or baseline → accuracy delta (pp), speedup ratio, perplexity reduction
- **Scaling/moderator** (ML): how does X change with model size/data/compute → regression coefficients, correlation

The archetype informs the dynamic collection fields, comparison framing, and
statistical null when relevant. It never changes the six universal broad card
types or injects fixed medical/ML categories into every project.

