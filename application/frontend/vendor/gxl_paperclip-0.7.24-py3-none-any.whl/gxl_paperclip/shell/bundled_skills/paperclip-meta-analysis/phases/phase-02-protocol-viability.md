> ### Internal subroutine · Protocol and Source Readiness · User stage: Question
> - **Consumes:** the decomposed question and useful archetype from Phase 1.
> - **Produces:** `protocol_draft.json`, `source_readiness.json`,
>   provisional `collection_spec.json`, and `planned_outputs.json`.
> - **Precondition:** requested deliverable and decision context are understood.
> - **Next:** `phase-02-schema-discovery.md`, then the Question
>   `AskUserQuestion` checkpoint. Claude records approval privately; only then
>   continue to Phase 3.

## Phase 2: Protocol, Collection Plan, and Viability

This subroutine designs the review before evidence collection. PICO/PECO and
MISO are useful examples, not universal schemas. Build contracts around the
actual question and requested outputs.

### 2a. Check source readiness and viability

Run a small source-explicit scoping search across every relevant, verifiable
Paperclip corpus. Record exact source names and queries. Check:

1. recent syntheses that overlap the proposed scope;
2. likely primary-source volume and design diversity;
3. readable full-text/table/supplement availability;
4. likely terminology, population/unit, intervention/exposure/method,
   comparator, outcome/finding, timepoint, and definition variation;
5. known source omissions or verification constraints; and
6. whether requested analyses/visualizations appear supportable.

Write `source_readiness.json` with:

```json
{
  "schema_version": 1,
  "sources_checked": [],
  "queries": [],
  "existing_syntheses": [],
  "estimated_landscape": {},
  "access_and_verification_constraints": [],
  "anticipated_gaps": [],
  "verdict": "proceed | scope_down | stop",
  "rationale": ""
}
```

Do not present a numeric study threshold as a universal viability rule.
Explain what the observed scale means for this question and the desired
outputs.

### 2b. Write protocol_draft.json

The draft records:

- review question and project-specific decomposition;
- scope and operational definitions;
- inclusion/exclusion rules and eligible source/publication types;
- date/language rules and justified source constraints;
- screening and deduplication rules;
- dependency/overlap rules;
- adaptive search policy;
- material-deviation policy;
- requested Evidence and Results deliverables; and
- unresolved user decisions.

The protocol must allow query refinement for coverage gaps while requiring a
dated, user-approved material deviation for changed eligibility, definitions,
grouping, analysis direction, or output intent.

Do not write canonical `protocol.json` directly. Question approval preserves
the draft bytes atomically as `protocol.json`.

### 2c. Design collection_spec.json

New guided projects use a dynamic collection contract. The fixed universal
card types are:

```text
source_context
analysis_unit
finding
definition
relationship
assessment
```

The spec must include:

- `schema_version` and material `version`;
- non-empty rationale;
- universal wrapper with card type, dynamic record/category type, stable ID,
  paper/document ID, every source location/line, raw payload, relationships,
  missingness, ambiguity, and assessment provenance;
- project-specific categories, fields, and definitions;
- aliases and provisional normalizations;
- approved missing-status choices;
- `pilot_status:"not_run"` or `"needs_rerun"`;
- empty/current pilot summary and revision history.

Do not inject fixed effect-size, PICO, patient, benchmark, or quality columns
when the project does not need them. `analysis_unit` can represent a cohort,
arm, population, model/dataset/run, batch, site, or another defined unit.
`assessment` is reviewer judgment and must retain assessor/method/source-basis
provenance.

### 2d. Write planned_outputs.json

Capture analyses and visualizations the user wants, each with:

- stable output ID, purpose, and audience;
- required categories/fields/relationships;
- minimum readiness conditions;
- allowed descriptive fallback when inference is unsupported; and
- known limitations.

Output intent guides completeness; it never authorizes dropping an in-scope
verified finding.

### 2e. Define the representative pilot

Plan a small, diverse pilot that exercises:

- expected source designs and publication forms;
- major categories and analysis-unit types;
- naming/definition/timepoint/denominator/grading variation;
- missing and ambiguous cases;
- at least one dense or multi-category paper when plausible; and
- independent extraction/agreement plus contract validation.

The pilot is a test of the material collection schema and output readiness, not
a miniature final result.

Do not ask for final Question approval yet. First run
`phase-02-schema-discovery.md`, revise the provisional collection design from
source-pinned map observations, and then present one combined Question
checkpoint. Never ask the user to manage the discovery map or run a lifecycle
command.
