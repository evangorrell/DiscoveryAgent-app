# Paperclip Guided Evidence Synthesis Overview

Read this once, then load only the internal phase files called by the current
stage. The workflow exposes exactly three stages to the user: **Question**,
**Evidence**, and **Results**.

Numbered phases are implementation subroutines. Claude manages them and the
private `guided_analysis.py` lifecycle helper. Users receive plain-language
summaries and answer `AskUserQuestion`; they are never instructed to type
private helper commands.

## Stage 1 — Question

Internal order:

1. question decomposition (`phase-01-decomposition.md`);
2. protocol, source readiness, collection design, and output intent
   (`phase-02-protocol-viability.md`);
3. representative map-based schema discovery
   (`phase-02-schema-discovery.md`).

Required draft artifacts:

- `protocol_draft.json` — scope, eligibility, definitions, dependency rules,
  deviations, and review question;
- `source_readiness.json` — sources/queries checked, access constraints,
  likely coverage, existing syntheses, and proceed/scope-down/stop verdict;
- `schema_discovery.json` — merged, source-pinned field/option observations
  from the bundled fixed discovery-map contract;
- `schema_optimization.candidate.json` — Claude's provisional canonical fields,
  bounded/open/hybrid vocabulary choices, aliases, and decision rationale;
- `collection_spec.json` — dynamic categories, fields, definitions, aliases,
  provisional normalizations, missing statuses, and pilot state;
- `planned_outputs.json` — analyses and visualizations the user wants, with
  their required evidence fields.

Question approval snapshots these files, atomically preserves
`protocol_draft.json` as canonical `protocol.json`, and authorizes generation
of the provisional project extraction schema. The reusable discovery schema is
not the project extraction schema.

> **CHECKPOINT — ASK THE USER:** Explain the proposed scope and material
> choices in plain language, including which vocabularies are bounded, open, or
> hybrid and which discoveries were excluded as background-only. Use
> `AskUserQuestion` to approve, revise, or stop. Do not begin Evidence until the
> answer explicitly approves the proposal.

## Stage 2 — Evidence

Internal order:

1. dynamic extraction guidance (`phase-03-extraction-guidance.md`);
2. source-explicit iterative search (`phase-04-search.md`);
3. representative pilot, categorical/schema optimization and lock,
   user-reviewed revisions, then scaled structured waves
   (`phase-05-screening-extraction.md`);
4. deterministic repo staging/addition, final verification drain, and universal export
   (`phase-06-verification-gate.md`);
5. variance/precision, completeness, and coverage audit;
6. classification and harmonization before analysis
   (`phase-08-harmonization.md`);
7. deterministic `evidence_review.json`.

Search and extraction alternate in waves: broad retrieval → deduplication →
screen/extract → coverage review → targeted gap search → repeat. Scale is
justified by category/unit coverage and marginal yield, never a universal card
quota.

The representative pilot must cover diverse source designs and expected record
categories. The new structured worker is compared with the exhaustive worker
during migration; value/location agreement and contract validation must pass.
Claude optimizes categorical options and generates one paper-level schema in
which every value has its own source path/lines. Material changes to meaning,
grouping, hierarchy, denominator, timepoint, grading, options, or collection
structure are presented through `AskUserQuestion`, applied only after user
approval, and trigger a new pilot. Scaled extraction cannot start with a stale
pilot or schema lock. After the final pilot, show the exact generated schema
files, a human-readable revision summary, and the paths for inspection. A
separate explicit approve-and-lock answer is required before `schema-lock` and
scaled extraction.

The default worker returns one strict full-paper object without repo mutation.
Only explicit size/schema failures use the tool-based exhaustive fallback,
whose category-record schema is bound to the same lock. Deterministic
`repo-stage` merges and validates outputs, `repo-add` persists claims, and the
later commit verifies them. Hide this orchestration detail from the user.

### Verified visual-evidence boundary

- Exact values in readable article text, readable tables, or text-based
  supplements are eligible.
- Values visible only in figures, plots, screenshots, scanned pages, or image
  tables are not added to the verified repo.
- A caption cannot verify a numeric value visible only inside its image.
- Record each such gap as `missing_visual_evidence`.
- Image tools may discover a gap, but image-derived values remain outside
  `verified_findings.json` until a separate visual-verification contract exists.

The Evidence artifacts preserve all verified cards, user-approved
harmonization, exclusions/duplicates, reviewer decision provenance, and
analysis/visualization readiness.

> **CHECKPOINT — ASK THE USER:** Present coverage, gaps, visual exclusions,
> harmonization, unresolved choices, and readiness. Use `AskUserQuestion` to
> revise Evidence, proceed to Results, or stop. Passing gates never causes an
> automatic transition.

## Stage 3 — Results

Internal order:

1. generated package-backed analysis (`phase-07-statistical-analysis.md`);
2. managed execution/result validation;
3. manuscript synthesis (`phase-09-synthesis.md`);
4. artifact inventory (`phase-10-output.md`);
5. fixed data/methodological gates (`quality-gates.md`);
6. iterative report authoring and fixed render QA (`phase-11-render.md`);
7. explicit versioned publication (`phase-12-persist.md`).

The generated analysis package freezes approved inputs, methods, source/tests,
runtime, and hashes. Optional recipes remain example-only. Claude authors
`report_spec.json`, `dashboard_spec.json`, and self-contained `index.html`.
Every report revision archives the previous result/report artifacts in
`revisions/results-vN/`, reruns QA, and returns to user review.

QA pass means ready for review. Preview is local and never uploads.

> **CHECKPOINT — ASK THE USER:** Use `AskUserQuestion` to revise Results,
> reopen Evidence, stop, or explicitly publish. Publish only to
> `analyses/<slug>/v<results_revision>` after an explicit answer; never infer
> approval from a passing preview.

## Durable layers

1. **Paper repo:** verified source-backed cards and exact evidence locations.
2. **Run directory:** question contracts, Evidence artifacts, generated
   analysis package, synthesis, revision archives, report, QA, and manifests.
3. **Clipboard:** immutable versioned publication only after explicit approval.

Repo commits do not upload artifacts. Preview and QA do not publish. Reopening
Evidence invalidates its freeze and managed execution; report-only revision
preserves both.

The topic is: `$ARGUMENTS`
