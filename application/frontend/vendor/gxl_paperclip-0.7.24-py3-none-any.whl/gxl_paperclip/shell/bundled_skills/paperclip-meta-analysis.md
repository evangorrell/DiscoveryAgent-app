---
name: paperclip-meta-analysis
description: >-
  Guide a systematic review, evidence map, or quantitative synthesis through
  three explicit user checkpoints: Question, Evidence, and Results. Uses
  project-specific verified extraction, generated analysis packages, iterative
  report review, and explicit versioned publication.
---

# Paperclip Guided Evidence Synthesis

This workflow has exactly three user-visible stages: **Question**,
**Evidence**, and **Results**. The numbered phase files are modular internal
subroutines used by Claude; they are not extra user stages.

Claude owns orchestration and private lifecycle state. Never ask the user to
run `guided_analysis.py` or expose the lifecycle helper as a public Paperclip
command group.
At every checkpoint, summarize the decision in plain language and use
`AskUserQuestion`. A successful validator, pilot, or QA run is never user
approval.

## Stage 1 — Question

Run these internal subroutines:

1. `phases/phase-01-decomposition.md`
2. `phases/phase-02-protocol-viability.md`
3. `phases/phase-02-schema-discovery.md`

Produce `protocol_draft.json`, `source_readiness.json`,
`schema_discovery.json`, `schema_optimization.candidate.json`,
`collection_spec.json`, and `planned_outputs.json`. Schema determination uses
`map` with the bundled fixed `schema-discovery.schema.json`; an unconstrained
free-text map is not the approval artifact. Claude merges the mapped
observations into a project-specific proposal and never claims that pilot
categories are comprehensive. Universal repo card types are applied later by
deterministic staging, not emitted as the paper-level extraction format.

> **CHECKPOINT — ASK THE USER:** Present the proposed question, scope, source
> readiness, collection categories/fields, planned analyses/visualizations,
> bounded/open/hybrid vocabulary choices, important exclusions, unresolved
> normalization choices, and tradeoffs. Use `AskUserQuestion` with
> plain-language choices to approve, request changes, or stop. Remain in
> Question until the user explicitly approves. Claude then records approval
> privately, materializes canonical `protocol.json`, and generates the
> provisional project extraction schema.

## Stage 2 — Evidence

After Question approval, run these internal subroutines in this order:

1. `phases/phase-03-extraction-guidance.md`
2. `phases/phase-04-search.md`
3. `phases/phase-05-screening-extraction.md`
4. `phases/phase-06-verification-gate.md`
5. variance/precision and coverage audit
6. `phases/phase-08-harmonization.md`
7. deterministic `evidence_review.json` refresh

Evidence starts with a representative pilot. Present material ambiguities and
schema/output revisions to the user, apply only user-approved material
changes, and rerun the pilot until it passes for the exact approved collection
plan. After the final pilot, present the exact generated
`schema_optimization.json`, `extraction_schema.json`, and
`fallback_claim_schema.json`, plus a plain-language revision summary and exact
paths for inspection. Use `AskUserQuestion` to approve-and-lock, revise/rerun,
or stop. Claude locks the exact schema only after explicit approval. Only then
launch scaled search/screen/extract waves.

The default extractor makes one full-paper Claude call over a canonical packet
and returns one strict schema-valid object without changing the repo. Persistent
schema/size failures explicitly fall back to the tool-using exhaustive worker;
fallback records use a generated schema bound to the same lock and merge before
verification. Claude runs deterministic `repo-stage`, then a separate
`repo-add`, then the separate repo verification commit. This is internal; never
ask the user to manage workers, shards, staging, or commits.

Only exact values in readable text, readable tables, or text supplements are
eligible as verified source findings. Values visible only in figures, plots,
screenshots, scans, or image tables are excluded from the verified repo.
Captions do not verify numbers visible only in an image. Record those gaps as
`missing_visual_evidence` until a separate visual-verification contract exists.

> **CHECKPOINT — ASK THE USER:** Present `evidence_review.json`, including
> coverage, exclusions, unresolved questions, visual-evidence gaps,
> harmonization decisions, and analysis/visualization readiness. Use
> `AskUserQuestion` with plain-language choices to revise Evidence, proceed to
> Results, or stop. Do not generate analysis merely because Evidence gates
> pass. Claude opens Results privately only after an explicit user choice.

## Stage 3 — Results

After the user approves analysis:

1. `phases/phase-07-statistical-analysis.md` — generate and execute a
   package-backed analysis tailored to approved Evidence
2. validate execution and result contracts
3. `phases/phase-09-synthesis.md`
4. `phases/phase-10-output.md`
5. `phases/quality-gates.md`
6. `phases/phase-11-render.md` — iterative agent-authored report
7. `phases/phase-12-persist.md` — explicit versioned publication

Examples are optional and example-only; they are never the default analysis or
correctness contract. Passing data/render QA means the current revision is
ready for review, not approved and not uploaded. Claude previews the report,
uses `AskUserQuestion`, archives each requested Results revision before
editing, and repeats authoring/QA/preview until the user accepts it.

> **CHECKPOINT — ASK THE USER:** Offer plain-language choices to revise the
> report, reopen Evidence, stop, or publish. Publication occurs only after an
> explicit publish choice and always targets a new immutable
> `analyses/<slug>/v<results_revision>` path. Preview and QA never upload.

## Non-negotiable invariants

- The paper repo remains the source of truth for verified source-backed cards.
- Extraction workers do not mutate the repo. One orchestrator owns the
  deterministic staging/add step and verification commits.
- Every extracted value has its own source path/lines. All retained repo claims
  are stable-ID, exact-location, and fully resolved.
- Schema discovery uses the bundled structured discovery contract; free-text
  brainstorming is never treated as source-provenanced schema approval.
- Open-world products/outcomes/assays/cohorts preserve `as_reported` wording and
  are not forced into a supposedly comprehensive enum.
- Final generated schema files and their pilot changes are shown to the user;
  validator/pilot success never substitutes for explicit approval before lock
  and scale.
- `verified_findings.json` comes only from the universal exporter.
- Reviewer/Claude assessments retain judgment provenance and are not presented
  as source-reported facts.
- Harmonization and Evidence review finish before any generated analysis.
- Reopening Evidence invalidates downstream execution; report-only revision
  does not.
- No automatic stage transition and no automatic upload.

Start by reading `paperclip-meta-analysis/phases/00-overview.md`.
