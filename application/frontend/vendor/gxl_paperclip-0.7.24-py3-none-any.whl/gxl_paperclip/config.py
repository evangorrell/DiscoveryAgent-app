"""Configuration constants for Paperclip."""

from __future__ import annotations

import json
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Server base URL (backend — hosts /api/cli)
# ---------------------------------------------------------------------------
DEFAULT_BASE_URL = os.getenv("PAPERCLIP_BASE_URL", "https://paperclip.gxl.ai")

# ---------------------------------------------------------------------------
# OAuth 2.0 Authentication
# ---------------------------------------------------------------------------
OAUTH_BASE_URL = os.getenv(
    "PAPERCLIP_OAUTH_URL",
    f"{DEFAULT_BASE_URL}/api/oauth",
)

# ---------------------------------------------------------------------------
# API Key Authentication (alternative to OAuth)
# ---------------------------------------------------------------------------
PAPERCLIP_API_KEY = os.getenv("PAPERCLIP_API_KEY", "")

# ---------------------------------------------------------------------------
# Local storage
# ---------------------------------------------------------------------------
PAPERCLIP_DIR = Path(os.getenv("PAPERCLIP_CONFIG_DIR", Path.home() / ".paperclip"))
CREDENTIALS_FILE = PAPERCLIP_DIR / "credentials.json"
CONFIG_FILE = PAPERCLIP_DIR / "config.json"


def _read_state() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def get_base_url() -> str:
    """Resolve the effective server base URL.

    Precedence:
      1. An explicit ``PAPERCLIP_BASE_URL`` env var (highest). This is the
         override knob the chat / MCP backends use to pin a spawned CLI to the
         same-environment backend (dev→dev, staging→staging, prod→prod),
         independent of whatever ``~/.paperclip/config.json`` happens to hold.
      2. A user-configured ``base_url`` in ``config.json`` (set via
         ``paperclip config --url``).
      3. The hard-coded ``DEFAULT_BASE_URL``.

    Kept here (not in cli.py) so that credentials.py can import it without
    circular dependencies.
    """
    env_url = os.getenv("PAPERCLIP_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    state = _read_state()

    if "base_url" in state:
        return state["base_url"].rstrip("/")
    mcp_url = state.get("mcp_url", "")
    if mcp_url and "/mcp/" in mcp_url:
        return mcp_url.split("/mcp/")[0]
    return DEFAULT_BASE_URL.rstrip("/")


def repos_enabled() -> bool:
    """User-local preference for whether the paper-repositories feature is active.

    Defaults to ``True``. Toggled via ``paperclip repos disable`` / ``enable``.
    Lives here so both the CLI and the skill installer can read it without a
    circular import.
    """
    return bool(_read_state().get("repos_enabled", True))


def set_repos_enabled(enabled: bool) -> None:
    """Persist the local repos on/off preference to config.json."""
    PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
    state = _read_state()
    state["repos_enabled"] = bool(enabled)
    CONFIG_FILE.write_text(json.dumps(state, indent=2))
