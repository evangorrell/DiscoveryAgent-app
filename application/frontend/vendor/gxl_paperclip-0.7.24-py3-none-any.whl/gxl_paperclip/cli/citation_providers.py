"""Public citation-provider clients for the citation-explorer workflow.

Edge sources (return citing-paper records):
  * OpenAlex — citing works via ``filter=cites:<OpenAlex ID>``
  * NIH iCite — PubMed ``citedByPmids`` (PMID resolution via Europe PMC)

Count / provenance checks (do not supply full citing DOI lists publicly):
  * Crossref — ``is-referenced-by-count``
  * OpenCitations — incoming citation edges + counts
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)

MAX_RETRIES = 5
BACKOFF_BASE_S = 1.0
DEFAULT_LIST_LIMIT = 50
MAX_LIST_RESULTS = 200
REQUEST_TIMEOUT_S = 60

_DOI_RE = re.compile(
    r"(?:doi\.org/|doi:\s*)?(10\.\d{4,9}/[-._;()/:A-Z0-9]+)",
    re.IGNORECASE,
)
_ARXIV_RE = re.compile(
    r"(?:arxiv\.org/(?:abs|pdf|html)/)?(\d{4}\.\d{4,5})(?:v\d+)?",
    re.IGNORECASE,
)


def normalize_doi(value: str | None) -> str | None:
    """Normalize a DOI string. Return None when no DOI is present."""
    if not value:
        return None
    text = value.strip()
    match = _DOI_RE.search(text)
    if not match:
        # Bare DOI without prefix
        if text.lower().startswith("10."):
            doi = text.split()[0].rstrip(".,;)")
            return doi.lower()
        return None
    return match.group(1).rstrip(".,;)").lower()


def normalize_title(value: str | None) -> str:
    """Lowercase title with collapsed whitespace and stripped punctuation edges."""
    if not value:
        return ""
    cleaned = re.sub(r"\s+", " ", value.strip().lower())
    cleaned = cleaned.strip(" .,:;\"'`")
    return cleaned


def extract_arxiv_id(value: str | None) -> str | None:
    """Extract a bare arXiv id (``YYMM.NNNNN``) from a URL or id string."""
    if not value:
        return None
    match = _ARXIV_RE.search(value.strip())
    return match.group(1) if match else None


def user_agent() -> str:
    contact = os.getenv("CITATIONS_CONTACT_EMAIL", "dev@gxl.ai")
    return f"gxl-citation-explorer/0.1 (mailto:{contact})"


def get_json(url: str, *, headers: dict[str, str] | None = None) -> Any:
    """GET JSON with bounded retry/backoff for public provider APIs."""
    req_headers = {"Accept": "application/json", "User-Agent": user_agent()}
    if headers:
        req_headers.update(headers)
    request = urllib.request.Request(url, headers=req_headers)
    for attempt in range(MAX_RETRIES + 1):
        try:
            with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_S) as response:
                return json.load(response)
        except urllib.error.HTTPError as exc:
            transient = exc.code == 429 or 500 <= exc.code < 600
            if not transient or attempt >= MAX_RETRIES:
                raise
            retry_after = exc.headers.get("Retry-After") if exc.headers else None
            try:
                delay = float(retry_after) if retry_after else None
            except (TypeError, ValueError):
                delay = None
            time.sleep(delay or BACKOFF_BASE_S * (2**attempt))
        except urllib.error.URLError:
            if attempt >= MAX_RETRIES:
                raise
            time.sleep(BACKOFF_BASE_S * (2**attempt))
    raise RuntimeError("unreachable")


def _query(url: str, params: dict[str, Any]) -> str:
    return f"{url}?{urllib.parse.urlencode(params)}"


@dataclass
class CitingRecord:
    """One citing work from a public provider (before Paperclip matching)."""

    title: str = ""
    doi: str | None = None
    pmid: str | None = None
    arxiv_id: str | None = None
    year: int | None = None
    openalex_id: str | None = None
    providers: list[str] = field(default_factory=list)
    source_ids: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ProviderChecks:
    """Independent count / provenance checks (not authoritative edge lists)."""

    crossref_is_referenced_by_count: int | None = None
    opencitations_citation_count: int | None = None
    openalex_cited_by_count: int | None = None
    icite_cited_by_pmid_count: int | None = None
    errors: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ProviderBundle:
    """Union of citing records plus independent checks for one target DOI."""

    target_doi: str
    target_pmid: str | None = None
    target_openalex_id: str | None = None
    target_title: str = ""
    citing: list[CitingRecord] = field(default_factory=list)
    checks: ProviderChecks = field(default_factory=ProviderChecks)
    provider_edge_counts: dict[str, int] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "target_doi": self.target_doi,
            "target_pmid": self.target_pmid,
            "target_openalex_id": self.target_openalex_id,
            "target_title": self.target_title,
            "citing": [c.to_dict() for c in self.citing],
            "checks": self.checks.to_dict(),
            "provider_edge_counts": dict(self.provider_edge_counts),
            "errors": dict(self.errors),
        }


def resolve_pmid(doi: str) -> str | None:
    """Resolve a PubMed ID for a DOI via Europe PMC."""
    query = _query(
        "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
        {"query": f"DOI:{doi}", "format": "json", "pageSize": 1},
    )
    result = get_json(query)
    rows = (result.get("resultList") or {}).get("result") or []
    if not rows:
        return None
    pmid = rows[0].get("pmid")
    return str(pmid) if pmid else None


def fetch_openalex(doi: str, *, list_limit: int) -> dict[str, Any]:
    """Fetch OpenAlex target metadata and a bounded citing-work list."""
    params: dict[str, Any] = {
        "select": (
            "id,doi,title,publication_year,ids,cited_by_count,"
            "referenced_works,updated_date"
        )
    }
    api_key = os.getenv("OPENALEX_API_KEY")
    if api_key:
        params["api_key"] = api_key
    target = get_json(
        _query(f"https://api.openalex.org/works/https://doi.org/{doi}", params)
    )
    openalex_id = str(target["id"]).rsplit("/", 1)[-1]

    citing_params: dict[str, Any] = {
        "filter": f"cites:{openalex_id}",
        "per-page": min(list_limit, 200),
        "select": "id,doi,title,publication_year,ids,cited_by_count",
    }
    if api_key:
        citing_params["api_key"] = api_key

    results: list[dict[str, Any]] = []
    cursor: str | None = "*"
    while cursor and len(results) < list_limit:
        page_params = dict(citing_params)
        page_params["cursor"] = cursor
        page_params["per-page"] = min(200, list_limit - len(results))
        page = get_json(_query("https://api.openalex.org/works", page_params))
        batch = page.get("results") or []
        results.extend(batch)
        cursor = (page.get("meta") or {}).get("next_cursor")
        if not batch:
            break

    return {
        "target": target,
        "citing_works": results[:list_limit],
        "citing_count": (page.get("meta") or {}).get("count")
        if results
        else target.get("cited_by_count"),
        "openalex_id": openalex_id,
    }


def fetch_crossref(doi: str) -> dict[str, Any]:
    """Fetch Crossref target metadata (counts + outgoing refs; no citing list)."""
    contact = os.getenv("CITATIONS_CONTACT_EMAIL", "dev@gxl.ai")
    url = _query(
        f"https://api.crossref.org/works/{urllib.parse.quote(doi, safe='/')}",
        {"mailto": contact},
    )
    response = get_json(url)
    return {"target": response["message"]}


def fetch_icite(doi: str, *, list_limit: int, pmid: str | None = None) -> dict[str, Any]:
    """Fetch NIH iCite citing PMIDs for a DOI."""
    resolved = pmid or resolve_pmid(doi)
    if not resolved:
        return {"pmid": None, "target": None, "reason": "no PMID for DOI"}
    response = get_json(
        _query(
            "https://icite.od.nih.gov/api/pubs",
            {"pmids": resolved, "legacy": "false"},
        )
    )
    rows = response.get("data") or []
    target = rows[0] if rows else None
    if target:
        target = dict(target)
        for field_name in ("citedByPmids", "citedByPmidsByYear", "citedPmids"):
            values = target.get(field_name)
            if isinstance(values, list):
                target[field_name] = values[:list_limit]
    return {"pmid": resolved, "target": target}


def fetch_opencitations(doi: str, *, list_limit: int) -> dict[str, Any]:
    """Fetch OpenCitations incoming citation edges (used as a check + edge source)."""
    encoded = urllib.parse.quote(f"doi:{doi}", safe=":/")
    citations = get_json(
        f"https://api.opencitations.net/index/v2/citations/{encoded}"
    )
    return {
        "citations": (citations or [])[:list_limit],
        "citation_count_returned": len(citations or []),
    }


def _ids_from_openalex(work: dict[str, Any]) -> tuple[str | None, str | None, str | None]:
    ids = work.get("ids") or {}
    doi = normalize_doi(work.get("doi") or ids.get("doi"))
    pmid = None
    if ids.get("pmid"):
        pmid = str(ids["pmid"]).rsplit("/", 1)[-1]
    arxiv_id = None
    if ids.get("arxiv"):
        arxiv_id = extract_arxiv_id(str(ids["arxiv"]))
    return doi, pmid, arxiv_id


def _record_keys(
    doi: str | None,
    pmid: str | None,
    arxiv_id: str | None,
    title: str,
) -> list[str]:
    keys: list[str] = []
    if doi:
        keys.append(f"doi:{doi}")
    if pmid:
        keys.append(f"pmid:{pmid}")
    if arxiv_id:
        keys.append(f"arxiv:{arxiv_id}")
    title_key = normalize_title(title)
    if title_key:
        keys.append(f"title:{title_key}")
    return keys


def _merge_record(
    by_key: dict[str, CitingRecord],
    *,
    title: str,
    doi: str | None,
    pmid: str | None,
    arxiv_id: str | None,
    year: int | None,
    openalex_id: str | None,
    provider: str,
    source_id: str | None = None,
) -> None:
    keys = _record_keys(doi, pmid, arxiv_id, title)
    if not keys:
        return

    existing: CitingRecord | None = None
    for key in keys:
        hit = by_key.get(key)
        if hit is not None:
            existing = hit
            break

    if existing is None:
        record = CitingRecord(
            title=title or "",
            doi=doi,
            pmid=str(pmid) if pmid else None,
            arxiv_id=arxiv_id,
            year=year,
            openalex_id=openalex_id,
            providers=[provider],
        )
        if source_id:
            record.source_ids[provider] = source_id
        for key in keys:
            by_key[key] = record
        return

    if provider not in existing.providers:
        existing.providers.append(provider)
    if source_id:
        existing.source_ids[provider] = source_id
    if not existing.doi and doi:
        existing.doi = doi
    if not existing.pmid and pmid:
        existing.pmid = str(pmid)
    if not existing.arxiv_id and arxiv_id:
        existing.arxiv_id = arxiv_id
    if not existing.title and title:
        existing.title = title
    if existing.year is None and year is not None:
        existing.year = year
    if not existing.openalex_id and openalex_id:
        existing.openalex_id = openalex_id

    # Keep every identifier key pointing at the same record.
    for key in _record_keys(
        existing.doi, existing.pmid, existing.arxiv_id, existing.title
    ):
        by_key[key] = existing


def _opencitations_citing_doi(edge: dict[str, Any]) -> str | None:
    """Extract citing DOI from an OpenCitations citation edge."""
    for field_name in ("citing", "citing_doi"):
        raw = edge.get(field_name)
        if not raw:
            continue
        # Values look like "doi:10.1234/foo" or bare DOIs / OMIDs
        for part in str(raw).split():
            doi = normalize_doi(part.replace("doi:", ""))
            if doi:
                return doi
    return None


def collect_providers(
    doi: str,
    *,
    list_limit: int = DEFAULT_LIST_LIMIT,
    fetchers: dict[str, Callable[..., dict[str, Any]]] | None = None,
) -> ProviderBundle:
    """Fetch and union citing records from OpenAlex + iCite; check OC + Crossref.

    Individual provider failures are isolated into ``bundle.errors`` so the
    workflow can continue with partial results.
    """
    limit = max(1, min(int(list_limit), MAX_LIST_RESULTS))
    bundle = ProviderBundle(target_doi=doi)
    by_key: dict[str, CitingRecord] = {}

    def _openalex() -> dict[str, Any]:
        fn = (fetchers or {}).get("openalex", fetch_openalex)
        return fn(doi, list_limit=limit)

    def _icite(pmid: str | None = None) -> dict[str, Any]:
        fn = (fetchers or {}).get("icite", fetch_icite)
        return fn(doi, list_limit=limit, pmid=pmid)

    def _crossref() -> dict[str, Any]:
        fn = (fetchers or {}).get("crossref", fetch_crossref)
        return fn(doi)

    def _opencitations() -> dict[str, Any]:
        fn = (fetchers or {}).get("opencitations", fetch_opencitations)
        return fn(doi, list_limit=limit)

    # OpenAlex first (gives title + OA id); others in parallel after.
    try:
        oa = _openalex()
        target = oa.get("target") or {}
        bundle.target_openalex_id = oa.get("openalex_id") or str(
            target.get("id", "")
        ).rsplit("/", 1)[-1]
        bundle.target_title = target.get("title") or ""
        bundle.checks.openalex_cited_by_count = target.get("cited_by_count")
        works = oa.get("citing_works") or []
        bundle.provider_edge_counts["openalex"] = len(works)
        for work in works:
            wdoi, wpmid, warxiv = _ids_from_openalex(work)
            oa_id = str(work.get("id", "")).rsplit("/", 1)[-1] or None
            year = work.get("publication_year")
            try:
                year_i = int(year) if year is not None else None
            except (TypeError, ValueError):
                year_i = None
            _merge_record(
                by_key,
                title=work.get("title") or "",
                doi=wdoi,
                pmid=wpmid,
                arxiv_id=warxiv,
                year=year_i,
                openalex_id=oa_id,
                provider="openalex",
                source_id=oa_id,
            )
    except Exception as exc:  # noqa: BLE001 - isolate provider failures
        logger.warning("OpenAlex fetch failed for %s: %s", doi, exc)
        bundle.errors["openalex"] = str(exc)
        bundle.checks.errors["openalex"] = str(exc)

    # Resolve PMID once for iCite (and reuse Europe PMC result).
    try:
        bundle.target_pmid = resolve_pmid(doi)
    except Exception as exc:  # noqa: BLE001
        logger.warning("PMID resolve failed for %s: %s", doi, exc)
        bundle.errors["europepmc"] = str(exc)

    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {
            pool.submit(_icite, bundle.target_pmid): "icite",
            pool.submit(_crossref): "crossref",
            pool.submit(_opencitations): "opencitations",
        }
        results: dict[str, Any] = {}
        for fut in as_completed(futures):
            name = futures[fut]
            try:
                results[name] = fut.result()
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s fetch failed for %s: %s", name, doi, exc)
                bundle.errors[name] = str(exc)
                bundle.checks.errors[name] = str(exc)

    icite = results.get("icite")
    if icite:
        if icite.get("pmid") and not bundle.target_pmid:
            bundle.target_pmid = str(icite["pmid"])
        target = icite.get("target")
        if target:
            bundle.checks.icite_cited_by_pmid_count = target.get("citation_count") or target.get(
                "citedByPmidCount"
            )
            cited = target.get("citedByPmids") or []
            bundle.provider_edge_counts["icite"] = len(cited)
            for pmid in cited:
                _merge_record(
                    by_key,
                    title="",
                    doi=None,
                    pmid=str(pmid),
                    arxiv_id=None,
                    year=None,
                    openalex_id=None,
                    provider="icite",
                    source_id=str(pmid),
                )

    crossref = results.get("crossref")
    if crossref:
        msg = crossref.get("target") or {}
        bundle.checks.crossref_is_referenced_by_count = msg.get("is-referenced-by-count")
        if not bundle.target_title:
            titles = msg.get("title") or []
            if titles:
                bundle.target_title = titles[0]

    oc = results.get("opencitations")
    if oc:
        citations = oc.get("citations") or []
        bundle.checks.opencitations_citation_count = oc.get("citation_count_returned")
        # OpenCitations edges are useful when OpenAlex is thin; keep as edges
        # but still surface the count under checks.
        bundle.provider_edge_counts["opencitations"] = len(citations)
        for edge in citations:
            citing_doi = _opencitations_citing_doi(edge)
            if not citing_doi:
                continue
            _merge_record(
                by_key,
                title="",
                doi=citing_doi,
                pmid=None,
                arxiv_id=None,
                year=None,
                openalex_id=None,
                provider="opencitations",
                source_id=str(edge.get("oci") or citing_doi),
            )

    # by_key stores multiple aliases per record; unique by identity.
    unique: list[CitingRecord] = []
    seen: set[int] = set()
    for record in by_key.values():
        marker = id(record)
        if marker in seen:
            continue
        seen.add(marker)
        unique.append(record)
    bundle.citing = unique
    return bundle
