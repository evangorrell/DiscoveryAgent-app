"""Manage the active data-source filter for Paperclip searches.

The server CLI backend accepts a ``-s/--source`` flag per call (e.g. ``pmc``,
``fda``, ``trials``, ``patents``, or country-scoped variants like ``fda/jp``,
``trials/us``). This module lets users pick a subset of top-level sources once,
persist it to ``~/.paperclip/config.json``, and have subsequent
``paperclip search``/``sql`` calls automatically fan out across the selected
sources.

UX mirrors ``paperclip install``: an arrow-key multi-select checkbox on a
TTY, with a numbered fallback for non-interactive shells.
"""

from __future__ import annotations

import json
import re
import shlex
from collections.abc import Iterable

import click

from .. import config

GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"


def _is_prod_server() -> bool:
    """True when connected to the production server (not local/staging)."""
    base = config.get_base_url()
    if "localhost" in base or "127.0.0.1" in base:
        return False
    if "staging" in base:
        return False
    return True


# ── Source catalogue ─────────────────────────────────────────────

# Ordered for display. ``key`` is the value the server expects in ``-s``.
# Top-level sources are shown in the banner; country-scoped variants are
# listed in the search error help and CLI --help.
_ALL_SOURCES: list[dict[str, str]] = [
    {
        "key": "pmc",
        "label": "PubMed Central",
        "desc": "Peer-reviewed biomedical papers with full text",
    },
    {
        "key": "biorxiv",
        "label": "bioRxiv",
        "desc": "Life sciences preprints",
    },
    {
        "key": "medrxiv",
        "label": "medRxiv",
        "desc": "Clinical and health sciences preprints",
    },
    {
        "key": "arxiv",
        "label": "arXiv",
        "desc": "Physics, math, CS, and quantitative biology preprints",
    },
    {
        "key": "abstracts",
        "label": "Abstracts",
        "desc": "Broader coverage with titles and abstracts only (no full text)",
    },
    {
        "key": "fda",
        "label": "FDA (US)",
        "desc": "US FDA drug approval reviews and regulatory documents",
    },
    {
        "key": "fda/jp",
        "label": "PMDA (Japan)",
        "desc": "Japan PMDA regulatory documents",
    },
    {
        "key": "fda/eu",
        "label": "EMA (EU)",
        "desc": "EU EMA regulatory documents",
    },
    {
        "key": "trials",
        "label": "Clinical Trials",
        "desc": "800K+ trials from ClinicalTrials.gov and international registries",
    },
    {
        "key": "trials/us",
        "label": "US Trials",
        "desc": "ClinicalTrials.gov (US)",
    },
    {
        "key": "trials/eu",
        "label": "EU Trials",
        "desc": "EU Clinical Trials Register",
    },
    {
        "key": "trials/jp",
        "label": "Japan Trials",
        "desc": "JRCT (Japan Registry of Clinical Trials)",
    },
    {
        "key": "trials/cn",
        "label": "China Trials",
        "desc": "ChiCTR (Chinese Clinical Trial Registry)",
    },
    {
        "key": "patents",
        "label": "Patents",
        "desc": "Curated drug-discovery patents with metadata and available full text",
    },
    {
        "key": "proteins",
        "label": "Proteins",
        "desc": "UniProt + PDB + ChEMBL (574K+ proteins, structures, bioactivities)",
    },
    {
        "key": "uniprot",
        "label": "UniProt (alias)",
        "desc": "Alias for -s proteins (UniProt Swiss-Prot)",
    },
    {
        "key": "pdb",
        "label": "PDB (alias)",
        "desc": "Alias for -s proteins (PDB structures)",
    },
    {
        "key": "chembl",
        "label": "ChEMBL (alias)",
        "desc": "Alias for -s proteins (ChEMBL pharmacology)",
    },
    {
        "key": "clipboard",
        "label": "My Clipboard",
        "desc": "Your uploaded files (scope to a folder with -s clipboard/<folder>)",
    },
]

_FDA_KEYS = {"fda", "fda/jp", "fda/eu"}
_PATENTS_KEYS = {"patents"}
_STAGING_ONLY_KEYS: set[str] = set()


def _get_sources() -> list[dict[str, str]]:
    """Return the source catalogue, excluding staging-only sources on production."""
    if _is_prod_server():
        return [s for s in _ALL_SOURCES if s["key"] not in _STAGING_ONLY_KEYS]
    return list(_ALL_SOURCES)


# Keep SOURCES as a module-level reference for backward compat, but
# all internal callers should use _get_sources() for env awareness.
SOURCES = _ALL_SOURCES

_VALID_KEYS = {s["key"] for s in _ALL_SOURCES}
_PAPERS_KEYS = {"pmc", "biorxiv", "medrxiv", "arxiv", "abstracts"}
_TRIALS_KEYS = {"trials", "trials/us", "trials/eu", "trials/jp", "trials/cn"}
_DEFAULT_SEARCH_KEYS = {"pmc", "biorxiv", "medrxiv", "arxiv"}
# Sources that don't support full-text ``search``; they're queryable only via ``sql``.
_SQL_ONLY_KEYS: set[str] = set()
_LEGACY_KEY_MAP: dict[str, str] = {}
_STATE_KEY = "sources"


# ── Persistence ──────────────────────────────────────────────────


def _load_state() -> dict:
    if not config.CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(config.CONFIG_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _save_state(state: dict) -> None:
    config.PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
    config.CONFIG_FILE.write_text(json.dumps(state, indent=2))


def _migrate_keys(keys: Iterable[str]) -> list[str]:
    """Translate legacy source keys (e.g. old ``fda``) to their current form."""
    out: list[str] = []
    seen: set[str] = set()
    for k in keys:
        key = _LEGACY_KEY_MAP.get(k, k)
        if key in _VALID_KEYS and key not in seen:
            out.append(key)
            seen.add(key)
    return out


def get_selected() -> list[str] | None:
    """Return the active source filter.

    Only the core papers sources are searched by default.  Non-papers
    sources (fda, trials, patents, abstracts) are opt-in via ``-s``.
    """
    return [s["key"] for s in _get_sources() if s["key"] in _DEFAULT_SEARCH_KEYS]


def set_selected(keys: Iterable[str]) -> list[str]:
    """Persist the given source keys, de-duped and validated. Returns the stored list."""
    accepted = set(_migrate_keys(keys))
    ordered = [s["key"] for s in _ALL_SOURCES if s["key"] in accepted]
    state = _load_state()
    if ordered:
        state[_STATE_KEY] = ordered
    else:
        state.pop(_STATE_KEY, None)
    _save_state(state)
    return ordered


def clear_selected() -> None:
    state = _load_state()
    if _STATE_KEY in state:
        state.pop(_STATE_KEY, None)
        _save_state(state)


def describe(keys: list[str] | None) -> str:
    """Short human-readable label for a selection."""
    if not keys:
        return "all sources (default)"
    labels = {s["key"]: s["label"] for s in _ALL_SOURCES}
    return ", ".join(labels.get(k, k) for k in keys)


# ── Filter application ──────────────────────────────────────────


_VDIR_PATH_RE = re.compile(
    r"/(?:fda|clinicaltrials|trials)/(?:us|jp|eu|cn|intl)(?:/|\s|$)"
    r"|/(?:clipboard|patents)(?:/|\s|$)"
)


def _raw_has_vdir_path(raw: str) -> bool:
    """Return True if ``raw`` contains a virtual directory path like ``/fda/us``.

    When a vdir path is present the server routes the request to the
    correct backend regardless of ``-s``, so client-side source fan-out
    would only produce duplicate results.
    """
    return bool(_VDIR_PATH_RE.search(raw))


def _raw_has_source_flag(raw: str) -> bool:
    """Return True if the user already passed ``-s`` / ``--source`` themselves."""
    try:
        tokens = shlex.split(raw)
    except ValueError:
        # Unbalanced quotes: assume no flag and let the server report.
        return False
    for tok in tokens:
        if tok in ("-s", "--source"):
            return True
        if tok.startswith("--source="):
            return True
    return False


_SOURCE_VALUE_RE = re.compile(r"(?:^|\s)(?:-s|--source)(?:\s+|=)(\S+)(?=\s|$)")


def _extract_explicit_source(raw: str) -> str | None:
    """Extract the value of ``-s``/``--source`` from a raw command string."""
    m = _SOURCE_VALUE_RE.search(raw)
    return m.group(1) if m else None


def _strip_source_flag_from_raw(raw: str) -> str:
    """Remove ``-s``/``--source`` and its value from the raw command string."""
    raw = re.sub(r"(?:^|\s)(?:-s|--source)\s+\S+", " ", raw)
    raw = re.sub(r"(?:^|\s)--source=\S+", " ", raw)
    return raw.strip()


def _fan_out_sources(
    stripped_raw: str,
    keys: list[str],
    fallback_raw: str,
) -> list[tuple[str | None, str]]:
    """Build per-backend requests from a list of source keys.

    Papers-backend keys are grouped into a single comma-joined request;
    each non-papers key gets its own request.
    """
    papers = [k for k in keys if k in _PAPERS_KEYS]
    non_papers = [k for k in keys if k not in _PAPERS_KEYS]

    requests: list[tuple[str | None, str]] = []
    if papers:
        if len(papers) == 1:
            requests.append((papers[0], stripped_raw))
        else:
            requests.append((",".join(papers), stripped_raw))
    for key in non_papers:
        requests.append((key, stripped_raw))
    return requests or [(None, fallback_raw)]


def plan_requests(
    raw: str,
    selected: list[str] | None,
    *,
    command: str = "search",
) -> list[tuple[str | None, str]]:
    """Decide how many requests to send for a search/sql invocation.

    Returns a list of ``(source, raw)`` tuples. ``source`` is either a
    key (to be injected as ``-s <source>``) or ``None`` meaning
    "no flag — let the server default apply".

    Rules:
      * If the user already specified ``-s`` in ``raw``, respect it.
      * If no filter is saved, send a single no-flag call.
      * If the filter spans all default papers sources, collapse into one call.
      * Each non-papers source (fda, trials, patents) gets its own call.
    """
    if _raw_has_source_flag(raw):
        source_val = _extract_explicit_source(raw)
        if source_val and "," in source_val:
            keys = _migrate_keys(k.strip() for k in source_val.split(",") if k.strip())
            if keys:
                stripped = _strip_source_flag_from_raw(raw)
                return _fan_out_sources(stripped, keys, raw)
        return [(None, raw)]
    if _raw_has_vdir_path(raw):
        return [(None, raw)]
    if not selected:
        return [(None, raw)]

    selected = _migrate_keys(selected)
    papers = [k for k in selected if k in _PAPERS_KEYS]
    non_papers = [k for k in selected if k not in _PAPERS_KEYS]

    requests: list[tuple[str | None, str]] = []
    if papers:
        if set(papers) >= _DEFAULT_SEARCH_KEYS:
            requests.append((None, raw))
            for key in papers:
                if key not in _DEFAULT_SEARCH_KEYS:
                    requests.append((key, raw))
        elif len(papers) == 1:
            requests.append((papers[0], raw))
        else:
            requests.append((",".join(papers), raw))
    for key in non_papers:
        requests.append((key, raw))
    return requests or [(None, raw)]


def inject_source_flag(raw: str, source: str | None) -> str:
    """Prepend ``-s <source>`` to ``raw`` if a source override is requested."""
    if not source:
        return raw
    prefix = f"-s {shlex.quote(source)} "
    return prefix + raw if raw else prefix.rstrip()


def abstracts_excluded_by_default(selected: list[str] | None, raw: str) -> bool:
    """Return True if abstracts were excluded because no filter was set."""
    if _raw_has_source_flag(raw):
        return False
    return selected is not None and "abstracts" not in selected


def run_selector() -> list[str]:
    """Show which sources are active by default.

    Returns the list of active source keys.
    """
    active = get_selected() or []
    click.echo()
    click.echo(f"  {GREEN}\u2713{RESET} Default sources: {BOLD}{describe(active)}{RESET}")
    click.echo(
        f"  {DIM}Add sources per query with{RESET} -s <source> "
        f"{DIM}(e.g. -s fda or -s trials/us){RESET}"
    )
    click.echo()
    return active


def print_status() -> None:
    """Print the currently active sources."""
    current = get_selected()
    click.echo()
    click.echo(f"  {BOLD}Default sources:{RESET} {describe(current)}")
    click.echo(
        f"  {DIM}Add other sources per-query with -s <source> (e.g. -s fda, -s trials).{RESET}"
    )
    click.echo()


def expand_source_aliases(raw: str) -> str:
    """Expand source aliases in a raw command string (pass-through)."""
    return raw
