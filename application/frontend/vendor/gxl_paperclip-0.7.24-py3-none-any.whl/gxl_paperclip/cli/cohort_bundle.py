"""Streaming CSV cohort bundle export and validated reload."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
BASE_COLUMNS = [
    "source", "document_id", "title", "abstract", "authors", "journal", "year",
    "article_type", "doi", "score", "relevance_score", "bm25_score",
    "embedding_similarity", "match_evidence_json",
]
MAX_FIELD_BYTES = 10 * 1024 * 1024
MAX_ROWS = 10_000


class BundleError(ValueError):
    pass


def _json_cell(value: Any) -> str:
    return json.dumps(value if value is not None else [], ensure_ascii=False, separators=(",", ":"))


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def export_bundle(client, identifier: str, destination: str | Path) -> tuple[Path, dict]:
    """Fetch at most 500 rows at a time and atomically publish a v1 bundle."""
    dest = Path(destination).expanduser().resolve()
    if dest.exists() and (not dest.is_dir() or any(dest.iterdir())):
        raise BundleError(f"destination exists and is not empty: {dest}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=f".{dest.name}.", dir=dest.parent))
    count = missing = duplicates = 0
    seen: set[tuple[str, str]] = set()
    columns = list(BASE_COLUMNS)
    workflow = None
    result_id = identifier
    alias = None
    try:
        csv_path = tmp / "cohort.csv"
        cursor = 0
        writer = None
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            while True:
                page = client.results.page(identifier, cursor=cursor, limit=500)
                result_id = page.get("result_id") or result_id
                alias = page.get("alias") or alias
                workflow = page.get("workflow") or workflow
                rows = page.get("papers") or []
                if writer is None:
                    writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
                    writer.writeheader()
                for raw in rows:
                    if count >= MAX_ROWS:
                        raise BundleError(
                            f"cohort exceeds the bundle limit of {MAX_ROWS} rows"
                        )
                    row = dict(raw)
                    key = (str(row.get("source", "")), str(row.get("document_id", "")))
                    if key in seen:
                        duplicates += 1
                    else:
                        seen.add(key)
                    if not row.get("title") or not row.get("abstract"):
                        missing += 1
                    row["match_evidence_json"] = _json_cell(row.pop("match_evidence", []))
                    writer.writerow(row)
                    count += 1
                next_cursor = page.get("next_cursor")
                if next_cursor is None:
                    break
                if isinstance(next_cursor, bool) or not isinstance(next_cursor, int):
                    raise BundleError("server returned an invalid cohort cursor")
                if next_cursor <= cursor:
                    raise BundleError("server returned a non-advancing cohort cursor")
                cursor = next_cursor
        digest = _sha256_file(csv_path)
        declared = page.get("count", count)
        if count != declared:
            raise BundleError(f"export row count mismatch: expected {declared}, wrote {count}")
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "result_id": result_id, "alias": alias, "paper_count": count,
            "exported_at": datetime.now(UTC).isoformat(),
            "workflow": workflow,
            "config_hash": (workflow or {}).get("config_hash"),
            "columns": columns, "cohort_csv_sha256": digest,
            "duplicate_count": duplicates, "missing_metadata_count": missing,
        }
        (tmp / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8"
        )
        if dest.exists():
            dest.rmdir()
        os.replace(tmp, dest)
        return dest, manifest
    except BaseException:
        shutil.rmtree(tmp, ignore_errors=True)
        raise


def load_bundle(path: str | Path) -> tuple[list[dict[str, Any]], dict]:
    root = Path(path).expanduser().resolve()
    try:
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise BundleError(f"invalid or missing manifest.json: {exc}") from exc
    if manifest.get("schema_version") != SCHEMA_VERSION:
        raise BundleError(f"unsupported bundle schema: {manifest.get('schema_version')}")
    csv_path = root / "cohort.csv"
    try:
        digest = _sha256_file(csv_path)
    except OSError as exc:
        raise BundleError(f"missing cohort.csv: {exc}") from exc
    if digest != manifest.get("cohort_csv_sha256"):
        raise BundleError("cohort.csv checksum mismatch")
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    physical_count = 0
    with csv_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if not {"source", "document_id"}.issubset(reader.fieldnames or []):
            raise BundleError("cohort.csv requires source and document_id columns")
        for line, raw in enumerate(reader, 2):
            physical_count += 1
            if physical_count > MAX_ROWS:
                raise BundleError(f"bundle exceeds the MVP limit of {MAX_ROWS} rows")
            if any(len((value or "").encode("utf-8")) > MAX_FIELD_BYTES for value in raw.values()):
                raise BundleError(
                    f"row {line} contains a field larger than {MAX_FIELD_BYTES} bytes"
                )
            key = (raw["source"].strip(), raw["document_id"].strip())
            if not all(key):
                raise BundleError(f"row {line} has an empty identifier")
            if key in seen:
                continue
            seen.add(key)
            try:
                evidence = json.loads(raw.pop("match_evidence_json", "[]") or "[]")
            except ValueError as exc:
                raise BundleError(f"row {line} has invalid match evidence JSON") from exc
            if not isinstance(evidence, list) or len(evidence) > 3 or any(
                len(str(item.get("snippet", ""))) > 300
                for item in evidence
                if isinstance(item, dict)
            ):
                raise BundleError(f"row {line} exceeds match evidence limits")
            raw["match_evidence"] = evidence
            rows.append(raw)
    line_count = sum(1 for _ in csv_path.open(encoding="utf-8"))
    if line_count < 1 or int(manifest.get("paper_count", -1)) < len(rows):
        raise BundleError("manifest paper count does not match cohort.csv")
    # Declared count includes duplicates by design; verify against physical CSV records.
    if physical_count != int(manifest.get("paper_count", -1)):
        raise BundleError("manifest paper count does not match cohort.csv")
    return rows, manifest
