"""Load and normalize declarative search workflow files."""

from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import Any

import yaml


class SearchConfigError(ValueError):
    """Raised when a search workflow cannot be loaded or parameterized."""


_PLACEHOLDER_RE = re.compile(r"\$\{([A-Za-z][A-Za-z0-9_-]{0,63})\}")
_PARAMETER_TYPES = {"string", "integer", "float", "boolean", "string_list"}


def _coerce(value: Any, declared_type: str, name: str) -> Any:
    if declared_type == "string":
        if isinstance(value, (dict, list)):
            raise SearchConfigError(f"parameter {name!r} must be a string")
        return str(value)
    if declared_type == "integer":
        if isinstance(value, bool):
            raise SearchConfigError(f"parameter {name!r} must be an integer")
        try:
            return int(value)
        except (TypeError, ValueError) as exc:
            raise SearchConfigError(f"parameter {name!r} must be an integer") from exc
    if declared_type == "float":
        if isinstance(value, bool):
            raise SearchConfigError(f"parameter {name!r} must be a number")
        try:
            return float(value)
        except (TypeError, ValueError) as exc:
            raise SearchConfigError(f"parameter {name!r} must be a number") from exc
    if declared_type == "boolean":
        if isinstance(value, bool):
            return value
        lowered = str(value).strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
        raise SearchConfigError(f"parameter {name!r} must be a boolean")
    if declared_type == "string_list":
        if isinstance(value, str):
            return [part.strip() for part in value.split(",") if part.strip()]
        if isinstance(value, list) and all(isinstance(item, str) for item in value):
            return value
        raise SearchConfigError(f"parameter {name!r} must be a list of strings")
    raise SearchConfigError(f"parameter {name!r} has unsupported type {declared_type!r}")


def _parse_assignments(values: tuple[str, ...], flag: str) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for assignment in values:
        if "=" not in assignment:
            raise SearchConfigError(f"{flag} expects NAME=VALUE, got {assignment!r}")
        name, value = assignment.split("=", 1)
        name = name.strip()
        if not name or name in parsed:
            detail = "empty name" if not name else f"duplicate value for {name!r}"
            raise SearchConfigError(f"invalid {flag}: {detail}")
        parsed[name] = value
    return parsed


def _interpolate(value: Any, parameters: dict[str, Any]) -> Any:
    if isinstance(value, dict):
        return {key: _interpolate(item, parameters) for key, item in value.items()}
    if isinstance(value, list):
        return [_interpolate(item, parameters) for item in value]
    if not isinstance(value, str):
        return value
    full = _PLACEHOLDER_RE.fullmatch(value)
    if full:
        name = full.group(1)
        if name not in parameters:
            raise SearchConfigError(f"unknown parameter placeholder {name!r}")
        return copy.deepcopy(parameters[name])

    def replace(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in parameters:
            raise SearchConfigError(f"unknown parameter placeholder {name!r}")
        replacement = parameters[name]
        if isinstance(replacement, (dict, list)):
            raise SearchConfigError(f"parameter {name!r} can only be embedded when it is a scalar")
        return str(replacement)

    return _PLACEHOLDER_RE.sub(replace, value)


def load_search_config(
    path: str,
    *,
    parameter_overrides: tuple[str, ...] = (),
    input_overrides: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Safely load YAML, resolve typed parameters, and bind external inputs."""
    config_path = Path(path).expanduser()
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SearchConfigError(f"config file not found: {config_path}") from exc
    except OSError as exc:
        raise SearchConfigError(f"could not read config file: {exc}") from exc
    except yaml.YAMLError as exc:
        raise SearchConfigError(f"invalid YAML: {exc}") from exc
    if not isinstance(raw, dict):
        raise SearchConfigError("config must be a YAML mapping")
    if "save" in raw:
        raise SearchConfigError(
            "workflow files cannot define storage policy; use --save-as when running the config"
        )

    overrides = _parse_assignments(parameter_overrides, "--set")
    declarations = raw.get("parameters") or {}
    if not isinstance(declarations, dict):
        raise SearchConfigError("parameters must be a mapping")
    unknown = sorted(set(overrides) - set(declarations))
    if unknown:
        raise SearchConfigError(f"undeclared parameter override(s): {', '.join(unknown)}")

    resolved: dict[str, Any] = {}
    for name, declaration in declarations.items():
        if not isinstance(declaration, dict):
            raise SearchConfigError(f"parameter {name!r} must be a mapping")
        declared_type = declaration.get("type", "string")
        if declared_type not in _PARAMETER_TYPES:
            raise SearchConfigError(
                f"parameter {name!r} type must be one of: {', '.join(sorted(_PARAMETER_TYPES))}"
            )
        if name in overrides:
            value = overrides[name]
        elif "default" in declaration:
            value = declaration["default"]
        elif declaration.get("required", False):
            raise SearchConfigError(f"missing required parameter: {name}")
        else:
            continue
        resolved[name] = _coerce(value, declared_type, name)

    inputs = raw.get("inputs") or {}
    if not isinstance(inputs, dict):
        raise SearchConfigError("inputs must be a mapping")
    bound_inputs = _parse_assignments(input_overrides, "--input")
    unknown_inputs = sorted(set(bound_inputs) - set(inputs))
    if unknown_inputs:
        raise SearchConfigError(f"undeclared input(s): {', '.join(unknown_inputs)}")
    for name, declaration in inputs.items():
        if not isinstance(declaration, dict):
            raise SearchConfigError(f"input {name!r} must be a mapping")
        if declaration.get("type") != "result_set":
            raise SearchConfigError(f"input {name!r} must have type: result_set")
        if declaration.get("required", False) and name not in bound_inputs:
            raise SearchConfigError(f"missing required input: {name}")

    normalized = _interpolate(copy.deepcopy(raw), resolved)
    normalized["resolved_parameters"] = resolved
    normalized["resolved_inputs"] = bound_inputs
    return normalized
