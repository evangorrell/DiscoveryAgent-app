"""Fetch and install Paperclip skill files for Claude Code, Cursor, or Codex."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from collections.abc import Iterable
from pathlib import Path

import click
import requests

from .. import config

CYAN = "\033[96m"
GREEN = "\033[92m"
RED = "\033[91m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"
CLR = "\033[2K"

_CODEX_START = "<!-- paperclip-skill-start -->"
_CODEX_END = "<!-- paperclip-skill-end -->"

# The installed agent skill is a lightweight pointer (placeholder.md) that
# tells the agent to run `paperclip skill` for the full documentation. Older
# servers only publish the full skill at /skills/skill.md, so that stays as
# a fallback.
_PLACEHOLDER_ENDPOINT = "/skills/placeholder.md"
_LEGACY_SKILL_ENDPOINT = "/skills/skill.md"
# Full documentation, printed by `paperclip skill` / `paperclip skills system`.
_FULL_SKILL_ENDPOINT = "/skills/full_skill.md"

# Marks skill content that has already had the repos sections removed, so the
# strip is idempotent (refresh runs on every login / every few hours).
_REPOS_DISABLED_MARKER = "<!-- paperclip-repos-disabled -->"

AGENTS = [
    {
        "key": "claude-code",
        "label": "Claude Code",
        "desc": ".claude/skills/paperclip/SKILL.md",
    },
    {
        "key": "cursor",
        "label": "Cursor",
        "desc": ".cursor/skills/paperclip/SKILL.md",
    },
    {
        "key": "codex",
        "label": "Codex",
        "desc": ".agents/skills/paperclip/SKILL.md",
    },
]


def fetch_full_skill(base_url: str, timeout: int = 10) -> str | None:
    """Fetch the full skill documentation (for `paperclip skill`).

    Prefers full_skill.md; falls back to the legacy skill.md name. The
    repos-disabled preference is applied so agents never see instructions
    for a feature that is turned off locally.

    Uses an ETag-validated local cache: the previous body and its ETag are
    kept in ~/.paperclip/cache, and each call revalidates with
    ``If-None-Match``. Unchanged content costs a single 304 round-trip
    instead of a full transfer, while changed content is picked up live.
    If the server is unreachable, the cached copy is served as a fallback.
    """
    cached_body, cached_etag = _read_skill_cache(base_url)
    headers = {"If-None-Match": cached_etag} if cached_etag else {}

    content: str | None = None
    for endpoint in (_FULL_SKILL_ENDPOINT, _LEGACY_SKILL_ENDPOINT):
        try:
            resp = requests.get(
                f"{base_url}{endpoint}", timeout=timeout, headers=headers
            )
            if resp.status_code == 304 and cached_body:
                content = cached_body
                break
            resp.raise_for_status()
        except Exception:
            continue
        if resp.text.strip():
            content = resp.text
            _write_skill_cache(base_url, content, resp.headers.get("ETag"))
            break

    if content is None:
        content = cached_body  # offline fallback

    if content is None:
        return None
    if not config.repos_enabled():
        content = strip_repos_sections(content)
    return content


def _skill_cache_file(base_url: str) -> Path:
    """Cache location for the full skill, keyed by server (dev/staging/prod)."""
    key = hashlib.sha256(base_url.encode("utf-8")).hexdigest()[:12]
    return config.PAPERCLIP_DIR / "cache" / f"full_skill-{key}.json"


def _read_skill_cache(base_url: str) -> tuple[str | None, str | None]:
    """Return (body, etag) from the cache, or (None, None) if unusable."""
    try:
        data = json.loads(_skill_cache_file(base_url).read_text())
        body = data.get("body")
        etag = data.get("etag")
        if isinstance(body, str) and body.strip():
            return body, etag if isinstance(etag, str) and etag else None
    except Exception:
        pass
    return None, None


def _write_skill_cache(base_url: str, body: str, etag: str | None) -> None:
    """Atomically persist the fetched skill body and its ETag (if any).

    The body is cached even without an ETag so the offline fallback works;
    revalidation then just degrades to a full fetch.
    """
    try:
        f = _skill_cache_file(base_url)
        f.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps({"etag": etag, "body": body})
        tmp = f.with_name(f"{f.name}.{os.getpid()}.tmp")
        tmp.write_text(payload)
        os.replace(tmp, f)
    except Exception:
        pass


def fetch_agent_skill(base_url: str, timeout: int = 15) -> str | None:
    """Fetch the content to install as the agent SKILL.md.

    Prefers the lightweight placeholder; falls back to the legacy full
    skill.md for servers that don't publish placeholder.md yet. Returns
    None if neither yields valid skill content.
    """
    for endpoint in (_PLACEHOLDER_ENDPOINT, _LEGACY_SKILL_ENDPOINT):
        try:
            resp = requests.get(f"{base_url}{endpoint}", timeout=timeout)
            resp.raise_for_status()
        except Exception:
            continue
        if resp.text.startswith("---\nname:"):
            return resp.text
    return None


# ── Install registry ──────────────────────────────────────────────
#
# Skill files installed before the registry existed can only be found by
# scanning, so refresh also discovers files in the cwd, its ancestors, and
# the home directory, and backfills them into the registry.

_SKILL_RELATIVE_PATHS = (
    Path(".claude") / "skills" / "paperclip" / "SKILL.md",
    Path(".cursor") / "skills" / "paperclip" / "SKILL.md",
    Path(".agents") / "skills" / "paperclip" / "SKILL.md",
)


def _safe_home() -> Path | None:
    """Path.home() that tolerates environments without a home directory."""
    try:
        return Path.home()
    except (RuntimeError, OSError):
        return None


def _registry_file() -> Path:
    return config.PAPERCLIP_DIR / "installed_skills.json"


def _read_registry() -> set[Path]:
    """Previously recorded skill-file locations.

    Tolerates a missing, corrupt, or hand-edited file: anything that is not
    a string holding an absolute path is ignored.
    """
    try:
        data = json.loads(_registry_file().read_text())
        if not isinstance(data, dict):
            return set()
        raw = data.get("paths", [])
        if not isinstance(raw, list):
            return set()
        return {
            Path(p) for p in raw if isinstance(p, str) and os.path.isabs(p)
        }
    except Exception:
        return set()


def _write_registry(paths: Iterable[Path]) -> None:
    """Atomically persist the registry (temp file + rename).

    A concurrent `paperclip` process reading mid-write must never see a
    truncated file, which `_read_registry` would treat as corrupt and drop.
    """
    try:
        f = _registry_file()
        f.parent.mkdir(parents=True, exist_ok=True)
        payload = (
            json.dumps({"paths": sorted(str(p) for p in set(paths))}, indent=2) + "\n"
        )
        tmp = f.with_name(f"{f.name}.{os.getpid()}.tmp")
        tmp.write_text(payload)
        os.replace(tmp, f)
    except Exception:
        pass


def _register_skill_paths(paths: Iterable[Path]) -> None:
    """Add *paths* to the registry, keeping existing entries."""
    existing = _read_registry()
    merged = existing | {Path(p) for p in paths}
    if merged != existing:
        _write_registry(merged)


def _candidate_dirs() -> list[Path]:
    """Directories scanned for existing installs: cwd, its ancestors, home."""
    dirs: list[Path] = []
    try:
        cwd = Path.cwd()
        dirs = [cwd, *cwd.parents]
    except OSError:
        pass  # cwd was deleted from under us
    home = _safe_home()
    if home is not None and home not in dirs:
        dirs.append(home)
    return dirs


# Bounded scan of the home directory (used by interactive `paperclip update`
# only — too slow for the background refresh). Depth-limited and skips
# directories that are large and can't contain a skill install.
_HOME_SCAN_MAX_DEPTH = 4
_HOME_SCAN_SKIP_DIRS = {
    "node_modules",
    "Library",
    "Applications",
    ".Trash",
    ".git",
    ".cache",
    ".npm",
    ".nvm",
    ".cargo",
    ".rustup",
    ".venv",
    "venv",
    "site-packages",
    "__pycache__",
    # Skill parents themselves — checked via _SKILL_RELATIVE_PATHS, no need
    # to descend into them.
    ".claude",
    ".cursor",
    ".agents",
}


def _scan_home_for_skills() -> set[Path]:
    """Find all installed SKILL.md files under the home directory.

    Bounded by depth and a directory denylist; never follows symlinks
    (`os.walk` default), so symlink loops can't hang the scan. Unreadable
    directories are silently skipped.
    """
    found: set[Path] = set()
    home = _safe_home()
    if home is None or not home.is_dir():
        return found
    base_depth = len(home.parts)
    for root, dirs, _files in os.walk(home):
        root_path = Path(root)
        depth = len(root_path.parts) - base_depth
        if depth >= _HOME_SCAN_MAX_DEPTH:
            dirs[:] = []
        else:
            dirs[:] = [d for d in dirs if d not in _HOME_SCAN_SKIP_DIRS]
        for rel in _SKILL_RELATIVE_PATHS:
            p = root_path / rel
            try:
                if p.is_file():
                    found.add(p)
            except OSError:
                continue
    return found


# Legacy AGENTS.md files are read in full to look for the sentinel; cap the
# size so a pathological multi-GB file can't stall a background refresh.
_LEGACY_FILE_MAX_BYTES = 10 * 1024 * 1024


def _is_legacy_codex_file(path: Path) -> bool:
    """True if *path* is an AGENTS.md containing the paperclip sentinel."""
    try:
        if not path.is_file() or path.stat().st_size > _LEGACY_FILE_MAX_BYTES:
            return False
        return _CODEX_START in path.read_text(errors="replace")
    except OSError:
        return False


def _display_path(path: Path) -> str:
    """Path relative to cwd or home when possible, for friendly output."""
    try:
        return str(path.relative_to(Path.cwd()))
    except (ValueError, OSError):
        pass
    home = _safe_home()
    if home is not None:
        try:
            return "~/" + str(path.relative_to(home))
        except ValueError:
            pass
    return str(path)


# ── Repos feature: strip skill content when disabled ─────────────

# Top-level (## ) sections removed wholesale when repos are disabled.
_REPOS_SECTION_PREFIXES = ("Paper Repositories",)
# Sub-level (### ) sections removed within otherwise-kept sections.
_REPOS_SUBSECTION_PREFIXES = ("Paper Repositories",)
# Stray lines (tips / workflow steps) that only make sense with repos.
_REPOS_LINE_SUBSTRINGS = (
    "**Cite**:",
    "check `status`",
    "papers marked",
)

_REPOS_DISABLED_NOTE = (
    f"{_REPOS_DISABLED_MARKER}\n"
    "## Paper repositories (disabled)\n\n"
    "The paper-repository feature (`init`, `add`, `commit`, `status`, "
    "`branch`, `merge`, and verified citations) is turned off in this "
    "environment. Do not use those commands. Cite sources directly, "
    "checking each claim against the document's full text first.\n"
)


def _heading_level(line: str) -> int:
    """Return the markdown heading level (1=#, 2=##, ...) or 0 if not a heading."""
    stripped = line.lstrip()
    n = 0
    for ch in stripped:
        if ch == "#":
            n += 1
        else:
            break
    if n and stripped[n : n + 1] == " ":
        return n
    return 0


def strip_repos_sections(content: str) -> str:
    """Remove paper-repository instructions from skill.md content.

    Used when the user has disabled the repos feature (``paperclip
    repos-feature disable``) so the coding agent is never told to use
    ``init``/``add``/``commit``/etc. Works on Markdown headings, so it
    tolerates edits to the
    surrounding prose, and is idempotent via ``_REPOS_DISABLED_MARKER``.
    """
    if _REPOS_DISABLED_MARKER in content:
        return content

    lines = content.splitlines()
    out: list[str] = []
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        level = _heading_level(line)

        if level == 2:
            title = line.lstrip()[2:].strip()
            if title.startswith(_REPOS_SECTION_PREFIXES):
                # Drop the whole section until the next ## (or EOF).
                i += 1
                while i < n and _heading_level(lines[i]) != 2:
                    i += 1
                continue
            if title.startswith("Citations"):
                # Keep the section + citation format, drop the repo workflow.
                out.append(line)
                out.append("")
                out.append(
                    "**Verify before citing.** Confirm each claim against the "
                    "source's full text before citing it."
                )
                out.append("")
                i += 1
                while i < n and _heading_level(lines[i]) not in (2, 3):
                    i += 1
                continue

        if level == 3 and line.lstrip()[3:].strip().startswith(
            _REPOS_SUBSECTION_PREFIXES
        ):
            # Drop the subsection until the next ### or ## (or EOF).
            i += 1
            while i < n and _heading_level(lines[i]) not in (2, 3):
                i += 1
            continue

        if level == 0 and any(s in line for s in _REPOS_LINE_SUBSTRINGS):
            i += 1
            continue

        out.append(line)
        i += 1

    result = "\n".join(out).rstrip() + "\n\n" + _REPOS_DISABLED_NOTE
    return result


# ── File writers ─────────────────────────────────────────────────


def _write_claude_code(content: str, target: Path) -> Path:
    skill_dir = target / ".claude" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_cursor(content: str, target: Path) -> Path:
    skill_dir = target / ".cursor" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_codex(content: str, target: Path) -> Path:
    skill_dir = target / ".agents" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_codex_legacy(content: str, target: Path) -> Path:
    """Write to AGENTS.md with sentinel comments (legacy Codex format)."""
    path = target / "AGENTS.md"
    wrapped = f"{_CODEX_START}\n{content}\n{_CODEX_END}\n"

    if path.exists():
        existing = path.read_text()
        if _CODEX_START in existing:
            i = existing.index(_CODEX_START)
            j = existing.index(_CODEX_END) + len(_CODEX_END)
            nl = existing.find("\n", j)
            j = nl + 1 if nl != -1 else j
            path.write_text(existing[:i] + wrapped + existing[j:])
        else:
            with open(path, "a") as f:
                f.write("\n" + wrapped)
    else:
        path.write_text(wrapped)

    return path


# ── Multi-select checkbox ─────────────────────────────────────────


def _checkbox(options: list, title: str, defaults: list[int] | None = None) -> list[int]:
    """Multi-select checkbox — arrows + space on TTY, comma-list fallback."""
    if not sys.stdin.isatty():
        return _checkbox_numbered(options, title, defaults)
    try:
        import termios  # noqa: F811
        import tty  # noqa: F811

        return _checkbox_arrows(options, title, termios, tty, defaults)
    except (ImportError, AttributeError):
        return _checkbox_numbered(options, title, defaults)


def _checkbox_numbered(options: list, title: str, defaults: list[int] | None = None) -> list[int]:
    click.echo(f"\n  {BOLD}{title}{RESET}\n")
    for i, opt in enumerate(options):
        click.echo(f"    {i + 1}) {opt['label']}  {DIM}{opt['desc']}{RESET}")
    click.echo()
    while True:
        raw = click.prompt("  Select (e.g. 1,2 or all)", default="1")
        if raw.strip().lower() == "all":
            return list(range(len(options)))
        try:
            chosen = [int(x.strip()) - 1 for x in raw.split(",") if x.strip()]
            if chosen and all(0 <= v < len(options) for v in chosen):
                return list(dict.fromkeys(chosen))
        except ValueError:
            pass
        click.echo(
            f"  Enter numbers 1\u2013{len(options)} separated by commas, or 'all'"
        )


def _checkbox_arrows(options: list, title: str, termios, tty, defaults: list[int] | None = None) -> list[int]:  # type: ignore[no-untyped-def]
    import shutil

    idx = 0
    n = len(options)
    selected: set[int] = set(defaults) if defaults else set()
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    cols = shutil.get_terminal_size((80, 24)).columns
    # n option lines; hint has no trailing \n so cursor stays on it
    render_lines = n

    def _trunc(text: str, width: int) -> str:
        """Truncate visible text (ignoring ANSI escapes) to *width* columns."""
        import re
        visible = re.sub(r"\x1b\[[0-9;]*m", "", text)
        if len(visible) <= width:
            return text
        # Walk the original string keeping track of visible length
        out: list[str] = []
        vlen = 0
        i = 0
        while i < len(text) and vlen < width - 1:
            if text[i] == "\x1b":
                j = text.index("m", i) + 1
                out.append(text[i:j])
                i = j
            else:
                out.append(text[i])
                vlen += 1
                i += 1
        out.append(RESET + "\u2026")
        return "".join(out)

    def render(first: bool = False) -> None:
        if not first:
            sys.stdout.write(f"\033[{render_lines}A\r")
        for i, opt in enumerate(options):
            check = f"{GREEN}\u2713{RESET}" if i in selected else " "
            cursor = f"{CYAN}\u203a{RESET}" if i == idx else " "
            line = f"   {cursor} [{check}] {opt['label']}  {DIM}{opt['desc']}{RESET}"
            sys.stdout.write(f"{CLR}{_trunc(line, cols)}\n")
        sys.stdout.write(
            f"{CLR}  {DIM}\u2191/\u2193 navigate \u00b7 space select \u00b7 enter confirm \u00b7 q quit{RESET}"  # noqa: E501
        )
        sys.stdout.flush()

    click.echo(f"\n  {BOLD}{title}{RESET}\n")
    render(first=True)

    try:
        tty.setcbreak(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                b = sys.stdin.read(1)
                if b == "[":
                    arrow = sys.stdin.read(1)
                    if arrow == "A":
                        idx = (idx - 1) % n
                    elif arrow == "B":
                        idx = (idx + 1) % n
                render()
            elif ch == " ":
                if idx in selected:
                    selected.discard(idx)
                else:
                    selected.add(idx)
                render()
            elif ch in ("\r", "\n"):
                sys.stdout.write("\n\n")
                sys.stdout.flush()
                if not selected:
                    return [idx]
                return sorted(selected)
            elif ch in ("q", "\x03"):
                sys.stdout.write("\n")
                raise SystemExit(0)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ── Main entry ───────────────────────────────────────────────────


def install_skill(base_url: str, target_dir: str = ".") -> None:
    """Interactive TUI to fetch and install Paperclip skill."""
    target = Path(target_dir).resolve()

    click.echo()
    click.echo(
        f"  {BOLD}\u256d\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256e{RESET}"  # noqa: E501
    )
    click.echo(f"  {BOLD}\u2502    Paperclip  Install     \u2502{RESET}")
    click.echo(
        f"  {BOLD}\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256f{RESET}"  # noqa: E501
    )

    choices = _checkbox(AGENTS, "Select your coding agent(s):")
    selected_agents = [AGENTS[i] for i in choices]

    click.echo(f"  {BOLD}Install directory{RESET}")
    dir_input = click.prompt("  Path", default=str(target), show_default=True)
    target = Path(dir_input).expanduser().resolve()

    if not target.is_dir():
        click.echo(f"\n  {RED}\u2717 Directory not found: {target}{RESET}")
        raise SystemExit(1)

    writers = {
        "claude-code": _write_claude_code,
        "cursor": _write_cursor,
        "codex": _write_codex,
    }

    click.echo("\n  Fetching skill ...")
    content = fetch_agent_skill(base_url)
    if content is None:
        click.echo(f"  {RED}\u2717 Failed to fetch valid skill content from server.{RESET}")
        raise SystemExit(1)

    if not config.repos_enabled():
        content = strip_repos_sections(content)

    installed_keys: list[str] = []
    installed_paths: list[Path] = []
    for agent in selected_agents:
        try:
            path = writers[agent["key"]](content, target)
        except OSError as e:
            click.echo(
                f"  {RED}\u2717 Failed to install for {agent['label']}: {e}{RESET}"
            )
            continue
        click.echo(f"  {GREEN}\u2713{RESET} Installed to {BOLD}{path}{RESET}")
        installed_keys.append(agent["key"])
        installed_paths.append(path)

    if not installed_keys:
        click.echo(f"\n  {RED}\u2717 No skills were installed.{RESET}")
        raise SystemExit(1)

    # Remember where we installed so `paperclip update` can refresh these
    # files regardless of the directory it is run from.
    _register_skill_paths(installed_paths)

    # Reload reminder
    click.echo()
    click.echo(
        f"  {BOLD}Next step:{RESET} reload your coding session so the skill is picked up."
    )
    click.echo()
    if "cursor" in installed_keys:
        click.echo(
            f'  {DIM}\u2022 Cursor:{RESET}      Reload Window  (Cmd/Ctrl+Shift+P \u2192 "Reload Window")'  # noqa: E501
        )
    if "claude-code" in installed_keys:
        click.echo(
            f"  {DIM}\u2022 Claude Code:{RESET}  Start a new session or run /reload"
        )
    if "codex" in installed_keys:
        click.echo(f"  {DIM}\u2022 Codex:{RESET}        Start a new Codex session")

    # Example query
    click.echo()
    click.echo(f"  {BOLD}Try it out:{RESET}")
    click.echo(
        f'  From the CLI:      {CYAN}paperclip search "GLP-1 receptor agonists"{RESET}'
    )
    click.echo(
        f"  Prompt your agent: {DIM}using {RESET}{CYAN}/paperclip{RESET}{DIM}, search for recent papers on GLP-1 receptor agonists{RESET}"  # noqa: E501
    )
    click.echo()


def _find_installed_skills() -> tuple[set[Path], set[Path]]:
    """Locate installed skill files via scanning and the install registry.

    Returns ``(standalone, legacy)`` where *standalone* are SKILL.md files
    and *legacy* are AGENTS.md files with sentinel comments. Registry
    entries whose files no longer exist are pruned; newly discovered files
    are backfilled into the registry.
    """
    standalone: set[Path] = set()
    legacy: set[Path] = set()

    for d in _candidate_dirs():
        for rel in _SKILL_RELATIVE_PATHS:
            p = d / rel
            try:
                if p.is_file():
                    standalone.add(p)
            except OSError:
                continue
        agents_path = d / "AGENTS.md"
        if _is_legacy_codex_file(agents_path):
            legacy.add(agents_path)

    registered = _read_registry()
    for p in registered:
        if p.name == "AGENTS.md":
            if _is_legacy_codex_file(p):
                legacy.add(p)
            # else: dropped from the registry by the rewrite below
        else:
            try:
                if p.is_file():
                    standalone.add(p)
            except OSError:
                continue

    found = standalone | legacy
    if found != registered:
        _write_registry(found)

    return standalone, legacy


def _refresh_skill_files(
    base_url: str,
    standalone: set[Path],
    legacy: set[Path],
    silent: bool = False,
) -> int:
    """Fetch the latest skill once and rewrite the given installed files."""
    targets: list[tuple[Path, str | None]] = [
        *((p, None) for p in sorted(standalone)),
        *((p, "legacy_codex") for p in sorted(legacy)),
    ]
    if not targets:
        if not silent:
            click.echo(f"  {DIM}No installed skill files found.{RESET}")
        return 0

    content = fetch_agent_skill(base_url, timeout=5)
    if content is not None and not config.repos_enabled():
        content = strip_repos_sections(content)

    if content is None:
        if not silent:
            click.echo(
                f"  {DIM}Could not fetch the latest skill — "
                f"{len(targets)} installed file(s) left unchanged.{RESET}"
            )
        return len(targets)

    for path, kind in targets:
        try:
            if kind == "legacy_codex":
                _write_codex_legacy(content, path.parent)
            else:
                path.write_text(content)
            if not silent:
                click.echo(f"  {DIM}Updated {_display_path(path)}{RESET}")
        except Exception:
            if not silent:
                click.echo(f"  {DIM}Could not update {_display_path(path)}{RESET}")

    return len(targets)


def refresh_installed_skills(base_url: str, silent: bool = False) -> int:
    """Update any previously installed skill files.

    Called on login and periodically during command execution so users
    always have the latest skill content without re-running `paperclip install`.
    Looks for installs in the cwd, its ancestors, the home directory, and
    any locations recorded in the install registry.

    When silent=True, suppresses all output (used for background refresh).
    Returns the number of skill files found.
    """
    standalone, legacy = _find_installed_skills()
    return _refresh_skill_files(base_url, standalone, legacy, silent=silent)


def find_and_refresh_all_skills(base_url: str) -> None:
    """Find every skill install on the machine and update them all.

    Used by interactive `paperclip update`. In addition to the fast lookup
    paths, runs a bounded scan of the home directory so installs in other
    projects are found too. Everything found is recorded in the registry and
    refreshed. If nothing is installed anywhere, offers a fresh install.
    """
    standalone, legacy = _find_installed_skills()
    try:
        standalone |= _scan_home_for_skills()
    except Exception:
        pass  # a scan failure must never block refreshing the known installs

    if not standalone and not legacy:
        click.echo(f"  {DIM}No installed skill files found.{RESET}")
        if sys.stdin.isatty():
            click.echo()
            install_skill(base_url)
        else:
            click.echo(f"  Run {CYAN}paperclip install{RESET} to set them up.")
        return

    _write_registry(standalone | legacy)
    _refresh_skill_files(base_url, standalone, legacy)


def _standalone_skill_paths(cwd: Path | None = None) -> list[Path]:
    """Installed SKILL.md locations for Claude Code, Cursor, and Codex."""
    base = cwd or Path.cwd()
    paths = {base / rel for rel in _SKILL_RELATIVE_PATHS}
    paths.update(p for p in _read_registry() if p.name == "SKILL.md")
    return sorted(paths)


def apply_repos_preference(base_url: str, enabled: bool) -> None:
    """Re-render installed skill files to match the repos on/off preference.

    On enable we re-fetch the full skill from the server (restores any
    previously stripped sections). On disable we both refresh (which now
    strips, since the preference is already persisted) and strip the
    standalone SKILL.md files in place so the change applies even offline.
    """
    try:
        refresh_installed_skills(base_url, silent=True)
    except Exception:
        pass

    if not enabled:
        for path in _standalone_skill_paths():
            try:
                if path.exists():
                    path.write_text(strip_repos_sections(path.read_text()))
            except Exception:
                pass


_SKILL_CHECK_FILE = Path.home() / ".paperclip" / ".last_skill_refresh"
_SKILL_REFRESH_INTERVAL = 4 * 3600  # 4 hours


def maybe_refresh_skills(base_url: str) -> None:
    """Silently refresh installed skill files if the cooldown has elapsed.

    Safe to call on every command — checks a timestamp file and only
    hits the network every 4 hours. All failures are swallowed.
    """
    try:
        last = 0.0
        try:
            last = float(_SKILL_CHECK_FILE.read_text().strip())
        except (OSError, ValueError):
            last = 0.0  # missing or corrupt timestamp → treat as expired
        now = time.time()
        if last > now:
            last = 0.0  # future timestamp (clock skew) → treat as expired
        if now - last < _SKILL_REFRESH_INTERVAL:
            return

        found = refresh_installed_skills(base_url, silent=True)

        # Only burn the cooldown when something was actually refreshed, so
        # a run from a directory with no install doesn't block the next
        # refresh of the real install location. Finding zero targets is
        # cheap (filesystem stats only — no network).
        if found > 0:
            _SKILL_CHECK_FILE.parent.mkdir(parents=True, exist_ok=True)
            _SKILL_CHECK_FILE.write_text(str(time.time()))
    except Exception:
        pass
