"""Private skill helper implementation for persistent guided analysis projects.

This Click group is intentionally not registered on the public Paperclip CLI.
Claude invokes it through the served ``guided_analysis.py`` skill script.
"""

from __future__ import annotations

import json
import re
import shlex
import shutil
import uuid
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, NoReturn

import click

from ..analysis_project import (
    AnalysisProject,
    AnalysisProjectStore,
    AnalysisRunError,
    AnalysisStateError,
    ExtractionPlanningError,
    GateReport,
    PilotComparisonError,
    ReportStateError,
    RepositoryRef,
    RepoStagingError,
    SchemaOptimizationError,
    apply_repo_staging,
    approve_question,
    archive_results_revision,
    build_publish_manifest,
    build_results_binding,
    complete_collection_pilot,
    execute_analysis,
    freeze_evidence,
    lock_extraction_schema,
    log_unknown_schema_observation,
    optimize_extraction_schema,
    publication_for_revision,
    report_status,
    review_gate,
    revise_project,
    sha256_file,
    utc_now,
    validate_current_execution,
    validate_publish,
    write_evidence_review,
    write_extraction_merge,
    write_extraction_plan,
    write_pilot_comparison,
    write_publish_manifest,
    write_repo_staging,
)
from ..meta_analysis.export_verified import write_verified_findings

_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


def _fail(message: str, json_output: bool, *, details: object | None = None) -> NoReturn:
    if json_output:
        payload: dict[str, Any] = {"ok": False, "error": message}
        if details is not None:
            payload["details"] = details
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        click.echo(f"Error: {message}", err=True)
    raise click.exceptions.Exit(1)


def _emit_checkpoint(
    project: AnalysisProject,
    json_output: bool,
    *,
    message: str,
    changed: bool | None = None,
    gate: GateReport | None = None,
    inventory: list[dict[str, Any]] | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    if json_output:
        payload = project.summary()
        payload["ok"] = getattr(gate, "ok", True)
        payload["message"] = message
        if changed is not None:
            payload["changed"] = changed
        if gate is not None:
            payload["gate"] = gate.to_dict()
        if inventory is not None:
            payload["upload_inventory"] = inventory
        if extra is not None:
            payload.update(extra)
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
        return

    click.echo("[analysis checkpoint]")
    click.echo(f"project: {project.slug} ({project.project_id})")
    click.echo(f"stage: {project.stage}")
    click.echo(f"status: {project.status}")
    click.echo(f"revision: {project.revision}")
    click.echo(
        f"repo: {project.repo.name}@{project.repo.branch} ({project.repo.sha or 'uncommitted'})"
    )
    click.echo(f"next: {project.next_action or '-'}")
    click.echo(f"message: {message}")
    if gate is not None:
        click.echo(f"gate: {'pass' if gate.ok else 'blocked'}")
        for blocker in gate.blockers:
            click.echo(f"blocker: {blocker}")
    if inventory is not None:
        click.echo("upload inventory:")
        for item in inventory:
            click.echo(f"  {item['path']}  sha256:{item['sha256']}  {item['size_bytes']} bytes")
    if extra is not None:
        for key, value in extra.items():
            click.echo(f"{key.replace('_', ' ')}: {value}")


def _load_project(
    store: AnalysisProjectStore,
    directory: Path | None,
    json_output: bool,
) -> AnalysisProject:
    try:
        return store.load(directory) if directory else store.load_active()
    except AnalysisStateError as exc:
        _fail(str(exc), json_output)


def _normal_slug(value: str, json_output: bool) -> str:
    slug = value.strip().lower()
    if not _SLUG_RE.fullmatch(slug):
        _fail(
            "Slug must start with a letter or number and contain only "
            "lowercase letters, numbers, '.', '_' or '-'.",
            json_output,
        )
    return slug


def _exit_if_blocked(
    project: AnalysisProject,
    gate: GateReport,
    json_output: bool,
    message: str,
) -> None:
    _emit_checkpoint(project, json_output, message=message, changed=False, gate=gate)
    if not gate.ok:
        raise click.exceptions.Exit(1)


@click.group("guided-analysis", invoke_without_command=True)
@click.pass_context
def analysis_group(ctx: click.Context) -> None:
    """Private Claude helper for a persistent, checkpointed guided analysis."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@analysis_group.command("start")
@click.argument("slug")
@click.option(
    "--dir",
    "directory",
    required=True,
    type=click.Path(path_type=Path),
    help="Local topic directory.",
)
@click.option("--question", required=True, help="Research question for the analysis.")
@click.option("--repo", "--repo-name", "repo_name", default=None, help="Associated repo name.")
@click.option("--branch", "repo_branch", default="main", show_default=True)
@click.option("--sha", "repo_sha", default=None, help="Associated repo commit SHA.")
@click.option(
    "--legacy-import",
    is_flag=True,
    help="Explicitly import a pre-dynamic-contract project.",
)
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def start_command(
    slug: str,
    directory: Path,
    question: str,
    repo_name: str | None,
    repo_branch: str,
    repo_sha: str | None,
    legacy_import: bool,
    json_output: bool,
) -> None:
    """Create a local project and make it active; no remote repo is created."""
    slug = _normal_slug(slug, json_output)
    question = question.strip()
    if not question:
        _fail("Question cannot be empty.", json_output)
    normalized_repo = (repo_name or slug).strip()
    normalized_branch = repo_branch.strip()
    if not normalized_repo:
        _fail("Repository name cannot be empty.", json_output)
    if not normalized_branch:
        _fail("Repository branch cannot be empty.", json_output)
    directory = directory.expanduser().resolve()
    if directory.exists() and not directory.is_dir():
        _fail(f"Topic path is not a directory: {directory}", json_output)
    try:
        directory.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        _fail(f"Cannot create topic directory {directory}: {exc}", json_output)

    store = AnalysisProjectStore()
    state_file = directory / "analysis_project.json"
    if state_file.exists():
        try:
            project = store.load(directory)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
        same = (
            project.slug == slug
            and project.question == question
            and project.repo.name == normalized_repo
            and project.repo.branch == normalized_branch
            and project.repo.sha == repo_sha
            and project.legacy_import == legacy_import
            and Path(project.topic_dir).resolve() == directory
        )
        if not same:
            _fail(
                f"{directory} already contains a different analysis project "
                f"({project.slug}, {project.project_id}).",
                json_output,
            )
        try:
            store.set_active(directory)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
        _emit_checkpoint(
            project,
            json_output,
            message="Existing matching project resumed.",
            changed=False,
        )
        return

    now = utc_now()
    project = AnalysisProject(
        project_id=str(uuid.uuid4()),
        slug=slug,
        topic_dir=str(directory),
        question=question,
        repo=RepositoryRef(
            name=normalized_repo,
            branch=normalized_branch,
            sha=repo_sha,
        ),
        legacy_import=legacy_import,
        created_at=now,
        updated_at=now,
    )
    try:
        store.save(project, touch=False)
        store.set_active(directory)
    except AnalysisStateError as exc:
        _fail(str(exc), json_output)
    _emit_checkpoint(project, json_output, message="Analysis project started.", changed=True)


@analysis_group.command("status")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def status_command(directory: Path | None, json_output: bool) -> None:
    """Show the active or explicitly selected project."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    _emit_checkpoint(project, json_output, message="Project status.")


@analysis_group.command("review")
@click.argument(
    "stage",
    required=False,
    type=click.Choice(["question", "evidence", "results"]),
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option(
    "--stage",
    "stage_option",
    type=click.Choice(["question", "evidence", "results"]),
)
@click.option(
    "--refresh",
    is_flag=True,
    help="Rebuild evidence_review.json from current evidence-stage artifacts.",
)
@click.option(
    "--landmarks",
    "landmark_list",
    type=click.Path(path_type=Path),
    help="Optional landmark list inside the analysis project directory.",
)
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def review_command(
    stage: str | None,
    directory: Path | None,
    stage_option: str | None,
    refresh: bool,
    landmark_list: Path | None,
    json_output: bool,
) -> None:
    """Validate required artifacts and frozen hashes for a checkpoint."""
    if stage and stage_option and stage != stage_option:
        _fail("Positional stage and --stage disagree.", json_output)
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    target = stage_option or stage or project.stage
    if landmark_list is not None and not refresh:
        _fail("--landmarks requires --refresh.", json_output)
    if refresh:
        if target != "evidence":
            _fail("--refresh is only valid for the evidence checkpoint.", json_output)
        try:
            verified_path = Path(project.topic_dir) / "verified_findings.json"
            if not project.legacy_import and not verified_path.is_file():
                write_verified_findings(project.topic_dir)
            write_evidence_review(
                project.topic_dir,
                landmark_list_path=landmark_list,
            )
        except (OSError, ValueError) as exc:
            _fail(f"Could not refresh evidence review: {exc}", json_output)
    gate = review_gate(project, target)
    messages = {
        "question": "Question reviewed; HARD STOP until the user explicitly approves it.",
        "evidence": "Evidence reviewed; HARD STOP until the user explicitly chooses analysis.",
        "results": ("Results QA passed; ready for review only. No artifacts were uploaded."),
    }
    next_actions = {
        "question": (
            "Ask the user; after explicit approval Claude runs "
            "python3 guided_analysis.py approve question"
        ),
        "evidence": (
            "Ask the user; after an explicit analyze choice Claude runs "
            "python3 guided_analysis.py analyze"
        ),
        "results": ("Ask the user whether to revise, reopen Evidence, stop, or publish"),
    }
    if gate.ok and (
        project.status != "awaiting_user" or project.next_action != next_actions[target]
    ):
        project.status = "awaiting_user"
        project.next_action = next_actions[target]
        try:
            store.save(project)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
    message = (
        messages[target] if gate.ok else f"{target.capitalize()} review blocked; no transition."
    )
    _exit_if_blocked(project, gate, json_output, message)


@analysis_group.group("approve", invoke_without_command=True)
@click.pass_context
def approve_group(ctx: click.Context) -> None:
    """Record an explicit human checkpoint approval."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@approve_group.command("question")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def approve_question_command(directory: Path | None, json_output: bool) -> None:
    """Approve the question artifacts and advance to evidence."""
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    project, gate, changed = approve_question(project)
    if gate.ok and changed:
        try:
            store.save(project)
            store.set_active(project.topic_dir)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
    _emit_checkpoint(
        project,
        json_output,
        message="Question approved." if changed else "Question approval unchanged.",
        changed=changed,
        gate=gate,
    )
    if not gate.ok:
        raise click.exceptions.Exit(1)


@analysis_group.command("revise")
@click.argument(
    "stage",
    required=False,
    type=click.Choice(["question", "evidence", "results"]),
)
@click.option(
    "--stage",
    "stage_option",
    type=click.Choice(["question", "evidence", "results"]),
    help="Stage to revise (alternative to the positional argument).",
)
@click.option("--question", help="Replacement question when revising question.")
@click.option(
    "--reason",
    help="Reason for the revision (required when revising results).",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def revise_command(
    stage: str | None,
    stage_option: str | None,
    question: str | None,
    reason: str | None,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Open a stage for revision and invalidate its dependent approvals."""
    if stage and stage_option and stage != stage_option:
        _fail("Positional stage and --stage disagree.", json_output)
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    target = stage_option or stage or project.stage
    archive: dict[str, Any] | None = None
    if target == "results" and not (reason or "").strip():
        _fail("--reason is required when revising results.", json_output)
    try:
        if target not in ("question", "evidence", "results"):
            raise ValueError(f"Unknown stage {target!r}")
        if ("question", "evidence", "results").index(target) > (
            "question",
            "evidence",
            "results",
        ).index(project.stage):
            raise ValueError(
                f"Cannot revise future stage {target!r} while project is at {project.stage!r}"
            )
        if project.stage == "results":
            archive = archive_results_revision(
                project,
                reason or f"Reopened {target} stage.",
            )
        revise_project(project, target, question)
        if archive is not None:
            project.results_revision += 1
        if target == "results":
            project.results_binding = build_results_binding(
                project,
                reason=(reason or "").strip(),
            )
        store.save(project)
        store.set_active(project.topic_dir)
    except (ValueError, AnalysisStateError, ReportStateError, OSError) as exc:
        _fail(str(exc), json_output)
    _emit_checkpoint(
        project,
        json_output,
        message=f"{target.capitalize()} opened for revision; downstream approvals invalidated.",
        changed=True,
        extra={
            "results_archive": archive["archive"] if archive else None,
            "results_revision": project.results_revision,
        },
    )


@analysis_group.group("pilot", invoke_without_command=True)
@click.pass_context
def pilot_group(ctx: click.Context) -> None:
    """Record private representative-pilot lifecycle state."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@pilot_group.command("complete")
@click.option(
    "--summary",
    "summary_path",
    required=True,
    type=click.Path(path_type=Path),
    help="Claude-authored pilot summary JSON.",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def pilot_complete_command(
    summary_path: Path,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Bind a passing pilot summary to the approved collection schema."""
    try:
        summary = json.loads(summary_path.expanduser().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _fail(f"Could not read pilot summary: {exc}", json_output)
    if not isinstance(summary, dict):
        _fail("Pilot summary must contain a JSON object.", json_output)
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    project, gate, changed = complete_collection_pilot(project, summary)
    if gate.ok and changed:
        try:
            store.save(project)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
    _emit_checkpoint(
        project,
        json_output,
        message=(
            "Pilot passed for the current approved collection schema."
            if changed
            else "Pilot completion unchanged."
            if gate.ok
            else "Pilot completion blocked."
        ),
        changed=changed,
        gate=gate,
    )
    if not gate.ok:
        raise click.exceptions.Exit(1)


@analysis_group.command("schema-optimize")
@click.option(
    "--input",
    "--registry",
    "registry_path",
    required=True,
    type=click.Path(path_type=Path),
    help="Claude/user-authored optimized field registry candidate JSON.",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option(
    "--json/--human",
    "json_output",
    default=True,
    help="Emit machine-readable JSON (default) or a short human summary.",
)
def schema_optimize_command(
    registry_path: Path,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Revision and generate a deterministic structured-extraction schema."""
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    previous_state = (
        project.schema_registry_sha256,
        project.extraction_schema_sha256,
        project.schema_lock_sha256,
        project.scaled_extraction_ready,
    )
    try:
        registry, extraction_schema, artifact_changed = optimize_extraction_schema(
            project,
            registry_path,
        )
    except (OSError, SchemaOptimizationError, ValueError) as exc:
        _fail(str(exc), json_output)
    current_state = (
        project.schema_registry_sha256,
        project.extraction_schema_sha256,
        project.schema_lock_sha256,
        project.scaled_extraction_ready,
    )
    state_changed = current_state != previous_state
    if state_changed:
        try:
            store.save(project)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
    try:
        collection = json.loads(
            (Path(project.topic_dir) / "collection_spec.json").read_text(
                encoding="utf-8"
            )
        )
    except (OSError, json.JSONDecodeError):
        collection = {}
    pilot_ready = (
        isinstance(collection, dict)
        and collection.get("pilot_status") == "ready_for_scale"
    )
    payload = {
        "ok": True,
        "changed": artifact_changed or state_changed,
        "registry_revision": registry["revision"],
        "optimization_input_sha256": registry["optimization_input_sha256"],
        "category_count": len(
            {field["category"] for field in registry["fields"] if isinstance(field, dict)}
        ),
        "field_count": len(registry["fields"]),
        "extraction_schema_id": extraction_schema["$id"],
        "scaled_extraction_ready": project.scaled_extraction_ready,
        "pilot_ready_for_lock": pilot_ready,
    }
    if json_output:
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        click.echo("[schema optimization]")
        click.echo(f"revision: {payload['registry_revision']}")
        click.echo(f"fields: {payload['field_count']}")
        click.echo(f"changed: {str(payload['changed']).lower()}")
        click.echo(
            "next: run schema-lock before scaled extraction"
            if pilot_ready
            else "next: run the representative pilot, then re-optimize and lock"
        )


@analysis_group.command("schema-lock")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option(
    "--json/--human",
    "json_output",
    default=True,
    help="Emit machine-readable JSON (default) or a short human summary.",
)
def schema_lock_command(directory: Path | None, json_output: bool) -> None:
    """Lock exact registry/schema bytes after an approved passing pilot."""
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    try:
        lock, changed = lock_extraction_schema(project)
        if changed:
            store.save(project)
    except (AnalysisStateError, OSError, SchemaOptimizationError, ValueError) as exc:
        _fail(str(exc), json_output)
    payload = {
        "ok": True,
        "changed": changed,
        "scaled_extraction_ready": project.scaled_extraction_ready,
        "schema_registry_sha256": lock["schema_registry_sha256"],
        "extraction_schema_sha256": lock["extraction_schema_sha256"],
        "fallback_claim_schema_sha256": lock["fallback_claim_schema_sha256"],
        "schema_lock_sha256": project.schema_lock_sha256,
        "lock_content_sha256": lock["lock_content_sha256"],
    }
    if json_output:
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        click.echo("[schema lock]")
        click.echo("status: locked")
        click.echo(f"changed: {str(changed).lower()}")
        click.echo(f"lock sha256: {project.schema_lock_sha256}")


@analysis_group.command("schema-observe")
@click.option("--document-id", required=True, help="Paperclip document identifier.")
@click.option("--field", "field_id", required=True, help="Locked categorical field id.")
@click.option(
    "--as-reported",
    required=True,
    help="Unknown categorical wording exactly as reported.",
)
@click.option(
    "--source",
    "sources",
    required=True,
    multiple=True,
    type=(str, str),
    metavar="PATH LINES",
    help="Exact source path and canonical L# or L#-L# range; repeat as needed.",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option(
    "--json/--human",
    "json_output",
    default=True,
    help="Emit machine-readable JSON (default) or a short human summary.",
)
def schema_observe_command(
    document_id: str,
    field_id: str,
    as_reported: str,
    sources: tuple[tuple[str, str], ...],
    directory: Path | None,
    json_output: bool,
) -> None:
    """Log an unknown scaled categorical label without mutating the lock."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    try:
        artifact, changed = log_unknown_schema_observation(
            project,
            document_id=document_id,
            field_id=field_id,
            as_reported=as_reported,
            source_locations=[
                {"path": path, "lines": lines} for path, lines in sources
            ],
        )
    except (OSError, SchemaOptimizationError, ValueError) as exc:
        _fail(str(exc), json_output)
    payload = {
        "ok": True,
        "changed": changed,
        "selected_option_id": "other",
        "observation_count": len(artifact["observations"]),
        "schema_lock_sha256": artifact["schema_lock_sha256"],
    }
    if json_output:
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        click.echo("[schema observation]")
        click.echo("selected option: other")
        click.echo(f"changed: {str(changed).lower()}")


@analysis_group.command("pilot-compare")
@click.option(
    "--structured-manifest",
    "structured_paths",
    required=True,
    multiple=True,
    type=click.Path(path_type=Path),
)
@click.option(
    "--exhaustive-manifest",
    "exhaustive_paths",
    required=True,
    multiple=True,
    type=click.Path(path_type=Path),
)
@click.option(
    "--structured-verifier-pass-rate",
    type=click.FloatRange(0.0, 1.0),
)
@click.option(
    "--exhaustive-verifier-pass-rate",
    type=click.FloatRange(0.0, 1.0),
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json/--human", "json_output", default=True)
def pilot_compare_command(
    structured_paths: tuple[Path, ...],
    exhaustive_paths: tuple[Path, ...],
    structured_verifier_pass_rate: float | None,
    exhaustive_verifier_pass_rate: float | None,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Compare structured pilot extraction with the exhaustive reference."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)

    def load(paths: tuple[Path, ...], label: str) -> list[dict[str, Any]]:
        manifests = []
        for path in paths:
            try:
                value = json.loads(path.expanduser().read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                _fail(f"Could not read {label} manifest {path}: {exc}", json_output)
            if not isinstance(value, dict):
                _fail(f"{label} manifest {path} must contain one JSON object.", json_output)
            manifests.append(value)
        return manifests

    try:
        artifact = write_pilot_comparison(
            project.topic_dir,
            load(structured_paths, "structured"),
            load(exhaustive_paths, "exhaustive"),
            structured_verifier_pass_rate=structured_verifier_pass_rate,
            exhaustive_verifier_pass_rate=exhaustive_verifier_pass_rate,
        )
    except (OSError, PilotComparisonError, ValueError) as exc:
        _fail(str(exc), json_output)
    if json_output:
        click.echo(json.dumps({"ok": True, **artifact}, indent=2, sort_keys=True))
    else:
        click.echo("[pilot comparison]")
        click.echo(f"status: {artifact['status']}")
        click.echo(f"field recall: {artifact['field_recall']}")
        click.echo(f"value agreement: {artifact['value_agreement']}")
        click.echo(
            f"source-location agreement: {artifact['source_location_agreement']}"
        )


@analysis_group.command("repo-stage")
@click.option(
    "--manifest",
    "manifest_paths",
    required=True,
    multiple=True,
    type=click.Path(path_type=Path),
    help="Structured-extraction map manifest JSON; repeat to combine resumed runs.",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json/--human", "json_output", default=True)
def repo_stage_command(
    manifest_paths: tuple[Path, ...],
    directory: Path | None,
    json_output: bool,
) -> None:
    """Validate and flatten extracted values without changing a repo."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    manifests = []
    for path in manifest_paths:
        try:
            value = json.loads(path.expanduser().read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            _fail(f"Could not read map manifest {path}: {exc}", json_output)
        if not isinstance(value, dict):
            _fail(f"Map manifest {path} must contain one JSON object.", json_output)
        manifests.append(value)
    try:
        artifact, changed = write_repo_staging(project, manifests)
    except (OSError, RepoStagingError, ValueError) as exc:
        _fail(str(exc), json_output)
    payload = {
        "ok": artifact["ready_to_add"],
        "changed": changed,
        "paper_count": artifact["paper_count"],
        "claim_count": artifact["claim_count"],
        "blockers": artifact["blockers"],
        "next_step": artifact["next_step"],
    }
    if json_output:
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        click.echo("[repo stage]")
        click.echo(f"papers: {artifact['paper_count']}")
        click.echo(f"claims: {artifact['claim_count']}")
        click.echo(f"ready: {str(artifact['ready_to_add']).lower()}")
        click.echo(f"next: {artifact['next_step']}")
    if not artifact["ready_to_add"]:
        raise click.exceptions.Exit(1)


@analysis_group.command("repo-add")
@click.option("--repo", "repo_name", help="Repo to check out before adding claims.")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json/--human", "json_output", default=True)
def repo_add_command(
    repo_name: str | None,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Add staged claims; verification happens later in repo commit."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    try:
        payload = {"ok": True, **apply_repo_staging(project, repo_name=repo_name)}
    except (OSError, RepoStagingError, ValueError) as exc:
        _fail(str(exc), json_output)
    if json_output:
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        click.echo("[repo add]")
        click.echo(f"papers added: {payload['papers_added']}")
        click.echo(f"claims added: {payload['claims_added']}")
        click.echo(f"next: {payload['next_step']}")


@analysis_group.command("extraction-plan")
@click.option(
    "--inventory",
    "inventory_path",
    required=True,
    type=click.Path(path_type=Path),
    help="Claude/Paperclip-authored paper complexity inventory JSON.",
)
@click.option(
    "--thresholds",
    "thresholds_path",
    type=click.Path(path_type=Path),
    help="Optional JSON object overriding dense-paper planning defaults.",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option(
    "--json/--human",
    "json_output",
    default=True,
    help="Emit machine-readable JSON (default) or a short human summary.",
)
def extraction_plan_command(
    inventory_path: Path,
    thresholds_path: Path | None,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Build deterministic private map tasks for paper extraction."""
    thresholds: dict[str, Any] | None = None
    if thresholds_path is not None:
        try:
            loaded = json.loads(thresholds_path.expanduser().read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            _fail(f"Could not read extraction thresholds: {exc}", json_output)
        if not isinstance(loaded, dict):
            _fail("Extraction thresholds must contain a JSON object.", json_output)
        thresholds = loaded
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    try:
        plan = write_extraction_plan(
            project,
            inventory_path,
            thresholds=thresholds,
        )
    except (ExtractionPlanningError, OSError, ValueError) as exc:
        _fail(str(exc), json_output)
    if json_output:
        click.echo(json.dumps(plan, indent=2, sort_keys=True))
        return
    dense = sum(paper["classification"] == "dense" for paper in plan["papers"])
    click.echo("[extraction plan]")
    click.echo(f"plan: {plan['plan_id']} revision {plan['revision']}")
    click.echo(f"papers: {len(plan['papers'])} ({dense} dense)")
    click.echo(f"tasks: {len(plan['tasks'])}")


@analysis_group.command("extraction-merge")
@click.option(
    "--shards-dir",
    required=True,
    type=click.Path(path_type=Path),
    help="Directory containing one saved JSON output per planned shard.",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option(
    "--json/--human",
    "json_output",
    default=True,
    help="Emit machine-readable JSON (default) or a short human summary.",
)
def extraction_merge_command(
    shards_dir: Path,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Validate and deterministically merge every required shard output."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    try:
        result = write_extraction_merge(project, shards_dir)
    except (ExtractionPlanningError, OSError, ValueError) as exc:
        _fail(str(exc), json_output)
    if json_output:
        click.echo(json.dumps(result, indent=2, sort_keys=True))
    else:
        click.echo("[extraction merge]")
        click.echo(f"status: {result['status']}")
        click.echo(f"cards: {result['accounting']['merged_card_count']}")
        for conflict in result["conflicts"]:
            click.echo(f"conflict: {conflict['code']}: {conflict['message']}")
    if result["status"] != "success":
        raise click.exceptions.Exit(1)


@analysis_group.command("analyze")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def analyze_command(directory: Path | None, json_output: bool) -> None:
    """Freeze reviewed evidence and advance to the results stage."""
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    project, gate, changed = freeze_evidence(project)
    if gate.ok and changed:
        try:
            store.save(project)
            store.set_active(project.topic_dir)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
    _emit_checkpoint(
        project,
        json_output,
        message=(
            "Evidence frozen; results stage opened." if changed else "Evidence freeze unchanged."
        ),
        changed=changed,
        gate=gate,
    )
    if not gate.ok:
        raise click.exceptions.Exit(1)


@analysis_group.command("run")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--dry-run", is_flag=True, help="Validate the bundle without executing code.")
@click.option(
    "--timeout",
    "timeout_seconds",
    type=click.IntRange(1, 3600),
    help="Override the declared local execution timeout.",
)
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def run_command(
    directory: Path | None,
    dry_run: bool,
    timeout_seconds: int | None,
    json_output: bool,
) -> None:
    """Validate and run the package-backed analysis bundle locally."""
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    try:
        result = execute_analysis(
            project,
            dry_run=dry_run,
            timeout_seconds=timeout_seconds,
        )
    except AnalysisRunError as exc:
        _fail(str(exc), json_output)
    if not dry_run:
        project.results_binding = build_results_binding(
            project,
            reason="Managed analysis execution completed.",
        )
        project.status = "results_report_in_progress"
        project.next_action = (
            "author report_spec.json and index.html, run fixed QA, then preview for review"
        )
        try:
            store.save(project)
        except AnalysisStateError as exc:
            _fail(str(exc), json_output)
        result["results_revision"] = project.results_revision
        result["results_binding"] = project.results_binding
    if json_output:
        click.echo(json.dumps(result, indent=2, sort_keys=True))
    else:
        click.echo("[analysis run]")
        click.echo(f"project: {project.slug}")
        click.echo(f"status: {'preflight passed' if dry_run else 'completed'}")
        click.echo(f"message: {result['message']}")
        if result.get("analysis_sha256"):
            click.echo(f"analysis sha256: {result['analysis_sha256']}")
        if result.get("execution_sha256"):
            click.echo(f"execution sha256: {result['execution_sha256']}")


@analysis_group.command("validate-results")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def validate_results_command(directory: Path | None, json_output: bool) -> None:
    """Validate that managed results match their latest local execution."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    result = validate_current_execution(project)
    if json_output:
        click.echo(json.dumps(result, indent=2, sort_keys=True))
    elif result["ok"]:
        click.echo("[analysis results]")
        click.echo("status: valid")
        click.echo(f"analysis sha256: {result['analysis_sha256']}")
        click.echo(f"execution sha256: {result['execution_sha256']}")
    else:
        click.echo("Error: managed analysis results are invalid:", err=True)
        for error in result["errors"]:
            click.echo(f"  - {error}", err=True)
    if not result["ok"]:
        raise click.exceptions.Exit(1)


@analysis_group.command("report-status")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def report_status_command(directory: Path | None, json_output: bool) -> None:
    """Show report contract, revision diff, execution, and publication bindings."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    result = report_status(project)
    if json_output:
        click.echo(json.dumps(result, indent=2, sort_keys=True))
        return
    click.echo("[analysis report status]")
    click.echo(f"project: {project.slug}")
    click.echo(f"results revision: {project.results_revision}")
    click.echo(f"report spec: {'valid' if result['report_spec']['ok'] else 'invalid'}")
    click.echo(f"execution binding: {'current' if not result['binding_errors'] else 'stale'}")
    diff = result["diff_summary"]
    click.echo(
        "diff: "
        f"{len(diff['added'])} added, {len(diff['modified'])} modified, "
        f"{len(diff['removed'])} removed"
    )


@analysis_group.command("resume")
@click.argument("path", required=False, type=click.Path(path_type=Path))
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def resume_command(
    path: Path | None,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Select an existing local analysis project as active."""
    if path and directory and path.expanduser().resolve() != directory.expanduser().resolve():
        _fail("PATH and --dir refer to different projects.", json_output)
    store = AnalysisProjectStore()
    selected = directory or path
    project = _load_project(store, selected, json_output)
    try:
        store.set_active(project.topic_dir)
    except AnalysisStateError as exc:
        _fail(str(exc), json_output)
    _emit_checkpoint(project, json_output, message="Analysis project resumed.", changed=True)


@analysis_group.command("fork")
@click.argument("slug")
@click.option(
    "--dir",
    "target_dir",
    required=True,
    type=click.Path(path_type=Path),
    help="New local topic directory.",
)
@click.option("--from-dir", "source_dir", type=click.Path(path_type=Path))
@click.option("--repo", "--repo-name", "repo_name", default=None)
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def fork_command(
    slug: str,
    target_dir: Path,
    source_dir: Path | None,
    repo_name: str | None,
    json_output: bool,
) -> None:
    """Copy a project and its artifacts into an independent local project."""
    slug = _normal_slug(slug, json_output)
    store = AnalysisProjectStore()
    parent = _load_project(store, source_dir, json_output)
    source = Path(parent.topic_dir).resolve()
    target = target_dir.expanduser().resolve()
    normalized_repo = (repo_name or slug).strip()
    if not normalized_repo:
        _fail("Repository name cannot be empty.", json_output)
    if target == source or source in target.parents:
        _fail("Fork target must be outside the parent project directory.", json_output)
    if target.exists():
        if not target.is_dir():
            _fail(f"Fork target is not a directory: {target}", json_output)
        if any(target.iterdir()):
            _fail(f"Fork target must be empty: {target}", json_output)
    else:
        try:
            target.mkdir(parents=True)
        except OSError as exc:
            _fail(f"Cannot create fork target {target}: {exc}", json_output)

    try:
        for child in source.iterdir():
            if child.name == "analysis_project.json":
                continue
            destination = target / child.name
            if child.is_dir():
                shutil.copytree(child, destination)
            elif child.is_file():
                shutil.copy2(child, destination)
    except OSError as exc:
        _fail(f"Could not copy project artifacts: {exc}", json_output)

    now = utc_now()
    child_project = AnalysisProject(
        project_id=str(uuid.uuid4()),
        parent_id=parent.project_id,
        slug=slug,
        topic_dir=str(target),
        question=parent.question,
        repo=RepositoryRef(
            name=normalized_repo,
            branch=parent.repo.branch,
            sha=parent.repo.sha,
        ),
        legacy_import=parent.legacy_import,
        revision=1,
        created_at=now,
        updated_at=now,
    )
    try:
        store.save(child_project, touch=False)
        store.set_active(target)
    except AnalysisStateError as exc:
        _fail(str(exc), json_output)
    _emit_checkpoint(
        child_project,
        json_output,
        message=f"Forked from {parent.slug}; copied artifacts require fresh approval.",
        changed=True,
    )


@analysis_group.command("preview")
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--serve", is_flag=True, help="Serve the project directory until interrupted.")
@click.option(
    "--print-only",
    is_flag=True,
    help="Validate and print the preview URL without starting a server.",
)
@click.option("--port", default=8008, show_default=True, type=click.IntRange(1, 65535))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def preview_command(
    directory: Path | None,
    serve: bool,
    print_only: bool,
    port: int,
    json_output: bool,
) -> None:
    """Validate index.html and optionally serve it locally; never uploads."""
    project = _load_project(AnalysisProjectStore(), directory, json_output)
    index = Path(project.topic_dir) / "index.html"
    if not index.is_file():
        _fail(f"Preview requires {index}.", json_output)
    try:
        sample = index.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        _fail(f"Cannot read index.html: {exc}", json_output)
    if not sample.strip() or "<html" not in sample.lower():
        _fail("index.html is empty or does not contain an <html> document.", json_output)

    url = f"http://127.0.0.1:{port}/index.html"
    if json_output:
        payload = project.summary()
        payload.update(
            {
                "ok": True,
                "message": "Preview validated locally; no artifacts were uploaded.",
                "preview_url": url,
                "uploaded": False,
            }
        )
        click.echo(json.dumps(payload, indent=2, sort_keys=True))
    else:
        _emit_checkpoint(project, False, message=f"Preview validated: {index}")
        click.echo(f"preview: {url}")

    if not serve or print_only:
        return
    handler = partial(SimpleHTTPRequestHandler, directory=project.topic_dir)
    try:
        with ThreadingHTTPServer(("127.0.0.1", port), handler) as server:
            server.serve_forever()
    except KeyboardInterrupt:
        return
    except OSError as exc:
        _fail(f"Could not start preview server: {exc}", json_output)


@analysis_group.command("publish")
@click.option("--dry-run", is_flag=True, help="Validate and print uploads without writing files.")
@click.option(
    "--record-uploaded",
    is_flag=True,
    help="Record success after the standard paperclip upload command completes.",
)
@click.option("--dir", "directory", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON.")
def publish_command(
    dry_run: bool,
    record_uploaded: bool,
    directory: Path | None,
    json_output: bool,
) -> None:
    """Validate and prepare a versioned upload for Claude to publish."""
    if dry_run and record_uploaded:
        _fail("--dry-run and --record-uploaded cannot be used together.", json_output)
    store = AnalysisProjectStore()
    project = _load_project(store, directory, json_output)
    gate, inventory = validate_publish(project)
    if not gate.ok:
        _emit_checkpoint(
            project,
            json_output,
            message="Publish validation blocked.",
            changed=False,
            gate=gate,
            inventory=inventory,
        )
        raise click.exceptions.Exit(1)
    destination = f"analyses/{project.slug}/v{project.results_revision}"
    hashes = {item["path"]: item["sha256"] for item in inventory}
    previous = publication_for_revision(project)
    if previous is not None:
        if previous.get("artifact_hashes") != hashes:
            _fail(
                "This results revision was already published with different artifacts. "
                "Claude must run 'python3 guided_analysis.py revise results "
                "--reason <text>' before publishing another version.",
                json_output,
            )
        _emit_checkpoint(
            project,
            json_output,
            message="Current results revision is already published; no files uploaded.",
            changed=False,
            gate=gate,
            inventory=inventory,
            extra={
                "destination": destination,
                "published": True,
                "idempotent": True,
                "publish_manifest_sha256": previous.get("publish_manifest_sha256"),
            },
        )
        return

    root = Path(project.topic_dir)
    manifest_path = root / "publish_manifest.json"
    upload_files = [str(root / item["path"]) for item in inventory]
    upload_files.append(str(manifest_path))
    upload_command = shlex.join(["paperclip", "upload", *upload_files, "--into", destination])

    if dry_run:
        dry_manifest = build_publish_manifest(
            project,
            inventory,
            status="dry_run",
        )
        _emit_checkpoint(
            project,
            json_output,
            message=(
                f"Publish dry run passed for /clipboard/{destination}/; no artifacts were uploaded."
            ),
            changed=False,
            gate=gate,
            inventory=inventory,
            extra={
                "destination": destination,
                "published": False,
                "dry_run": True,
                "manifest": dry_manifest,
                "upload_files": upload_files,
                "upload_command": upload_command,
            },
        )
        return

    manifest: dict[str, Any] | None = None
    if manifest_path.is_file():
        try:
            loaded = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            loaded = None
        if isinstance(loaded, dict):
            manifest = loaded
    expected_manifest_fields = {
        "schema_version": 1,
        "project_id": project.project_id,
        "slug": project.slug,
        "project_revision": project.revision,
        "results_revision": project.results_revision,
        "destination": destination,
        "status": "published",
        "results_binding": project.results_binding,
        "artifact_hashes": hashes,
        "artifacts": inventory,
    }
    manifest_is_current = manifest is not None and all(
        manifest.get(key) == value for key, value in expected_manifest_fields.items()
    )

    if not record_uploaded:
        if not manifest_is_current:
            manifest = build_publish_manifest(project, inventory, status="published")
            try:
                manifest_path = write_publish_manifest(project, manifest)
            except OSError as exc:
                _fail(f"Could not prepare publish manifest: {exc}", json_output)
        manifest_hash = sha256_file(manifest_path)
        _emit_checkpoint(
            project,
            json_output,
            message=(
                "Publish validation passed and publish_manifest.json was prepared. "
                "No artifacts were uploaded; Claude must run the returned standard "
                "paperclip upload command."
            ),
            changed=False,
            gate=gate,
            inventory=inventory,
            extra={
                "destination": destination,
                "published": False,
                "prepared": True,
                "upload_files": upload_files,
                "upload_command": upload_command,
                "publish_manifest_sha256": manifest_hash,
            },
        )
        return

    if not manifest_is_current:
        _fail(
            "No current prepared publish_manifest.json exists. Run "
            "'python3 guided_analysis.py publish' before paperclip upload, then "
            "record the successful upload.",
            json_output,
        )

    manifest_hash = sha256_file(manifest_path)
    publication = {
        "status": "published",
        "published_at": utc_now(),
        "destination": destination,
        "results_revision": project.results_revision,
        "artifact_hashes": hashes,
        "publish_manifest_sha256": manifest_hash,
    }
    project.publications.append(publication)
    project.status = "published"
    project.next_action = (
        "published; Claude uses 'python3 guided_analysis.py revise results "
        "--reason <text>' for another version"
    )
    try:
        store.save(project)
    except AnalysisStateError as exc:
        _fail(str(exc), json_output)
    _emit_checkpoint(
        project,
        json_output,
        message=f"Recorded successful versioned upload to /clipboard/{destination}/.",
        changed=True,
        gate=gate,
        inventory=inventory,
        extra={
            "destination": destination,
            "published": True,
            "idempotent": False,
            "publish_manifest_sha256": manifest_hash,
        },
    )
