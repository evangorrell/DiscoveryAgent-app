"""Paperclip — Click front-end over the Python SDK.

All transport, auth, and command logic live in :mod:`gxl_paperclip.client`.
This module only handles local concerns: Click commands, interactive login,
dashboard rendering, progress bars, and ANSI formatting.
"""

from __future__ import annotations

import base64
import csv
import json
import logging
import os
import re
import shlex
import shutil
import sys
from pathlib import Path

import click
import requests

from .. import __version__, config
from ..client import (
    APIKeyAuth,
    AuthError,
    BearerAuth,
    ExecuteResult,
    FileCredentialsAuth,
    MapProgressEvent,
    MapResultEvent,
    NetworkError,
    PaperclipClient,
    PaperclipError,
    RateLimitError,
    RequestTimeoutError,
    ResultRow,
    ServerError,
)
from ..client.credentials import Credentials
from . import sources as sources_mod
from .claim_ids import stable_claim_id as _stable_claim_id
from .login import run_login
from .skill import (
    apply_repos_preference,
    find_and_refresh_all_skills,
    install_skill,
    maybe_refresh_skills,
    refresh_installed_skills,
)
from .updater import (
    auto_update,
    check_update_available,
    fetch_latest_version,
    is_managed_install,
    needs_update,
    perform_update,
)

logger = logging.getLogger(__name__)

_FEATURE_FLAGS_FILE = config.PAPERCLIP_DIR / "feature_flags.json"
_FEATURE_FLAGS_TTL_SECONDS = 300  # 5 minutes


def _read_cached_flags() -> dict:
    """Read feature flags from local cache file, or return empty dict."""
    try:
        if _FEATURE_FLAGS_FILE.exists():
            import time

            data = json.loads(_FEATURE_FLAGS_FILE.read_text())
            cached_at = data.get("_cached_at", 0)
            if time.time() - cached_at < _FEATURE_FLAGS_TTL_SECONDS:
                return data.get("flags", {})
            # Stale but still usable as fallback
            return data.get("flags", {})
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _write_cached_flags(flags: dict) -> None:
    """Write feature flags to local cache file with timestamp."""
    import time

    try:
        config.PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
        _FEATURE_FLAGS_FILE.write_text(
            json.dumps({"flags": flags, "_cached_at": time.time()})
        )
    except OSError:
        pass


def _should_refresh_flags() -> bool:
    """True if the cached flags file is missing or stale."""
    import time

    try:
        if _FEATURE_FLAGS_FILE.exists():
            data = json.loads(_FEATURE_FLAGS_FILE.read_text())
            cached_at = data.get("_cached_at", 0)
            return (time.time() - cached_at) >= _FEATURE_FLAGS_TTL_SECONDS
    except (json.JSONDecodeError, OSError):
        pass
    return True


def _fetch_feature_flags() -> None:
    """Fetch feature flags from the backend and cache locally.

    Called once per CLI process in the startup preamble. Fails silently
    on network errors (stale cache or defaults are used instead).
    """
    if not _should_refresh_flags():
        return

    base = config.get_base_url()
    try:
        resp = requests.get(f"{base}/api/features/", timeout=5)
        if resp.status_code == 200:
            flags = resp.json()
            _write_cached_flags(flags)
    except Exception:
        pass


def _get_feature_flag(name: str, default: bool = False) -> bool:
    """Read a single feature flag from the cache."""
    flags = _read_cached_flags()
    return flags.get(name, default)


def _is_mcp_mode() -> bool:
    """True when the CLI is running as the MCP passthrough executor.

    Set via the ``PAPERCLIP_MCP`` env var by the server that shells out to the
    CLI. In this mode local-only commands are disabled and interactive /
    side-effecting behavior (auto-update, skill install, login prompts) is
    suppressed.
    """
    return os.getenv("PAPERCLIP_MCP", "").strip().lower() in ("1", "true", "yes")


# Commands that only make sense on a user's local machine and are therefore
# rejected when the CLI runs as the MCP passthrough executor. This is a
# denylist: any NEW command is automatically available over MCP with no
# further changes required here.
MCP_DISABLED_COMMANDS = frozenset(
    {
        "login",
        "logout",
        "setup",
        "config",
        "repos-feature",
        "install",
        "update",
    }
)


def _is_paper_repos_enabled() -> bool:
    """Check if the paper repos feature is enabled.

    Repos are GA — the only gate is the user's local preference (toggled via
    ``paperclip repos-feature enable/disable``). Under MCP passthrough the
    server owns this decision, so repos are enabled unconditionally.
    """
    if _is_mcp_mode():
        return True
    return config.repos_enabled()


def _is_library_enabled() -> bool:
    """Library is GA — always enabled."""
    return True


_REPO_COMMANDS = frozenset(
    {
        "repo",
        "import",
    }
)


GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CLR = "\033[2K"

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")
_RESULTS_PAGE_SIZE = 10


# ── Helpers ───────────────────────────────────────────────────────


def _load_state() -> dict:
    if config.CONFIG_FILE.exists():
        try:
            return json.loads(config.CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save_state(state: dict):
    config.PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
    config.CONFIG_FILE.write_text(json.dumps(state, indent=2))


def _get_base_url() -> str:
    """Resolve the base API URL (the backend origin)."""
    return config.get_base_url()


def _get_skills_url() -> str:
    """Resolve the origin serving skill documentation and catalog files."""
    configured = os.environ.get("PAPERCLIP_SKILLS_URL", "").strip().rstrip("/")
    frontend = os.environ.get("PAPERCLIP_FRONTEND_URL", "").strip().rstrip("/")
    return configured or frontend or _get_base_url()


# Global API key storage (set at CLI invocation, never persisted)
_api_key: str | None = None


def _set_api_key(ctx, param, value):
    """Callback to store API key from CLI or env var."""
    global _api_key
    if value:
        _api_key = value
    return value


def _ensure_auth() -> Credentials | None:
    """Return valid credentials, triggering interactive login if needed.

    If an API key is provided via --api-key or PAPERCLIP_API_KEY env var,
    no OAuth credentials are needed. Returns None in that case.
    """
    if _api_key:
        return None

    creds = Credentials.load()
    if creds:
        return creds

    if not sys.stdin.isatty():
        click.echo(
            f"{RED}[error] Not authenticated. Run: paperclip login{RESET}", err=True
        )
        click.echo(
            f"{RED}       Or use --api-key flag or PAPERCLIP_API_KEY env var{RESET}",
            err=True,
        )
        sys.exit(1)

    click.echo(f"{DIM}Not signed in — starting login...{RESET}")
    base = _get_base_url()
    creds = run_login(base_url=base)
    click.echo(f"{GREEN}✓{RESET} Authenticated as {BOLD}{creds.email}{RESET}\n")

    _maybe_install_skill(base)
    return creds


def _maybe_install_skill(base_url: str) -> None:
    """Offer to install the agent skill if none is detected in the current project."""
    cwd = Path.cwd()
    known_paths = [
        cwd / ".claude" / "skills" / "paperclip" / "SKILL.md",
        cwd / ".cursor" / "skills" / "paperclip" / "SKILL.md",
        cwd / ".agents" / "skills" / "paperclip" / "SKILL.md",
    ]
    if any(p.exists() for p in known_paths):
        try:
            refresh_installed_skills(base_url)
        except Exception:
            pass
        return

    if not sys.stdin.isatty():
        return

    if click.confirm("  Install Paperclip skill for your coding agent?", default=True):
        install_skill(base_url)


def _is_local_server() -> bool:
    base = _get_base_url()
    return "localhost" in base or "127.0.0.1" in base


def _is_prod_server() -> bool:
    """True when connected to the production server (not local/staging)."""
    base = _get_base_url()
    if "localhost" in base or "127.0.0.1" in base:
        return False
    if "staging" in base:
        return False
    return True


_PAPERCLIP_REEXEC = "PAPERCLIP_REEXEC"


def _re_exec() -> None:
    """Re-execute the current command so the just-installed code is used.

    Uses os.execv to replace the process in-place. Sets an env var guard
    to prevent infinite re-exec loops if something goes wrong.
    """
    if os.environ.get(_PAPERCLIP_REEXEC):
        return

    exe = sys.executable
    argv = sys.argv[:]

    paperclip_bin = shutil.which("paperclip")
    if paperclip_bin:
        argv = [paperclip_bin] + sys.argv[1:]
        exe = paperclip_bin

    os.environ[_PAPERCLIP_REEXEC] = "1"
    try:
        os.execv(exe, argv)
    except OSError:
        pass


_repo_only_flag = False


def _get_active_repo_name() -> str | None:
    """Get the effective repo name: --repo override > sticky active > None."""
    if not _is_paper_repos_enabled():
        return None
    try:
        from . import repo

        return repo.get_active_repo()
    except Exception:
        return None


def _repo_tag() -> str:
    """Return a colored repo tag for appending to output, or empty string."""
    name = _get_active_repo_name()
    if not name:
        return ""
    return f"{DIM}[repo: {CYAN}{name}{RESET}{DIM}]{RESET}"


_PAPER_ID_RE = re.compile(
    r"\b(bio_[a-f0-9]+|PMC\d+|med_[a-f0-9]+|arx_[a-zA-Z0-9_.]+)\b"
)

# Pattern for doc_ids in map output: "  [ok] Title  (PMC123)" or "  [ok] Title  (fda_abc)"
_MAP_DOC_ID_RE = re.compile(
    r"^\s+\[(ok|error)\]\s+.+?\(("
    r"(?:bio_|med_|PMC|arx_|fda_|tri_|pat_)[a-zA-Z0-9_.]+|"
    r"NCT\d+|"
    r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}"
    r")\)\s*$"
)


def _extract_repo_flags(args: list[str]) -> tuple[list[str], str | None, bool]:
    """Strip ``--commit`` and ``--add`` flags from args before proxying to server.

    Returns ``(clean_args, commit_message, add_to_repo)``.
    """
    clean: list[str] = []
    commit_msg: str | None = None
    add_to_repo = False
    i = 0
    while i < len(args):
        if args[i] == "--commit" and i + 1 < len(args):
            commit_msg = args[i + 1]
            i += 2
        elif args[i] == "--add":
            add_to_repo = True
            i += 1
        else:
            clean.append(args[i])
            i += 1
    return clean, commit_msg, add_to_repo


def _auto_annotate_map_results(output: str) -> int:
    """Parse map output and annotate repo papers with their per-paper answers.

    Returns number of papers annotated.
    """
    active = _get_active_repo_name()
    if not active:
        return 0

    lines = output.split("\n")
    annotated = 0
    i = 0
    while i < len(lines):
        m = _MAP_DOC_ID_RE.match(lines[i])
        if m and m.group(1) == "ok":
            doc_id = m.group(2)
            answer_lines: list[str] = []
            j = i + 1
            while j < len(lines) and lines[j].startswith("    "):
                answer_lines.append(lines[j].strip())
                j += 1
            answer = " ".join(answer_lines)[:300]
            if answer:
                try:
                    from .. import repo

                    repo.annotate_paper(doc_id, answer)
                    annotated += 1
                except Exception:
                    pass
            i = j
        else:
            i += 1
    return annotated


def _repo_commit(message: str, repo_name: str | None = None) -> bool:
    """Commit the active repo with the given message. Returns True on success."""
    try:
        from .. import repo

        repo.commit(message, repo_name=repo_name)
        return True
    except Exception:
        return False


def _repo_add_paper_ids(paper_ids: list[str], note: str | None = None) -> dict:
    """Add papers to the active repo. Returns add result dict."""
    from .. import repo

    result = repo.add_papers(paper_ids)
    if note and result.get("added"):
        for pid in result["added"]:
            try:
                repo.annotate_paper(pid, note)
            except Exception:
                pass
    return result


_FILTERABLE_CMDS = {"search", "sql"}

_SEARCH_FLAGS_WITH_ARG = {
    "-n",
    "--limit",
    "-m",
    "-T",
    "--type",
    "--since",
    "--category",
    "--sort",
    "--tag",
    "--source",
    "-s",
    "--ranking",
    "--journal",
    "--article-type",
    "--atype",
    "--year",
}


def _extract_query_from_raw(raw: str) -> str:
    """Pull the bare query string out of a search args string."""
    try:
        tokens = shlex.split(raw)
    except ValueError:
        return raw.strip()
    parts: list[str] = []
    skip = False
    for tok in tokens:
        if skip:
            skip = False
            continue
        if tok in _SEARCH_FLAGS_WITH_ARG:
            skip = True
            continue
        if tok.startswith("-"):
            continue
        parts.append(tok)
    return " ".join(parts)


def _execute_with_source_filter(command: str, raw: str) -> None:
    """Dispatch a search/sql command, fanning out across selected sources.

    If the user already passed ``-s`` in ``raw`` or no filter is stored,
    this is equivalent to calling ``_execute(command, raw)`` once.
    """
    if command == "search" and not sources_mod._raw_has_source_flag(raw) and not sources_mod._raw_has_vdir_path(raw):
        click.echo(
            "Error: search requires a source flag (-s).\n\n"
            "Available sources:\n"
            "  -s pmc          PubMed Central papers\n"
            "  -s biorxiv      bioRxiv preprints\n"
            "  -s medrxiv      medRxiv preprints\n"
            "  -s arxiv        arXiv preprints\n"
            "  -s abstracts    Abstract-only corpus (broader, no full text)\n"
            "  -s fda          FDA regulatory documents (US)\n"
            "  -s fda/jp       PMDA regulatory documents (Japan)\n"
            "  -s fda/eu       EMA regulatory documents (EU)\n"
            "  -s trials       Clinical trials (all registries)\n"
            "  -s trials/us    ClinicalTrials.gov (US)\n"
            "  -s trials/eu    EU Clinical Trials Register\n"
            "  -s trials/jp    JRCT (Japan)\n"
            "  -s trials/cn    ChiCTR (China)\n"
            "  -s proteins     UniProt + PDB + ChEMBL protein databases\n"
            "  -s uniprot      Alias for -s proteins\n\n"
            "Examples:\n"
            '  paperclip search -s pmc "CRISPR delivery"\n'
            '  paperclip search -s fda "pembrolizumab"\n'
            '  paperclip search -s trials/us "breast cancer HER2"\n',
            err=True,
        )
        raise SystemExit(1)

    selected = sources_mod.get_selected()
    show_abstracts_hint = (
        command == "search" and sources_mod.abstracts_excluded_by_default(selected, raw)
    )
    plan = sources_mod.plan_requests(raw, selected, command=command)

    if len(plan) == 1:
        _, only_raw = plan[0]
        if plan[0][0]:
            only_raw = sources_mod.inject_source_flag(raw, plan[0][0])
        _execute_argv(command, shlex.split(only_raw))
    else:
        for i, (source, base_raw) in enumerate(plan):
            scoped_raw = sources_mod.inject_source_flag(base_raw, source)
            label = source if source else "default"
            click.echo(
                f"{DIM}── source: {BOLD}{label}{RESET}{DIM} ({i + 1}/{len(plan)}) ──{RESET}",
                err=True,
            )
            _execute_argv(command, shlex.split(scoped_raw))

    if show_abstracts_hint:
        query = _extract_query_from_raw(raw)
        hint_cmd = (
            f'paperclip search -s abstracts "{query}"'
            if query
            else "paperclip search -s abstracts ..."
        )
        click.echo(
            f"\n{DIM}Tip: also search the abstract-only corpus (broader coverage, no full text):\n"
            f"  {RESET}{hint_cmd}{RESET}",
            err=True,
        )


# ── SDK client construction ───────────────────────────────────────


_client_singleton: PaperclipClient | None = None


def _build_client() -> PaperclipClient:
    """Construct a :class:`PaperclipClient` from current process state.

    Resolution order:

    1. ``PAPERCLIP_BEARER_TOKEN`` env → :class:`BearerAuth`.
    2. ``--api-key`` / ``PAPERCLIP_API_KEY`` → :class:`APIKeyAuth`.
    3. Otherwise → :class:`FileCredentialsAuth` (after :func:`_ensure_auth`).
    """
    base = _get_base_url()
    ua = f"paperclip/{__version__}"

    bearer = os.getenv("PAPERCLIP_BEARER_TOKEN", "").strip()
    if bearer:
        return PaperclipClient(auth=BearerAuth(bearer), base_url=base, user_agent=ua)

    if _api_key:
        return PaperclipClient(auth=APIKeyAuth(_api_key), base_url=base, user_agent=ua)

    creds = _ensure_auth()

    if creds is not None:
        return PaperclipClient(
            auth=FileCredentialsAuth(credentials=creds), base_url=base, user_agent=ua
        )

    click.echo(f"{RED}[error] No authentication available.{RESET}", err=True)
    sys.exit(1)


def _get_client(*, force_new: bool = False) -> PaperclipClient:
    """Return a cached :class:`PaperclipClient`, rebuilding if requested."""
    global _client_singleton
    if force_new or _client_singleton is None:
        _client_singleton = _build_client()
    return _client_singleton


def _is_refresh_network_error(exc: AuthError) -> bool:
    """Detect the "OAuth refresh hit a network issue" case inside an :class:`AuthError`.

    The CLI previously showed a distinct "Could not reach the server" message
    when refreshing the ID token failed. Preserve that output by sniffing the
    wrapped cause.
    """
    cause = exc.__cause__
    if cause is None:
        return False
    if isinstance(cause, (requests.ConnectionError, requests.Timeout)):
        return True
    msg = str(cause).lower()
    return "reach the server" in msg


# ── Command execution + rendering ─────────────────────────────────


_update_and_skills_checked = False


def _auto_update_and_refresh_skills(*, once: bool = False) -> None:
    """Silent auto-update + skill refresh, matching previous ``_execute`` preamble.

    When ``once=True`` (interactive shell), the check runs only on the first
    call per process so subsequent shell commands don't re-hit the update
    endpoint on every keystroke.
    """
    global _update_and_skills_checked
    if once and _update_and_skills_checked:
        return

    # Under MCP passthrough the executor is a fresh, non-interactive subprocess
    # with a per-session config dir — skip auto-update, skill refresh, and the
    # feature-flag fetch (repos are force-enabled by ``_is_paper_repos_enabled``).
    if _is_mcp_mode():
        _update_and_skills_checked = True
        return

    base = _get_base_url()
    try:
        if auto_update(base):
            _re_exec()
    except Exception:
        pass

    try:
        maybe_refresh_skills(base)
    except Exception:
        pass

    try:
        _fetch_feature_flags()
    except Exception:
        pass

    _update_and_skills_checked = True


def _repo_only_requested(args: list[str]) -> bool:
    """True when repo-scoping is requested via the global flag or inline token."""
    return _repo_only_flag or ("--repo-only" in args)


def _strip_scope_flags(args: list[str]) -> list[str]:
    """Remove --repo-only and --corpus tokens from the arg list."""
    return [a for a in args if a not in ("--repo-only", "--corpus")]


def _augment_search_args_for_repo(args: list[str]) -> list[str]:
    """Inject ``--document-ids`` only when repo-scoping is explicitly requested.

    Default: full corpus. ``--repo-only`` opts in to scoping.
    ``--corpus`` forces full corpus even when ``--repo-only`` is set.
    """
    force_corpus = "--corpus" in args
    repo_only = _repo_only_requested(args)
    args = _strip_scope_flags(args)

    if force_corpus or not repo_only:
        return args

    active = _get_active_repo_name()
    if not active:
        return args

    ids: set[str] = set()

    try:
        from . import repo

        repo_ids = repo.get_repo_paper_ids(active)
        if repo_ids:
            ids.update(repo_ids)
    except Exception:
        pass

    try:
        from . import repo

        ids = repo.get_repo_paper_ids(active)
    except Exception:
        return args

    if not ids:
        return args

    return list(args) + ["--document-ids", ",".join(ids)]


def _augment_map_args_for_repo(args: list[str]) -> list[str]:
    """Inject ``--document-ids`` only when repo-scoping is explicitly requested.

    Default: full corpus. ``--repo-only`` opts in to scoping.
    ``--corpus`` forces full corpus even when ``--repo-only`` is set.
    ``--from`` and explicit ``--document-ids`` also bypass augmentation.
    """
    force_corpus = "--corpus" in args
    repo_only = _repo_only_requested(args)
    args = _strip_scope_flags(args)

    if force_corpus or not repo_only:
        return args

    has_from = False
    has_doc_ids = False
    for a in args:
        if a == "--from":
            has_from = True
        if a in ("--document-ids", "--document_ids"):
            has_doc_ids = True
    if has_from or has_doc_ids:
        return args

    active = _get_active_repo_name()
    if not active:
        return args

    try:
        from . import repo

        ids = repo.get_repo_paper_ids(active)
    except Exception:
        return args

    if not ids:
        return args

    return list(args) + ["--document-ids", ",".join(ids)]


def _prepare_map_worker_args(args: list[str]) -> tuple[list[str], str]:
    """Validate trusted map workers and inject the active exhaustive repo."""
    prepared = _normalize_map_recovery_args(args)
    control_flags = ("--resume", "--retry-failed", "--cancel")

    def has_control_flag() -> bool:
        return any(
            token == flag or token.startswith(f"{flag}=")
            for token in prepared
            for flag in control_flags
        )

    worker = "quick-reader"
    if "--worker" in prepared:
        index = prepared.index("--worker")
        if index + 1 >= len(prepared):
            raise click.UsageError("--worker requires a value")
        worker = prepared[index + 1].strip().lower()
        prepared[index + 1] = worker
    else:
        for index, token in enumerate(prepared):
            if token.startswith("--worker="):
                worker = token.split("=", 1)[1].strip().lower()
                if not worker:
                    raise click.UsageError("--worker requires a value")
                prepared[index] = f"--worker={worker}"
                break
    allowed = {
        "quick-reader",
        "eligibility-screen",
        "structured-extraction",
        "exhaustive-extraction",
    }
    if worker not in allowed:
        raise click.UsageError(
            "unknown map worker; choose quick-reader, eligibility-screen, "
            "structured-extraction, or exhaustive-extraction"
        )
    if "--claim-schema" in prepared:
        index = prepared.index("--claim-schema")
        if index + 1 >= len(prepared):
            raise click.UsageError("--claim-schema requires JSON")
        try:
            schema = json.loads(prepared[index + 1])
        except json.JSONDecodeError as exc:
            raise click.UsageError(f"invalid --claim-schema JSON: {exc}") from exc
        if not isinstance(schema, dict):
            raise click.UsageError("--claim-schema must be a JSON object")
    if worker == "exhaustive-extraction":
        if "--claim-schema" not in prepared and not has_control_flag():
            raise click.UsageError(
                "exhaustive-extraction requires --claim-schema JSON"
            )
        if "--repo" not in prepared:
            active = _get_active_repo_name()
            if active:
                prepared.extend(["--repo", active])
            elif not has_control_flag():
                raise click.UsageError(
                    "exhaustive-extraction requires --repo NAME or an active repo"
                )
    if worker == "structured-extraction" and not has_control_flag():
        if "--output_schema" not in prepared:
            raise click.UsageError("structured-extraction requires --output_schema JSON Schema")
        schema_index = prepared.index("--output_schema")
        if schema_index + 1 >= len(prepared):
            raise click.UsageError("--output_schema requires JSON Schema")
        try:
            output_schema = json.loads(prepared[schema_index + 1])
        except json.JSONDecodeError as exc:
            raise click.UsageError(f"invalid --output_schema JSON: {exc}") from exc
        if not isinstance(output_schema, dict) or not output_schema:
            raise click.UsageError("--output_schema must be a non-empty JSON Schema object")
        if "--claim-schema" in prepared:
            raise click.UsageError(
                "structured-extraction rejects --claim-schema; use only --output_schema"
            )
        if "--repo" in prepared:
            raise click.UsageError("structured-extraction does not persist to repos; remove --repo")
    if worker == "quick-reader" and has_control_flag():
        return prepared, "resume"
    return prepared, worker


def _normalize_map_recovery_args(args: list[str]) -> list[str]:
    """Canonicalize map recovery controls around one ``--resume`` map ID.

    Recovery uses ``--resume MAP_ID [--retry-failed]`` so there is one
    unambiguous map-ID argument.
    """
    prepared: list[str] = []
    resume_id: str | None = None
    retry_failed = False
    index = 0

    def set_resume_id(value: str) -> None:
        nonlocal resume_id
        value = value.strip()
        if not value:
            raise click.UsageError("--resume requires a map ID")
        if resume_id is not None and resume_id != value:
            raise click.UsageError("map recovery accepts only one map ID")
        resume_id = value

    while index < len(args):
        token = args[index]
        if token == "--resume":
            if index + 1 >= len(args):
                raise click.UsageError("--resume requires a map ID")
            set_resume_id(args[index + 1])
            index += 2
            continue
        if token.startswith("--resume="):
            set_resume_id(token.split("=", 1)[1])
            index += 1
            continue
        if token == "--retry-failed":
            if index + 1 < len(args) and args[index + 1].startswith("m_"):
                raise click.UsageError(
                    "use --resume MAP_ID --retry-failed; "
                    "--retry-failed does not accept a map ID"
                )
            retry_failed = True
            index += 1
            continue
        if token.startswith("--retry-failed="):
            raise click.UsageError(
                "use --resume MAP_ID --retry-failed; "
                "--retry-failed does not accept a map ID"
            )
        prepared.append(token)
        index += 1

    if retry_failed and resume_id is None:
        raise click.UsageError("--retry-failed requires --resume MAP_ID")
    if resume_id is not None:
        prepared.extend(["--resume", resume_id])
    if retry_failed:
        prepared.append("--retry-failed")
    return prepared


def _execute_argv(command: str, args: list[str]) -> ExecuteResult | None:
    """Run ``command`` with raw ``args`` and render the response.

    ``args`` is a list of argv tokens, NOT a pre-joined shell string.
    """
    _auto_update_and_refresh_skills()

    # Extract repo flags (--commit, --add) before proxying to server
    args, commit_msg, add_to_repo = _extract_repo_flags(args)

    if command == "map":
        try:
            args, worker = _prepare_map_worker_args(args)
        except click.UsageError as exc:
            click.echo(f"{RED}[error] {exc}{RESET}", err=True)
            sys.exit(2)
        if worker == "structured-extraction" and (commit_msg or add_to_repo):
            click.echo(
                f"{RED}[error] structured-extraction does not support --commit or --add{RESET}",
                err=True,
            )
            sys.exit(2)
        args = _augment_map_args_for_repo(args)
        _render_map(args, commit_msg=commit_msg, worker=worker)
        return

    if command == "search":
        args = _augment_search_args_for_repo(args)
        # Validate --ranking flag
        _VALID_RANKINGS = {"bm25", "vector", "hybrid", "analogical"}
        for i, a in enumerate(args):
            if a == "--ranking" and i + 1 < len(args):
                val = args[i + 1].lower()
                if val not in _VALID_RANKINGS:
                    click.echo(
                        f"{RED}[error] Invalid --ranking '{args[i+1]}'. "
                        f"Must be one of: {', '.join(sorted(_VALID_RANKINGS))}{RESET}",
                        err=True,
                    )
                    sys.exit(1)
                args[i + 1] = val
                break

    client = _get_client()
    result = _execute_with_retry(client, command, args)
    if command == "search-workflow" and result.exit_code != 0:
        detail = result.output or ""
        if "command not found" in detail.lower():
            raise click.ClickException(
                "This Paperclip server does not support YAML search workflows. "
                "Run against the updated local unified stack."
            )
        _render_execute_result(command, args, result)
        raise SystemExit(result.exit_code or 1)
    _render_execute_result(command, args, result)

    # Post-command repo operations for search
    active_repo = _get_active_repo_name()
    if active_repo and command == "search" and result.exit_code == 0:
        if add_to_repo:
            paper_ids = _PAPER_ID_RE.findall(result.output or "")
            if paper_ids:
                try:
                    add_result = _repo_add_paper_ids(paper_ids)
                    n = len(add_result.get("added", []))
                    if n:
                        click.echo(f"{DIM}  auto-added {n} papers to repo{RESET}")
                except Exception:
                    pass

    if commit_msg and active_repo:
        if _repo_commit(commit_msg):
            click.echo(f"{DIM}  committed: {commit_msg}{RESET}")
    return result


def _execute_with_retry(
    client: PaperclipClient, command: str, args: list[str]
) -> ExecuteResult:
    """Call :meth:`PaperclipClient.execute` with CLI error handling.

    Maps SDK exceptions to the exact error strings / exit codes the previous
    ``_execute`` printed, and preserves the OAuth ``401 → re-login → retry``
    dance.

    A 429 (rate limit OR the "too many concurrent long-running commands" cap on
    map/verify/commit) is retried with exponential backoff. This is safe because
    the server rejects on the concurrency gate BEFORE executing the command, so
    a retry never double-runs — it just waits for a slot. Without this, a commit
    that momentarily collided with other verifies would hard-fail and its claims
    would be dropped.
    """
    import time as _time

    def _exec_retry_429(cl: PaperclipClient) -> ExecuteResult:
        attempts = 6
        for i in range(attempts):
            try:
                return cl.execute(command, args=args)
            except RateLimitError as exc:
                if i == attempts - 1:
                    raise
                wait = min(2 * (2 ** i), 30)
                click.echo(
                    f"{YELLOW}[waiting] {exc} Retrying in {wait}s "
                    f"({i + 1}/{attempts - 1})...{RESET}",
                    err=True,
                )
                _time.sleep(wait)
        raise RateLimitError("retry budget exhausted")  # unreachable

    try:
        return _exec_retry_429(client)
    except AuthError as exc:
        if _is_refresh_network_error(exc):
            click.echo(
                f"{RED}[error] Could not reach the server. Please try again.{RESET}",
                err=True,
            )
            sys.exit(1)
        if _api_key:
            click.echo(
                f"{RED}[error] Authentication failed (API key invalid).{RESET}",
                err=True,
            )
            sys.exit(1)
        if _is_mcp_mode():
            # Forwarded credential is invalid/expired. Don't attempt interactive
            # re-login or delete any local credentials in the passthrough.
            click.echo(f"{RED}[error] Authentication failed.{RESET}", err=True)
            sys.exit(1)
        Credentials.delete()
        click.echo(f"{DIM}Session expired — re-authenticating...{RESET}", err=True)
        _ensure_auth()
        click.echo(f"{DIM}Retrying...{RESET}", err=True)
        new_client = _get_client(force_new=True)
        try:
            return _exec_retry_429(new_client)
        except AuthError:
            click.echo(f"{RED}[error] Authentication failed.{RESET}", err=True)
            sys.exit(1)
        except (NetworkError, ServerError, PaperclipError):
            click.echo(
                f"{RED}[error] Something went wrong. Please try again.{RESET}", err=True
            )
            sys.exit(1)
    except RateLimitError as e:
        msg = str(e) if str(e) else "Too many requests. Please wait a moment."
        click.echo(f"{YELLOW}[rate limit] {msg}{RESET}", err=True)
        sys.exit(1)
    except RequestTimeoutError:
        click.echo(f"{RED}[error] Request timed out{RESET}", err=True)
        if command in ("search", "map", "sql", "lookup"):
            click.echo(
                f"{DIM}Try: narrower query, add --since 1y, or --source pmc{RESET}",
                err=True,
            )
        sys.exit(1)
    except NetworkError:
        click.echo(f"{RED}[error] Could not reach the server.{RESET}", err=True)
        click.echo(
            f"{DIM}       If this persists, try: paperclip login{RESET}", err=True
        )
        sys.exit(1)
    except ServerError:
        click.echo(
            f"{RED}[error] Something went wrong. Please try again.{RESET}", err=True
        )
        sys.exit(1)
    except PaperclipError:
        click.echo(
            f"{RED}[error] Something went wrong. Please try again.{RESET}", err=True
        )
        sys.exit(1)


def _strip_response_envelope(text: str) -> tuple[str, bool]:
    """Strip the server-side ResponseManager envelope from large MCP responses.

    The MCP server wraps responses >50KB in a "Large Response Saved" envelope
    with metadata headers and a truncated preview.  The CLI should show the raw
    content instead, since the user (or shell redirect) expects cat-like output.

    Returns (stripped_content, was_truncated).

    Server format::

        🔄 Large Response Saved
        ...metadata lines...
        Preview (first N characters):
        ------------------------------------------------------------
        <content>
        ------------------------------------------------------------
    """
    if "Large Response Saved" not in text:
        return _strip_tool_response_header(text), False

    lines = text.split("\n")

    # Content starts after the first "----…" separator that follows a
    # "Preview (first … characters):" line.
    start = 0
    for i, line in enumerate(lines):
        if re.match(r"^-{20,}$", line.strip()):
            start = i + 1
            break
    else:
        return _strip_tool_response_header(text), False

    # Content ends before the trailing "----…" / "[… content truncated …]" / blank
    end = len(lines)
    truncated = False
    for i in range(len(lines) - 1, start - 1, -1):
        s = lines[i].strip()
        if "content truncated" in s:
            truncated = True
            continue
        if not s or re.match(r"^-{20,}$", s):
            continue
        end = i + 1
        break

    content = "\n".join(lines[start:end]).strip()
    content = content if content else text
    return _strip_tool_response_header(content), truncated


def _strip_tool_response_header(text: str) -> str:
    """Strip the 'Tool Response: …' / 'Generated: …' / '====…' header."""
    if not text.startswith("Tool Response:"):
        return text
    lines = text.split("\n")
    for i, line in enumerate(lines):
        if re.match(r"^={20,}$", line.strip()):
            rest = "\n".join(lines[i + 1 :]).strip()
            return rest if rest else text
    return text


def _render_execute_result(
    command: str, args: list[str], result: ExecuteResult
) -> None:
    """Format an :class:`ExecuteResult` exactly like the pre-SDK CLI did."""
    if result.download_url:
        filename = result.download_filename or "download.bin"
        if not sys.stdout.isatty():
            _stream_binary_to_stdout(result.download_url)
            return
        click.echo(
            f"{DIM}Binary file ({filename}). Redirect to save locally, e.g.:{RESET}"
        )
        raw = _format_argv_for_hint(args)
        click.echo(f"  {command} {raw} > {filename}".rstrip())
        return

    output = result.output or ""

    if _maybe_handle_mcp_binary(output):
        return

    output, was_truncated = _strip_response_envelope(output)

    if output:
        click.echo(output)
        if was_truncated and sys.stdout.isatty():
            raw = _format_argv_for_hint(args)
            click.echo(
                f"\n{DIM}--- truncated (preview only) ---\n"
                f"To save full results:  paperclip {command} {raw} > output.txt{RESET}",
                err=True,
            )

    active_repo = _get_active_repo_name()
    result_id = result.result_id
    if active_repo and command == "search":
        try:
            from . import repo

            repo.record_search(shlex.join(args), result_id)
        except Exception:
            pass

    elapsed = result.elapsed_ms
    tag = _repo_tag()
    footer_parts = []
    if elapsed is not None:
        label = f"{elapsed}ms" if elapsed < 1000 else f"{elapsed / 1000:.1f}s"
        if result_id:
            footer_parts.append(f"{DIM}[{label}, saved to {result_id}]{RESET}")
        else:
            footer_parts.append(f"{DIM}[{label}]{RESET}")
    if tag:
        footer_parts.append(tag)
    if footer_parts:
        # The timing/repo footer is UI chrome, not command output. When stdout
        # is piped (e.g. `paperclip cat meta.json | jq`), send it to stderr so
        # it never corrupts machine-readable output; keep it on stdout only for
        # interactive terminals.
        click.echo("  ".join(footer_parts), err=not sys.stdout.isatty())


def _format_argv_for_hint(args: list[str]) -> str:
    """Reconstruct the original ``raw`` shell string for the redirect hint line."""
    return shlex.join(args) if args else ""


def _maybe_handle_mcp_binary(output: str) -> bool:
    """Detect an MCP-path binary_download JSON payload and stream or hint.

    Returns ``True`` if the payload was handled (caller should not print
    anything else) and ``False`` otherwise.
    """
    stripped = output.strip() if output else ""
    if (
        not stripped
        or '"binary_download"' not in stripped
        or '"download_url"' not in stripped
    ):
        return False
    try:
        payload = json.loads(stripped)
    except json.JSONDecodeError:
        return False
    if not isinstance(payload, dict) or payload.get("type") != "binary_download":
        return False
    url = payload.get("download_url", "")
    fname = payload.get("filename") or "download.bin"
    if url and not sys.stdout.isatty():
        _stream_binary_to_stdout(url)
        return True
    if url:
        click.echo(
            f"{DIM}Binary file ({fname}). Redirect to save locally, e.g.:{RESET}"
        )
        click.echo(f"  paperclip cat <path> > {fname}")
        return True
    return False


def _stream_binary_to_stdout(url: str) -> None:
    """Fetch a signed download URL and stream bytes to stdout.

    Used when the user redirects or pipes binary output, e.g.
        paperclip cat /papers/<id>/figures/fig1.jpg > fig1.jpg

    Error messages are intentionally URL-free: ``requests`` exception strings
    normally embed the full failing URL (including the signature), which
    would then land in terminal recorders, piped logs, CI capture, agent
    transcripts, etc. We strip them down to a status code or a generic
    network error.
    """
    try:
        with requests.get(url, stream=True, timeout=120) as r:
            r.raise_for_status()
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    sys.stdout.buffer.write(chunk)
            sys.stdout.buffer.flush()
    except requests.HTTPError as e:
        status = e.response.status_code if e.response is not None else "?"
        click.echo(
            f"{RED}[error] Download failed (HTTP {status}). "
            f"Re-run the command to get a fresh link.{RESET}",
            err=True,
        )
        sys.exit(1)
    except requests.RequestException:
        click.echo(f"{RED}[error] Download failed (network).{RESET}", err=True)
        sys.exit(1)


def _render_map(
    args: list[str],
    *,
    commit_msg: str | None = None,
    worker: str = "quick-reader",
) -> None:
    """Run a streaming map command and render progress + final result."""
    client = _get_client()
    repo_name = None
    if "--repo" in args:
        repo_index = args.index("--repo")
        if repo_index + 1 < len(args):
            repo_name = args[repo_index + 1]

    def _do_stream(events_iter):
        output = _consume_map_stream(events_iter)
        _post_map_repo_actions(
            output, commit_msg, worker=worker, repo_name=repo_name
        )

    def _run_stream(active_client, stream_args: list[str]) -> None:
        import random as _random
        import time as _time

        for attempt in range(6):
            try:
                _do_stream(active_client.stream("map", stream_args))
                return
            except RateLimitError:
                if attempt == 5:
                    raise
                delay = _random.uniform(0.0, min(30.0, 2.0 * (2**attempt)))
                click.echo(
                    f"{YELLOW}[rate limit] Retrying map in {delay:.1f}s...{RESET}",
                    err=True,
                )
                _time.sleep(delay)

    try:
        stream_args = args
        recovered = False
        while True:
            try:
                _run_stream(client, stream_args)
                break
            except _MapStreamInterrupted as exc:
                if recovered or not exc.run_id:
                    raise
                recovered = True
                stream_args = ["--resume", exc.run_id]
                click.echo(
                    f"{YELLOW}[recovery] Stream interrupted; resuming "
                    f"{exc.run_id}...{RESET}",
                    err=True,
                )
        return
    except _MapStreamInterrupted as exc:
        click.echo(f"{RED}[error] Stream ended without result{RESET}", err=True)
        if exc.run_id:
            click.echo(
                f"{DIM}       Resume later with: paperclip map --resume "
                f"{exc.run_id}{RESET}",
                err=True,
            )
        sys.exit(1)
    except AuthError as exc:
        if _is_refresh_network_error(exc):
            click.echo(
                f"{RED}[error] Could not reach the server. Please try again.{RESET}",
                err=True,
            )
            sys.exit(1)
        if _api_key:
            click.echo(
                f"{RED}[error] Authentication failed (API key invalid).{RESET}",
                err=True,
            )
            sys.exit(1)
        if _is_mcp_mode():
            # Forwarded credential is invalid/expired. Don't attempt interactive
            # re-login or delete any local credentials in the passthrough.
            click.echo(f"{RED}[error] Authentication failed.{RESET}", err=True)
            sys.exit(1)
        Credentials.delete()
        click.echo(f"{DIM}Session expired — re-authenticating...{RESET}", err=True)
        _ensure_auth()
        try:
            retry_client = _get_client(force_new=True)
            _run_stream(retry_client, stream_args)
            return
        except AuthError:
            click.echo(f"{RED}[error] Authentication failed.{RESET}", err=True)
            sys.exit(1)
        except Exception:
            click.echo(
                f"{RED}[error] Something went wrong. Please try again.{RESET}", err=True
            )
            sys.exit(1)
    except RateLimitError as e:
        msg = str(e) if str(e) else "Too many requests. Please wait a moment."
        click.echo(f"{YELLOW}[rate limit] {msg}{RESET}", err=True)
        sys.exit(1)
    except RequestTimeoutError:
        click.echo(f"{RED}[error] Request timed out{RESET}", err=True)
        click.echo(
            f"{DIM}Tip: re-run search with -n 5 to limit papers, then map again.{RESET}",
            err=True,
        )
        sys.exit(1)
    except NetworkError:
        click.echo(f"{RED}[error] Could not reach the server.{RESET}", err=True)
        click.echo(
            f"{DIM}       If this persists, try: paperclip login{RESET}", err=True
        )
        sys.exit(1)
    except (ServerError, PaperclipError):
        click.echo(
            f"{RED}[error] Something went wrong. Please try again.{RESET}", err=True
        )
        sys.exit(1)


class _MapStreamInterrupted(PaperclipError):
    """A map stream ended after exposing a recoverable run ID."""

    def __init__(self, run_id: str | None):
        super().__init__("Map stream ended without a final result")
        self.run_id = run_id


def _consume_map_stream(events) -> str:
    """Drain a map event stream, rendering progress lines and the final result.

    Returns the map output text for downstream processing (auto-annotation).
    """
    wrote_progress = False
    got_result = False
    got_result_id = False
    run_id = None
    output_text = ""
    try:
        for ev in events:
            if isinstance(ev, MapProgressEvent):
                if ev.run_id:
                    run_id = ev.run_id
                # Progress uses carriage-return / clear-line escapes meant for a TTY.
                # Suppress it under MCP passthrough so it doesn't pollute the output.
                if _is_mcp_mode():
                    continue
                bar = _progress_bar(ev.completed + ev.failed, ev.total)
                status = f"{DIM}  {bar}  {ev.completed + ev.failed}/{ev.total} papers"
                if ev.run_id:
                    status += f"  run {ev.run_id}"
                if ev.failed:
                    status += f" ({ev.failed} failed)"
                status += f"  [{ev.elapsed_s:g}s]{RESET}"
                click.echo(f"{CLR}\r{status}", nl=False, err=True)
                wrote_progress = True
            elif isinstance(ev, MapResultEvent):
                if wrote_progress:
                    click.echo("", err=True)
                if ev.output:
                    click.echo(ev.output)
                    output_text = ev.output
                if ev.elapsed_ms is not None:
                    label = (
                        f"{ev.elapsed_ms}ms"
                        if ev.elapsed_ms < 1000
                        else f"{ev.elapsed_ms / 1000:.1f}s"
                    )
                    if ev.result_id:
                        click.echo(f"{DIM}[{label}, saved to {ev.result_id}]{RESET}")
                    else:
                        click.echo(f"{DIM}[{label}]{RESET}")
                got_result = True
                got_result_id = bool(ev.result_id)
                if ev.exit_code != 0:
                    sys.exit(1)
    except (NetworkError, RequestTimeoutError) as exc:
        if wrote_progress:
            click.echo("", err=True)
        raise _MapStreamInterrupted(run_id) from exc

    if not got_result or (not output_text.strip() and not got_result_id):
        if wrote_progress:
            click.echo("", err=True)
        raise _MapStreamInterrupted(run_id)

    return output_text


def _post_map_repo_actions(
    output: str,
    commit_msg: str | None,
    *,
    worker: str = "quick-reader",
    repo_name: str | None = None,
) -> None:
    """Auto-annotate papers from map results and optionally commit."""
    active = repo_name or _get_active_repo_name()
    if not active:
        return
    n = (
        0
        if worker
        in {
            "exhaustive-extraction",
            "structured-extraction",
            "resume",
        }
        else _auto_annotate_map_results(output)
    )
    if worker == "structured-extraction":
        return
    if n:
        click.echo(f"{DIM}  auto-annotated {n} papers from map results{RESET}")
    if commit_msg:
        if _repo_commit(commit_msg, repo_name=active):
            click.echo(f"{DIM}  committed: {commit_msg}{RESET}")


def _progress_bar(done: int, total: int, width: int = 20) -> str:
    if total <= 0:
        return "[" + "." * width + "]"
    filled = int(width * done / total)
    return "[" + "#" * filled + "." * (width - filled) + "]"


# ── Dashboard ─────────────────────────────────────────────────────


def _check_update_hint(base: str) -> str | None:
    """Return an update hint string if a newer version is available, else None.

    Uses a cached, non-blocking check so the dashboard stays fast.
    """
    try:
        latest = check_update_available(base)
        if latest:
            return latest
    except Exception:
        pass
    return None


def _show_dashboard():
    """Show status, recent results, and quick-start hints."""
    creds = Credentials.load()
    base = _get_base_url()

    click.echo()
    click.echo(f"  {BOLD}Paperclip{RESET} v{__version__}")
    rule = "\u2500" * 40
    click.echo(f"  {DIM}{rule}{RESET}")

    if _is_local_server():
        click.echo(f"  {GREEN}\u2713{RESET} Local dev server")
        click.echo(f"  {DIM}Server: {base}{RESET}")
        active = _get_active_repo_name()
        if active:
            repo_detail = ""
            try:
                from . import repo

                s = repo.get_status()
                if s and s.get("paper_count") is not None:
                    repo_detail = f" {DIM}({s['paper_count']} papers, {s.get('active_branch', 'main')}){RESET}"
            except Exception:
                pass
            click.echo(f"  {GREEN}●{RESET} Repo: {BOLD}{active}{RESET}{repo_detail}")
    elif creds:
        click.echo(f"  {GREEN}\u2713{RESET} Signed in as {BOLD}{creds.email}{RESET}")
        click.echo(f"  {DIM}Server: {base}{RESET}")
        active = _get_active_repo_name()
        if active:
            repo_detail = ""
            try:
                from . import repo

                s = repo.get_status()
                if s and s.get("paper_count") is not None:
                    repo_detail = f" {DIM}({s['paper_count']} papers, {s.get('active_branch', 'main')}){RESET}"
            except Exception:
                pass
            click.echo(f"  {GREEN}●{RESET} Repo: {BOLD}{active}{RESET}{repo_detail}")
        if _is_paper_repos_enabled():
            try:
                from . import repo as repo_mod

                lib_info = repo_mod.library_get_info()
                if lib_info and lib_info["total"] > 0:
                    click.echo(
                        f"  {DIM}📚 Library: {lib_info['total']} papers ({lib_info['matched']} matched){RESET}"
                    )
            except Exception:
                pass
    else:
        click.echo(f"  {DIM}\u2717 Not signed in{RESET}")
        click.echo(f"  {DIM}Run any command to sign in automatically.{RESET}")
        click.echo()
        click.echo(f"  {BOLD}Try:{RESET}")
        click.echo('    paperclip search -s pmc "protein design"')
        click.echo()
        return

    try:
        client = _get_client()
        rows = client.results.list(limit=5, timeout=5)
        if rows:
            click.echo()
            click.echo(f"  {BOLD}Recent searches{RESET}")
            for r in rows:
                rid = r.result_id or "?"
                raw = r.raw_input or r.command or ""
                if len(raw) > 55:
                    raw = raw[:52] + "..."
                click.echo(f"    {CYAN}{rid}{RESET}  {raw}")
            click.echo(
                f"  {DIM}Run {RESET}{DIM}{BOLD}paperclip results{RESET}{DIM} to export searches{RESET}"  # noqa: E501
            )
    except Exception:
        pass

    click.echo()
    click.echo(
        f'    {CYAN}search{RESET}    Find papers/docs     paperclip search -s pmc "CRISPR delivery"'
    )
    click.echo(
        f"    {CYAN}lookup{RESET}    Find by metadata     paperclip lookup doi 10.1101/..."
    )
    click.echo(
        f'    {CYAN}grep{RESET}      Regex search         paperclip grep "kinase" /papers/<id>/content.lines'  # noqa: E501
    )
    click.echo(
        f'    {CYAN}sql{RESET}       Query database       paperclip sql "SELECT title FROM documents ..."'  # noqa: E501
    )
    click.echo(
        f"    {CYAN}cat{RESET}       Read file            paperclip cat /papers/<id>/meta.json"
    )
    click.echo(
        f"    {CYAN}head{RESET}      Preview file         paperclip head -50 /papers/<id>/content.lines"  # noqa: E501
    )
    click.echo(
        f"    {CYAN}ls{RESET}        List files           paperclip ls /papers/<id>/sections/"
    )
    click.echo(
        f'    {CYAN}scan{RESET}      Multi-keyword find   paperclip scan /papers/<id>/content.lines "p53" "MDM2"'  # noqa: E501
    )
    click.echo(
        f'    {CYAN}map{RESET}       Summarize papers     paperclip map "What methods were used?"'
    )
    click.echo(
        f'    {CYAN}ask-image{RESET} Analyze figures      paperclip ask-image /papers/<id>/figures/fig1.jpg "Describe"'  # noqa: E501
    )

    click.echo()
    click.echo(
        f"  {DIM}Specify source with{RESET} -s <source> {DIM}(e.g.{RESET} -s pmc{DIM},{RESET} -s fda{DIM},{RESET} -s trials/us{DIM}){RESET}"
    )

    latest = _check_update_hint(base)
    if latest:
        click.echo()
        click.echo(
            f"  {YELLOW}Update available: v{latest}{RESET}  {DIM}(run: paperclip update){RESET}"
        )

    click.echo()


# ── Click group with pass-through catch-all ───────────────────────


_PASSTHROUGH = dict(
    ignore_unknown_options=True,
    allow_extra_args=True,
    help_option_names=[],
)


def _execute_search_config(args: list[str]) -> bool:
    """Execute ``search --config`` locally; return whether it was handled."""
    config_path: str | None = None
    parameter_overrides: list[str] = []
    input_overrides: list[str] = []
    save_as: str | None = None
    unexpected: list[str] = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--config":
            if i + 1 >= len(args):
                raise click.UsageError("--config requires a YAML file path")
            config_path = args[i + 1]
            i += 2
        elif arg.startswith("--config="):
            config_path = arg.split("=", 1)[1]
            i += 1
        elif arg in ("--set", "--input"):
            if i + 1 >= len(args):
                raise click.UsageError(f"{arg} requires NAME=VALUE")
            (parameter_overrides if arg == "--set" else input_overrides).append(
                args[i + 1]
            )
            i += 2
        elif arg.startswith("--set="):
            parameter_overrides.append(arg.split("=", 1)[1])
            i += 1
        elif arg.startswith("--input="):
            input_overrides.append(arg.split("=", 1)[1])
            i += 1
        elif arg == "--save-as":
            if i + 1 >= len(args):
                raise click.UsageError("--save-as requires an alias")
            save_as = args[i + 1]
            i += 2
        elif arg.startswith("--save-as="):
            save_as = arg.split("=", 1)[1]
            i += 1
        else:
            unexpected.append(arg)
            i += 1
    if config_path is None:
        return False
    if unexpected:
        raise click.UsageError(
            "--config cannot be combined with a query or ordinary search options: "
            + " ".join(unexpected)
        )
    from .search_config import SearchConfigError, load_search_config

    try:
        spec = load_search_config(
            config_path,
            parameter_overrides=tuple(parameter_overrides),
            input_overrides=tuple(input_overrides),
        )
    except SearchConfigError as exc:
        raise click.UsageError(str(exc)) from exc
    payload = json.dumps(spec, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    encoded = base64.urlsafe_b64encode(payload).decode("ascii")
    workflow_args = ["--spec", encoded]
    if save_as:
        workflow_args.extend(["--save-as", save_as])
    _execute_argv("search-workflow", workflow_args)
    return True


class _PaperclipGroup(click.Group):
    """Catch-all group that forwards unknown commands to the server.

    Unregistered subcommands (search, lookup, sql, grep, cat, head, ls, scan,
    bash, pull, ask-image, python, map, etc.) are sent as-is to
    :func:`_execute_argv`, which dispatches to the SDK.
    """

    def get_command(self, ctx: click.Context, cmd_name: str):
        # "repos" is an alias for "repo" (the docs and blog use both forms).
        # Normalize before the feature gate so the alias is gated identically.
        if cmd_name == "repos":
            cmd_name = "repo"
        if cmd_name in _REPO_COMMANDS and not _is_paper_repos_enabled():
            # When the user has turned repos off locally, show a clear
            # "disabled" message. (A server-side flag still falls through to
            # the historical bash-proxy behavior.)
            if not config.repos_enabled():
                return self._make_repos_disabled_cmd(cmd_name)
            return self._make_bash_proxy(cmd_name)
        rv = super().get_command(ctx, cmd_name)
        if rv is not None:
            return rv
        return self._make_bash_proxy(cmd_name)

    @staticmethod
    def _make_repos_disabled_cmd(cmd_name: str) -> click.Command:
        @click.command(
            cmd_name,
            context_settings=_PASSTHROUGH,
            help=f"'{cmd_name}' is unavailable — paper repositories are disabled.",
        )
        @click.argument("args", nargs=-1, type=click.UNPROCESSED)
        def disabled(args: tuple) -> None:
            click.echo(
                f"{YELLOW}Paper repositories are disabled.{RESET} "
                f"The {BOLD}{cmd_name}{RESET} command is unavailable.",
                err=True,
            )
            click.echo(
                f"{DIM}Run {RESET}{BOLD}paperclip repos-feature enable{RESET}"
                f"{DIM} to turn the feature back on.{RESET}",
                err=True,
            )
            raise SystemExit(2)

        return disabled

    @staticmethod
    def _make_bash_proxy(cmd_name: str) -> click.Command:
        @click.command(
            cmd_name,
            context_settings=_PASSTHROUGH,
            help=f"Run '{cmd_name}' on the paper filesystem.",
        )
        @click.argument("args", nargs=-1, type=click.UNPROCESSED)
        @click.pass_context
        def proxy(ctx, args: tuple) -> None:
            global _api_key

            filtered_args: list[str] = []
            i = 0
            while i < len(args):
                if args[i] == "--api-key" and i + 1 < len(args):
                    _api_key = args[i + 1]
                    i += 2
                elif args[i].startswith("--api-key="):
                    _api_key = args[i].split("=", 1)[1]
                    i += 1
                else:
                    filtered_args.append(args[i])
                    i += 1

            active = _get_active_repo_name()

            if cmd_name == "search" and _execute_search_config(filtered_args):
                return

            if active and cmd_name in ("cat", "head", "tail", "grep", "scan", "bash"):
                joined = shlex.join(filtered_args)
                ids_in_cmd = _PAPER_ID_RE.findall(joined)
                if ids_in_cmd:
                    try:
                        from . import repo

                        repo_ids = set(repo.get_repo_paper_ids())
                        outside = [pid for pid in ids_in_cmd if pid not in repo_ids]
                        if outside:
                            click.echo(
                                f"{DIM}(note: {', '.join(outside)} not in repo '{active}'){RESET}",
                                err=True,
                            )
                    except Exception:
                        pass

            if cmd_name in _FILTERABLE_CMDS:
                raw = shlex.join(filtered_args)
                _execute_with_source_filter(cmd_name, raw)
            else:
                _execute_argv(cmd_name, filtered_args)

        return proxy

    def resolve_command(self, ctx: click.Context, args):
        cmd_name = args[0] if args else None
        if cmd_name and not cmd_name.startswith("-"):
            cmd = self.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd_name, cmd, args[1:]
        return super().resolve_command(ctx, args)

    def invoke(self, ctx):
        if ctx.invoked_subcommand in ("config", "login"):
            if _api_key:
                click.echo(
                    f"{RED}[error] --api-key is not allowed for '{ctx.invoked_subcommand}' command{RESET}",  # noqa: E501
                    err=True,
                )
                sys.exit(1)
        return super().invoke(ctx)


@click.group(cls=_PaperclipGroup, invoke_without_command=True)
@click.version_option(package_name="gxl-paperclip")
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.option("--repo-only", "repo_only", is_flag=True, help="Restrict search/map to the active repo's papers (default: full corpus)")
@click.option(
    "--repo",
    "repo_name",
    default=None,
    help="Use this repo (without changing sticky state)",
)
@click.option(
    "--api-key",
    callback=_set_api_key,
    expose_value=False,
    help=(
        "API key for authentication (alternative to OAuth). "
        "Can also be set via PAPERCLIP_API_KEY env var."
    ),
    envvar="PAPERCLIP_API_KEY",
)
@click.pass_context
def main(ctx, debug: bool, repo_only: bool, repo_name: str | None):
    """Paperclip — search biomedical papers, regulatory documents, and clinical trials from the command line.

    \b
    Quick start:
        paperclip search -s pmc "protein design"
        paperclip search -s pmc,biorxiv,medrxiv "protein design"
        paperclip search -s fda "DeepHealth 510k"
        paperclip search -s trials/us "HER2 breast cancer"
        paperclip search -s pmc --min-embedding-similarity 0.7 --min-bm25-score 5 "protein design"
        paperclip cat /papers/bio_dca47d15/meta.json
        paperclip cat /fda/<uuid>/meta.json

    \b
    Search requires -s/--source. Common sources:
        pmc, biorxiv, medrxiv, arxiv, abstracts
        fda, fda/jp, fda/eu
        trials, trials/us, trials/eu, trials/jp, trials/cn
        proteins
    Combine sources with commas, for example: -s pmc,biorxiv,medrxiv

    \b
    Paper repos (persistent, sticky):
        paperclip repo init my-topic "Description"
        paperclip repo checkout my-topic           # all subsequent commands scoped here
        paperclip search -s pmc "query"             # search all PMC (record search in active repo)
        paperclip --repo-only search -s pmc "query" # restrict search to repo papers
        paperclip repo add PMC123 bio_456

    Sign-in happens automatically on first use.
    Use --api-key or set PAPERCLIP_API_KEY env var for non-interactive authentication.
    Run `paperclip skill` for the full command and filesystem guide.
    """
    level = logging.DEBUG if debug else logging.WARNING
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")

    ctx.ensure_object(dict)
    ctx.obj["repo_only"] = repo_only

    if _is_mcp_mode() and ctx.invoked_subcommand in MCP_DISABLED_COMMANDS:
        click.echo(
            f"{RED}[error] '{ctx.invoked_subcommand}' is not available over MCP. "
            f"Run it from the paperclip CLI on your own machine.{RESET}",
            err=True,
        )
        sys.exit(2)

    global _repo_only_flag
    _repo_only_flag = repo_only

    if repo_name and _is_paper_repos_enabled():
        repo_name = repo_name.strip().replace(" ", "-").lower()
        try:
            from . import repo

            m = repo._load_manifest(repo_name)
            if m is None:
                click.echo(
                    f"{RED}[error] Repo '{repo_name}' not found.{RESET}", err=True
                )
                sys.exit(1)
            repo.set_repo_override(repo_name)
        except Exception as e:
            click.echo(f"{RED}[error] {e}{RESET}", err=True)
            sys.exit(1)

    if ctx.invoked_subcommand is None:
        _show_dashboard()


# ── login (local) ─────────────────────────────────────────────────


@main.command()
@click.option(
    "--no-install", is_flag=True, hidden=True, help="Skip skill install prompt"
)
def login(no_install: bool):
    """Sign in to Paperclip via browser."""
    base = _get_base_url()
    creds = run_login(base_url=base)

    click.echo(f"\n{GREEN}✓{RESET} Authenticated as {BOLD}{creds.email}{RESET}")
    click.echo(f"  Server: {base}")

    if not no_install:
        _maybe_install_skill(base)


# ── logout (local) ────────────────────────────────────────────────


@main.command()
def logout():
    """Sign out and remove stored credentials."""
    config_removed = False
    creds_removed = False

    if config.CONFIG_FILE.exists():
        config.CONFIG_FILE.unlink()
        config_removed = True
    if Credentials.delete():
        creds_removed = True

    if config_removed or creds_removed:
        click.echo("Logged out. Credentials removed.")
    else:
        click.echo("No credentials found.")


# ── config (local) ────────────────────────────────────────────────


@main.command("config")
@click.option("--url", help="Set server base URL (e.g. http://localhost:8002)")
@click.option("--show", is_flag=True, help="Show current configuration")
@click.option(
    "--sources",
    "sources_args",
    multiple=True,
    help="Set source filter (e.g. --sources pmc --sources fda)",
)
@click.option("--sources-list", is_flag=True, help="Show current source filter")
@click.option("--sources-clear", is_flag=True, help="Remove source filter")
def config_cmd(
    url: str | None,
    show: bool,
    sources_args: tuple,
    sources_list: bool,
    sources_clear: bool,
):
    """Configure Paperclip settings and show connection diagnostics.

    \b
    Examples:
        paperclip config                          # show diagnostics
        paperclip config --url http://localhost:8002
        paperclip config --sources pmc --sources fda
        paperclip config --sources-list
        paperclip config --sources-clear
    """
    from . import repo as repo_mod

    if sources_clear:
        sources_mod.print_status()
        return

    if sources_list:
        sources_mod.print_status()
        return

    if sources_args:
        sources_mod.print_status()
        return

    state = _load_state()

    if url and not show:
        state["base_url"] = url.rstrip("/")
        state.pop("mcp_url", None)
        _save_state(state)
        click.echo(f"{GREEN}✓{RESET} Server URL set: {url}")
        return

    base = _get_base_url()
    click.echo(f"\n  {BOLD}Paperclip{RESET}")
    click.echo(f"  Server:  {base}")
    if "base_url" not in state and "mcp_url" not in state:
        click.echo(f"           {YELLOW}(default){RESET}")
    creds = Credentials.load()
    api_key = state.get("api_key")
    env_bearer = os.getenv("PAPERCLIP_BEARER_TOKEN", "").strip()
    env_api_key = os.getenv("PAPERCLIP_API_KEY", "").strip()
    if env_bearer:
        click.echo(f"  Auth:    {GREEN}✓{RESET} bearer token (env)")
    elif env_api_key:
        click.echo(f"  Auth:    {GREEN}✓{RESET} API key (env)")
    elif api_key:
        click.echo(f"  Auth:    {GREEN}✓{RESET} API key")
    elif creds:
        click.echo(f"  Auth:    {GREEN}✓{RESET} {creds.email}")
    else:
        click.echo(f"  Auth:    {YELLOW}✗{RESET} (run: paperclip login)")
    click.echo(f"  Config:  {config.PAPERCLIP_DIR}")

    try:
        resp = requests.get(f"{base}/health", timeout=3)
        if resp.ok:
            click.echo(f"  Health:  {GREEN}✓{RESET} server reachable")
        else:
            click.echo(f"  Health:  {RED}✗{RESET} {resp.status_code}")
    except Exception:
        click.echo(f"  Health:  {RED}✗{RESET} unreachable")

    selected = sources_mod.get_selected()
    if selected:
        click.echo(f"  Sources: {sources_mod.describe(selected)}")
    else:
        click.echo(f"  Sources: {DIM}all (no filter){RESET}")

    click.echo()


# ── install (local) ───────────────────────────────────────────────


@main.command()
@click.option("--dir", "target_dir", default=".", help="Project directory")
def install(target_dir: str):
    """Install Paperclip skill for Claude Code or Codex."""
    install_skill(_get_base_url(), target_dir)


@main.command()
def skill():
    """Print the full Paperclip documentation (load this before doing any work).

    The installed agent skill and the MCP instructions are lightweight
    pointers; this command returns the full ground-truth documentation:
    filesystem layout, command reference, workflows, citation format, and
    SQL schemas.
    """
    _skills_system_impl()


# ── repos feature toggle (local) ──────────────────────────────────


def _print_repos_status() -> None:
    enabled = config.repos_enabled()
    if enabled:
        click.echo(f"  Paper repositories: {GREEN}enabled{RESET}")
        click.echo(f"  {DIM}Disable with: paperclip repos-feature disable{RESET}")
    else:
        click.echo(f"  Paper repositories: {YELLOW}disabled{RESET}")
        click.echo(f"  {DIM}Enable with:  paperclip repos-feature enable{RESET}")


@main.group("repos-feature", invoke_without_command=True)
@click.pass_context
def repos_feature_cmd(ctx):
    """Enable or disable the paper-repositories feature.

    \b
    When disabled, the repo commands (init, add, commit, branch,
    merge, repo status/log/history, verified citations) are turned off and
    those sections are stripped from the installed coding-agent skill so it
    won't try to use them.

    \b
    Examples:
        paperclip repos-feature              # show current setting
        paperclip repos-feature disable      # turn the feature off
        paperclip repos-feature enable       # turn it back on
    """
    if ctx.invoked_subcommand is None:
        _print_repos_status()


@repos_feature_cmd.command("disable")
def repos_feature_disable():
    """Turn off paper repositories and strip them from the agent skill."""
    config.set_repos_enabled(False)
    click.echo(f"{GREEN}\u2713{RESET} Paper repositories disabled.")
    try:
        apply_repos_preference(_get_base_url(), enabled=False)
    except Exception:
        pass
    click.echo(
        f"  {DIM}Repo commands are now unavailable and the installed skill "
        f"no longer references them.{RESET}"
    )


@repos_feature_cmd.command("enable")
def repos_feature_enable():
    """Turn paper repositories back on and restore them in the agent skill."""
    config.set_repos_enabled(True)
    click.echo(f"{GREEN}\u2713{RESET} Paper repositories enabled.")
    try:
        apply_repos_preference(_get_base_url(), enabled=True)
    except Exception:
        pass


@repos_feature_cmd.command("status")
def repos_feature_status():
    """Show whether the paper-repositories feature is enabled."""
    _print_repos_status()


# ── skills group ─────────────────────────────────────────────────


@main.group(invoke_without_command=True)
@click.pass_context
def skills(ctx):
    """Browse, search, and load Paperclip skills.

    \b
    Run without a subcommand to list all available skills:
        paperclip skills

    \b
    Subcommands:
        paperclip skills list                  List all available skills
        paperclip skills search "query"        Search for a skill by keyword
        paperclip skills show <name>           Show a skill's full instructions
        paperclip skills system                Print the core system prompt
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(skills_list)


def _fetch_skills_index() -> list[dict]:
    base = _get_skills_url()
    try:
        resp = requests.get(f"{base}/skills/skills/index.json", timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception:
        click.echo("Failed to fetch skills index from server.", err=True)
        raise SystemExit(1)


@skills.command("list")
def skills_list():
    """List all available skills grouped by domain."""
    index = _fetch_skills_index()
    if not index:
        click.echo("No skills available.")
        return

    by_domain: dict[str, list[dict]] = {}
    for s in index:
        by_domain.setdefault(s["domain_label"], []).append(s)

    for domain_label, domain_skills in by_domain.items():
        click.echo(f"\n  {BOLD}{domain_label}{RESET}")
        for s in domain_skills:
            name = s["name"]
            desc = s.get("description", "")
            if len(desc) > 80:
                desc = desc[:77] + "..."
            click.echo(f"    {CYAN}{name:<30}{RESET} {DIM}{desc}{RESET}")

    click.echo(f"\n  {DIM}Use `paperclip skills show <name>` to view full instructions.{RESET}")
    click.echo(f"  {DIM}Use `paperclip skills search \"query\"` to find skills by keyword.{RESET}\n")


@skills.command("search")
@click.argument("query")
def skills_search(query: str):
    """Search skills by keyword matching against name, description, and triggers."""
    index = _fetch_skills_index()
    if not index:
        click.echo("No skills available.")
        return

    query_lower = query.lower()
    query_terms = query_lower.split()

    scored: list[tuple[int, dict]] = []
    for s in index:
        searchable = " ".join([
            s.get("name", ""),
            s.get("description", ""),
            s.get("triggers", ""),
            s.get("domain_label", ""),
        ]).lower()
        score = sum(1 for term in query_terms if term in searchable)
        if score > 0:
            scored.append((score, s))

    scored.sort(key=lambda x: x[0], reverse=True)

    if not scored:
        click.echo(f"  No skills matching \"{query}\".")
        click.echo(f"\n  {DIM}Run `paperclip skills list` to see all available skills.{RESET}")
        return

    click.echo(f"\n  {BOLD}Skills matching \"{query}\":{RESET}\n")
    for _score, s in scored:
        name = s["name"]
        desc = s.get("description", "")
        domain = s.get("domain_label", "")
        if len(desc) > 70:
            desc = desc[:67] + "..."
        click.echo(f"    {CYAN}{name:<30}{RESET} {DIM}[{domain}]{RESET}")
        if desc:
            click.echo(f"      {desc}")

    click.echo(f"\n  {DIM}Use `paperclip skills show <name>` to view full instructions.{RESET}\n")


@skills.command("show")
@click.argument("name")
def skills_show(name: str):
    """Show a skill's full instructions."""
    name = name.removesuffix(".md")
    if (
        not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_./-]*", name)
        or any(part in {"", ".", ".."} for part in name.split("/"))
    ):
        raise click.UsageError("invalid skill path")
    base = _get_skills_url()
    try:
        resp = requests.get(f"{base}/skills/skills/{name}.md", timeout=10)
        resp.raise_for_status()
        click.echo(resp.text)
    except requests.exceptions.HTTPError as e:
        if e.response is not None and e.response.status_code == 404:
            click.echo(f"  {RED}Skill \"{name}\" not found.{RESET}", err=True)
            click.echo(f"\n  {DIM}Run `paperclip skills list` to see available skills.{RESET}")
        else:
            click.echo(f"  {RED}Failed to fetch skill: {e}{RESET}", err=True)
        raise SystemExit(1)
    except Exception:
        click.echo("Failed to fetch skill from server.", err=True)
        raise SystemExit(1)


def _skills_system_impl():
    """Shared implementation for `skills system` and deprecated `skill`."""
    from .skill import fetch_full_skill

    content = fetch_full_skill(_get_skills_url())
    if content is None:
        click.echo("Failed to fetch skill documentation from server.", err=True)
        raise SystemExit(1)
    click.echo(content)


@skills.command("system")
def skills_system():
    """Print the full Paperclip system prompt.

    Outputs the canonical skill.md to stdout. Intended for agents to read
    before making tool calls, but also useful as a human-readable reference.
    """
    _skills_system_impl()


# ── sources (local) ───────────────────────────────────────────────


@main.command(hidden=True)
@click.option(
    "--list", "list_only", is_flag=True, help="Print the active source filter and exit."
)
@click.option(
    "--clear", "clear_only", is_flag=True, help="Remove the active source filter."
)
@click.argument("keys", nargs=-1)
def sources(list_only: bool, clear_only: bool, keys: tuple[str, ...]):
    """Select which data sources to search over.

    \b
    Deprecated: use `paperclip config --sources` instead.
    """
    sources_mod.run_selector()


# ── setup (local) ────────────────────────────────────────────────


@main.command()
@click.option(
    "--dir", "target_dir", default=".", help="Project directory for skill files"
)
def setup(target_dir: str):
    """Sign in and install agent skills (for pip/uv installs).

    \b
    Combines `paperclip login` + `paperclip install` into one step.
    Use this after installing via pip or uv:
        pip install https://paperclip.gxl.ai/paperclip.whl
        paperclip setup
    """
    base = _get_base_url()

    creds = Credentials.load()
    if creds:
        click.echo(f"{GREEN}✓{RESET} Already signed in as {BOLD}{creds.email}{RESET}")
    else:
        creds = run_login(base_url=base)
        click.echo(f"\n{GREEN}✓{RESET} Authenticated as {BOLD}{creds.email}{RESET}")

    click.echo()
    install_skill(base, target_dir)


# ── update (local) ───────────────────────────────────────────────


@main.command()
def update():
    """Update Paperclip to the latest version and refresh agent skills."""
    base = _get_base_url()
    click.echo(f"  {DIM}Current version: {__version__}{RESET}")
    click.echo(f"  {DIM}Checking for updates...{RESET}")

    latest = fetch_latest_version(base)
    if latest is None:
        click.echo(
            f"  {DIM}Could not check for binary updates (server unreachable).{RESET}"
        )
    elif not needs_update(latest):
        click.echo(f"  {GREEN}✓{RESET} Already up to date (v{__version__})")
    else:
        click.echo(f"  {BOLD}New version available: v{latest}{RESET}")

        if not is_managed_install():
            click.echo(
                f"\n  {YELLOW}Paperclip was not installed via the standard installer.{RESET}"
            )
            click.echo("  To update, re-run the installer:")
            click.echo(f"    {BOLD}curl -fsSL {base}/install.sh | bash{RESET}")
        else:
            click.echo(f"  {DIM}Downloading...{RESET}")
            ok, msg = perform_update(base)
            if ok:
                click.echo(f"\n  {GREEN}✓{RESET} Updated to v{msg}")
                click.echo(
                    f"  {DIM}Restart your shell or run a new command to use the new version.{RESET}"
                )
            else:
                click.echo(f"\n  {RED}Update failed: {msg}{RESET}")
                click.echo(f"  {DIM}You can update manually:{RESET}")
                click.echo(f"    {BOLD}curl -fsSL {base}/install.sh | bash{RESET}")

    click.echo(f"\n  {DIM}Refreshing agent skills...{RESET}")
    find_and_refresh_all_skills(base)


# ── uninstall (local) ─────────────────────────────────────────────


@main.command()
@click.option(
    "--keep-credentials",
    is_flag=True,
    help="Keep credentials (only remove binary + skills)",
)
def uninstall(keep_credentials: bool):
    """Remove Paperclip from this machine."""
    removed = []
    bin_path = Path.home() / ".local" / "bin" / "paperclip"
    install_dir = config.PAPERCLIP_DIR

    if bin_path.exists():
        bin_path.unlink()
        removed.append(str(bin_path))

    if install_dir.exists():
        if keep_credentials:
            lib_dir = install_dir / "lib"
            if lib_dir.exists():
                shutil.rmtree(lib_dir)
                removed.append(str(lib_dir))
        else:
            shutil.rmtree(install_dir)
            removed.append(str(install_dir))

    cwd = Path.cwd()
    skill_dirs = [
        cwd / ".claude" / "skills" / "paperclip",
        cwd / ".cursor" / "skills" / "paperclip",
        cwd / ".agents" / "skills" / "paperclip",
    ]
    for d in skill_dirs:
        if d.exists():
            shutil.rmtree(d)
            removed.append(str(d))

    if removed:
        click.echo(f"{GREEN}✓{RESET} Removed:")
        for r in removed:
            click.echo(f"    {r}")
        click.echo(
            f"\n  {DIM}To reinstall: curl -fsSL https://paperclip.gxl.ai/install.sh | bash{RESET}"
        )
    else:
        click.echo("Nothing to remove — Paperclip doesn't appear to be installed.")


# ── Paper Repo Commands (local) ──────────────────────────────────


@main.group("repo", invoke_without_command=True)
@click.option("-n", "limit", type=int, default=10, help="Number of repos to show (default 10, 0 = all).")
@click.pass_context
def repo_cmd(ctx, limit):
    """List repos or show repo details.

    \b
    Examples:
        paperclip repo                  # list 10 most recent repos
        paperclip repo -n 0             # list all repos
        paperclip repo info <name>      # overview of a specific repo
        paperclip repo status           # current papers, claims, [OK]/[X]
        paperclip repo claims           # claims as JSON (with doc_id + line pins)
        paperclip repo log              # commit history
        paperclip repo history          # command audit trail
    """
    if ctx.invoked_subcommand is not None:
        return

    from datetime import datetime, timezone

    from . import repo

    try:
        repos = repo.list_repos()
        if not repos:
            click.echo(
                f"{DIM}No repos. Create one with: paperclip repo init <name>{RESET}"
            )
            return
        active = repo.get_active_repo()

        def _parse_date(r):
            raw = r.get("created_at", "")
            if not raw:
                return datetime.min.replace(tzinfo=timezone.utc)
            try:
                return datetime.fromisoformat(raw.replace("Z", "+00:00"))
            except (ValueError, TypeError):
                return datetime.min.replace(tzinfo=timezone.utc)

        repos.sort(key=_parse_date, reverse=True)

        active_repo = None
        rest = []
        for r in repos:
            if r["name"] == active:
                active_repo = r
            else:
                rest.append(r)

        if limit > 0:
            rest = rest[: limit - (1 if active_repo else 0)]

        ordered = ([active_repo] if active_repo else []) + rest
        total = len(repos)

        shown = len(ordered)
        header = f"\n  {BOLD}Paper Repos{RESET} ({shown}"
        if shown < total:
            header += f" of {total}, use -n 0 for all"
        header += ")\n"
        click.echo(header)

        now = datetime.now(timezone.utc)
        for r in ordered:
            marker = f"{GREEN}●{RESET}" if r["name"] == active else f"{DIM}○{RESET}"
            papers = f"{DIM}({r['paper_count']} papers){RESET}"
            dt = _parse_date(r)
            if dt == datetime.min.replace(tzinfo=timezone.utc):
                date_str = ""
            else:
                delta = now - dt
                if delta.days == 0:
                    date_str = f"{DIM}today{RESET}"
                elif delta.days == 1:
                    date_str = f"{DIM}yesterday{RESET}"
                elif delta.days < 7:
                    date_str = f"{DIM}{delta.days}d ago{RESET}"
                else:
                    date_str = f"{DIM}{dt.strftime('%b %d')}{RESET}"
            desc = f"  {DIM}{r['description'][:50]}{RESET}" if r.get("description") else ""
            click.echo(f"    {marker} {r['name']}  {papers}  {date_str}{desc}")
        click.echo(f"\n  {DIM}Switch: paperclip repo checkout <name>{RESET}\n")
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)


@repo_cmd.command("init")
@click.argument("name")
@click.argument("description", required=False, default="")
@click.option(
    "--from-library",
    "from_library",
    is_flag=True,
    help="Seed repo with matched papers from your library",
)
@click.option(
    "-s",
    "--search",
    "lib_query",
    default=None,
    help="Filter library papers by keyword (with --from-library)",
)
def init_cmd(name: str, description: str, from_library: bool, lib_query: str | None):
    """Create a new paper repo.

    \b
    Examples:
        paperclip repo init kras-resistance "KRAS G12C resistance mechanisms"
        paperclip repo init my-review
        paperclip repo init lit-review --from-library            # seed with all library papers
        paperclip repo init subset --from-library -s "CRISPR"    # seed with matching library papers
    """
    from . import repo

    try:
        m = repo.init_repo(name, description)
        click.echo(f"{GREEN}✓{RESET} Created repo: {BOLD}{m['name']}{RESET}")
        if description:
            click.echo(f"  {DIM}{description}{RESET}")

        if from_library:
            papers = repo.library_get_papers()
            if not papers:
                click.echo(f"  {DIM}Library is empty — nothing to seed.{RESET}")
            else:
                corpus_papers = {
                    pid: p for pid, p in papers.items() if not pid.startswith("ref_")
                }
                if lib_query:
                    q = lib_query.lower()
                    corpus_papers = {
                        pid: p
                        for pid, p in corpus_papers.items()
                        if q in (p.get("title", "") or "").lower()
                        or q in (p.get("authors", "") or "").lower()
                        or q in (p.get("journal", "") or "").lower()
                    }
                if corpus_papers:
                    titles = {
                        pid: p["title"]
                        for pid, p in corpus_papers.items()
                        if p.get("title")
                    }
                    dois = {
                        pid: p["doi"]
                        for pid, p in corpus_papers.items()
                        if p.get("doi")
                    }
                    result = repo.add_papers(
                        list(corpus_papers.keys()), titles=titles, dois=dois
                    )
                    meta = {}
                    for pid, p in corpus_papers.items():
                        m = {}
                        for k in (
                            "authors",
                            "journal",
                            "year",
                            "pub_year",
                            "cited_by_count",
                            "entry_key",
                            "source",
                        ):
                            if p.get(k):
                                m[k] = p[k]
                        if m:
                            meta[pid] = m
                    if meta:
                        repo.update_paper_metadata(meta)
                    click.echo(
                        f"  {GREEN}+{RESET} Added {len(result['added'])} papers from library"
                    )
                else:
                    filter_msg = f' matching "{lib_query}"' if lib_query else ""
                    click.echo(f"  {DIM}No matched library papers{filter_msg}.{RESET}")
        else:
            click.echo(f"  {DIM}Add papers: paperclip repo add PMC123 bio_456{RESET}")
            click.echo(f"  {DIM}Or from library: paperclip repo add --from-library{RESET}")
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)
    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


@repo_cmd.command("info")
@click.argument("name")
def repo_info_cmd(name: str):
    """Show details of a specific repo."""
    from . import repo

    try:
        info = repo.get_repo_info(name.strip().replace(" ", "-").lower())
        if info is None:
            click.echo(f"{RED}[error] Repo '{name}' not found.{RESET}", err=True)
            sys.exit(1)

        active = repo.get_active_repo()
        _render_repo_detail(info, active)
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)




def _repo_picker(repos: list[dict], active: str | None) -> int | None:
    """Interactive picker for repos. Returns selected index or None."""
    if not sys.stdin.isatty():
        click.echo(f"\n  {BOLD}Paper Repos{RESET} ({len(repos)})\n")
        for r in repos:
            marker = f"{GREEN}●{RESET}" if r["name"] == active else f"{DIM}○{RESET}"
            click.echo(
                f"  {marker} {BOLD}{r['name']}{RESET}  {DIM}({r['paper_count']} papers){RESET}"
            )
            if r["description"]:
                click.echo(f"    {DIM}{r['description']}{RESET}")
        click.echo()
        return None

    try:
        import termios
        import tty
    except (ImportError, AttributeError):
        return None

    n = len(repos)
    idx = 0
    for i, r in enumerate(repos):
        if r["name"] == active:
            idx = i
            break

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)

    def render(first: bool = False) -> None:
        import shutil

        cols = shutil.get_terminal_size((80, 24)).columns

        if not first:
            sys.stdout.write(f"\033[{n}A\r")
        for i, r in enumerate(repos):
            marker = f"{GREEN}●{RESET}" if r["name"] == active else f"{DIM}○{RESET}"
            papers = f"({r['paper_count']} papers)"
            name = r["name"]
            if i == idx:
                prefix = f"  › "
                # visible: prefix + "○ " + name + "  " + papers + "  " + desc
                used = len(prefix) + 2 + len(name) + 2 + len(papers)
            else:
                prefix = f"    "
                used = len(prefix) + 2 + len(name) + 2 + len(papers)

            desc_text = r.get("description") or ""
            if desc_text:
                max_desc = cols - used - 4
                if max_desc > 10:
                    desc_text = desc_text[:max_desc]
                    desc = f"  {DIM}{desc_text}{RESET}"
                else:
                    desc = ""
            else:
                desc = ""

            papers_fmt = f"{DIM}{papers}{RESET}"
            if i == idx:
                sys.stdout.write(
                    f"{CLR}  {CYAN}› {RESET}{marker} {BOLD}{name}{RESET}  {papers_fmt}{desc}\n"
                )
            else:
                sys.stdout.write(f"{CLR}    {marker} {name}  {papers_fmt}{desc}\n")
        sys.stdout.write(f"{CLR}  {DIM}↑/↓ navigate · enter select · q quit{RESET}")
        sys.stdout.flush()

    click.echo(f"\n  {BOLD}Paper Repos{RESET} ({n})\n")
    render(first=True)

    try:
        tty.setcbreak(fd)
        while True:
            ch = os.read(fd, 1)
            if ch == b"\x1b":
                b = os.read(fd, 1)
                if b == b"[":
                    arrow = os.read(fd, 1)
                    if arrow == b"A":
                        idx = (idx - 1) % n
                    elif arrow == b"B":
                        idx = (idx + 1) % n
                render()
            elif ch in (b"\r", b"\n"):
                sys.stdout.write("\n\n")
                sys.stdout.flush()
                return idx
            elif ch in (b"q", b"\x03"):
                sys.stdout.write("\n")
                sys.stdout.flush()
                return None
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _repo_claim_stats(info: dict, active: str | None) -> dict:
    """Summarize a repo's claims using repo-native, domain-agnostic terms.

    The paper repo is general-purpose: papers hold *claims* (annotations), each
    verified against cited lines on commit. This reports totals plus the
    verification breakdown ([OK]/[X]/[?]) and — data-driven, no hardcoded
    vocabulary — the distribution of any `type` field the claims carry, so a
    caller can see how many of each kind exist without the repo knowing what
    those kinds mean. (The meta-analysis skill maps its "effect size" onto a
    claim of type "effect"; that mapping lives in the skill, not here.)
    """
    import json as _json
    from collections import Counter

    total_claims = 0
    by_type: Counter = Counter()
    verified = failed = errored = unverified = 0

    verification: dict = {}
    if active and info.get("name") == active:
        try:
            from . import repo as _repo

            verification = (
                _repo.load_server_verification(active)
                or _repo.load_verification(active)
                or {}
            )
        except Exception:
            verification = {}

    for pid, pinfo in (info.get("papers") or {}).items():
        anns = pinfo.get("annotations") or []
        vlist = verification.get(pid) or []
        if isinstance(vlist, dict):
            vlist = [vlist]
        by_id = {
            str(v.get("claim_id")): v
            for v in vlist
            if isinstance(v, dict) and v.get("claim_id")
        }
        for i, a in enumerate(anns):
            total_claims += 1
            note = (a.get("note") or "").strip()
            if note.startswith("{"):
                try:
                    t = _json.loads(note).get("type")
                    if t:
                        by_type[str(t)] += 1
                except Exception:
                    pass
            claim_id = _stable_claim_id(pid, note, a)
            verdict = by_id.get(claim_id)
            if verdict is None and i < len(vlist):
                candidate = vlist[i]
                if isinstance(candidate, dict) and candidate.get("claim") == note:
                    verdict = candidate
            if verdict is not None:
                supported = verdict.get("supported")
                if supported is True:
                    verified += 1
                elif supported is None:
                    errored += 1
                else:
                    failed += 1
            else:
                unverified += 1

    return {
        "total_claims": total_claims,
        "by_type": dict(by_type),
        "verified": verified,
        "failed": failed,
        "errored": errored,
        "unverified": unverified,
        "has_verification": bool(verification),
    }


def _render_repo_detail(info: dict, active: str | None) -> None:
    """Render the full detail view for a repo."""
    marker = f"{GREEN}●{RESET} " if info["name"] == active else ""
    click.echo(f"\n  {marker}{BOLD}{info['name']}{RESET}")
    if info["description"]:
        click.echo(f"  {DIM}{info['description']}{RESET}")

    bd = _repo_claim_stats(info, active)
    stats = [
        f"{info['paper_count']} papers",
        f"{info['commit_count']} commits",
        f"{bd['total_claims']} claims",
    ]
    if info["branch_count"] > 1:
        stats.append(
            f"{info['branch_count']} branches (active: {info['active_branch']})"
        )
    else:
        stats.append(f"branch: {info['active_branch']}")
    click.echo(f"  {DIM}{' · '.join(stats)}{RESET}")

    # Verification breakdown — repo-native progress signal (from the last
    # commit's per-claim verification). Domain-agnostic: works for any repo.
    if bd["total_claims"]:
        if bd["has_verification"]:
            vparts = [f"{GREEN}{bd['verified']} verified [OK]{RESET}"]
            if bd["failed"]:
                vparts.append(f"{RED}{bd['failed']} failed [X]{RESET}")
            if bd["errored"]:
                vparts.append(f"{YELLOW}{bd['errored']} errored [!]{RESET}")
            if bd["unverified"]:
                vparts.append(f"{DIM}{bd['unverified']} unverified [?]{RESET}")
            click.echo(f"  {DIM}claims: {' · '.join(vparts)}{RESET}")
        else:
            click.echo(
                f"  {DIM}claims: {bd['unverified']} not yet verified "
                f"— run `paperclip repo commit` to verify{RESET}"
            )
        # Data-driven claim-type distribution (whatever `type` values the
        # claims carry; the repo does not assign meaning to them).
        if bd["by_type"]:
            parts = ", ".join(f"{v} {k}" for k, v in sorted(bd["by_type"].items(), key=lambda kv: -kv[1]))
            click.echo(f"  {DIM}by type: {parts}{RESET}")

    if info.get("created_at"):
        created = info["created_at"][:16].replace("T", " ")
        all_ts = [info["created_at"]]
        for pinfo in info.get("papers", {}).values():
            if pinfo.get("added_at"):
                all_ts.append(pinfo["added_at"])
            for a in pinfo.get("annotations", []):
                if a.get("ts"):
                    all_ts.append(a["ts"])
        for srch in info.get("searches", []):
            if srch.get("timestamp"):
                all_ts.append(srch["timestamp"])
        last = max(all_ts)[:16].replace("T", " ")
        if last != created:
            click.echo(f"  {DIM}Created: {created} · Last activity: {last}{RESET}")
        else:
            click.echo(f"  {DIM}Created: {created}{RESET}")

    rule = f"  {DIM}{'─' * 50}{RESET}"

    # ── Commits ──
    commits = info.get("commits", [])
    if commits:
        click.echo(f"\n  {BOLD}Commits{RESET} ({len(commits)})")
        click.echo(rule)
        for c in reversed(commits[-10:]):
            sha = c.get("sha", "?")[:8]
            msg = c.get("message", "")
            ts = c.get("timestamp", "")[:16].replace("T", " ")
            added = c.get("added", [])
            removed = c.get("removed", [])
            delta_parts = []
            if added:
                delta_parts.append(f"{GREEN}+{len(added)}{RESET}")
            if removed:
                delta_parts.append(f"{RED}-{len(removed)}{RESET}")
            delta = f" ({', '.join(delta_parts)})" if delta_parts else ""
            click.echo(f"    {YELLOW}{sha}{RESET}  {msg}{delta}  {DIM}{ts}{RESET}")

    # ── Papers with notes ──
    papers = info.get("papers", {})
    if papers:
        annotated = {pid: p for pid, p in papers.items() if p.get("annotations")}
        matched_count = sum(1 for pid in papers if not pid.startswith("ref_"))
        total_count = len(papers)

        if matched_count < total_count:
            click.echo(
                f"\n  {BOLD}Papers{RESET} ({GREEN}{matched_count}{RESET}/{total_count} linked)"
            )
        else:
            click.echo(f"\n  {BOLD}Papers{RESET} ({total_count})")
        click.echo(rule)

        # Show annotated papers first
        if annotated:
            for pid, pinfo in list(annotated.items())[:15]:
                _render_paper_line(pid, pinfo)
            remaining_annotated = len(annotated) - 15
            if remaining_annotated > 0:
                click.echo(
                    f"    {DIM}... and {remaining_annotated} more with notes{RESET}"
                )

        # Show remaining papers (no notes) as a compact count
        unannotated_count = total_count - len(annotated)
        if unannotated_count > 0 and annotated:
            click.echo(
                f"    {DIM}+ {unannotated_count} more papers without notes{RESET}"
            )
        elif not annotated:
            for pid, pinfo in list(papers.items())[:15]:
                _render_paper_line(pid, pinfo)
            if total_count > 15:
                click.echo(f"    {DIM}... and {total_count - 15} more{RESET}")

    # ── Recent searches ──
    searches = info.get("searches", [])
    if searches:
        recent = searches[-5:]
        click.echo(f"\n  {BOLD}Recent searches{RESET} ({len(searches)} total)")
        click.echo(rule)
        for srch in recent:
            q = srch.get("query", "")
            rid = srch.get("result_id", "")
            ts = srch.get("timestamp", "")[:10]
            rid_str = f" → {CYAN}{rid}{RESET}" if rid else ""
            click.echo(f"    {DIM}{ts}{RESET}  {q}{rid_str}")

    if info["name"] != active:
        click.echo(f"\n  {DIM}Use: paperclip repo checkout {info['name']}{RESET}")
    click.echo()


def _render_paper_line(pid: str, pinfo: dict) -> None:
    """Render a single paper line in repo detail view."""
    title = pinfo.get("title", "")
    authors = pinfo.get("authors", "")
    year = pinfo.get("pub_year") or pinfo.get("year")
    added_at = pinfo.get("added_at", "")
    cites = pinfo.get("cited_by_count")
    is_ref = pid.startswith("ref_")
    marker = f"{DIM}○{RESET}" if is_ref else f"{GREEN}✓{RESET}"
    line = f"    {marker} {CYAN}{pid}{RESET}"
    if title:
        line += f"  {title[:40]}"
    # Add author (first author + et al.)
    if authors:
        first_author = authors.split(",")[0].strip().split()[-1]
        author_str = f"{first_author} et al." if "," in authors else first_author
        line += f"  {DIM}·{RESET} {author_str}"
    # Add year
    if year:
        line += f" {DIM}({year}){RESET}"
    # Add added date
    if added_at:
        date_str = added_at[:10] if isinstance(added_at, str) else str(added_at)[:10]
        line += f"  {DIM}· added {date_str}{RESET}"
    tags = []
    anns = pinfo.get("annotations", [])
    if anns:
        tags.append(f"{len(anns)} note{'s' if len(anns) != 1 else ''}")
    if cites:
        tags.append(f"{cites} cites")
    if tags:
        line += f"  {DIM}[{', '.join(tags)}]{RESET}"
    click.echo(line)
    for a in anns[-2:]:
        loc = f" {a['lines']}" if a.get("lines") else ""
        click.echo(f"      {DIM}↳{loc} {a['note'][:60]}{RESET}")


@main.command("library")
@click.argument("paper_id", required=False, default=None)
@click.option(
    "--matched", is_flag=True, help="Show only matched (corpus-linked) papers"
)
@click.option("--unmatched", is_flag=True, help="Show only unmatched papers")
@click.option(
    "--rematch", is_flag=True, help="Re-run corpus matching on unmatched entries"
)
@click.option("--remove", is_flag=True, help="Remove a paper from the library")
@click.option(
    "-s",
    "--search",
    "query",
    default=None,
    help="Search library by keyword (title, authors, journal)",
)
def library_cmd(
    paper_id: str | None,
    matched: bool,
    unmatched: bool,
    rematch: bool,
    remove: bool,
    query: str | None,
):
    """View your personal paper library, or details for a single paper.

    \b
    The library stores every paper you've imported (from .bib/.ris files
    or paper references). Papers matched to the corpus show ✓; unmatched
    entries show ○ with their bib metadata preserved.

    \b
    Examples:
        paperclip library                     # show all imported papers
        paperclip library ref_abd3ed48        # view a specific paper's details
        paperclip library PMC11166971         # view a matched paper
        paperclip library --matched           # only corpus-linked papers
        paperclip library --unmatched         # only unmatched bib entries
        paperclip library -s "fine-tuning"    # search library by keyword
        paperclip library --rematch           # retry matching unmatched entries
        paperclip library --remove PMC123456  # remove a paper from the library
    """  # noqa: D301 — click needs \b for formatting
    if not _is_library_enabled():
        click.echo(f"{RED}[error] Library is not available yet.{RESET}", err=True)
        sys.exit(1)
    from . import repo

    if rematch:
        _library_rematch()
        return

    if remove:
        if not paper_id:
            click.echo(
                f"\n  {RED}Specify a paper ID to remove: paperclip library --remove <paper_id>{RESET}"
            )
            click.echo()
            return
        removed = repo.library_remove_papers([paper_id])
        if removed:
            click.echo(
                f"\n  {GREEN}✓{RESET} Removed {CYAN}{paper_id}{RESET} from library"
            )
        else:
            click.echo(f"\n  {DIM}Paper {paper_id} not found in library.{RESET}")
        click.echo()
        return

    if paper_id:
        _library_show_paper(paper_id)
        return

    info = repo.library_get_info()
    if info is None or info["total"] == 0:
        click.echo(f"\n  {DIM}Your library is empty.{RESET}")
        click.echo(f"  {DIM}Import papers: paperclip import refs.bib{RESET}")
        click.echo()
        return

    click.echo(f"\n  {BOLD}Personal Library{RESET}")
    click.echo(
        f"  {GREEN}{info['matched']}{RESET} matched · "
        f"{DIM}{info['unmatched']}{RESET} unmatched · "
        f"{info['total']} total"
    )

    papers = info.get("papers", {})
    if not papers:
        click.echo()
        return

    if matched:
        papers = {pid: p for pid, p in papers.items() if not pid.startswith("ref_")}
    elif unmatched:
        papers = {pid: p for pid, p in papers.items() if pid.startswith("ref_")}

    if query:
        q = query.lower()
        papers = {
            pid: p
            for pid, p in papers.items()
            if q in (p.get("title") or "").lower()
            or q in (p.get("authors") or "").lower()
            or q in (p.get("journal") or "").lower()
            or q in pid.lower()
        }
        if not papers:
            click.echo(f'\n  {DIM}No results for "{query}" in library.{RESET}')
            click.echo()
            return
        click.echo(f'  {DIM}Search: "{query}" → {len(papers)} results{RESET}')

    if not papers:
        label = "matched" if matched else "unmatched"
        click.echo(f"\n  {DIM}No {label} papers in library.{RESET}")
        click.echo()
        return

    click.echo()
    for i, (pid, pinfo) in enumerate(list(papers.items())[:30], 1):
        title = pinfo.get("title", "")
        authors = pinfo.get("authors", "")
        year = pinfo.get("pub_year") or pinfo.get("year") or ""
        journal = pinfo.get("journal", "")
        doi = pinfo.get("doi", "")
        is_ref = pid.startswith("ref_")
        marker = f"{DIM}○{RESET}" if is_ref else f"{GREEN}✓{RESET}"

        # First-author et al. format
        author_short = ""
        if authors:
            parts = [a.strip() for a in authors.split(" and ")]
            last = (
                parts[0].split(",")[0].strip()
                if "," in parts[0]
                else parts[0].split()[-1]
            )
            if len(parts) > 2:
                author_short = f"{last} et al."
            elif len(parts) == 2:
                last2 = (
                    parts[1].split(",")[0].strip()
                    if "," in parts[1]
                    else parts[1].split()[-1]
                )
                author_short = f"{last} & {last2}"
            else:
                author_short = last

        # "Rafailov et al. (2024). Direct preference optimization... Journal."
        ref_line = f"  {marker} "
        if author_short:
            ref_line += f"{author_short}"
            if year:
                ref_line += f" ({year})"
            ref_line += ". "
        elif year:
            ref_line += f"({year}) "
        if title:
            ref_line += f"{BOLD}{title}{RESET}"
        if journal:
            ref_line += f". {DIM}{journal}{RESET}"
        click.echo(ref_line)
        click.echo(
            f"    {CYAN}{pid}{RESET}" + (f"  {DIM}doi:{doi}{RESET}" if doi else "")
        )

    if len(papers) > 30:
        click.echo(f"\n  {DIM}... and {len(papers) - 30} more{RESET}")

    if info["unmatched"] > 0:
        click.echo(f"\n  {DIM}Re-run matching: paperclip library --rematch{RESET}")
    click.echo()
    if _is_paper_repos_enabled():
        click.echo(f"  {DIM}Add to repo:     paperclip repo add --from-library{RESET}")
        click.echo(f"  {DIM}New repo:        paperclip repo init <name> --from-library{RESET}")
    click.echo()


def _library_show_paper(paper_id: str):
    """Show full details for a single library paper."""
    from . import repo

    papers = repo.library_get_papers()

    # Support prefix matching for ref_ IDs
    info = papers.get(paper_id)
    resolved_id = paper_id
    if info is None:
        candidates = [pid for pid in papers if pid.startswith(paper_id)]
        if len(candidates) == 1:
            resolved_id = candidates[0]
            info = papers[resolved_id]
        elif len(candidates) > 1:
            click.echo(
                f"{YELLOW}Ambiguous — matches {len(candidates)} entries:{RESET}",
                err=True,
            )
            for c in candidates[:5]:
                click.echo(f"  {CYAN}{c}{RESET}  {papers[c].get('title', '')[:50]}")
            return
        else:
            click.echo(
                f"{RED}[error] '{paper_id}' not found in library.{RESET}", err=True
            )
            return

    is_ref = resolved_id.startswith("ref_")
    marker = f"{DIM}○ unmatched{RESET}" if is_ref else f"{GREEN}✓ corpus-linked{RESET}"

    click.echo(f"\n  {BOLD}{info.get('title') or resolved_id}{RESET}")
    click.echo(f"  {marker}")
    click.echo()

    fields = [
        ("ID", resolved_id),
        ("Authors", info.get("authors", "")),
        ("Journal", info.get("journal", "")),
        ("Year", str(info.get("pub_year") or info.get("year") or "")),
        ("DOI", info.get("doi", "")),
        ("Citations", info.get("cited_by_count", "")),
        ("Cite key", info.get("entry_key", "")),
        ("Source", info.get("import_source", "")),
        ("Added", (info.get("added_at") or "")[:16].replace("T", " ")),
    ]
    for label, value in fields:
        if value:
            val_str = str(value)
            if label == "DOI":
                val_str = f"{val_str}  {DIM}(https://doi.org/{val_str}){RESET}"
            click.echo(f"  {BOLD}{label}:{RESET}  {val_str}")

    if not is_ref:
        click.echo(
            f"\n  {DIM}Full text: paperclip cat /papers/{resolved_id}/meta.json{RESET}"
        )
        click.echo(
            f"  {DIM}Read:      paperclip head -50 /papers/{resolved_id}/content.lines{RESET}"
        )
    click.echo()


def _library_rematch():
    """Re-run corpus matching on unmatched library entries."""
    from . import repo
    from ._citations import match_bib_entries_in_corpus

    papers = repo.library_get_papers()
    unmatched = {pid: p for pid, p in papers.items() if pid.startswith("ref_")}

    if not unmatched:
        click.echo(f"\n  {DIM}No unmatched entries to re-match.{RESET}")
        click.echo()
        return

    click.echo(f"\n  {BOLD}Re-matching {len(unmatched)} unmatched entries...{RESET}\n")

    entries = []
    for pid, pinfo in unmatched.items():
        entries.append(
            {
                "title": pinfo.get("title", ""),
                "doi": pinfo.get("doi", ""),
                "authors": pinfo.get("authors", ""),
                "journal": pinfo.get("journal", ""),
                "year": pinfo.get("year") or pinfo.get("pub_year", ""),
                "entry_key": pinfo.get("entry_key", ""),
                "_original_ref_id": pid,
            }
        )

    def _on_progress(done: int, total: int, phase: str):
        click.echo(f"  {DIM}  Matching: {done}/{total} ({phase}){RESET}", err=True)

    try:
        results = match_bib_entries_in_corpus(entries, on_progress=_on_progress)
    except Exception as e:
        click.echo(f"{RED}[error] Matching failed: {e}{RESET}", err=True)
        return

    newly_matched = [e for e in results if e.get("corpus_id")]
    if not newly_matched:
        click.echo(f"\n  {DIM}No new matches found.{RESET}")
        click.echo()
        return

    new_ids = []
    new_titles: dict[str, str] = {}
    new_dois: dict[str, str] = {}
    new_meta: dict[str, dict] = {}
    old_ref_ids = []

    for e in newly_matched:
        cid = e["corpus_id"]
        old_ref = e.get("_original_ref_id", "")
        new_ids.append(cid)
        if e.get("title"):
            new_titles[cid] = e["title"]
        if e.get("doi"):
            new_dois[cid] = e["doi"]
        if old_ref:
            old_ref_ids.append(old_ref)
            old_info = unmatched.get(old_ref, {})
            new_meta[cid] = {
                "authors": e.get("authors") or old_info.get("authors", ""),
                "journal": e.get("journal") or old_info.get("journal", ""),
                "year": e.get("year")
                or old_info.get("year")
                or old_info.get("pub_year", ""),
                "entry_key": e.get("entry_key") or old_info.get("entry_key", ""),
                "source": "bib_import",
            }
        click.echo(
            f"  {GREEN}✓{RESET} {DIM}{old_ref}{RESET} → {CYAN}{cid}{RESET}  {e.get('title', '')[:50]}"
        )

    repo.library_add_papers(new_ids, titles=new_titles, dois=new_dois)
    if new_meta:
        repo.library_update_metadata(new_ids, new_meta)
    if old_ref_ids:
        repo.library_remove_papers(old_ref_ids)

    click.echo(
        f"\n  {GREEN}✓{RESET} Matched {len(newly_matched)} papers (replaced ref_ IDs with corpus IDs)"
    )
    click.echo()


@repo_cmd.command("checkout")
@click.argument("name", required=True)
def checkout_cmd(name: str):
    """Switch to a paper repo, or deactivate with '-'.

    \b
    Examples:
        paperclip repo checkout kras-resistance   # activate repo
        paperclip repo checkout -                 # deactivate (back to global)
        paperclip repo checkout main              # switch to branch (if active repo has it)
    """
    from . import repo

    if name == "-":
        repo.set_active_repo(None)
        click.echo(
            f"{GREEN}✓{RESET} Deactivated repo. Commands now run against the full corpus."
        )
        return

    # Try switching branch first if there's an active repo
    active = repo.get_active_repo()
    if active:
        branches = repo.list_branches()
        branch_names = {b["name"] for b in branches}
        if name in branch_names:
            try:
                result = repo.switch_branch(name)
                click.echo(
                    f"{GREEN}●{RESET} Switched to branch: {BOLD}{result['branch']}{RESET} ({result['paper_count']} papers)"
                )
            except ValueError as e:
                click.echo(f"{RED}[error] {e}{RESET}", err=True)
                sys.exit(1)
            return

    # Otherwise switch repo
    try:
        doc = repo.checkout_repo(name)
        branch = doc.get("active_branch", "main")
        bd = doc.get("branches", {}).get(branch, {})
        n = len(bd.get("papers", {}))
        click.echo(
            f"{GREEN}●{RESET} Active repo: {BOLD}{doc.get('name', name)}{RESET} ({n} papers, branch: {branch})"
        )
        click.echo(
            f"  {DIM}All commands now tagged here. Use --repo-only to restrict search/map.{RESET}"
        )
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)
    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


def _validate_structured_claim(body: str) -> dict:
    """Validate a ``--json`` claim body and return the parsed object.

    Domain-agnostic contract for a structured claim: it must be a JSON object
    carrying a non-empty string ``type`` (the discriminator ``repo claims
    --type`` and downstream compile steps filter on). This intentionally does
    NOT inspect any type-specific fields (e.g. ``effect_size``) — enforcing the
    per-type schema is the caller's/skill's job. Raises ``ValueError`` with a
    human-readable reason on any violation so callers can fail loud.
    """
    import json as _json

    try:
        obj = _json.loads(body)
    except _json.JSONDecodeError as exc:
        raise ValueError(f"not valid JSON ({exc})")
    if not isinstance(obj, dict):
        raise ValueError(f"must be a JSON object, got {type(obj).__name__}")
    t = obj.get("type")
    if not isinstance(t, str) or not t.strip():
        raise ValueError('missing required non-empty string field "type"')
    return obj


@repo_cmd.command("add")
@click.argument("paper_ids", nargs=-1, required=False)
@click.option(
    "--lines",
    "lines",
    default=None,
    help="Line range hint for claim verification (e.g. L45-L52).",
)
@click.option(
    "--commit",
    "commit_msg",
    default=None,
    help="Auto-commit after adding papers, with this message.",
)
@click.option(
    "--repo",
    "inline_repo",
    default=None,
    hidden=True,
    help="Alias for global --repo flag (agents sometimes put --repo after add)",
)
@click.option(
    "--from-library",
    "from_library",
    is_flag=True,
    help="Add matched papers from your library to the active repo",
)
@click.option(
    "-s",
    "--search",
    "lib_query",
    default=None,
    help="Filter library papers by keyword (with --from-library)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help=(
        "Treat the claim as a structured JSON object and validate it before "
        "storing (must be a JSON object with a non-empty string 'type'). "
        "Fails loudly on malformed JSON instead of storing an unusable claim."
    ),
)
def add_cmd(
    paper_ids: tuple,
    lines: str | None,
    commit_msg: str | None,
    inline_repo: str | None,
    from_library: bool,
    lib_query: str | None,
    as_json: bool,
):
    """Add papers to the active repo, optionally with a verifiable claim.

    \b
    Examples:
        paperclip repo add PMC123 bio_456
        paperclip repo add PMC123 "Hypertonic saline reduces cold duration by 1.9 days"
        paperclip repo add PMC123 "Saline shortens URTI by 1.5 days" --lines L45-L52
        paperclip repo add PMC123 --json '{"type":"effect","effect_id":"PMC123#orr","effect_size":0.74}' --lines L45
        paperclip repo add PMC123
        paperclip repo add --from-library
        paperclip repo add --from-library -s "proteomics"

    \b
    When a claim string is provided after the paper ID, it is stored as an
    annotation to be verified on commit. A paper can have multiple claims
    (call add multiple times with the same ID and different claims).
    """
    from . import repo

    if inline_repo:
        repo.set_repo_override(inline_repo)
        try:
            repo.checkout_repo(inline_repo)
        except ValueError:
            pass

    if not repo.get_active_repo():
        click.echo(
            f"{RED}[error] No repo selected. Pass --repo <name> (or export PAPERCLIP_REPO=<name>); create one with: paperclip repo init <name>{RESET}", err=True
        )
        sys.exit(1)

    if from_library:
        _add_from_library(lib_query)
        return

    if not paper_ids:
        click.echo(
            f"{RED}[error] Provide paper IDs or use --from-library{RESET}", err=True
        )
        sys.exit(1)

    # Separate paper IDs from an inline claim string.
    # Convention: first arg(s) that look like paper IDs (start with PMC, bio_, med_,
    # arx_, fda_, tri_, or match known patterns) are IDs; the remaining trailing
    # argument is treated as a claim.
    ids: list[str] = []
    claim: str | None = None
    for arg in paper_ids:
        if claim is not None:
            claim += " " + arg
        elif _looks_like_paper_id(arg):
            ids.append(arg)
        else:
            claim = arg

    if not ids:
        click.echo(
            f"{RED}[error] No valid paper IDs found in arguments.{RESET}", err=True
        )
        sys.exit(1)

    # --json: validate the claim body up front so a malformed structured claim
    # fails loudly at collection instead of being silently dropped downstream
    # (an unstructured claim verifies fine but is never compiled/pooled).
    if as_json:
        if not claim:
            click.echo(
                f"{RED}[error] --json requires a claim body after the paper id, "
                f"e.g. paperclip repo add {ids[0]} --json '{{\"type\":\"effect\",...}}'{RESET}",
                err=True,
            )
            sys.exit(1)
        try:
            _validate_structured_claim(claim)
        except ValueError as exc:
            click.echo(
                f"{RED}[error] --json claim is invalid: {exc}{RESET}\n"
                f"{DIM}  A structured claim must be a JSON object with a non-empty "
                f'"type" field, e.g. \'{{"type":"effect", ...}}\'.{RESET}',
                err=True,
            )
            sys.exit(1)

    # Parse --lines into a list
    lines_list: list[str] | None = None
    if lines:
        lines_list = [l.strip() for l in lines.replace(",", " ").split() if l.strip()]

    try:
        result = repo.add_papers(ids)
        if result["added"]:
            for pid in result["added"]:
                click.echo(f"  {GREEN}+{RESET} {pid}")
            click.echo(
                f"{DIM}  {len(result['added'])} added, {result['total']} total{RESET}"
            )

            # Fetch DOIs + citation counts in one call (internal OpenAlex DB)
            try:
                enrichment = repo.lookup_citations(result["added"])
                new_dois = enrichment.get("dois") or {}
                counts = enrichment.get("counts") or {}
                if new_dois:
                    repo.update_paper_dois(new_dois)
                if counts:
                    repo.update_paper_citations(
                        {pid: {"paper_id": pid, "cited_by_count": c} for pid, c in counts.items()}
                    )
                    top_pid = max(counts, key=counts.get)
                    click.echo(
                        f"{DIM}  {len(new_dois)} DOIs + {len(counts)} citation counts"
                        f"  (top: {counts[top_pid]:,} cites){RESET}"
                    )
                elif new_dois:
                    click.echo(f"{DIM}  {len(new_dois)} DOIs stored{RESET}")
            except Exception:
                pass
        else:
            click.echo(
                f"{DIM}  Already in repo ({result['total']} total){RESET}"
            )

        # Annotate with claim if provided — always annotate all requested IDs,
        # not just newly added ones, so re-adding with a new claim works.
        if claim:
            target_ids = ids

            def _attach(pid: str):
                try:
                    repo.annotate_paper(pid, claim, lines=lines_list)
                    return (pid, None)
                except ValueError as exc:
                    return (pid, exc)

            # Attaching the same claim to many papers is independent per paper
            # (distinct entries, row-locked server-side), so fan out when there's
            # more than one. ex.map preserves input order for stable output.
            if len(target_ids) > 1:
                import os as _os
                from concurrent.futures import ThreadPoolExecutor as _TPE

                try:
                    add_jobs = int(_os.getenv("PAPERCLIP_ADD_JOBS", "8"))
                except ValueError:
                    add_jobs = 8
                add_jobs = max(1, min(add_jobs, len(target_ids)))
                with _TPE(max_workers=add_jobs) as _ex:
                    attach_results = list(_ex.map(_attach, target_ids))
            else:
                attach_results = [_attach(pid) for pid in target_ids]

            for pid, exc in attach_results:
                if exc is None:
                    lines_hint = f" {DIM}({lines}){RESET}" if lines else ""
                    click.echo(
                        f"  {DIM}↳ {pid}: \"{claim[:80]}\"{lines_hint}{RESET}"
                    )
                else:
                    # Never drop a claim silently — a swallowed failure here
                    # means the claim is never verified and never pooled.
                    click.echo(
                        f"  {RED}[warn] could not attach claim to {pid}: {exc}{RESET}",
                        err=True,
                    )

        if commit_msg:
            try:
                commit_result = repo.commit(commit_msg)
                click.echo(
                    f"  {DIM}committed: {commit_msg} "
                    f"[{commit_result.get('sha', '')[:8]}]{RESET}"
                )
            except Exception:
                pass
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)
    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


def _looks_like_paper_id(arg: str) -> bool:
    """Heuristic: return True if arg looks like a paper/document ID."""
    prefixes = ("PMC", "bio_", "med_", "arx_", "fda_", "tri_", "NCT")
    if any(arg.startswith(p) for p in prefixes):
        return True
    # UUID (e.g. bioRxiv document_id resolved from DOI)
    if re.match(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", arg):
        return True
    # Pure numeric (PMID) or alphanumeric with underscores (custom IDs)
    if re.match(r"^[A-Za-z0-9_-]+$", arg) and not " " in arg and len(arg) <= 30:
        return True
    return False


def _add_from_library(query: str | None = None) -> None:
    """Add matched library papers to the active repo, optionally filtered by keyword."""
    from . import repo

    papers = repo.library_get_papers()
    if not papers:
        click.echo(
            f"  {DIM}Library is empty. Import a .bib file first: paperclip import refs.bib{RESET}"
        )
        return

    corpus_papers = {pid: p for pid, p in papers.items() if not pid.startswith("ref_")}
    if query:
        q = query.lower()
        corpus_papers = {
            pid: p
            for pid, p in corpus_papers.items()
            if q in (p.get("title", "") or "").lower()
            or q in (p.get("authors", "") or "").lower()
            or q in (p.get("journal", "") or "").lower()
        }

    if not corpus_papers:
        filter_msg = f' matching "{query}"' if query else ""
        unmatched = sum(1 for pid in papers if pid.startswith("ref_"))
        click.echo(f"  {DIM}No matched library papers{filter_msg}.{RESET}")
        if unmatched:
            click.echo(
                f"  {DIM}{unmatched} unmatched entries — try: paperclip library --rematch{RESET}"
            )
        return

    titles = {pid: p["title"] for pid, p in corpus_papers.items() if p.get("title")}
    dois = {pid: p["doi"] for pid, p in corpus_papers.items() if p.get("doi")}
    result = repo.add_papers(list(corpus_papers.keys()), titles=titles, dois=dois)

    meta = {}
    for pid, p in corpus_papers.items():
        m = {}
        for k in (
            "authors",
            "journal",
            "year",
            "pub_year",
            "cited_by_count",
            "entry_key",
            "source",
        ):
            if p.get(k):
                m[k] = p[k]
        if m:
            meta[pid] = m
    if meta:
        repo.update_paper_metadata(meta)

    if result["added"]:
        click.echo(
            f"  {GREEN}+{RESET} Added {len(result['added'])} papers from library ({result['total']} total in repo)"
        )
        for pid in result["added"][:10]:
            title = titles.get(pid, "")
            line = f"    {CYAN}{pid}{RESET}"
            if title:
                line += f"  {title[:50]}"
            click.echo(line)
        if len(result["added"]) > 10:
            click.echo(f"    {DIM}... and {len(result['added']) - 10} more{RESET}")
    else:
        click.echo(
            f"  {DIM}All library papers already in repo ({result['total']} total){RESET}"
        )


@main.command("import")
@click.argument("source")
@click.option("--doi", default=None, help="Paper DOI (skips DOI lookup if provided)")
@click.option("--limit", "-n", default=None, type=int, help="Max references to add")
@click.option(
    "--min-cites",
    default=0,
    type=int,
    help="Only include refs with at least N citations",
)
@click.option("--dry-run", is_flag=True, help="Show matches without adding to repo")
@click.option(
    "--init", "init_repo_name", default=None,
    help="Create a new repo from the file",
    hidden=not _is_paper_repos_enabled(),
)
@click.option(
    "--add-to-repo", is_flag=True,
    help="Also add imported papers to the active repo",
    hidden=not _is_paper_repos_enabled(),
)
@click.option(
    "--into", "into_clipboard",
    default=None,
    help="Import into a clipboard folder as corpus links (e.g. --into /clipboard/thesis-refs)",
)
def import_cmd(
    source: str,
    doi: str | None,
    limit: int | None,
    min_cites: int,
    dry_run: bool,
    init_repo_name: str | None,
    add_to_repo: bool,
    into_clipboard: str | None,
):
    """Import from PDFs, a .bib/.ris file, or a paper's references.

    \b
    From PDF files (uploads to your personal library):
        paperclip import paper.pdf
        paperclip import ~/papers/              # all PDFs in directory (recursive)
        paperclip import ~/papers/ --dry-run
        paperclip import ~/papers/ --add-to-repo
        paperclip import ~/papers/ --init my-review

    \b
    From a bibliography file (imports to your personal library):
        paperclip import refs.bib
        paperclip import refs.ris
        paperclip import refs.bib --dry-run
        paperclip import refs.bib --init my-review
        paperclip import refs.bib --add-to-repo
        paperclip import refs.bib --into /clipboard/thesis-refs

    \b
    From a paper (via Semantic Scholar):
        paperclip import PMC11282385
        paperclip import PMC11282385 --min-cites 50
        paperclip import PMC11282385 --dry-run

    Papers go into your personal library first. Use --add-to-repo to also
    add them to the active repo, or --init to create a new repo and add
    papers to both library and repo. Use --into to create corpus links
    in a clipboard folder (matched papers become symbolic links, unmatched
    become metadata-only entries).
    Matched entries get their corpus paper ID. Unmatched entries are
    still stored with all available metadata (title, authors,
    year, DOI, journal) so you can search and export them.
    """
    if not _is_library_enabled():
        click.echo(f"{RED}[error] Import is not available yet.{RESET}", err=True)
        sys.exit(1)

    if not _is_paper_repos_enabled():
        init_repo_name = None
        add_to_repo = False

    source_path = Path(source).expanduser()

    if source_path.is_dir() or source.lower().endswith(".pdf"):
        _import_pdfs(
            source_path,
            dry_run=dry_run,
            init_name=init_repo_name,
            add_to_repo=add_to_repo,
        )
    elif source.endswith(".bib") or source.endswith(".ris"):
        _import_bib_file(
            source,
            dry_run=dry_run,
            init_name=init_repo_name,
            limit=limit,
            add_to_repo=add_to_repo,
            into_clipboard=into_clipboard,
        )
    else:
        if init_repo_name:
            click.echo(f"{RED}[error] --init is only for file imports{RESET}", err=True)
            sys.exit(1)
        _import_from_paper(
            source, doi=doi, limit=limit, min_cites=min_cites, dry_run=dry_run
        )


def _import_from_paper(
    paper_id: str, *, doi: str | None, limit: int | None, min_cites: int, dry_run: bool
):
    """Original import: seed a repo from a paper's Semantic Scholar references."""
    from . import repo
    from ._citations import get_paper_references, match_references_in_corpus

    if not dry_run and not repo.get_active_repo():
        click.echo(
            f"{RED}[error] No repo selected. Pass --repo <name> (or export PAPERCLIP_REPO=<name>); create one with: paperclip repo init <name>{RESET}", err=True
        )
        sys.exit(1)

    click.echo(f"  {DIM}Fetching references for {paper_id}...{RESET}", err=True)
    try:
        refs = get_paper_references(paper_id, known_doi=doi)
    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)

    if not refs:
        click.echo(f"{DIM}No references found for {paper_id}.{RESET}")
        return

    click.echo(
        f"  {DIM}Found {len(refs)} references. Matching against corpus...{RESET}",
        err=True,
    )

    try:
        refs = match_references_in_corpus(refs)
    except Exception as e:
        click.echo(f"{RED}[error] Matching failed: {e}{RESET}", err=True)
        sys.exit(1)

    if min_cites > 0:
        refs = [r for r in refs if r.get("citation_count", 0) >= min_cites]

    matched = [r for r in refs if r.get("corpus_id")]
    unmatched = [r for r in refs if not r.get("corpus_id")]

    if not matched:
        click.echo(
            f"\n  {DIM}No references found in the corpus (out of {len(refs)} total).{RESET}"
        )
        if unmatched[:5]:
            click.echo(f"\n  {BOLD}Top unmatched references:{RESET}")
            for r in sorted(
                unmatched, key=lambda x: x.get("citation_count", 0), reverse=True
            )[:5]:
                cites = r.get("citation_count", 0)
                title = r.get("title", "")[:60]
                click.echo(f"    {DIM}{cites:>5} cites{RESET}  {title}")
        return

    matched.sort(key=lambda x: x.get("citation_count", 0), reverse=True)
    if limit:
        matched = matched[:limit]

    click.echo(
        f"\n  {BOLD}Matched {len(matched)}{RESET} of {len(refs)} references in corpus\n"
    )

    for r in matched:
        cites = r.get("citation_count", 0)
        title = r.get("title", "")[:55]
        year = r.get("year") or "?"
        cid = r["corpus_id"]
        click.echo(
            f"  {GREEN}+{RESET} {CYAN}{cid}{RESET}  {cites:>5} cites  {year}  {title}"
        )

    if unmatched:
        click.echo(
            f"\n  {DIM}{len(unmatched)} references not in corpus (preprints, books, older papers){RESET}"
        )

    if dry_run:
        click.echo(
            f"\n  {DIM}Dry run — no papers added. Remove --dry-run to add.{RESET}"
        )
        return

    ids_to_add = [r["corpus_id"] for r in matched]
    titles_map = {r["corpus_id"]: r.get("title", "") for r in matched}
    dois_map = {r["corpus_id"]: r["doi"] for r in matched if r.get("doi")}

    # Write to personal library first
    try:
        repo.library_add_papers(
            ids_to_add, titles=titles_map, dois=dois_map, source_file=f"refs:{paper_id}"
        )
    except Exception:
        pass

    try:
        result = repo.add_papers(ids_to_add, titles=titles_map, dois=dois_map)
        added = result.get("added", [])
        click.echo(
            f"\n  {GREEN}✓{RESET} Added {len(added)} papers ({result['total']} total in repo)"
        )
        if len(ids_to_add) > len(added):
            click.echo(f"  {DIM}{len(ids_to_add) - len(added)} already in repo{RESET}")

        try:
            cite_data = {}
            for r in matched:
                if r.get("corpus_id"):
                    cite_data[r["corpus_id"]] = {
                        "paper_id": r["corpus_id"],
                        "cited_by_count": r.get("citation_count", 0),
                        "title": r.get("title", ""),
                        "pub_year": r.get("year"),
                        "doi": r.get("doi", ""),
                        "s2_id": r.get("s2_id", ""),
                    }
            if cite_data:
                repo.update_paper_citations(cite_data)
        except Exception:
            pass

    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


# ── PDF import ────────────────────────────────────────────────────

_MAX_PDF_BATCH_FILES = 20
# Batches POST as one multipart request through Cloud Run's HTTP/1 ingress,
# which caps requests at 32 MiB — keep batches safely under that.
_MAX_PDF_BATCH_BYTES = 30 * 1024 * 1024  # 30 MB


def _collect_pdfs(source: Path) -> list[Path]:
    """Collect PDF file paths from a single file or directory (recursive)."""
    if source.is_file():
        if not source.suffix.lower() == ".pdf":
            click.echo(f"{RED}[error] Not a PDF file: {source}{RESET}", err=True)
            sys.exit(1)
        return [source]

    if not source.is_dir():
        click.echo(f"{RED}[error] Path not found: {source}{RESET}", err=True)
        sys.exit(1)

    pdfs = sorted(source.rglob("*.pdf"))
    pdf_lower = sorted(source.rglob("*.PDF"))
    seen = {p.resolve() for p in pdfs}
    for p in pdf_lower:
        if p.resolve() not in seen:
            pdfs.append(p)
            seen.add(p.resolve())
    return pdfs


def _batch_pdfs(
    paths: list[Path],
) -> list[list[Path]]:
    """Split paths into batches respecting server limits."""
    batches: list[list[Path]] = []
    current: list[Path] = []
    current_size = 0

    for p in paths:
        size = p.stat().st_size
        if current and (
            len(current) >= _MAX_PDF_BATCH_FILES
            or current_size + size > _MAX_PDF_BATCH_BYTES
        ):
            batches.append(current)
            current = []
            current_size = 0
        current.append(p)
        current_size += size

    if current:
        batches.append(current)
    return batches


def _import_pdfs(
    source: Path,
    *,
    dry_run: bool,
    init_name: str | None,
    add_to_repo: bool = False,
):
    """Import PDF files into the personal library."""
    from . import repo

    if not repo.validate_auth():
        click.echo(
            f"{RED}[error] Authentication failed (invalid credentials).{RESET}",
            err=True,
        )
        sys.exit(1)

    pdfs = _collect_pdfs(source)
    if not pdfs:
        click.echo(f"{DIM}No PDF files found in {source}{RESET}")
        return

    total_bytes = sum(p.stat().st_size for p in pdfs)
    label = f"from {source.name}/" if source.is_dir() else source.name
    click.echo(
        f"\n  {BOLD}Found {len(pdfs)} PDF{'s' if len(pdfs) != 1 else ''}{RESET}"
        f" {DIM}({total_bytes / 1024 / 1024:.1f} MB, {label}){RESET}\n"
    )

    for i, p in enumerate(pdfs[:20], 1):
        size_kb = p.stat().st_size / 1024
        click.echo(f"    {CYAN}{i:>3}.{RESET} {p.name}  {DIM}({size_kb:.0f} KB){RESET}")
    if len(pdfs) > 20:
        click.echo(f"    {DIM}... and {len(pdfs) - 20} more{RESET}")

    if dry_run:
        click.echo(
            f"\n  {DIM}Dry run — no files uploaded. Remove --dry-run to import.{RESET}"
        )
        return

    batches = _batch_pdfs(pdfs)
    client = _get_client()

    total_added = 0
    total_matched = 0
    total_skipped = 0
    all_errors: list[str] = []
    all_added_refs: list[dict] = []

    for batch_idx, batch in enumerate(batches):
        if len(batches) > 1:
            click.echo(
                f"\n  {DIM}Uploading batch {batch_idx + 1}/{len(batches)}"
                f" ({len(batch)} files)...{RESET}",
                err=True,
            )
        else:
            click.echo(
                f"\n  {DIM}Uploading {len(batch)} file{'s' if len(batch) != 1 else ''}...{RESET}",
                err=True,
            )

        files_data: list[tuple[str, bytes]] = []
        for p in batch:
            files_data.append((p.name, p.read_bytes()))

        try:
            start_resp = client.library.upload_pdfs(files_data)
        except AuthError:
            click.echo(
                f"{RED}[error] Authentication failed (API key invalid).{RESET}",
                err=True,
            )
            sys.exit(1)
        except (ServerError, RequestTimeoutError) as e:
            click.echo(f"{RED}[error] Upload failed: {e}{RESET}", err=True)
            sys.exit(1)

        job_id = str(start_resp.get("job_id", ""))
        if not job_id:
            click.echo(f"{RED}[error] Server did not return a job ID.{RESET}", err=True)
            sys.exit(1)

        last_pct = -1

        def _on_progress(processed: int, total: int) -> None:
            # Carriage-return progress is for a TTY; suppress under MCP so the
            # control characters don't pollute the returned output.
            if _is_mcp_mode():
                return
            nonlocal last_pct
            pct = int(100 * processed / total) if total else 0
            if pct != last_pct:
                last_pct = pct
                click.echo(
                    f"\r  {DIM}Processing… {processed}/{total} ({pct}%){RESET}",
                    nl=False,
                    err=True,
                )

        try:
            result = client.library.poll_import_job(job_id, on_progress=_on_progress)
        except (ServerError, RequestTimeoutError) as e:
            click.echo(f"\n{RED}[error] Import failed: {e}{RESET}", err=True)
            sys.exit(1)
        finally:
            click.echo("", err=True)

        total_added += int(result.get("papers_added", 0))
        total_skipped += int(result.get("papers_skipped", 0))
        batch_errors = result.get("errors") or []
        all_errors.extend(batch_errors)
        added_papers = result.get("added_papers") or []
        all_added_refs.extend(added_papers)

    click.echo(
        f"\n  {GREEN}✓{RESET} {BOLD}{total_added} paper{'s' if total_added != 1 else ''} imported{RESET}"
    )
    if total_skipped:
        click.echo(f"  {DIM}{total_skipped} skipped (already in library){RESET}")

    if all_errors:
        click.echo(
            f"\n  {RED}{len(all_errors)} error{'s' if len(all_errors) != 1 else ''}:{RESET}"
        )
        for err in all_errors[:10]:
            click.echo(f"    {DIM}{err}{RESET}")
        if len(all_errors) > 10:
            click.echo(f"    {DIM}... and {len(all_errors) - 10} more{RESET}")

    # Add to repo if requested
    if init_name:
        try:
            repo.init_repo(init_name, f"Imported PDFs from {source.name}")
            click.echo(f"  {GREEN}✓{RESET} Created repo: {BOLD}{init_name}{RESET}")
        except ValueError as e:
            click.echo(f"{RED}[error] {e}{RESET}", err=True)
            sys.exit(1)

    active = repo.get_active_repo()
    if active and (add_to_repo or init_name) and all_added_refs:
        paper_ids = [r.get("paper_id", "") for r in all_added_refs if r.get("paper_id")]
        titles_map = {
            r["paper_id"]: r["title"]
            for r in all_added_refs
            if r.get("paper_id") and r.get("title")
        }
        dois_map = {
            r["paper_id"]: r["doi"]
            for r in all_added_refs
            if r.get("paper_id") and r.get("doi")
        }
        if paper_ids:
            try:
                result = repo.add_papers(paper_ids, titles=titles_map, dois=dois_map)
                added_count = len(result.get("added", []))
                click.echo(
                    f"  {GREEN}✓{RESET} Also added {added_count} to repo"
                    f" '{active}' ({result['total']} total)"
                )
            except ValueError:
                pass
    elif active and not add_to_repo and not init_name and all_added_refs:
        if _is_paper_repos_enabled():
            click.echo(
                f"  {DIM}Tip: Use --add-to-repo to also add to repo '{active}'{RESET}"
            )
    elif not active and not init_name and all_added_refs:
        if _is_paper_repos_enabled():
            click.echo(
                f"  {DIM}Tip: paperclip repo init <name> to create a repo, then paperclip repo add --from-library{RESET}"
            )

    click.echo(f"\n  {DIM}View: paperclip library{RESET}")


def _import_bib_file(
    filepath: str,
    *,
    dry_run: bool,
    init_name: str | None,
    limit: int | None,
    add_to_repo: bool = False,
    into_clipboard: str | None = None,
):
    """Import papers from a .bib or .ris file into the personal library."""
    from . import repo
    from ._bibparse import make_ref_id, parse_file
    from ._citations import match_bib_entries_in_corpus

    # Validate authentication before any work
    if not repo.validate_auth():
        click.echo(
            f"{RED}[error] Authentication failed (invalid credentials).{RESET}",
            err=True,
        )
        sys.exit(1)

    # Parse the file
    try:
        entries = parse_file(filepath)
    except (ValueError, FileNotFoundError, OSError) as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)

    if not entries:
        click.echo(f"{DIM}No entries found in {filepath}.{RESET}")
        return

    fname = Path(filepath).name
    click.echo(f"\n  {BOLD}Parsed {len(entries)} entries{RESET} from {fname}\n")

    # Match against corpus
    def _on_progress(done: int, total: int, phase: str):
        click.echo(f"  {DIM}  Matching: {done}/{total} ({phase}){RESET}", err=True)

    click.echo(f"  {DIM}Matching against paper corpus...{RESET}", err=True)
    try:
        entries = match_bib_entries_in_corpus(entries, on_progress=_on_progress)
    except Exception as e:
        click.echo(f"{RED}[error] Matching failed: {e}{RESET}", err=True)
        sys.exit(1)

    matched = [e for e in entries if e.get("corpus_id")]
    unmatched = [e for e in entries if not e.get("corpus_id")]

    if limit:
        matched = matched[:limit]
        unmatched = unmatched[: max(0, limit - len(matched))]

    # Display results
    click.echo(
        f"\n  {BOLD}Results:{RESET} {GREEN}{len(matched)} matched{RESET}, "
        f"{YELLOW}{len(unmatched)} unmatched{RESET} of {len(entries)} entries\n"
    )

    if matched:
        click.echo(f"  {BOLD}Matched (full text available):{RESET}")
        for e in matched[:20]:
            title = e.get("title", "")[:50]
            year = e.get("year", "?")
            click.echo(
                f"    {GREEN}✓{RESET} {CYAN}{e['corpus_id']}{RESET}  {year}  {title}"
            )
        if len(matched) > 20:
            click.echo(f"    {DIM}... and {len(matched) - 20} more{RESET}")

    if unmatched:
        click.echo(f"\n  {BOLD}Unmatched (metadata only, no full text):{RESET}")
        for e in unmatched[:10]:
            title = e.get("title", "")[:50]
            year = e.get("year", "?")
            ref_id = make_ref_id(e)
            click.echo(f"    {YELLOW}○{RESET} {DIM}{ref_id}{RESET}  {year}  {title}")
        if len(unmatched) > 10:
            click.echo(f"    {DIM}... and {len(unmatched) - 10} more{RESET}")

    if dry_run:
        click.echo(
            f"\n  {DIM}Dry run — no papers added. Remove --dry-run to add.{RESET}"
        )
        return

    # ── Write to personal library ──
    all_ids = []
    all_titles: dict[str, str] = {}
    all_dois: dict[str, str] = {}
    all_meta: dict[str, dict] = {}

    for e in matched:
        cid = e["corpus_id"]
        all_ids.append(cid)
        if e.get("title"):
            all_titles[cid] = e["title"]
        if e.get("doi"):
            all_dois[cid] = e["doi"]
        if e.get("authors") or e.get("journal"):
            all_meta[cid] = {
                "authors": e.get("authors", ""),
                "journal": e.get("journal", ""),
                "year": e.get("year", ""),
                "entry_key": e.get("entry_key", ""),
                "source": "bib_import",
            }

    for e in unmatched:
        ref_id = make_ref_id(e)
        all_ids.append(ref_id)
        if e.get("title"):
            all_titles[ref_id] = e["title"]
        if e.get("doi"):
            all_dois[ref_id] = e["doi"]
        all_meta[ref_id] = {
            "authors": e.get("authors", ""),
            "journal": e.get("journal", ""),
            "year": e.get("year", ""),
            "entry_key": e.get("entry_key", ""),
            "source": "bib_import",
        }

    try:
        lib_result = repo.library_add_papers(
            all_ids,
            titles=all_titles,
            dois=all_dois,
            source_file=fname,
            metadata=all_meta,
        )
    except AuthError as e:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)
    if all_meta:
        repo.library_update_metadata(list(all_meta.keys()), all_meta)

    click.echo(
        f"\n  {GREEN}✓{RESET} Added {len(lib_result['added'])} papers to library ({lib_result['total']} total)"
    )
    click.echo(
        f"    {GREEN}{len(matched)}{RESET} full-text papers + {YELLOW}{len(unmatched)}{RESET} metadata-only entries"
    )
    click.echo(f"\n  {DIM}View: paperclip library{RESET}")

    # ── Also add to repo if --add-to-repo or --init was used ──
    if init_name:
        try:
            desc = f"Imported from {fname}"
            repo.init_repo(init_name, desc)
            click.echo(f"  {GREEN}✓{RESET} Created repo: {BOLD}{init_name}{RESET}")
        except ValueError as e:
            click.echo(f"{RED}[error] {e}{RESET}", err=True)
            sys.exit(1)

    active = repo.get_active_repo()
    if active and (add_to_repo or init_name):
        try:
            result = repo.add_papers(all_ids, titles=all_titles, dois=all_dois)
            added_count = len(result.get("added", []))
            if all_meta:
                repo.update_paper_bib_metadata(all_meta)
            click.echo(
                f"  {GREEN}✓{RESET} Also added {added_count} to repo '{active}' ({result['total']} total)"
            )
        except ValueError:
            pass
    elif active and not add_to_repo and not init_name:
        if _is_paper_repos_enabled():
            click.echo(
                f"  {DIM}Tip: Use --add-to-repo to also add to repo '{active}'{RESET}"
            )
    elif not active and not init_name:
        if _is_paper_repos_enabled():
            click.echo(
                f"  {DIM}Tip: paperclip repo init <name> to create a repo, then paperclip repo add <id> to curate{RESET}"
            )

    # ── Create corpus links in clipboard folder if --into was specified ──
    if into_clipboard and not dry_run:
        _import_bib_to_clipboard(into_clipboard, matched, unmatched, fname)


def _import_bib_to_clipboard(
    folder_path: str,
    matched: list[dict],
    unmatched: list[dict],
    source_filename: str,
):
    """Create corpus links in a clipboard folder for bib-imported papers.

    Matched papers become corpus_link entries (symbolic links to /papers/),
    unmatched become metadata-only entries.
    """
    import httpx

    from ._bibparse import make_ref_id

    folder = folder_path.strip().rstrip("/")
    for prefix in ("/clipboard/", "clipboard/"):
        if folder.startswith(prefix):
            folder = folder[len(prefix):]
            break

    base_url = config.get_base_url()
    headers = {}
    try:
        from ..client.auth import get_auth
        auth = get_auth()
        headers = auth.apply()
    except Exception:
        pass

    # Create the folder via MCP (mkdir)
    click.echo(f"\n  {DIM}Creating clipboard folder: /clipboard/{folder}{RESET}")
    try:
        with httpx.Client(base_url=base_url, headers=headers, timeout=30.0) as client:
            resp = client.post("/api/user/mcp/bash", json={"command": f"mkdir /clipboard/{folder}"})
            if resp.status_code not in (200, 409):
                logger.debug("mkdir response: %s %s", resp.status_code, resp.text[:200])
    except Exception as e:
        logger.debug("mkdir failed: %s", e)

    # Create corpus links for matched papers
    linked = 0
    meta_only = 0

    with httpx.Client(base_url=base_url, headers=headers, timeout=30.0) as client:
        for entry in matched:
            corpus_id = entry.get("corpus_id", "")
            if not corpus_id:
                continue
            try:
                resp = client.post(
                    "/api/user/mcp/bash",
                    json={"command": f"cp /papers/{corpus_id} /clipboard/{folder}/"},
                )
                if resp.status_code == 200:
                    linked += 1
            except Exception as e:
                logger.debug("cp failed for %s: %s", corpus_id, e)

        # Create metadata-only entries for unmatched papers
        for entry in unmatched:
            ref_id = make_ref_id(entry)
            title = entry.get("title", ref_id)
            bib_meta = {
                "authors": entry.get("authors", ""),
                "journal": entry.get("journal", ""),
                "year": entry.get("year", ""),
                "doi": entry.get("doi", ""),
                "entry_key": entry.get("entry_key", ""),
            }
            try:
                resp = client.post(
                    "/api/user/documents",
                    json={
                        "title": title,
                        "filename": ref_id,
                        "folder_path": folder,
                        "source_type": "bib",
                        "link_type": "uploaded",
                        "bib_meta": bib_meta,
                    },
                )
                if resp.status_code in (200, 201):
                    meta_only += 1
            except Exception as e:
                logger.debug("metadata entry failed for %s: %s", ref_id, e)

    click.echo(
        f"  {GREEN}✓{RESET} Clipboard /clipboard/{folder}: "
        f"{GREEN}{linked}{RESET} corpus links + {YELLOW}{meta_only}{RESET} metadata entries"
    )
    click.echo(f"    {DIM}View: paperclip ls /clipboard/{folder}{RESET}")


@repo_cmd.command("remove")
@click.argument("paper_id")
def remove_cmd(paper_id: str):
    """Remove a paper from the active repo."""
    from . import repo

    try:
        result = repo.remove_paper(paper_id)
        click.echo(
            f"  {DIM}Removed {paper_id}. {result['total']} papers remaining.{RESET}"
        )
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)
    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


def _unresolved_verification_count(verification: dict | None) -> int:
    """Count claim checks that did not produce a conclusive verdict."""
    unresolved = 0
    for claims in (verification or {}).values():
        entries = claims if isinstance(claims, list) else [claims]
        unresolved += sum(
            1
            for entry in entries
            if not isinstance(entry, dict)
            or entry.get("supported") not in (True, False)
        )
    return unresolved


@repo_cmd.command("commit")
@click.option(
    "-m",
    "--message",
    required=True,
    help="Commit message — explain what you found and what's missing",
)
@click.option(
    "-r", "--rationale", default=None, help="Extended rationale (appended to message)"
)
@click.option(
    "--verify/--no-verify",
    default=True,
    help="Verify claim against papers before committing (default: verify)",
)
@click.option(
    "-j",
    "--jobs",
    type=int,
    default=None,
    help="Concurrent verify calls to fan out (default: PAPERCLIP_VERIFY_JOBS or 8). "
    "Papers and claims within each paper are verified concurrently; stable claim "
    "IDs preserve alignment regardless of completion order. "
    "Higher is faster up to the server per-user cap; 429s are retried, so "
    "over-shooting the cap is safe.",
)
def commit_cmd(message: str, rationale: str | None, verify: bool, jobs: int | None):
    """Snapshot the current repo state with a commit message.

    \b
    The commit message is the audit trail — explain what papers were
    added/removed and why, what you found, and what's still missing.

    Before committing, each paper's claim (annotation) is verified by a
    subagent against the paper's content. Use --no-verify to skip.

    Examples:
        paperclip repo commit -m "initial resistance papers"
        paperclip repo commit -m "Found 3 phase-2 trials" -r "Added spleen LNP data, still need phase-3."
        paperclip repo commit -m "quick snapshot" --no-verify
    """
    from . import repo

    full_message = f"{message}\n\n{rationale}" if rationale else message

    # Capture active repo name ONCE at the start to prevent race conditions
    # where concurrent agents change the .active file mid-operation.
    active_name = repo.get_active_repo() or ""

    try:
        verification = None
        if verify:
            verification = _run_commit_verification(
                full_message, repo_name=active_name, jobs=jobs
            )
            unresolved = _unresolved_verification_count(verification)
            if unresolved:
                click.echo(
                    f"{RED}[error] Verification remained unresolved for "
                    f"{unresolved} claim(s); no commit was created.{RESET}\n"
                    f"{DIM}Retry the same command. Completed claim checks will "
                    f"be reused.{RESET}",
                    err=True,
                )
                sys.exit(1)

        entry = repo.commit(full_message)

        click.echo(f"  {GREEN}[{entry['sha']}]{RESET} {message}")
        if entry.get("added"):
            click.echo(f"  {DIM}+{len(entry['added'])} added{RESET}", nl=False)
        if entry.get("removed"):
            click.echo(f"  {DIM}-{len(entry['removed'])} removed{RESET}", nl=False)
        click.echo(f"  {DIM}{entry['paper_count']} papers committed{RESET}")

        if verification:
            repo.save_verification(active_name, verification)
            full_cache = repo.load_verification(active_name) or verification
            repo.push_verification_to_server(full_cache)

            click.echo()
            for doc_id, claims_list in verification.items():
                if isinstance(claims_list, dict):
                    claims_list = [claims_list]
                for v in claims_list:
                    supported = v.get("supported")
                    if supported is True:
                        mark = f"{GREEN}[OK]{RESET}"
                    elif supported is None:
                        mark = f"{YELLOW}[!]{RESET}"
                    else:
                        mark = f"{RED}[X]{RESET}"
                    claim = v.get("claim", "")
                    click.echo(f"  {mark} {doc_id}: {claim}")
                    reason = v.get("reason", "")
                    if reason:
                        click.echo(f"    {DIM}evidence: {reason}{RESET}")
                    vlines = v.get("lines", [])
                    if vlines:
                        click.echo(f"    {DIM}lines: {_format_line_refs(vlines)}{RESET}")
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)
    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


def _format_line_refs(line_nums: list) -> str:
    """Collapse consecutive line numbers into ranges: [1,2,3,5,7,8,9] -> 'L1-L3, L5, L7-L9'."""
    if not line_nums:
        return ""
    # Verification results normally contain integer line numbers, but an MCP
    # verifier can occasionally return metadata such as "N" / "N/A" in the
    # same field. Rendering a completed commit must not fail because one result
    # contains malformed display metadata. Keep valid positive line references
    # (including numeric and L-prefixed strings) and ignore everything else.
    parsed: set[int] = set()
    for raw in line_nums:
        if isinstance(raw, bool):
            continue
        if isinstance(raw, int):
            n = raw
        elif isinstance(raw, float) and raw.is_integer():
            n = int(raw)
        elif isinstance(raw, str):
            token = raw.strip()
            if token[:1].lower() == "l":
                token = token[1:]
            if not token.isdigit():
                continue
            n = int(token)
        else:
            continue
        if n > 0:
            parsed.add(n)

    nums = sorted(parsed)
    if not nums:
        return ""
    ranges: list[str] = []
    start = prev = nums[0]
    for n in nums[1:]:
        if n == prev + 1:
            prev = n
        else:
            ranges.append(f"L{start}" if start == prev else f"L{start}-L{prev}")
            start = prev = n
    ranges.append(f"L{start}" if start == prev else f"L{start}-L{prev}")
    return ", ".join(ranges)


def _parse_verify_output(output: str) -> dict:
    """Parse the JSON object from a ``verify`` command's output.

    When the ``verify`` command runs over the MCP execute path (API-key auth),
    the spawned CLI appends a human-readable footer line (e.g. ``[7.9s]``) after
    the JSON payload. A plain ``json.loads`` then fails with "Extra data", which
    would record every claim as a false failure even though verification
    succeeded server-side. Decode only the leading JSON value and ignore any
    trailing footer text.
    """
    import json as _json

    text = (output or "").strip()
    if not text:
        return {}
    start = text.find("{")
    if start == -1:
        # Surface the original error for the caller's except handler.
        return _json.loads(text)
    obj, _ = _json.JSONDecoder().raw_decode(text, start)
    return obj if isinstance(obj, dict) else {}


def _run_commit_verification(
    commit_message: str, repo_name: str = "", jobs: int | None = None
) -> dict | None:
    """Run claim verification against all papers in the active repo.

    Each paper's annotation (claim) is verified against the paper's content
    by a dedicated subagent. Papers without annotations are skipped.
    Papers with multiple annotations get each claim verified independently.

    Args:
        commit_message: The commit message (unused currently, reserved).
        repo_name: Pinned repo name to use for caching (avoids re-reading
            the .active file which may race with concurrent agents).

    Returns the verification dict:
        {doc_id: [{claim, supported, reason, lines}, ...]}
    Each paper maps to a *list* of per-claim verification results.
    """
    import json as _json
    import os as _os
    from concurrent.futures import (
        ThreadPoolExecutor as _ThreadPoolExecutor,
        as_completed as _as_completed,
    )

    from . import repo

    # Client-side verify concurrency: fan out up to `jobs` verify calls at once.
    # This is NOT the throughput ceiling — the real limiter is the SERVER's
    # per-user long-running cap (default 8, internal 32, liftable to 64 for a
    # trusted run via the X-Paperclip-Long-Cap override). The client fans out
    # freely and 429s are retried with full jitter, so `jobs` can safely exceed
    # the cap; extra calls just queue behind it. Default 8 (matches the default
    # server cap so a single run fully utilizes it); raise via --jobs or
    # PAPERCLIP_VERIFY_JOBS for internal / cap-lifted runs (higher = faster, up
    # to the server cap — measured ~2x from jobs=8 to jobs=32 at N=300).
    if jobs is None:
        try:
            jobs = int(_os.getenv("PAPERCLIP_VERIFY_JOBS", "8"))
        except ValueError:
            jobs = 8
    jobs = max(1, jobs)

    # Retry budget for transient 429s (per-user cap collisions). More attempts
    # help when many agents share one cap; full jitter (in _verify_call) keeps
    # them from retrying in lockstep. Override with PAPERCLIP_VERIFY_RETRIES.
    try:
        _VERIFY_RETRIES = max(1, int(_os.getenv("PAPERCLIP_VERIFY_RETRIES", "8")))
    except ValueError:
        _VERIFY_RETRIES = 8

    # Max documents per single verify call. Single-claim papers are batched into
    # one verify call to amortize overhead (the server verifies the batch's docs
    # in parallel internally), but the batch must stay SMALL: total concurrent
    # server-side work is roughly jobs x batch, and pushing that too high makes
    # heavy calls exceed the gateway timeout and return 5xx/HTML instead of a
    # verdict (observed: ~38 docs/call x 8 concurrent floods the verifier). Cap
    # the batch so each call stays light and a single failure poisons few docs.
    # Override with PAPERCLIP_VERIFY_BATCH.
    try:
        _VERIFY_BATCH = max(1, int(_os.getenv("PAPERCLIP_VERIFY_BATCH", "12")))
    except ValueError:
        _VERIFY_BATCH = 12

    # Claims within one paper can now be verified concurrently by one backend
    # request. Keep this separate from `jobs` (concurrent requests/papers) so
    # total verifier pressure remains bounded at roughly jobs * claim_jobs.
    try:
        _CLAIM_JOBS = max(
            1, int(_os.getenv("PAPERCLIP_VERIFY_CLAIM_JOBS", "4"))
        )
    except ValueError:
        _CLAIM_JOBS = 4

    # Bound one paper's serialized claim payload. Large structured extractions
    # can contain hundreds of verbose, path-pinned claims; sending all of them
    # in one shell-routed request can exceed parser/gateway budgets and trigger
    # the legacy one-at-a-time fallback.
    try:
        _CLAIM_BATCH = max(
            1, int(_os.getenv("PAPERCLIP_VERIFY_CLAIM_BATCH", "25"))
        )
    except ValueError:
        _CLAIM_BATCH = 25

    # Bound total verifier pressure, not just HTTP request count. Raising
    # --jobs without accounting for documents/claims per request previously
    # multiplied server work until otherwise healthy requests returned empty
    # or timed out. Trusted deployments may raise this explicit budget.
    try:
        _MAX_INFLIGHT = max(
            1, int(_os.getenv("PAPERCLIP_VERIFY_MAX_INFLIGHT", "96"))
        )
    except ValueError:
        _MAX_INFLIGHT = 96
    per_request_work = max(_VERIFY_BATCH, _CLAIM_JOBS)
    jobs = min(jobs, max(1, _MAX_INFLIGHT // per_request_work))

    status = repo.get_status()
    papers = status.get("papers", {})
    if not papers:
        return None

    # Skip already-verified claims. Merge the SERVER-merged verdicts with the
    # local cache so that when MULTIPLE agents commit to the same repo, each one
    # skips claims a PEER already verified and pushed — not just its own. Local
    # wins on conflict (it holds this agent's freshest, possibly un-pushed
    # verdicts); the server fills in every peer's papers. This turns N concurrent
    # subagents from "each re-verifies the whole repo" into "each verifies mostly
    # what's still outstanding". (For the cleanest split — subagents ADD, one
    # final commit verifies — there are no peers mid-commit and this is a no-op.)
    existing_verification = repo.load_verification(repo_name) or {}
    try:
        server_v = repo.load_server_verification(repo_name) or {}
        for pid, lst in server_v.items():
            if pid not in existing_verification:
                existing_verification[pid] = lst
    except Exception as exc:
        logger.debug("Could not merge server verification for skip-check: %s", exc)

    def _is_conclusive(prev: dict, claim_text: str) -> bool:
        """A previous result is conclusive if it has a real True/False verdict
        AND the claim text hasn't changed since it was verified."""
        if prev.get("supported") is None:
            return False
        if prev.get("claim") != claim_text:
            return False
        reason = prev.get("reason", "")
        if isinstance(reason, str) and reason.startswith("error:"):
            return False
        return True

    # Build per-paper verification PLANS. Each plan carries the FULL ordered
    # claim list plus which claim indices still need verifying, so every task
    # emits a COMPLETE, position-aligned result list.
    #
    # Skip granularity is per-CLAIM: a claim with a conclusive prior result
    # (True/False with matching claim text) is never re-submitted — but its
    # verdict is REUSED in place. Emitting a compacted list of only the
    # newly-verified claims would misalign a multi-claim paper on re-commit,
    # because save_verification (and compile) align per-claim results to
    # annotations BY INDEX.
    paper_plans: dict[str, dict] = {}
    for pid, info in papers.items():
        annots = info.get("annotations") or info.get("_annotations") or []
        note = info.get("note") or ""

        claims: list[str] = []
        if annots:
            for ann in annots:
                ann_note = ann.get("note", "")
                if ann_note:
                    claims.append(ann_note)
        elif note:
            claims.append(note)

        if not claims:
            continue

        prev_results = existing_verification.get(pid, [])
        if isinstance(prev_results, dict):
            prev_results = [prev_results]

        claim_ids = [
            _stable_claim_id(
                pid,
                claim_text,
                annots[ci] if ci < len(annots) else None,
            )
            for ci, claim_text in enumerate(claims)
        ]
        # New verdicts carry claim_id, so a reordered annotation list cannot
        # misattach a prior result. Positional lookup remains as a compatibility
        # fallback for caches written by older clients.
        prev_by_id = {
            str(item.get("claim_id")): item
            for item in prev_results
            if isinstance(item, dict) and item.get("claim_id")
        }
        aligned_prev: list[dict | None] = []
        need_idx: list[int] = []
        for ci, (claim_text, claim_id) in enumerate(zip(claims, claim_ids)):
            prev = prev_by_id.get(claim_id)
            if prev is None and ci < len(prev_results):
                candidate = prev_results[ci]
                if isinstance(candidate, dict) and candidate.get("claim") == claim_text:
                    prev = candidate
            aligned_prev.append(prev)
            if not (isinstance(prev, dict) and _is_conclusive(prev, claim_text)):
                need_idx.append(ci)

        if need_idx:
            paper_plans[pid] = {
                "claims": claims,
                "claim_ids": claim_ids,
                "annots": annots,
                "prev": aligned_prev,
                "need": set(need_idx),
            }

    if not paper_plans:
        click.echo(f"  {DIM}all claims already verified — skipping{RESET}")
        return None

    # Single-claim papers (exactly one total claim) batch efficiently — one
    # verify call covers many. Multi-claim papers each get their own task that
    # verifies only the still-needed claims but rebuilds the FULL ordered list.
    single_claim_papers: dict[str, str] = {}
    single_claim_annots: dict[str, list[dict]] = {}
    single_claim_ids: dict[str, str] = {}
    multi_claim_plans: dict[str, dict] = {}

    for pid, plan in paper_plans.items():
        if len(plan["claims"]) == 1:
            single_claim_papers[pid] = plan["claims"][0]
            single_claim_ids[pid] = plan["claim_ids"][0]
            if plan["annots"]:
                single_claim_annots[pid] = plan["annots"]
        else:
            multi_claim_plans[pid] = plan

    client = _get_client()
    all_results: dict[str, list[dict]] = {}

    # Incremental persistence: save verification marks every few papers so a
    # large commit (hundreds of claims, verified with up to `jobs` concurrent
    # calls) is RESUMABLE — a timeout or crash loses at most _PERSIST_EVERY
    # papers' worth of progress instead of everything. save_verification merges,
    # and a re-commit only re-verifies still-[?] claims, so partial progress
    # compounds. Called only from the main thread as futures complete, so a
    # simple snapshot keeps it consistent.
    _active_repo = repo_name or repo.get_active_repo() or ""
    _PERSIST_EVERY = 10
    _since_persist = 0

    def _persist_progress(force: bool = False) -> None:
        nonlocal _since_persist
        _since_persist += 1
        if not _active_repo or not all_results:
            return
        if force or _since_persist >= _PERSIST_EVERY:
            _since_persist = 0
            snapshot = {k: list(v) for k, v in all_results.items()}
            try:
                repo.save_verification(_active_repo, snapshot)
                full_cache = repo.load_verification(_active_repo) or snapshot
                repo.push_verification_to_server(full_cache)
            except Exception as exc:
                logger.debug("Incremental verification persist failed: %s", exc)

    def _verify_call(v_args: list[str]):
        """Run a verify, retrying transient failures (rate limit / gateway / timeout).

        `verify` is a long-running command capped per user (default 8; higher
        for internal users or when a trusted caller raises it). Two classes of
        transient failure must be retried — NOT recorded as a false [X] that
        drops a good effect:

        1. 429 (RateLimitError): the per-user concurrency cap rejected the call
           BEFORE it ran. Happens when several agents commit at once, or one
           agent fans out past the cap.
        2. 5xx / timeout / network (ServerError>=500, RequestTimeoutError,
           NetworkError): under heavy concurrent load the gateway or verifier
           returns an HTML error page or times out. These poison a whole batch
           if not retried (observed at ~300 papers).

        Retry with FULL JITTER (sleep in [0, backoff]) so concurrent retriers
        decorrelate instead of thundering the cap in lockstep. A real
        verification "failure" comes back as a normal result with
        supported=False, never as one of these exceptions, so retrying them is
        always safe.
        """
        import time as _t
        import random as _r

        for i in range(_VERIFY_RETRIES):
            try:
                result = client.execute("verify", v_args, timeout=300)
                if not result or not str(result.output or "").strip():
                    raise RuntimeError("verifier returned an empty response")
                return result
            except RuntimeError:
                if i == _VERIFY_RETRIES - 1:
                    raise
                _t.sleep(_r.uniform(0.0, min(30.0, 2.0 * (2 ** i))))
            except (RateLimitError, RequestTimeoutError, NetworkError):
                if i == _VERIFY_RETRIES - 1:
                    raise
                _t.sleep(_r.uniform(0.0, min(30.0, 2.0 * (2 ** i))))
            except ServerError as exc:
                # Only 5xx is transient; a 4xx ServerError is a real problem.
                sc = getattr(exc, "status_code", None)
                if sc is not None and sc < 500:
                    raise
                if i == _VERIFY_RETRIES - 1:
                    raise
                _t.sleep(_r.uniform(0.0, min(30.0, 2.0 * (2 ** i))))

    # ---- Fan out verification, bounded by `jobs` ------------------------------
    # Each work item owns a DISJOINT set of doc_ids and returns a complete,
    # ordered per-claim result list for each. Multi-claim papers submit all
    # pending claims together; the backend verifies up to _CLAIM_JOBS at once
    # and returns a stable claim_id-keyed map. The client reconstructs current
    # annotation order by ID, so out-of-order completion cannot corrupt
    # alignment. Because no two items touch the same pid, paper results are
    # still merged in the main thread without shared-state locking.
    def _batch_task(chunk: dict[str, str]) -> dict[str, list[dict]]:
        """Verify a batch of single-claim papers in one call. chunk: pid -> claim."""
        args = [
            "--claims", _json.dumps(chunk),
            "--document-ids", ",".join(chunk.keys()),
        ]
        annots_sub = {
            pid: single_claim_annots[pid] for pid in chunk if pid in single_claim_annots
        }
        if annots_sub:
            args.extend(["--annotations", _json.dumps(annots_sub)])
        out: dict[str, list[dict]] = {}
        try:
            result = _verify_call(args)
            output = (result.output or "") if result else ""
            raw = _parse_verify_output(output) if output.strip() else {}
            for pid, claim_text in chunk.items():
                v = raw.get(pid)
                if isinstance(v, list):
                    entries = v
                elif isinstance(v, dict):
                    entries = [v]
                else:
                    entries = [{
                        "claim": claim_text,
                        "supported": None,
                        "reason": "error: verify returned no result",
                    }]
                for entry in entries:
                    if isinstance(entry, dict):
                        entry.setdefault("claim_id", single_claim_ids[pid])
                        entry.setdefault("document_id", pid)
                out[pid] = entries
        except Exception as exc:
            logger.warning("Batch verify failed for %s: %s", list(chunk.keys()), exc)
            for pid, claim_text in chunk.items():
                out[pid] = [{
                    "claim_id": single_claim_ids[pid],
                    "document_id": pid,
                    "claim": claim_text,
                    "supported": None,
                    "reason": f"error: {exc}",
                }]
        return out

    def _paper_task(pid: str, plan: dict) -> dict[str, list[dict]]:
        """Verify a multi-claim paper, emitting the FULL ordered per-claim list:
        still-needed claims are submitted together and keyed by stable claim ID;
        already-conclusive claims are reused. The backend may finish claims in
        any order without risking verdict/annotation misalignment."""
        claims = plan["claims"]
        claim_ids = plan["claim_ids"]
        annots = plan["annots"]
        prev = plan["prev"]
        need = plan["need"]
        entries: list[dict | None] = [None] * len(claims)

        # Preserve already-conclusive entries, upgrading legacy positional
        # results with stable IDs as they pass through.
        for ci, claim_text in enumerate(claims):
            if ci not in need:
                entry = dict(prev[ci])
                entry.setdefault("claim_id", claim_ids[ci])
                entry.setdefault("document_id", pid)
                entries[ci] = entry

        claim_items = []
        for ci in sorted(need):
            item = {
                "claim_id": claim_ids[ci],
                "claim": claims[ci],
            }
            if ci < len(annots) and annots[ci].get("lines"):
                item["lines"] = annots[ci]["lines"]
            if ci < len(annots) and annots[ci].get("source_locations"):
                item["source_locations"] = annots[ci]["source_locations"]
            claim_items.append(item)

        def _unknown(ci: int, reason: str) -> dict:
            return {
                "claim_id": claim_ids[ci],
                "document_id": pid,
                "claim": claims[ci],
                "supported": None,
                "reason": reason,
            }

        def _legacy_verify_one(ci: int) -> dict:
            """Compatibility path for a pre-claim-ID backend during rollout."""
            args = [
                "--claims", _json.dumps({pid: claims[ci]}),
                "--document-ids", pid,
            ]
            if ci < len(annots):
                args.extend(["--annotations", _json.dumps({pid: [annots[ci]]})])
            try:
                result = _verify_call(args)
                output = result.output or ""
                if output.strip():
                    raw = _parse_verify_output(output)
                    v = raw.get(pid)
                    if isinstance(v, dict):
                        entry = v
                    elif isinstance(v, list) and v:
                        entry = v[0]
                    else:
                        entry = None
                    if isinstance(entry, dict):
                        entry.setdefault("claim_id", claim_ids[ci])
                        entry.setdefault("document_id", pid)
                        entry.setdefault("claim", claims[ci])
                        return entry
                    return _unknown(ci, "error: verify returned unparseable result")
                return _unknown(ci, "error: verify returned empty output")
            except Exception as exc:
                logger.warning("Legacy verify failed for %s claim %s: %s", pid, ci, exc)
                return _unknown(ci, f"error: {exc}")

        if claim_items:
            claim_index_by_id = {
                claim_ids[ci]: ci
                for ci in sorted(need)
            }
            for start in range(0, len(claim_items), _CLAIM_BATCH):
                batch = claim_items[start : start + _CLAIM_BATCH]
                batch_indexes = [
                    claim_index_by_id[item["claim_id"]]
                    for item in batch
                ]
                args = [
                    "--claims", _json.dumps({pid: batch}),
                    "--document-ids", pid,
                    "--max-concurrent", str(_CLAIM_JOBS),
                ]
                try:
                    result = _verify_call(args)
                    output = result.output or ""
                    raw = _parse_verify_output(output) if output.strip() else {}
                    by_claim_id = raw.get("claim_results")
                    if isinstance(by_claim_id, dict):
                        for ci in batch_indexes:
                            item = by_claim_id.get(claim_ids[ci])
                            if isinstance(item, dict):
                                entry = dict(item)
                                entry.setdefault("claim_id", claim_ids[ci])
                                entry.setdefault("document_id", pid)
                                entry.setdefault("claim", claims[ci])
                                entries[ci] = entry
                            else:
                                entries[ci] = _unknown(
                                    ci,
                                    "error: verify returned no result for claim_id",
                                )
                    else:
                        # A server running the previous protocol may accept the
                        # object payload but return the legacy per-document shape.
                        for ci in batch_indexes:
                            entries[ci] = _legacy_verify_one(ci)
                except Exception as exc:
                    logger.warning(
                        "Concurrent claim verify unavailable for %s batch %s-%s "
                        "(%s); falling back to legacy one-at-a-time protocol",
                        pid,
                        start + 1,
                        start + len(batch),
                        exc,
                    )
                    for ci in batch_indexes:
                        entries[ci] = _legacy_verify_one(ci)

        return {
            pid: [
                entry
                if isinstance(entry, dict)
                else _unknown(ci, "error: missing verification entry")
                for ci, entry in enumerate(entries)
            ]
        }

    # Assemble the work items (each a zero-arg callable returning {pid: [...]}).
    tasks: list = []
    if single_claim_papers:
        pids = list(single_claim_papers.keys())
        # Chunk by a fixed MAX BATCH SIZE (not by `jobs`). This keeps each verify
        # call light regardless of corpus size — the old `min(jobs, len(pids))`
        # scheme made batches grow without bound (300 papers / 8 jobs = ~38
        # docs/call), and heavy concurrent calls overwhelmed the gateway. Now the
        # number of chunks scales with N while `jobs` independently bounds how
        # many run at once, so total server load stays ~= jobs x batch.
        n_chunks = max(1, -(-len(pids) // _VERIFY_BATCH))  # ceil(len/batch)
        chunks: list[dict[str, str]] = [{} for _ in range(n_chunks)]
        for i, pid in enumerate(pids):
            chunks[i % n_chunks][pid] = single_claim_papers[pid]
        for ch in chunks:
            if ch:
                tasks.append(lambda ch=ch: _batch_task(ch))
    for pid, plan in multi_claim_plans.items():
        tasks.append(lambda pid=pid, plan=plan: _paper_task(pid, plan))

    if not tasks:
        _persist_progress(force=True)
        return all_results or None

    if jobs <= 1 or len(tasks) <= 1:
        for task in tasks:
            all_results.update(task())
            _persist_progress()
    else:
        with _ThreadPoolExecutor(max_workers=jobs) as ex:
            futures = [ex.submit(task) for task in tasks]
            for fut in _as_completed(futures):
                try:
                    all_results.update(fut.result())
                except Exception as exc:  # a task itself should never raise, but be safe
                    logger.warning("verify worker crashed: %s", exc)
                _persist_progress()

    _persist_progress(force=True)
    return all_results or None


@repo_cmd.command("status")
def status_cmd():
    """Show current repo state: papers, claims, and verification results.

    \b
    Like `git status` - shows where you are right now.
    Verification marks ([OK]/[X]) come from the last `paperclip repo commit`.

    Examples:
        paperclip repo status
    """
    from . import repo

    active = repo.get_active_repo()
    if not active:
        click.echo(
            f"No active repo. Use: paperclip repo init <name>"
        )
        return

    try:
        s = repo.get_status()
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)

    branch = s.get("active_branch", "main")
    papers = s.get("papers", {})
    commit_count = s.get("commit_count", 0)

    click.echo(f"\n  {BOLD}On repo {active}{RESET}  {DIM}branch {branch}{RESET}")
    click.echo(
        f"  {DIM}{len(papers)} paper{'s' if len(papers) != 1 else ''}, "
        f"{commit_count} commit{'s' if commit_count != 1 else ''}{RESET}\n"
    )

    if not papers:
        click.echo(f"  {DIM}No papers yet. Use: paperclip repo add <id> \"claim\"{RESET}\n")
        return

    verification = repo.load_verification() or {}

    has_unverified = False
    for pid, info in papers.items():
        title = info.get("title", "")
        year = info.get("year") or info.get("pub_year")
        annots = info.get("annotations") or []
        note = info.get("note") or ""

        # Collect all claims: prefer annotations list, fall back to note
        claims: list[str] = []
        claim_lines: list[str | None] = []
        if annots:
            for ann in annots:
                ann_note = ann.get("note", "")
                if ann_note:
                    claims.append(ann_note)
                    claim_lines.append(ann.get("lines"))
        elif note:
            claims.append(note)
            claim_lines.append(None)

        # Get verification results (list format from new multi-claim verification)
        v_list = verification.get(pid)
        if isinstance(v_list, dict):
            v_list = [v_list]

        # Determine paper-level mark from claims
        if v_list:
            all_supported = all(v.get("supported") is True for v in v_list)
            any_rejected = any(v.get("supported") is False for v in v_list)
            any_errored = any(v.get("supported") is None for v in v_list)
            if all_supported:
                paper_mark = f"{GREEN}[OK]{RESET}"
            elif any_rejected:
                paper_mark = f"{RED}[X]{RESET}"
            elif any_errored:
                paper_mark = f"{YELLOW}[!]{RESET}"
            else:
                paper_mark = f"{DIM}[?]{RESET}"
        elif claims:
            paper_mark = f"{DIM}[?]{RESET}"
            has_unverified = True
        else:
            paper_mark = f"{DIM}[?]{RESET}"

        header = f"  {paper_mark} {CYAN}{pid}{RESET}"
        if title:
            header += f"  {title[:50]}"
        if year:
            header += f" {DIM}({year}){RESET}"
        click.echo(header)

        if not claims:
            continue

        # Display each claim with its own verification result
        for ci, claim_text in enumerate(claims):
            if v_list and ci < len(v_list):
                v = v_list[ci]
                s = v.get("supported")
                if s is True:
                    c_mark = f"{GREEN}[OK]{RESET}"
                elif s is None:
                    c_mark = f"{YELLOW}[!]{RESET}"
                else:
                    c_mark = f"{RED}[X]{RESET}"
            else:
                v = None
                c_mark = f"{DIM}[?]{RESET}" if not v_list else ""
                has_unverified = True

            # For single-claim papers, use simpler formatting
            if len(claims) == 1:
                click.echo(f"    {DIM}claim: {claim_text}{RESET}")
            else:
                click.echo(f"    {c_mark} {DIM}claim: {claim_text}{RESET}")

            if v:
                reason = v.get("reason", "")
                if reason:
                    click.echo(f"    {DIM}evidence: {reason}{RESET}")
                vlines = v.get("lines", [])
                if vlines:
                    click.echo(f"    {DIM}lines: {_format_line_refs(vlines)}{RESET}")

    if has_unverified and papers:
        click.echo(
            f"\n  {DIM}[?] = not yet verified. Run: paperclip repo commit -m \"message\"{RESET}"
        )
    click.echo()


@repo_cmd.command("claims")
@click.option(
    "--verified-only",
    is_flag=True,
    help="Only emit claims verified [OK] on the last commit",
)
@click.option(
    "--type",
    "type_filter",
    default=None,
    help="Only emit claims whose 'type' equals this (e.g. effect, context)",
)
def claims_cmd(verified_only: bool, type_filter: str | None):
    """Emit repo claims as a JSON array — the machine-readable claim store.

    \b
    This is the source of truth for inspecting or exporting generic repo
    claims. Each element is the claim's JSON body augmented with
    fields that live OUTSIDE that body and are therefore lost when scraping
    `repo status` text:
      paperclip_doc_id  - the paper the claim is attached to
      paperclip_lines   - the exact source line pin from `repo add --lines`
      verified          - true iff the last commit marked this claim [OK]
    Domain-agnostic: the claim body is passed through untouched, so it works
    for any claim schema (medical effects, ML benchmark scores, etc.).

    \b
    Examples:
        paperclip repo claims                                  # all claims
        paperclip repo claims --verified-only --type effect    # progress/inspection
        paperclip repo claims --verified-only --type context   # progress/inspection

    Specialized workflows may require their own compiler and validation gates.
    Do not substitute this diagnostic export for those workflow artifacts.
    """
    from . import repo

    if not repo.get_active_repo():
        click.echo("[]")
        return

    status = repo.get_status()
    # Parallel workers push disjoint verification subsets into the server-merged
    # store. A local cache only represents the current process/config directory,
    # so prefer the authoritative server view and fall back for offline repos.
    verification = (
        repo.load_server_verification()
        or repo.load_verification()
        or {}
    )
    papers = status.get("papers", {})

    out: list[dict] = []
    for pid, info in papers.items():
        annots = info.get("annotations") or []
        note = info.get("note") or ""
        # Keep each complete annotation so stable claim IDs can align verdicts
        # independently of annotation or verifier completion order.
        entries: list[dict] = []
        if annots:
            for ann in annots:
                n = ann.get("note", "")
                if n:
                    entries.append(ann)
        elif note:
            entries.append({"note": note, "lines": None})

        v_list = verification.get(pid)
        if isinstance(v_list, dict):
            v_list = [v_list]
        v_by_id = {
            str(v.get("claim_id")): v
            for v in (v_list or [])
            if isinstance(v, dict) and v.get("claim_id")
        }

        for ci, ann in enumerate(entries):
            note_text = ann.get("note", "")
            lines = ann.get("lines")
            claim_id = _stable_claim_id(pid, note_text, ann)
            v = v_by_id.get(claim_id)
            # Compatibility with caches written before claim IDs existed. Only
            # accept a positional verdict when its claim text also matches.
            if v is None and v_list and ci < len(v_list):
                candidate = v_list[ci]
                if (
                    isinstance(candidate, dict)
                    and candidate.get("claim") == note_text
                ):
                    v = candidate
            is_verified = bool(v and v.get("supported"))
            if verified_only and not is_verified:
                continue
            claim: dict
            if "{" in note_text:
                try:
                    parsed = json.loads(note_text[note_text.index("{"):])
                    claim = parsed if isinstance(parsed, dict) else {"note": note_text}
                except json.JSONDecodeError:
                    claim = {"note": note_text}
            else:
                claim = {"note": note_text}
            if type_filter and claim.get("type") != type_filter:
                continue
            claim["paperclip_doc_id"] = pid
            if lines:
                claim["paperclip_lines"] = lines
            claim["claim_id"] = claim_id
            claim["verified"] = is_verified
            out.append(claim)

    click.echo(json.dumps(out, indent=2))


@repo_cmd.command("citations")
@click.argument("paper_ids", nargs=-1, required=False)
@click.option(
    "--graph", is_flag=True, help="Show citation relationships between papers"
)
@click.option(
    "--refresh", is_flag=True, help="Force fresh lookup from Semantic Scholar"
)
def citations_cmd(paper_ids: tuple, graph: bool, refresh: bool):
    """Citation counts and relationships for repo papers.

    \b
    Defaults to citation counts; use --graph for relationships.

    Examples:
        paperclip repo citations                          # counts for all repo papers
        paperclip repo citations --refresh                # force fresh from S2
        paperclip repo citations --graph                  # citation relationships
        paperclip repo citations PMC9170150 PMC11748609   # specific papers
    """
    from . import repo

    ids = list(paper_ids) if paper_ids else repo.get_repo_paper_ids()
    if not ids:
        click.echo(
            f"{RED}[error] No paper IDs. Provide IDs or activate a repo.{RESET}",
            err=True,
        )
        sys.exit(1)

    if graph:
        _show_cite_graph(ids, repo)
    else:
        _show_cite_counts(ids, repo, refresh=refresh)


def _show_cite_counts(ids: list[str], repo, *, refresh: bool) -> None:
    cached = repo.get_repo_citations()
    cached_ids = set(cached.keys())
    requested = set(ids)

    if not refresh and requested <= cached_ids:
        results = [cached[pid] for pid in ids if pid in cached]
    else:
        known_dois = repo.get_repo_dois()
        try:
            from ._citations import get_citation_counts

            results = get_citation_counts(ids, known_dois=known_dois or None)
        except Exception as e:
            click.echo(f"{RED}[error] {e}{RESET}", err=True)
            sys.exit(1)

        if not results:
            click.echo(f"{DIM}No citation data found for these papers.{RESET}")
            return

        try:
            new_dois = {r["paper_id"]: r["doi"] for r in results if r.get("doi")}
            if new_dois:
                repo.update_paper_dois(new_dois)
            repo.update_paper_citations({r["paper_id"]: r for r in results})
        except Exception:
            pass

    results.sort(key=lambda r: r["cited_by_count"] or 0, reverse=True)

    click.echo(f"Citation counts ({len(results)} papers, sorted by citations):\n")
    for r in results:
        cited = r["cited_by_count"] or 0
        year = r.get("pub_year") or "?"
        title = r.get("title", "")
        click.echo(f"  {r['paper_id']}  {cited} cites  {year}  {title}")

    total = sum(r["cited_by_count"] or 0 for r in results)
    avg = total / len(results) if results else 0
    unmatched = len(ids) - len(results)
    click.echo(
        f"\nTotal: {total:,} citations | Avg: {avg:,.0f} | Matched: {len(results)}/{len(ids)}"
    )
    if unmatched:
        matched_ids = {r["paper_id"] for r in results}
        missing = [pid for pid in ids if pid not in matched_ids]
        click.echo(
            f"Not found: {', '.join(missing[:5])}{'...' if len(missing) > 5 else ''}"
        )


def _show_cite_graph(ids: list[str], repo) -> None:
    if len(ids) < 2:
        click.echo(f"{DIM}Need at least 2 papers to build a citation graph.{RESET}")
        return

    known_dois = repo.get_repo_dois()

    click.echo(
        f"{DIM}  Querying Semantic Scholar for {len(ids)} papers...{RESET}", err=True
    )

    try:
        from ._citations import get_citation_graph

        graph = get_citation_graph(ids, known_dois=known_dois or None)
    except Exception as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)

    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    if not nodes:
        click.echo(f"{DIM}No papers resolved. Check that papers have DOIs.{RESET}")
        return

    new_dois = {n["id"]: n["doi"] for n in nodes if n.get("doi")}
    if new_dois:
        try:
            repo.update_paper_dois(new_dois)
        except Exception:
            pass

    titles = {n["id"]: n.get("title", "")[:50] for n in nodes}
    cites = {n["id"]: n.get("cited_by_count", 0) for n in nodes}

    click.echo(
        f"\n  {BOLD}Citation Graph{RESET} ({len(nodes)} papers, {len(edges)} connections)\n"
    )

    if not edges:
        click.echo(f"  {DIM}No citation links found between these papers.{RESET}")
        click.echo(f"  {DIM}(Papers may not reference each other directly.){RESET}\n")
        for n in sorted(nodes, key=lambda x: x["cited_by_count"], reverse=True):
            click.echo(
                f"  {CYAN}{n['id']:>16}{RESET}  {cites[n['id']]:>5} cites  {DIM}{titles[n['id']]}{RESET}"
            )
        click.echo()
        return

    edge_by_source: dict[str, list[dict]] = {}
    incoming: dict[str, int] = {n["id"]: 0 for n in nodes}
    outgoing: dict[str, int] = {n["id"]: 0 for n in nodes}
    for e in edges:
        edge_by_source.setdefault(e["source"], []).append(e)
        outgoing[e["source"]] = outgoing.get(e["source"], 0) + 1
        incoming[e["target"]] = incoming.get(e["target"], 0) + 1

    for src_id in sorted(edge_by_source, key=lambda x: cites.get(x, 0), reverse=True):
        src_title = titles.get(src_id, "")
        click.echo(f"  {CYAN}{src_id}{RESET}  {DIM}{src_title}{RESET}")
        for e in edge_by_source[src_id]:
            marker = f"{YELLOW}★{RESET}" if e.get("influential") else " "
            tgt = e["target"]
            click.echo(
                f"    {marker} cites → {CYAN}{tgt}{RESET}  {DIM}{titles.get(tgt, '')}{RESET}"
            )
        click.echo()

    if incoming:
        top = sorted(incoming.items(), key=lambda x: x[1], reverse=True)
        cited_in_repo = [(pid, cnt) for pid, cnt in top if cnt > 0]
        if cited_in_repo:
            click.echo(f"  {BOLD}Most cited within repo:{RESET}")
            for pid, cnt in cited_in_repo[:5]:
                click.echo(
                    f"    {CYAN}{pid}{RESET}  ← {cnt} repo paper{'s' if cnt > 1 else ''}  "
                    f"{DIM}({cites.get(pid, 0)} total cites){RESET}"
                )
            click.echo()

    click.echo(
        f"  {DIM}★ = influential citation  |  {len(edges)} links among {len(nodes)} papers{RESET}\n"
    )


@repo_cmd.command("branch")
@click.argument("name", required=False, default=None)
def branch_cmd(name: str | None):
    """List or create branches on the active repo.

    \b
    Examples:
        paperclip repo branch                   # list branches
        paperclip repo branch clinical-data     # create + switch to new branch
    """
    from . import repo

    if name:
        try:
            result = repo.create_branch(name)
            click.echo(
                f"{GREEN}✓{RESET} Created branch: {BOLD}{result['branch']}{RESET} ({result['papers']} papers)"
            )
            click.echo(f"  {DIM}Forked from current branch with all papers.{RESET}")
        except ValueError as e:
            click.echo(f"{RED}[error] {e}{RESET}", err=True)
            sys.exit(1)
        return

    branches = repo.list_branches()
    if not branches:
        click.echo(f"{DIM}No active repo or no branches.{RESET}")
        return

    active_repo = repo.get_active_repo()
    click.echo(f"\n  {BOLD}Branches{RESET} ({active_repo})\n")
    for b in branches:
        marker = f"{GREEN}●{RESET}" if b["active"] else f"{DIM}○{RESET}"
        click.echo(
            f"  {marker} {BOLD}{b['name']}{RESET}  "
            f"{DIM}({b['paper_count']} papers, {b['commit_count']} commits){RESET}"
        )
    click.echo()


@repo_cmd.command("merge")
@click.argument("source_branch")
def merge_cmd(source_branch: str):
    """Merge papers from another branch into the current branch.

    \b
    Combines papers (union). If both branches have the same paper,
    the current branch's version is kept. Records a merge commit.

    Examples:
        paperclip repo merge clinical-data
    """
    from . import repo

    try:
        result = repo.merge_branch(source_branch)
        if result["merged"] > 0:
            click.echo(
                f"  {GREEN}✓{RESET} Merged {BOLD}{result['merged']}{RESET} papers from '{result['source']}' into '{result['target']}'"
            )
            for pid in result["added"][:10]:
                click.echo(f"    {GREEN}+{RESET} {pid}")
            if len(result["added"]) > 10:
                click.echo(f"    {DIM}... and {len(result['added']) - 10} more{RESET}")
            click.echo(f"  {DIM}{result['total']} papers total{RESET}")
        else:
            click.echo(
                f"  {DIM}Nothing to merge — '{result['target']}' already has all papers from '{result['source']}'{RESET}"
            )
    except AuthError:
        click.echo(
            f"{RED}[error] Authentication failed (API key invalid).{RESET}", err=True
        )
        sys.exit(1)
    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


@repo_cmd.command("log")
@click.option("-n", "--limit", default=20, type=int, help="Max commits to show")
@click.option("--branch", "-b", default=None, help="Show log for a specific branch")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def log_cmd(limit: int, branch: str | None, as_json: bool):
    """Show commit log for the active repo.

    \b
    Like `git log` — shows the commit history with SHAs, messages,
    and paper counts.

    Examples:
        paperclip repo log
        paperclip repo log -n 5
        paperclip repo log --branch safety-concerns
    """
    import json as json_mod

    from . import repo

    active = repo.get_active_repo()
    if not active:
        click.echo("No active repo. Use: paperclip repo init <name>")
        return

    commits = repo.get_log(branch=branch, limit=limit)

    if as_json:
        click.echo(json_mod.dumps(commits, indent=2, default=str))
        return

    if not commits:
        click.echo(f"{DIM}No commits yet. Use: paperclip repo commit -m \"message\"{RESET}")
        return

    active_branch = branch or repo._get_active_branch_name()
    click.echo(f"\n  {BOLD}Commit log{RESET} ({active}/{active_branch})\n")

    for c in commits:
        sha = c.get("sha", "?")[:8]
        parent = c.get("parent_sha", "")
        msg = c.get("message", "").split("\n")[0]
        count = c.get("paper_count", 0)
        ts = str(c.get("timestamp", ""))[:19].replace("T", " ")

        click.echo(f"  {YELLOW}{sha}{RESET} {msg}")
        click.echo(f"    {DIM}{count} papers  {ts}{RESET}")
        if parent:
            click.echo(f"    {DIM}parent: {parent[:8]}{RESET}")
        click.echo()


@repo_cmd.command("history")
@click.option("--tool", "-t", default=None, help="Filter by tool name (e.g. search_papers)")
@click.option("--page", "-p", default=1, type=int, help="Page number")
@click.option("--per-page", "-n", default=20, type=int, help="Results per page")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def history_cmd(tool: str | None, page: int, per_page: int, as_json: bool):
    """Show command audit trail for the active repo.

    \b
    Examples:
        paperclip repo history
        paperclip repo history -t search_papers
        paperclip repo history -n 10
        paperclip repo history --json
    """
    from . import repo as repo_module
    import json as json_mod

    active = repo_module.get_active_repo()
    if not active:
        click.echo("No active repo. Use: paperclip repo init <name>")
        return

    result = repo_module.get_history(
        tool_name=tool,
        page=page,
        per_page=per_page,
    )
    entries = result.get("entries", [])
    total = result.get("total", 0)

    if as_json:
        click.echo(json_mod.dumps(result, indent=2, default=str))
        return

    if not entries:
        click.echo(f"{DIM}No command history found.{RESET}")
        return

    click.echo(f"\n  {BOLD}Command history{RESET} ({active}) — {total} total\n")

    for e in entries:
        ts = str(e.get("created_at", ""))[:19].replace("T", " ")
        tool_name = e.get("tool_name", "?")
        cmd = e.get("command", "")
        doc_ids = e.get("document_ids", [])
        exit_c = e.get("exit_code", 0)

        mark = f"{GREEN}✓{RESET}" if exit_c == 0 else f"{RED}✗{RESET}"
        click.echo(f"  {mark} {CYAN}{tool_name}{RESET}  {DIM}{ts}{RESET}")

        if cmd:
            display_cmd = cmd[:120] + ("..." if len(cmd) > 120 else "")
            click.echo(f"    {display_cmd}")

        if doc_ids:
            click.echo(f"    {DIM}docs: {', '.join(doc_ids[:5])}{RESET}")
            if len(doc_ids) > 5:
                click.echo(f"    {DIM}      ... and {len(doc_ids) - 5} more{RESET}")

        summary = e.get("result_summary", "")
        if summary:
            display = summary[:200] + ("..." if len(summary) > 200 else "")
            click.echo(f"    {DIM}→ {display}{RESET}")
        click.echo()

    if total > page * per_page:
        click.echo(f"  {DIM}Page {page}/{(total + per_page - 1) // per_page} — use -p {page + 1} for next{RESET}\n")


# ── Export ────────────────────────────────────────────────────────


@repo_cmd.command("export")
@click.argument("format", type=click.Choice(["bibtex", "bib", "ris", "markdown", "md", "csv"]))
@click.option(
    "-o", "--output", "outfile", default=None, help="Write to file instead of stdout"
)
def export_cmd(format: str, outfile: str | None):
    """Export the active repo as BibTeX, RIS, Markdown, or CSV.

    \b
    Examples:
        paperclip repo export bibtex > select-trial.bib
        paperclip repo export bib > select-trial.bib
        paperclip repo export ris -o select-trial.ris
        paperclip repo export markdown -o review.md
        paperclip repo export md -o review.md
        paperclip repo export csv -o papers.csv
    """
    from . import repo

    try:
        content = repo.export_repo(format)

        if outfile:
            with open(outfile, "w") as f:
                f.write(content)
            click.echo(f"  {GREEN}✓{RESET} Exported {format} → {outfile}", err=True)
        else:
            click.echo(content)

    except ValueError as e:
        click.echo(f"{RED}[error] {e}{RESET}", err=True)
        sys.exit(1)


# ── Timeline ──────────────────────────────────────────────────────


# ── Server-proxied commands ───────────────────────────────────────
# search, lookup, sql, bash, grep, cat, head, etc. are all handled by
# _PaperclipGroup's catch-all proxy — no explicit registration needed.


# ── Results helpers ───────────────────────────────────────────────


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def _parse_papers_from_output(output: str) -> list[dict]:
    """Parse formatted search/lookup output into paper records for CSV."""
    text = _strip_ansi(output)
    records: list[dict] = []

    entries = re.split(r"\n(?=\s+\d+\.\s)", text)
    for entry in entries:
        lines = entry.strip().split("\n")
        if not lines:
            continue
        m = re.match(r"\s*(\d+)\.\s+(.+)", lines[0])
        if not m:
            continue

        record: dict = {"title": m.group(2).strip()}
        remaining = [ln.strip() for ln in lines[1:] if ln.strip()]

        for line in remaining:
            if line.startswith("https://"):
                record.setdefault("url", line)
            elif line.startswith("doi:"):
                record.setdefault("url", f"https://doi.org/{line[4:]}")
            elif line.startswith('"'):
                record["abstract"] = line.strip('"')
            elif "\u00b7" in line or "·" in line:
                sep = "\u00b7" if "\u00b7" in line else "·"
                parts = [p.strip() for p in line.split(sep)]
                if parts:
                    record["id"] = parts[0]
                if len(parts) >= 2:
                    record["source"] = parts[1]
                if len(parts) >= 3:
                    record["date"] = parts[2]
            elif "authors" not in record:
                record["authors"] = line

        records.append(record)
    return records


def _paper_url_from_record(record: dict) -> str:
    doc_id = str(record.get("document_id") or record.get("id") or "")
    source = str(record.get("source") or "").lower()
    doi = str(record.get("doi") or "")

    if doc_id.startswith("PMC"):
        return f"https://www.ncbi.nlm.nih.gov/pmc/articles/{doc_id}/"
    if source == "arxiv" or doc_id.startswith(("arx_", "arxiv_")):
        arxiv_id = re.sub(r"^(arx|arxiv)_", "", doc_id)
        for category in (
            "astro-ph",
            "cond-mat",
            "cs",
            "gr-qc",
            "hep-ex",
            "hep-lat",
            "hep-ph",
            "hep-th",
            "math",
            "nlin",
            "nucl-ex",
            "nucl-th",
            "physics",
            "q-bio",
            "quant-ph",
            "stat",
        ):
            suffix = arxiv_id[len(category) :] if arxiv_id.startswith(category) else ""
            if suffix and suffix[0].isdigit():
                arxiv_id = f"{category}/{suffix}"
                break
        return f"https://arxiv.org/abs/{arxiv_id}"
    if doi:
        return f"https://doi.org/{doi}"
    return ""


def _format_full_papers_result(data: dict) -> str | None:
    result_data = data.get("result_data")
    if not isinstance(result_data, dict):
        return None
    papers = result_data.get("papers")
    if not isinstance(papers, list):
        return None

    rid = data.get("result_id", "")
    lines = [f"Found {len(papers)} papers" + (f"  [{rid}]" if rid else ""), ""]
    for i, paper in enumerate(papers, 1):
        title = paper.get("title") or "Untitled"
        authors = paper.get("authors") or ""
        doc_id = paper.get("document_id") or paper.get("id") or "?"
        source = paper.get("source") or ""
        date = (
            paper.get("pub_date")
            or paper.get("pub_year")
            or paper.get("month_year")
            or ""
        )
        abstract = paper.get("abstract_snippet") or paper.get("abstract") or ""
        url = _paper_url_from_record(paper)

        lines.append(f"  {BOLD}{i}. {title}{RESET}")
        if authors:
            short = str(authors)[:100] + ("..." if len(str(authors)) > 100 else "")
            lines.append(f"     {short}")
        meta = [str(doc_id)]
        if source:
            meta.append(str(source))
        if date:
            meta.append(str(date))
        lines.append(f"     {DIM}{' · '.join(meta)}{RESET}")
        if url:
            lines.append(f"     {CYAN}{url}{RESET}")
        if abstract:
            snippet = str(abstract).strip().replace("\n", " ")
            if len(snippet) > 220:
                snippet = snippet[:217] + "..."
            lines.append(f'     {DIM}"{snippet}"{RESET}')
        lines.append("")
    return "\n".join(lines)


def _results_picker(rows: list[dict]) -> int | None:
    """Interactive paginated picker for saved results."""
    if not sys.stdin.isatty():
        return None
    try:
        import termios
        import tty
    except (ImportError, AttributeError):
        return None

    n = len(rows)
    page_size = min(_RESULTS_PAGE_SIZE, n)
    total_pages = (n + page_size - 1) // page_size
    idx = 0
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    redraw_lines = page_size

    def _desc(r: dict) -> str:
        raw = r.get("raw_input", r.get("command", ""))
        return raw[:45] + ("..." if len(raw) > 45 else "")

    def _ts(r: dict) -> str:
        return (r.get("created_at") or "")[:16].replace("T", " ")

    def render(first: bool = False) -> None:
        page = idx // page_size
        start = page * page_size
        end = min(start + page_size, n)

        if not first:
            sys.stdout.write(f"\033[{redraw_lines}A\r")

        for i in range(start, start + page_size):
            if i < end:
                r = rows[i]
                rid = r.get("result_id", "?")
                desc = _desc(r)
                ts = _ts(r)
                if i == idx:
                    sys.stdout.write(
                        f"{CLR}  {CYAN}\u203a {rid}{RESET}  {desc}  {DIM}{ts}{RESET}\n"
                    )
                else:
                    sys.stdout.write(
                        f"{CLR}    {DIM}{rid}{RESET}  {desc}  {DIM}{ts}{RESET}\n"
                    )
            else:
                sys.stdout.write(f"{CLR}\n")

        pg = f"page {page + 1}/{total_pages}" if total_pages > 1 else ""
        paging = "n/p page \u00b7 " if total_pages > 1 else ""
        sys.stdout.write(
            f"{CLR}  {DIM}\u2191/\u2193 navigate \u00b7 enter save \u00b7 {paging}q quit  {pg}{RESET}"  # noqa: E501
        )
        sys.stdout.flush()

    click.echo(f"\n  {BOLD}Paperclip Results{RESET}")
    rule = "\u2500" * 40
    click.echo(f"  {DIM}{rule}{RESET}")
    click.echo(f"  {n} saved result{'s' if n != 1 else ''}\n")
    render(first=True)

    try:
        tty.setcbreak(fd)
        while True:
            ch = os.read(fd, 1)
            if ch == b"\x1b":
                b = os.read(fd, 1)
                if b == b"[":
                    arrow = os.read(fd, 1)
                    if arrow == b"A":
                        idx = (idx - 1) % n
                    elif arrow == b"B":
                        idx = (idx + 1) % n
                render()
            elif ch in (b"\r", b"\n"):
                sys.stdout.write("\n\n")
                sys.stdout.flush()
                return idx
            elif ch == b"n" and total_pages > 1:
                page = idx // page_size
                if page < total_pages - 1:
                    idx = (page + 1) * page_size
                    render()
            elif ch == b"p" and total_pages > 1:
                page = idx // page_size
                if page > 0:
                    idx = (page - 1) * page_size
                    render()
            elif ch in (b"q", b"\x03"):
                sys.stdout.write("\n")
                sys.stdout.flush()
                return None
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ── results command ───────────────────────────────────────────────


@main.command()
@click.argument("result_id", required=False, default=None)
@click.option("--list", "list_all", is_flag=True, help="Non-interactive list")
@click.option("--save", "save_path", default=None, help="Export to file (CSV or TXT)")
@click.option("--export-bundle", default=None, help="Export a portable cohort bundle directory")
@click.option("--import-bundle", default=None, help="Import a portable cohort bundle directory")
@click.option("--save-as", default=None, help="Alias for an imported bundle")
def results(
    result_id: str | None, list_all: bool, save_path: str | None,
    export_bundle: str | None, import_bundle: str | None, save_as: str | None,
):
    """View and export saved search results.

    \b
    View a specific result:
        paperclip results s_4a2b61f6

    Export to CSV:
        paperclip results s_4a2b61f6 --save results.csv

    Export or import a portable cohort bundle:
        paperclip results s_4a2b61f6 --export-bundle cohort/
        paperclip results --import-bundle cohort/ --save-as restored_cohort

    List all saved results:
        paperclip results --list
    """
    client = _get_client()

    if import_bundle:
        if result_id or save_path or export_bundle or list_all:
            raise click.UsageError(
                "--import-bundle cannot be combined with a result ID, --save, "
                "--export-bundle, or --list"
            )
        from .cohort_bundle import BundleError, load_bundle

        try:
            papers, manifest = load_bundle(import_bundle)
            imported = client.results.import_bundle(
                papers,
                provenance={
                    "original_result_id": manifest.get("result_id"),
                    "original_config_hash": manifest.get("config_hash"),
                    "bundle_schema_version": manifest.get("schema_version"),
                },
                save_as=save_as,
            )
        except (BundleError, OSError, PaperclipError) as exc:
            raise click.ClickException(str(exc)) from exc
        suffix = f" (alias: {save_as})" if save_as else ""
        click.echo(
            f"  {GREEN}\u2713{RESET} Loaded {imported['count']} papers as "
            f"{BOLD}{imported['result_id']}{RESET}{suffix}"
        )
        return
    if save_as:
        raise click.UsageError("--save-as requires --import-bundle")
    if export_bundle and not result_id:
        raise click.UsageError("--export-bundle requires a result ID or alias")
    if save_path and export_bundle:
        raise click.UsageError("--save and --export-bundle cannot be combined")

    def _fetch_result(rid: str) -> dict | None:
        try:
            data = client.results.get(rid)
        except NetworkError:
            click.echo(f"{RED}[error] Could not reach the server.{RESET}", err=True)
            click.echo(
                f"{DIM}       If this persists, try: paperclip login{RESET}", err=True
            )
            return None
        except PaperclipError as exc:
            if "not found" in str(exc).lower():
                click.echo(f"{RED}[error] Result {rid} not found.{RESET}", err=True)
            else:
                click.echo(
                    f"{RED}[error] Something went wrong. Please try again.{RESET}",
                    err=True,
                )
            return None
        return data.raw or {
            "result_id": data.result_id,
            "output": data.output,
            "command": data.command,
            "raw_input": data.raw_input,
            "created_at": data.created_at,
            "latency_ms": data.latency_ms,
        }

    def _export(rid: str, data: dict, dest_path: str) -> None:
        output = data.get("output", "")
        records = _parse_papers_from_output(output)
        dest = Path(dest_path).expanduser().resolve()

        if not records or dest.suffix != ".csv":
            dest.write_text(_strip_ansi(output))
            click.echo(f"  {GREEN}\u2713{RESET} Saved to {BOLD}{dest}{RESET}")
            return

        fieldnames = ["title", "authors", "id", "source", "date", "url", "abstract"]
        with open(dest, "w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(records)

        click.echo(
            f"  {GREEN}\u2713{RESET} Saved {len(records)} papers to {BOLD}{dest}{RESET}"
        )

    if result_id:
        if export_bundle:
            from .cohort_bundle import (
                BundleError,
                export_bundle as export_cohort_bundle,
            )

            try:
                dest, manifest = export_cohort_bundle(client, result_id, export_bundle)
            except (BundleError, OSError, PaperclipError) as exc:
                raise click.ClickException(str(exc)) from exc
            click.echo(
                f"  {GREEN}\u2713{RESET} Exported {manifest['paper_count']} papers "
                f"to {BOLD}{dest}{RESET}"
            )
            return
        data = _fetch_result(result_id)
        if not data:
            return
        if save_path:
            _export(result_id, data, save_path)
            return
        output = data.get("output", "")
        raw_input = data.get("raw_input", data.get("command", ""))
        if raw_input:
            click.echo(f"  {DIM}Query: {raw_input}{RESET}")
        full_output = _format_full_papers_result(data)
        if full_output:
            click.echo(full_output)
        elif output:
            click.echo(output)
        return

    try:
        rows = client.results.list()
    except NetworkError:
        click.echo(f"{RED}[error] Could not reach the server.{RESET}", err=True)
        click.echo(
            f"{DIM}       If this persists, try: paperclip login{RESET}", err=True
        )
        sys.exit(1)
    except PaperclipError:
        click.echo(
            f"{RED}[error] Something went wrong. Please try again.{RESET}", err=True
        )
        sys.exit(1)

    if not rows:
        click.echo(f"{DIM}No saved results. Run a search or map first.{RESET}")
        return

    rows_as_dicts = [r.raw or _resultrow_to_dict(r) for r in rows]

    if list_all or not sys.stdin.isatty():
        click.echo(f"{BOLD}Recent results ({len(rows_as_dicts)}):{RESET}\n")
        for r in rows_as_dicts:
            rid = r.get("result_id", "?")
            raw = r.get("raw_input", r.get("command", ""))
            ts = (r.get("created_at") or "")[:16].replace("T", " ")
            click.echo(f"  {rid}  {DIM}{raw}  {ts}{RESET}")
        return

    choice = _results_picker(rows_as_dicts)
    if choice is None:
        return

    selected = rows_as_dicts[choice]
    rid = selected["result_id"]
    data = _fetch_result(rid)
    if data:
        output = data.get("output", "")
        records = _parse_papers_from_output(output)
        default_ext = ".csv" if records else ".txt"
        path = click.prompt("  Save to", default=f"./{rid}{default_ext}")
        _export(rid, data, path)


def _resultrow_to_dict(r: ResultRow) -> dict:
    """Fallback translation for ResultRow → dict when ``raw`` is empty."""
    return {
        "result_id": r.result_id,
        "command": r.command,
        "raw_input": r.raw_input,
        "latency_ms": r.latency_ms,
        "created_at": r.created_at,
    }


_PAPER_REPO_COMMANDS = {
    "repo",
}

if not _FEATURE_FLAGS_FILE.exists():
    try:
        _fetch_feature_flags()
    except Exception:
        pass

if not _is_paper_repos_enabled():
    for _cmd_name in _PAPER_REPO_COMMANDS:
        main.commands.pop(_cmd_name, None)

if not _is_library_enabled():
    main.commands.pop("library", None)
    main.commands.pop("import", None)


if __name__ == "__main__":
    main()
from .sync import sync_group, upload_command, cp_command, mv_command, share_command, unshare_command
from .fetch import fetch_command
main.add_command(sync_group)
main.add_command(upload_command)
main.add_command(cp_command)
main.add_command(mv_command)
main.add_command(share_command)
main.add_command(unshare_command)
main.add_command(fetch_command)
from .git import git_cmd
main.add_command(git_cmd)
from .citation_explorer import register_cli as _register_citation_explorer
_register_citation_explorer(main)
