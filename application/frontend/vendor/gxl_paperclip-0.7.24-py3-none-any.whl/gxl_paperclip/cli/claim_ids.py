"""Stable identifiers for generic Paperclip repo claims."""

from __future__ import annotations

import hashlib
import json


def stable_claim_id(doc_id: str, claim: str, annotation: dict | None = None) -> str:
    """Hash the stable identity fields shared by every repo claim."""
    identity = json.dumps(
        {
            "document_id": doc_id,
            "claim": claim,
            "lines": (annotation or {}).get("lines"),
            "source_locations": (annotation or {}).get("source_locations"),
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=str,
    )
    return "clm_" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]
