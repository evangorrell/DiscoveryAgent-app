"""Citation-explorer workflow: resolve a paper, union citing edges, match full text.

Emits newline-delimited JSON progress events. Designed for both the
``paperclip citation-explorer`` CLI command and the local web app backend.
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from difflib import SequenceMatcher
from html import unescape as html_unescape
from typing import Any, Callable, Iterator
from urllib.error import HTTPError, URLError
from urllib.parse import unquote as urllib_unquote
from urllib.parse import parse_qs, urljoin, urlparse
from urllib.request import Request, urlopen

from .citation_providers import (
    CitingRecord,
    ProviderBundle,
    collect_providers,
    extract_arxiv_id,
    normalize_doi,
    normalize_title,
    user_agent,
)

logger = logging.getLogger(__name__)

EventCallback = Callable[[dict[str, Any]], None]
CancelCheck = Callable[[], bool]

DEFAULT_MATCH_WORKERS = 8
DEFAULT_CONTEXT_WORKERS = 4
DEFAULT_MAP_LIMIT = 100
MAX_TITLE_CANDIDATES = 10
SCORE_AGENT_MODEL = os.environ.get(
    "CITATION_EXPLORER_MODEL", "anthropic/claude-sonnet-5"
)
SCORE_AGENT_SYSTEM_PROMPT = """You are the Paperclip citation-importance scorer.
You receive a reduce synthesis of how citing papers refer to one TARGET paper.
Score specificity and importance only from that evidence. Do not invent passages.
Return ONLY compact JSON with keys score, label, rationale, evidence."""

_HTML_DOI_META_RE = re.compile(
    r'<meta[^>]+(?:name|property)=["\'](?:citation_doi|dc\.identifier|doi)["\'][^>]+'
    r'content=["\']([^"\']+)["\']',
    re.IGNORECASE,
)
_HTML_DOI_META_RE_ALT = re.compile(
    r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+'
    r'(?:name|property)=["\'](?:citation_doi|dc\.identifier|doi)["\']',
    re.IGNORECASE,
)
_HTML_CANONICAL_DOI_RE = re.compile(
    r"""(?is)<link[^>]+rel=["']canonical["'][^>]+href=["']https?://(?:dx\.)?doi\.org/([^"'?#\s]+)["']"""
)
_HTML_CANONICAL_DOI_RE_ALT = re.compile(
    r"""(?is)<link[^>]+href=["']https?://(?:dx\.)?doi\.org/([^"'?#\s]+)["'][^>]+rel=["']canonical["']"""
)
_JSON_LD_RE = re.compile(
    r"""(?is)<script[^>]+type=["']application/ld\+json["'][^>]*>(.*?)</script>"""
)
_LOOKUP_CITATION_KEY_RE = re.compile(r'Citation key:\s*"([^"]+)"')
_LOOKUP_MENTION_RE = re.compile(r"^\[(\d+)\] Section:\s*(.+)$")
_LOOKUP_LINE_RE = re.compile(r"^(>>>|   )\s*\[(\d+)\]\s*(.*)$")


@dataclass
class TargetPaper:
    """Resolved target paper metadata."""

    query: str
    doi: str | None = None
    paperclip_id: str | None = None
    title: str = ""
    pmid: str | None = None
    arxiv_id: str | None = None
    year: int | None = None
    authors: str = ""
    source: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CitationContext:
    """One in-text use of the target inside a citing paper."""

    section: str = ""
    line: int | None = None
    text: str = ""
    citation_key: str = ""
    block_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class MatchedCitingPaper:
    """A citing work after Paperclip matching and optional context extraction."""

    title: str = ""
    doi: str | None = None
    pmid: str | None = None
    arxiv_id: str | None = None
    year: int | None = None
    providers: list[str] = field(default_factory=list)
    paperclip_id: str | None = None
    has_fulltext: bool = False
    bibliography_only: bool = False
    contexts: list[CitationContext] = field(default_factory=list)
    summary: str = ""
    impact_role: str = "unclassified"
    limitation_signal: bool = False
    analysis_status: str = "not_mapped"
    match_method: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            **{k: v for k, v in asdict(self).items() if k != "contexts"},
            "contexts": [c.to_dict() for c in self.contexts],
        }


@dataclass
class ImportanceScore:
    """0-100 importance of the target paper in citing full text."""

    score: int = 0
    label: str = "nominal"
    rationale: str = ""
    evidence: list[str] = field(default_factory=list)
    method: str = "none"  # agent | reduce | llm | heuristic | empty
    prompt: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AnalysisResult:
    """Final typed result of a citation-explorer run."""

    target: TargetPaper
    counts: dict[str, int] = field(default_factory=dict)
    checks: dict[str, Any] = field(default_factory=dict)
    provider_edge_counts: dict[str, int] = field(default_factory=dict)
    provider_errors: dict[str, str] = field(default_factory=dict)
    citing_papers: list[MatchedCitingPaper] = field(default_factory=list)
    themes: str = ""
    importance: ImportanceScore | None = None
    candidates: list[dict[str, Any]] = field(default_factory=list)
    cancelled: bool = False
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "target": self.target.to_dict(),
            "counts": dict(self.counts),
            "checks": dict(self.checks),
            "provider_edge_counts": dict(self.provider_edge_counts),
            "provider_errors": dict(self.provider_errors),
            "citing_papers": [p.to_dict() for p in self.citing_papers],
            "themes": self.themes,
            "importance": self.importance.to_dict() if self.importance else None,
            "candidates": list(self.candidates),
            "cancelled": self.cancelled,
            "error": self.error,
        }


def _deduplicate_matched_papers(
    papers: list[MatchedCitingPaper],
) -> list[MatchedCitingPaper]:
    """Merge provider records that resolve to the same citing paper."""
    merged: dict[str, MatchedCitingPaper] = {}
    unkeyed = 0
    for paper in papers:
        if paper.paperclip_id:
            key = f"paperclip:{paper.paperclip_id.lower()}"
        elif paper.doi:
            key = f"doi:{paper.doi.lower()}"
        elif paper.pmid:
            key = f"pmid:{paper.pmid}"
        else:
            unkeyed += 1
            key = f"unkeyed:{unkeyed}"
        existing = merged.get(key)
        if existing is None:
            merged[key] = paper
            continue
        existing.providers = list(
            dict.fromkeys([*existing.providers, *paper.providers])
        )
        existing.has_fulltext = existing.has_fulltext or paper.has_fulltext
        for field_name in (
            "title",
            "doi",
            "pmid",
            "arxiv_id",
            "year",
            "paperclip_id",
            "match_method",
        ):
            if not getattr(existing, field_name) and getattr(paper, field_name):
                setattr(existing, field_name, getattr(paper, field_name))
    return list(merged.values())


def emit_event(
    callback: EventCallback | None,
    event_type: str,
    **payload: Any,
) -> dict[str, Any]:
    """Build and optionally deliver a progress event."""
    event = {"type": event_type, **payload}
    if callback is not None:
        callback(event)
    return event


def _cancelled(cancel: CancelCheck | None) -> bool:
    return bool(cancel and cancel())


def classify_query(query: str) -> tuple[str, str]:
    """Classify user input as DOI, corpus identifier, URL, or title.

    Returns ``(kind, normalized_value)``.
    """
    text = (query or "").strip()
    if not text:
        return "empty", ""

    pmc_match = re.fullmatch(r"(?i)(?:pmcid:\s*)?(PMC\d+)", text)
    if pmc_match:
        return "pmc", pmc_match.group(1).upper()

    pmid_match = re.fullmatch(r"(?i)(?:pmid:\s*)?(\d{6,9})", text)
    if pmid_match:
        return "pmid", pmid_match.group(1)

    doi = normalize_doi(text)
    if doi and (text.lower().startswith("10.") or "doi.org/" in text.lower() or text.lower().startswith("doi:")):
        return "doi", doi

    arxiv = extract_arxiv_id(text)
    if arxiv and ("arxiv" in text.lower() or re.fullmatch(r"\d{4}\.\d{4,5}(?:v\d+)?", text.strip())):
        return "arxiv", arxiv

    parsed = urlparse(text)
    if parsed.scheme in ("http", "https") and parsed.netloc:
        if doi:
            return "doi", doi
        if arxiv:
            return "arxiv", arxiv
        return "url", text

    if doi and " " not in text and "/" in text:
        return "doi", doi

    return "title", text


def _doi_from_json_ld(value: Any) -> str | None:
    """Read DOI-specific fields from JSON-LD without scanning article text."""
    if isinstance(value, list):
        for item in value:
            doi = _doi_from_json_ld(item)
            if doi:
                return doi
        return None
    if not isinstance(value, dict):
        return None

    for key in ("doi", "DOI"):
        doi = normalize_doi(value.get(key))
        if doi:
            return doi
    for key in ("sameAs", "@id"):
        raw = value.get(key)
        values = raw if isinstance(raw, list) else [raw]
        for item in values:
            if isinstance(item, str) and "doi.org/" in item.lower():
                doi = normalize_doi(item)
                if doi:
                    return doi
    identifier = value.get("identifier")
    identifiers = identifier if isinstance(identifier, list) else [identifier]
    for item in identifiers:
        if isinstance(item, dict):
            property_id = str(item.get("propertyID") or "").lower()
            if property_id == "doi":
                doi = normalize_doi(item.get("value"))
                if doi:
                    return doi
        elif isinstance(item, str) and (
            item.lower().startswith("doi:") or "doi.org/" in item.lower()
        ):
            doi = normalize_doi(item)
            if doi:
                return doi
    graph = value.get("@graph")
    return _doi_from_json_ld(graph) if graph is not None else None


def extract_doi_from_html(html: str) -> str | None:
    """Pull a DOI only from trusted page-identity metadata."""
    for pattern in (_HTML_DOI_META_RE, _HTML_DOI_META_RE_ALT):
        match = pattern.search(html)
        if match:
            return normalize_doi(match.group(1))
    for pattern in (_HTML_CANONICAL_DOI_RE, _HTML_CANONICAL_DOI_RE_ALT):
        match = pattern.search(html)
        if match:
            return normalize_doi(urllib_unquote(match.group(1)))
    for match in _JSON_LD_RE.finditer(html or ""):
        try:
            payload = json.loads(html_unescape(match.group(1)).strip())
        except (json.JSONDecodeError, TypeError):
            continue
        doi = _doi_from_json_ld(payload)
        if doi:
            return doi
    # Do not scan arbitrary page text. The first DOI there is often a
    # reference, not the DOI of the page itself.
    return None


# Elsevier/Cell PII, e.g. S2666-3899(23)00130-7
_ELSEVIER_PII_RE = re.compile(
    r"(?i)\b(S\d{4}-\d{3,4}\(\d{2}\)\d{4,7}-\d)\b"
)
_NATURE_ARTICLE_RE = re.compile(
    r"(?i)nature\.com/articles/(s\d{4,}-\d{2,}-\d+)"
)
_PMC_URL_RE = re.compile(r"(?i)/pmc/articles/(PMC\d+)")
_PUBMED_URL_RE = re.compile(r"(?i)ncbi\.nlm\.nih\.gov/pubmed/(\d+)")
_SCHOLAR_HOST_RE = re.compile(r"(?i)(?:^|\.)scholar\.google\.")
_SCHOLAR_DOI_LINK_RE = re.compile(
    r"""(?i)href=["']https?://(?:dx\.)?doi\.org/([^"'?#\s]+)"""
)
_SCHOLAR_RESULT_RE = re.compile(
    r"""(?is)<h3[^>]*class=["'][^"']*\bgs_rt\b[^"']*["'][^>]*>.*?<a[^>]+href=["']([^"']+)["'][^>]*>(.*?)</a>.*?</h3>"""
)
_SCHOLAR_CITATION_RE = re.compile(
    r"""(?is)<a[^>]*class=["'][^"']*\bgsc_oci_title_link\b[^"']*["'][^>]+href=["']([^"']+)["'][^>]*>(.*?)</a>"""
)
_HTML_TITLE_META_RE = re.compile(
    r"""(?is)<meta[^>]+(?:name|property)=["'](?:citation_title|dc\.title|og:title)["'][^>]+content=["']([^"']+)["']"""
)
_HTML_TITLE_META_RE_ALT = re.compile(
    r"""(?is)<meta[^>]+content=["']([^"']+)["'][^>]+(?:name|property)=["'](?:citation_title|dc\.title|og:title)["']"""
)


def extract_publisher_ids_from_url(url: str) -> dict[str, str]:
    """Extract publisher-native identifiers from a paper URL path."""
    parsed = urlparse(url)
    path = urllib_unquote(parsed.path or "")
    ids: dict[str, str] = {}
    pii = _ELSEVIER_PII_RE.search(path) or _ELSEVIER_PII_RE.search(url)
    if pii:
        ids["pii"] = pii.group(1).upper().replace(" ", "")
    nature = _NATURE_ARTICLE_RE.search(url)
    if nature:
        ids["nature_id"] = nature.group(1).lower()
    pmc = _PMC_URL_RE.search(url)
    if pmc:
        ids["pmcid"] = pmc.group(1).upper()
    pubmed = _PUBMED_URL_RE.search(url)
    if pubmed:
        ids["pmid"] = pubmed.group(1)
    return ids


def is_google_scholar_url(url: str) -> bool:
    """Return True for Google Scholar hosts in any country domain."""
    return bool(_SCHOLAR_HOST_RE.search((urlparse(url).hostname or "").lower()))


def extract_google_scholar_hints(
    url: str,
    html: str = "",
) -> dict[str, str]:
    """Extract a destination URL, DOI, or title from a Scholar paper URL."""
    parsed = urlparse(url)
    if not _SCHOLAR_HOST_RE.search((parsed.hostname or "").lower()):
        return {}

    hints: dict[str, str] = {}
    params = parse_qs(parsed.query)
    destination = (params.get("url") or [""])[0].strip()
    if destination:
        destination = urllib_unquote(destination)
        hints["destination_url"] = urljoin(url, destination)
        direct_doi = normalize_doi(destination)
        if direct_doi:
            hints["doi"] = direct_doi

    # A Scholar search-result URL can carry the exact title in q.
    scholar_query = (params.get("q") or [""])[0].strip()
    if scholar_query and len(scholar_query.split()) >= 3:
        hints["title"] = scholar_query.strip('"')

    if not html:
        return hints

    doi_link = _SCHOLAR_DOI_LINK_RE.search(html)
    if doi_link:
        doi = normalize_doi(urllib_unquote(doi_link.group(1)))
        if doi:
            hints["doi"] = doi

    for pattern in (_HTML_TITLE_META_RE, _HTML_TITLE_META_RE_ALT):
        title_match = pattern.search(html)
        if title_match:
            hints["title"] = html_unescape(title_match.group(1)).strip()
            break

    result_match = _SCHOLAR_CITATION_RE.search(html) or _SCHOLAR_RESULT_RE.search(html)
    if result_match:
        result_url, title_html = result_match.groups()
        result_url = html_unescape(result_url).strip()
        absolute_result_url = urljoin(url, result_url)
        if result_url and not is_google_scholar_url(absolute_result_url):
            hints.setdefault("destination_url", absolute_result_url)
        elif result_url:
            nested = extract_google_scholar_hints(absolute_result_url)
            if nested.get("destination_url"):
                hints.setdefault("destination_url", nested["destination_url"])
            if nested.get("doi"):
                hints.setdefault("doi", nested["doi"])
        title = re.sub(r"<[^>]+>", "", title_html)
        title = re.sub(r"^\s*\[[^\]]+\]\s*", "", html_unescape(title)).strip()
        if title:
            hints["title"] = title
    return hints


def _fetch_html_page(
    url: str,
    *,
    opener: Callable[[str], str] | None = None,
) -> str:
    if opener is not None:
        return opener(url)
    request = Request(
        url,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (compatible; GXL-Citation-Explorer/0.1; "
                "+https://gxl.ai; mailto:dev@gxl.ai)"
            ),
            "Accept": "text/html,application/xhtml+xml",
        },
    )
    with urlopen(request, timeout=30) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        return response.read(512_000).decode(charset, errors="replace")


def resolve_doi_via_europepmc(query: str) -> str | None:
    """Resolve a DOI through Europe PMC search (PII, PMCID, title fragment, etc.)."""
    from .citation_providers import get_json, _query

    payload = get_json(
        _query(
            "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
            {"query": query, "format": "json", "pageSize": 5},
        )
    )
    rows = (payload.get("resultList") or {}).get("result") or []
    for row in rows:
        doi = normalize_doi(row.get("doi"))
        if doi:
            return doi
    return None


def resolve_doi_via_crossref_query(query: str) -> str | None:
    """Best-effort Crossref bibliographic lookup for a publisher id or title."""
    from .citation_providers import get_json, _query

    contact = __import__("os").getenv("CITATIONS_CONTACT_EMAIL", "dev@gxl.ai")
    payload = get_json(
        _query(
            "https://api.crossref.org/works",
            {
                "query.bibliographic": query,
                "rows": 5,
                "mailto": contact,
            },
        )
    )
    items = (payload.get("message") or {}).get("items") or []
    query_norm = query.lower().replace(" ", "")
    for item in items:
        doi = normalize_doi(item.get("DOI"))
        if not doi:
            continue
        # Prefer exact alternative-id / PII matches when present.
        alts = item.get("alternative-id") or []
        if any(str(a).lower().replace(" ", "") == query_norm for a in alts):
            return doi
    # Fall back to first result only when the query looks like a PII/id.
    if items and _ELSEVIER_PII_RE.search(query):
        # Crossref often fails to rank Elsevier PIIs first; skip weak matches.
        return None
    return normalize_doi(items[0].get("DOI")) if items else None


def fetch_doi_from_url(url: str, *, opener: Callable[[str], str] | None = None) -> str | None:
    """Resolve a publisher URL to a DOI.

    Order:
    1. Direct DOI already in the URL
    2. HTML metadata from the page (when reachable)
    3. Publisher identifiers in the path (Elsevier PII, PMCID, ...) via Europe PMC
    """
    direct = normalize_doi(url)
    if direct and ("doi.org/" in url.lower() or url.lower().startswith("doi:")):
        return direct

    html_error: Exception | None = None
    if opener is not None:
        try:
            html = opener(url)
            doi = extract_doi_from_html(html)
            if doi:
                return doi
        except Exception as exc:  # noqa: BLE001 - fall through to id lookup
            html_error = exc
    else:
        request = Request(
            url,
            headers={
                # Browser-like UA: some publishers (Cell/Elsevier) block library UAs.
                "User-Agent": (
                    "Mozilla/5.0 (compatible; GXL-Citation-Explorer/0.1; "
                    "+https://gxl.ai; mailto:dev@gxl.ai)"
                ),
                "Accept": "text/html,application/xhtml+xml",
            },
        )
        try:
            with urlopen(request, timeout=30) as response:
                charset = response.headers.get_content_charset() or "utf-8"
                html = response.read(512_000).decode(charset, errors="replace")
            doi = extract_doi_from_html(html)
            if doi:
                return doi
        except Exception as exc:  # noqa: BLE001
            html_error = exc

    ids = extract_publisher_ids_from_url(url)
    for key in ("pii", "pmcid", "pmid", "nature_id"):
        value = ids.get(key)
        if not value:
            continue
        try:
            if key == "pmcid":
                doi = resolve_doi_via_europepmc(f"PMCID:{value}")
            elif key == "pmid":
                doi = resolve_doi_via_europepmc(f"EXT_ID:{value}")
            elif key == "pii":
                doi = resolve_doi_via_europepmc(value) or resolve_doi_via_crossref_query(
                    value
                )
            else:
                doi = resolve_doi_via_europepmc(value)
        except Exception as exc:  # noqa: BLE001
            logger.warning("DOI fallback via %s=%s failed: %s", key, value, exc)
            continue
        if doi:
            return doi

    if html_error is not None:
        raise html_error
    return None


def _paper_from_lookup_hit(hit: dict[str, Any]) -> dict[str, Any]:
    doc_id = (
        hit.get("document_id")
        or hit.get("id")
        or hit.get("pmc_id")
        or hit.get("paper_id")
        or ""
    )
    year = hit.get("pub_year") or hit.get("year")
    try:
        year_i = int(year) if year is not None else None
    except (TypeError, ValueError):
        year_i = None
    return {
        "paperclip_id": str(doc_id) if doc_id else None,
        "doi": normalize_doi(hit.get("doi")),
        "title": hit.get("title") or "",
        "pmid": str(hit["pmid"]) if hit.get("pmid") else None,
        "authors": hit.get("authors") or hit.get("first_author") or "",
        "year": year_i,
        "source": hit.get("source") or "",
        "arxiv_id": extract_arxiv_id(str(doc_id))
        if str(doc_id).startswith(("arx_", "arxiv"))
        else extract_arxiv_id(hit.get("doi")),
    }


_ANSI_RE = re.compile(r"\033\[[0-9;]*m")
_LOOKUP_BLOCK_RE = re.compile(
    r"(?m)^\s*\d+\.\s+(?P<title>.+?)\s*$"
    r"(?:\n\s+(?P<authors>.+?))?"
    r"\n\s+(?P<id>(?:PMC\d+|(?:bio|med|arx)_[0-9a-f]+|[0-9a-f-]{36}))"
    r"(?:\s*·\s*(?P<source>[^·\n]+))?"
    r"(?:\s*·\s*(?P<year>\d{4}))?",
)
_DOC_ID_LINE_RE = re.compile(
    r"(?m)^\s*((?:PMC\d+)|(?:(?:bio|med|arx)_[0-9a-f]{8,})|(?:[0-9a-f]{8}-[0-9a-f-]{27}))\b"
)


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text or "")


def _parse_lookup_text(output: str) -> list[dict[str, Any]]:
    """Parse Paperclip lookup CLI text into paper dicts."""
    text = _strip_ansi(output)
    papers: list[dict[str, Any]] = []
    for match in _LOOKUP_BLOCK_RE.finditer(text):
        year_raw = match.group("year")
        try:
            year = int(year_raw) if year_raw else None
        except ValueError:
            year = None
        source = (match.group("source") or "").strip()
        papers.append(
            {
                "paperclip_id": match.group("id"),
                "doi": None,
                "title": match.group("title").strip(),
                "pmid": None,
                "authors": (match.group("authors") or "").strip(),
                "year": year,
                "source": source,
                "arxiv_id": extract_arxiv_id(match.group("id")),
            }
        )
    if papers:
        return papers

    # Minimal fallback: collect bare document ids if formatting changes
    for match in _DOC_ID_LINE_RE.finditer(text):
        doc_id = match.group(1)
        papers.append(
            {
                "paperclip_id": doc_id,
                "doi": None,
                "title": "",
                "pmid": None,
                "authors": "",
                "year": None,
                "source": "",
                "arxiv_id": extract_arxiv_id(doc_id),
            }
        )
    return papers


def _lookup_papers(client: Any, field: str, value: str, *, limit: int = 5) -> list[dict[str, Any]]:
    """Run ``client.lookup`` and return normalized paper dicts."""
    try:
        # Prefer execute so we can request --json when the server supports it.
        result = client.execute(
            "lookup",
            [field, value, "-n", str(limit), "--json"],
            timeout=60,
        )
    except Exception:
        try:
            result = client.lookup(field, value, limit=limit)
        except Exception as exc:  # noqa: BLE001
            logger.warning("lookup %s %s failed: %s", field, value, exc)
            return []

    papers = list(getattr(result, "papers", None) or [])
    if papers:
        normalized = [_paper_from_lookup_hit(p) for p in papers if isinstance(p, dict)]
        if field == "doi":
            for item in normalized:
                item["doi"] = item.get("doi") or normalize_doi(value)
        return normalized

    output = getattr(result, "output", "") or ""
    if not output.strip():
        return []

    # Structured JSON body (rare today; keep for forward compatibility)
    stripped = _strip_ansi(output).strip()
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            data = json.loads(stripped)
        except json.JSONDecodeError:
            data = None
        if isinstance(data, list):
            normalized = [_paper_from_lookup_hit(p) for p in data if isinstance(p, dict)]
        elif isinstance(data, dict):
            rows = data.get("papers") or data.get("results") or []
            normalized = [_paper_from_lookup_hit(p) for p in rows if isinstance(p, dict)]
        else:
            normalized = []
        if normalized:
            if field == "doi":
                for item in normalized:
                    item["doi"] = item.get("doi") or normalize_doi(value)
            return normalized

    parsed = _parse_lookup_text(output)
    if field == "doi":
        for item in parsed:
            item["doi"] = item.get("doi") or normalize_doi(value)
    if field == "pmid":
        for item in parsed:
            item["pmid"] = item.get("pmid") or value
    if field == "title" and len(parsed) == 1 and not parsed[0].get("title"):
        parsed[0]["title"] = value
    return parsed


def _search_papers(client: Any, query: str, *, limit: int = 10) -> list[dict[str, Any]]:
    """Use Paperclip search when metadata lookup cannot resolve free text."""
    try:
        result = client.search(query, limit=limit, timeout=60)
    except Exception:
        try:
            result = client.execute(
                "search",
                [query, "-n", str(limit), "--json"],
                timeout=60,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Paperclip search failed for %s: %s", query, exc)
            return []
    papers = list(getattr(result, "papers", None) or [])
    if papers:
        return [_paper_from_lookup_hit(paper) for paper in papers if isinstance(paper, dict)]
    output = getattr(result, "output", "") or ""
    stripped = _strip_ansi(output).strip()
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict):
            rows = payload.get("papers") or payload.get("results") or []
        elif isinstance(payload, list):
            rows = payload
        else:
            rows = []
        normalized = [
            _paper_from_lookup_hit(paper) for paper in rows if isinstance(paper, dict)
        ]
        if normalized:
            return normalized
    return _parse_lookup_text(output)


def _rank_resolution_candidates(
    query: str,
    candidates: list[dict[str, Any]],
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    """Rank Paperclip matches and auto-select only a high-confidence title match."""
    query_title = normalize_title(query)
    scored: list[tuple[float, dict[str, Any]]] = []
    for candidate in candidates:
        candidate_title = normalize_title(candidate.get("title"))
        score = (
            SequenceMatcher(None, query_title, candidate_title).ratio()
            if query_title and candidate_title
            else 0.0
        )
        scored.append((score, candidate))
    scored.sort(
        key=lambda item: (
            item[0],
            int(item[1].get("year") or 0),
            bool(item[1].get("doi")),
        ),
        reverse=True,
    )
    ordered = [candidate for _, candidate in scored]
    exact = [
        candidate
        for score, candidate in scored
        if score == 1.0 and candidate.get("doi")
    ]
    if len(exact) == 1:
        return exact[0], ordered
    if not scored or not scored[0][1].get("doi"):
        return None, ordered

    top_score = scored[0][0]
    next_score = scored[1][0] if len(scored) > 1 else 0.0
    # Require near-exact similarity and a clear margin. This prevents a search
    # result's rank from silently becoming an identity assertion.
    if top_score >= 0.92 and (top_score - next_score) >= 0.08:
        return scored[0][1], ordered
    return None, ordered


def _client_head(client: Any, path: str, *, lines: int = 5, timeout: float = 30):
    """Call ``head`` via ``client.papers.head`` or ``client.execute``."""
    papers_api = getattr(client, "papers", None)
    if papers_api is not None and hasattr(papers_api, "head"):
        return papers_api.head(path, lines=lines, timeout=timeout)
    if hasattr(client, "head"):
        try:
            return client.head(path, lines=lines, timeout=timeout)
        except TypeError:
            return client.head(path, timeout=timeout)
    return client.execute("head", ["-n", str(lines), path], timeout=timeout)


def _has_readable_fulltext(client: Any, paperclip_id: str) -> bool:
    """True when ``/papers/<id>/content.lines`` returns readable content."""
    path = f"/papers/{paperclip_id}/content.lines"
    try:
        result = _client_head(client, path, lines=5, timeout=30)
    except Exception as exc:  # noqa: BLE001
        logger.debug("head %s failed: %s", path, exc)
        return False
    if getattr(result, "exit_code", 1) != 0:
        return False
    output = (getattr(result, "output", "") or "").strip()
    if not output:
        return False
    # Reject obvious missing-file messages
    lowered = output.lower()
    if "no such file" in lowered or "not found" in lowered or "error" in lowered[:40]:
        return False
    return True


def resolve_target(
    client: Any,
    query: str,
    *,
    select_doi: str | None = None,
    url_opener: Callable[[str], str] | None = None,
    on_event: EventCallback | None = None,
) -> tuple[TargetPaper | None, list[dict[str, Any]], str | None]:
    """Resolve a user query to a single target paper.

    Returns ``(target, candidates, error)``. When multiple title matches exist
    and ``select_doi`` is not provided, ``target`` is None and ``candidates``
    is populated for the UI to choose from.
    """
    if select_doi:
        doi = normalize_doi(select_doi)
        if not doi:
            return None, [], f"Invalid select DOI: {select_doi}"
        hits = _lookup_papers(client, "doi", doi, limit=5)
        target = TargetPaper(query=query, doi=doi)
        if hits:
            hit = hits[0]
            target.paperclip_id = hit.get("paperclip_id")
            target.title = hit.get("title") or ""
            target.pmid = hit.get("pmid")
            target.authors = hit.get("authors") or ""
            target.year = hit.get("year")
            target.source = hit.get("source") or ""
            target.arxiv_id = hit.get("arxiv_id")
        emit_event(on_event, "resolve", status="ok", target=target.to_dict())
        return target, [], None

    kind, value = classify_query(query)
    emit_event(on_event, "resolve", status="started", kind=kind, value=value)

    if kind == "empty":
        return None, [], "Query is empty"

    if kind in {"pmid", "pmc"}:
        lookup_field = "pmid" if kind == "pmid" else "pmc"
        hits = _lookup_papers(client, lookup_field, value, limit=3)
        hit = hits[0] if hits else {}
        doi = normalize_doi(hit.get("doi"))
        if not doi:
            europe_query = (
                f"EXT_ID:{value}" if kind == "pmid" else f"PMCID:{value}"
            )
            try:
                doi = resolve_doi_via_europepmc(europe_query)
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s DOI lookup failed for %s: %s", kind, value, exc)
        if doi:
            return resolve_target(
                client,
                doi,
                select_doi=doi,
                on_event=on_event,
            )
        return None, [], f"No DOI found for {value}"

    if kind == "url":
        if is_google_scholar_url(value):
            hints = extract_google_scholar_hints(value)
            if not hints.get("doi") and not hints.get("destination_url"):
                try:
                    scholar_html = _fetch_html_page(value, opener=url_opener)
                    hints.update(extract_google_scholar_hints(value, scholar_html))
                except (HTTPError, URLError, TimeoutError, OSError, ValueError) as exc:
                    logger.warning("Google Scholar page fetch failed: %s", exc)

            if hints.get("doi"):
                doi = hints["doi"]
                emit_event(
                    on_event,
                    "resolve",
                    status="scholar_resolved",
                    doi=doi,
                    url=value,
                )
                return resolve_target(
                    client,
                    doi,
                    select_doi=doi,
                    on_event=on_event,
                )
            destination = hints.get("destination_url")
            if destination:
                return resolve_target(
                    client,
                    destination,
                    url_opener=url_opener,
                    on_event=on_event,
                )
            title = hints.get("title")
            if title:
                return resolve_target(
                    client,
                    title,
                    on_event=on_event,
                )
            return None, [], (
                "Could not resolve this Google Scholar URL. Use a Scholar paper "
                "result link, a DOI, or the exact paper title."
            )

        try:
            doi = fetch_doi_from_url(value, opener=url_opener)
        except (HTTPError, URLError, TimeoutError, OSError, ValueError) as exc:
            return None, [], (
                "Could not resolve DOI from URL "
                f"(page blocked or unknown publisher id): {exc}"
            )
        if not doi:
            return None, [], "No DOI found for this URL"
        emit_event(on_event, "resolve", status="url_resolved", doi=doi, url=value)
        return resolve_target(
            client,
            doi,
            select_doi=doi,
            on_event=on_event,
        )

    if kind == "doi":
        return resolve_target(
            client,
            value,
            select_doi=value,
            on_event=on_event,
        )

    if kind == "arxiv":
        hits = _lookup_papers(client, "arxiv", value, limit=5)
        if not hits:
            # Try document id form
            hits = _lookup_papers(client, "arxiv", value, limit=5)
        if not hits:
            return None, [], f"No Paperclip paper found for arXiv:{value}"
        hit = hits[0]
        target = TargetPaper(
            query=query,
            doi=hit.get("doi"),
            paperclip_id=hit.get("paperclip_id"),
            title=hit.get("title") or "",
            pmid=hit.get("pmid"),
            arxiv_id=value,
            year=hit.get("year"),
            authors=hit.get("authors") or "",
            source=hit.get("source") or "",
        )
        if not target.doi:
            emit_event(on_event, "resolve", status="ok", target=target.to_dict())
            return target, [], None
        return resolve_target(
            client,
            target.doi,
            select_doi=target.doi,
            on_event=on_event,
        )

    # title
    hits = _lookup_papers(client, "title", value, limit=MAX_TITLE_CANDIDATES)
    if not hits:
        hits = _search_papers(client, value, limit=MAX_TITLE_CANDIDATES)
    if not hits:
        return None, [], f"No Paperclip papers matched input: {value}"

    selected, ordered = _rank_resolution_candidates(value, hits)
    if selected and selected.get("doi"):
        emit_event(
            on_event,
            "resolve",
            status="rules_selected",
            doi=selected["doi"],
        )
        return resolve_target(
            client,
            selected["doi"],
            select_doi=selected["doi"],
            on_event=on_event,
        )

    if len(ordered) > 1 or (ordered and ordered[0].get("doi")):
        candidates = ordered[:MAX_TITLE_CANDIDATES]
        emit_event(
            on_event,
            "candidates",
            candidates=candidates,
            message="Multiple papers matched this title. Select one DOI to continue.",
        )
        return None, candidates, None

    hit = ordered[0]
    if hit.get("doi"):
        return resolve_target(
            client,
            hit["doi"],
            select_doi=hit["doi"],
            on_event=on_event,
        )

    target = TargetPaper(
        query=query,
        doi=None,
        paperclip_id=hit.get("paperclip_id"),
        title=hit.get("title") or "",
        pmid=hit.get("pmid"),
        arxiv_id=hit.get("arxiv_id"),
        year=hit.get("year"),
        authors=hit.get("authors") or "",
        source=hit.get("source") or "",
    )
    emit_event(on_event, "resolve", status="ok", target=target.to_dict())
    return target, [], None


def match_citing_record(
    client: Any,
    record: CitingRecord,
) -> MatchedCitingPaper:
    """Match one citing record into Paperclip (DOI → PMID → arXiv → title)."""
    matched = MatchedCitingPaper(
        title=record.title,
        doi=record.doi,
        pmid=record.pmid,
        arxiv_id=record.arxiv_id,
        year=record.year,
        providers=list(record.providers),
    )

    attempts: list[tuple[str, str, str]] = []
    if record.doi:
        attempts.append(("doi", record.doi, "doi"))
    if record.pmid:
        attempts.append(("pmid", str(record.pmid), "pmid"))
    if record.arxiv_id:
        attempts.append(("arxiv", record.arxiv_id, "arxiv"))
    if record.title:
        attempts.append(("title", record.title, "title"))

    for field_name, value, method in attempts:
        hits = _lookup_papers(client, field_name, value, limit=3)
        if not hits:
            continue
        if method == "title":
            # Require exact normalized title to avoid false positives
            hits = [
                h
                for h in hits
                if normalize_title(h.get("title")) == normalize_title(value)
            ]
            if not hits:
                continue
        hit = hits[0]
        pid = hit.get("paperclip_id")
        if not pid:
            continue
        matched.paperclip_id = pid
        matched.match_method = method
        if not matched.title:
            matched.title = hit.get("title") or matched.title
        if not matched.doi:
            matched.doi = hit.get("doi")
        if not matched.pmid:
            matched.pmid = hit.get("pmid")
        matched.has_fulltext = _has_readable_fulltext(client, pid)
        break

    return matched


def parse_lookup_citation_output(output: str) -> tuple[str, list[CitationContext], bool]:
    """Parse ``lookup-citation`` text output.

    Returns ``(citation_key, contexts, bibliography_only)``.
    ``bibliography_only`` is True when a reference entry exists but no body uses.
    """
    text = output or ""
    key_match = _LOOKUP_CITATION_KEY_RE.search(text)
    citation_key = key_match.group(1) if key_match else ""

    if "no reference found matching" in text.lower():
        return citation_key, [], False

    if "no in-text mentions found" in text.lower():
        return citation_key, [], True

    contexts: list[CitationContext] = []
    current_section = ""
    current_lines: list[str] = []
    current_line_no: int | None = None
    current_block: str | None = None

    def _flush() -> None:
        nonlocal current_lines, current_line_no, current_block
        if current_lines:
            contexts.append(
                CitationContext(
                    section=current_section,
                    line=current_line_no,
                    text="\n".join(current_lines).strip(),
                    citation_key=citation_key,
                    block_id=current_block,
                )
            )
        current_lines = []
        current_line_no = None
        current_block = None

    for raw_line in text.splitlines():
        mention = _LOOKUP_MENTION_RE.match(raw_line.strip())
        if mention:
            _flush()
            current_section = mention.group(2).strip()
            continue
        line_match = _LOOKUP_LINE_RE.match(raw_line)
        if line_match:
            marker, block_id, content = line_match.groups()
            if marker.strip() == ">>>":
                try:
                    current_line_no = int(block_id)
                except ValueError:
                    current_line_no = None
                current_block = block_id
            current_lines.append(content)
            continue

    _flush()
    bibliography_only = bool(citation_key) and not contexts
    return citation_key, contexts, bibliography_only


_GREP_LINE_RE = re.compile(r"^L(\d+)(:|-)\s*(.*)$")
_REF_NUM_RE = re.compile(
    r"(?i)(?:^|\s)(?:\[(\d+)\]|(\d+)\.\s+[A-Z]|ref(?:erence)?\s*(\d+))"
)
_TITLE_STOPWORDS = {
    "about",
    "after",
    "analysis",
    "based",
    "from",
    "into",
    "paper",
    "study",
    "their",
    "these",
    "this",
    "using",
    "with",
}


def _grep_content_lines(
    client: Any,
    paperclip_id: str,
    pattern: str,
    *,
    before: int = 0,
    after: int = 0,
) -> list[tuple[int, str, bool]]:
    """Run grep and return ``(line_no, text, is_match)`` rows."""
    path = f"/papers/{paperclip_id}/content.lines"
    args = [pattern, path]
    if before:
        args.extend(["-B", str(before)])
    if after:
        args.extend(["-A", str(after)])
    try:
        result = client.execute("grep", args, timeout=60)
    except Exception as exc:  # noqa: BLE001
        logger.debug("grep %s in %s failed: %s", pattern, paperclip_id, exc)
        return []
    output = _strip_ansi(getattr(result, "output", "") or "")
    if not output or "no matches" in output.lower():
        return []
    hits: list[tuple[int, str, bool]] = []
    for raw in output.splitlines():
        match = _GREP_LINE_RE.match(raw.strip())
        if not match:
            continue
        hits.append(
            (
                int(match.group(1)),
                match.group(3),
                match.group(2) == ":",
            )
        )
    return hits


def _looks_like_bibliography(line_no: int, text: str, max_line_hint: int | None) -> bool:
    """Heuristic: late lines or bibliography-shaped text are reference-list hits."""
    lowered = text.lower()
    compact = re.sub(r"\s+", " ", text).strip()
    if re.fullmatch(r"\d{6,9}", compact):
        return True
    # Compact citation metadata lines, e.g. "2023 ; 4 : 100779 . 37521038"
    if re.search(r"^\d{4}\s*;\s*\d+\s*:\s*\d+", compact):
        return True
    if re.search(r"\b\d{5,8}\b", compact) and re.search(r"\b20\d{2}\b", compact):
        if len(compact) < 80 and not re.search(r"\b(we|our|this study|these)\b", lowered):
            return True
    if "doi.org" in lowered or re.search(r"\(\d{4}\)", text):
        if re.search(r"\d+\s*,\s*\d+", text) or "et al" in lowered:
            return True
    # Do not infer bibliography position from the largest matching line. The
    # largest *hit* is not the document length, so that rule misclassified the
    # final body citation as a reference-list entry.
    return False


def _citation_marker_pattern(citation_key: str) -> str:
    digits = re.search(r"\d+", citation_key or "")
    if digits:
        return rf"\[\s*{re.escape(digits.group(0))}\s*\]"
    return re.escape(citation_key.strip())


def _extract_mention_sentences(text: str, pattern: str) -> str:
    """Return the exact one or two sentences containing a verified mention."""
    source = (text or "").strip()
    if not source or not pattern:
        return ""
    try:
        mention_re = re.compile(pattern, re.IGNORECASE)
    except re.error:
        return ""
    if not mention_re.search(source):
        return ""

    boundaries = [0]
    for match in re.finditer(
        r"""[.!?]["”’]?\s+(?=[A-Z0-9“"'])""",
        source,
    ):
        boundaries.append(match.end())
    boundaries.append(len(source))
    sentences = [
        source[boundaries[index] : boundaries[index + 1]].strip()
        for index in range(len(boundaries) - 1)
        if source[boundaries[index] : boundaries[index + 1]].strip()
    ]
    matched = [
        index for index, sentence in enumerate(sentences) if mention_re.search(sentence)
    ]
    if not matched:
        return ""
    first = matched[0]
    selected = [sentences[first]]
    # Add one adjacent sentence only when the matching sentence is too short to
    # explain the claim. Never return more than two sentences.
    if len(selected[0]) < 45:
        if first + 1 < len(sentences):
            selected.append(sentences[first + 1])
        elif first > 0:
            selected.insert(0, sentences[first - 1])
    return " ".join(selected)


def _specific_context_text(
    context: CitationContext,
    target: TargetPaper,
) -> str:
    """Trim a context to a verified sentence-level target mention."""
    if context.citation_key:
        text = _extract_mention_sentences(
            context.text,
            _citation_marker_pattern(context.citation_key),
        )
        if text:
            return text
        return ""
    if target.doi:
        text = _extract_mention_sentences(context.text, re.escape(target.doi))
        if text:
            return text
    if target.title:
        words = [
            word
            for word in re.split(r"\s+", target.title)
            if len(word.strip(".,:;()")) > 3
            and word.lower().strip(".,:;()") not in _TITLE_STOPWORDS
        ]
        if len(words) >= 3:
            return _extract_mention_sentences(
                context.text,
                re.escape(" ".join(words[:4])),
            )
    return ""


def _sanitize_contexts(
    contexts: list[CitationContext],
    target: TargetPaper,
) -> list[CitationContext]:
    cleaned: list[CitationContext] = []
    seen: set[str] = set()
    for context in contexts:
        text = _specific_context_text(context, target)
        key = re.sub(r"\s+", " ", text).strip().lower()
        if not text or key in seen:
            continue
        seen.add(key)
        context.text = text
        cleaned.append(context)
    return cleaned


def _extract_contexts_via_grep(
    client: Any,
    paper: MatchedCitingPaper,
    target: TargetPaper,
) -> MatchedCitingPaper:
    """Locate bibliography + body mentions with grep when lookup-citation cannot."""
    patterns: list[tuple[str, str]] = []
    if target.doi:
        patterns.append((re.escape(target.doi), "doi"))
        patterns.append((re.escape(target.doi.split("/", 1)[-1][:48]), "doi"))
    if target.pmid:
        patterns.append((re.escape(str(target.pmid)), "identifier"))
    if target.title:
        # Prefer a distinctive token (e.g. ROSIE), not the first word. Titles
        # often start with generic words such as "This" or "Using".
        tokens = [
            t
            for t in re.split(r"\W+", target.title)
            if len(t) >= 4 and t.lower() not in _TITLE_STOPWORDS
        ]
        if tokens:
            acronyms = [token for token in tokens if token.isupper()]
            if acronyms:
                patterns.append((re.escape(acronyms[0]), "token"))
            distinctive = max(tokens, key=lambda token: (len(token), token.isupper()))
            if not acronyms or distinctive.lower() != acronyms[0].lower():
                patterns.append((re.escape(distinctive), "token"))
        words = [
            w
            for w in re.split(r"\s+", target.title)
            if len(w) > 3 and w.lower().strip(".,:;()") not in _TITLE_STOPWORDS
        ][:5]
        if len(words) >= 2:
            patterns.append((re.escape(" ".join(words[:4])), "title"))

    bibliography_windows: list[tuple[int, list[tuple[int, str, bool]]]] = []
    direct_contexts: list[CitationContext] = []
    seen_patterns: set[str] = set()
    for pattern, kind in patterns:
        if not pattern or pattern.lower() in seen_patterns:
            continue
        seen_patterns.add(pattern.lower())
        rows = _grep_content_lines(
            client,
            paper.paperclip_id or "",
            pattern,
            before=3,
            after=1,
        )
        for line_no, text, is_match in rows:
            if not is_match:
                continue
            bibliography = _looks_like_bibliography(line_no, text, None)
            if bibliography or kind == "identifier":
                window = [
                    row for row in rows if line_no - 3 <= row[0] <= line_no + 1
                ]
                bibliography_windows.append((line_no, window))
            elif kind in {"doi", "title"}:
                direct_contexts.append(
                    CitationContext(section="body", line=line_no, text=text)
                )

    citation_keys: list[str] = []
    for anchor_line, window in bibliography_windows:
        nearby = sorted(
            window,
            key=lambda row: (
                0 if row[0] <= anchor_line else 1,
                abs(anchor_line - row[0]),
            ),
        )
        for _, text, _ in nearby:
            key_match = _REF_NUM_RE.search(text)
            if key_match:
                key = next((group for group in key_match.groups() if group), "")
                if key and key not in citation_keys:
                    citation_keys.append(key)
                break

    marker_contexts: list[CitationContext] = []
    for citation_key in citation_keys:
        marker_pattern = rf"\[\s*{re.escape(citation_key)}\s*\]"
        marker_hits = _grep_content_lines(
            client,
            paper.paperclip_id or "",
            marker_pattern,
        )
        for line_no, text, is_match in marker_hits:
            if not is_match or _looks_like_bibliography(line_no, text, None):
                continue
            marker_contexts.append(
                CitationContext(
                    section="body",
                    line=line_no,
                    text=text,
                    citation_key=f"[{citation_key}]",
                )
            )

    paper.contexts = _sanitize_contexts(marker_contexts + direct_contexts, target)[:12]
    paper.bibliography_only = bool(bibliography_windows) and not paper.contexts
    return paper


def extract_contexts(
    client: Any,
    paper: MatchedCitingPaper,
    target: TargetPaper,
) -> MatchedCitingPaper:
    """Find bibliography entry + in-text uses of the target in one citing paper."""
    if not paper.paperclip_id or not paper.has_fulltext:
        return paper

    queries: list[str] = []
    if target.doi:
        queries.append(target.doi)
        queries.append(target.doi.split("/", 1)[-1][:40])
    if target.title:
        words = [w for w in re.split(r"\s+", target.title) if len(w) > 3][:6]
        if words:
            queries.append(" ".join(words[:4]))
        tokens = [t for t in re.split(r"\W+", target.title) if len(t) >= 4]
        if tokens:
            queries.append(tokens[0])
    if target.pmid:
        queries.append(str(target.pmid))
    if target.authors:
        first = target.authors.split(",")[0].split(";")[0].strip()
        if first:
            year = f" {target.year}" if target.year else ""
            queries.append(f"{first}{year}")

    # lookup-citation currently accepts UUID / bio_ / med_ ids, not PMC*.
    can_lookup_citation = bool(
        re.match(
            r"^(?:[0-9a-f]{8}-[0-9a-f-]+|(?:bio|med)_[0-9a-f]+)$",
            paper.paperclip_id,
            re.IGNORECASE,
        )
    )

    if can_lookup_citation:
        seen_queries: set[str] = set()
        for query in queries:
            q = query.strip()
            if not q or q.lower() in seen_queries:
                continue
            seen_queries.add(q.lower())
            try:
                result = client.execute(
                    "lookup-citation",
                    [paper.paperclip_id, q],
                    timeout=60,
                )
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "lookup-citation failed for %s (%s): %s",
                    paper.paperclip_id,
                    q,
                    exc,
                )
                continue
            output = getattr(result, "output", "") or ""
            if "not in a paper directory" in output.lower():
                break
            key, contexts, bibliography_only = parse_lookup_citation_output(output)
            if contexts:
                cleaned = _sanitize_contexts(contexts, target)
                if cleaned:
                    paper.contexts = cleaned[:12]
                    paper.bibliography_only = False
                    return paper
            if bibliography_only or (key and not contexts):
                paper.bibliography_only = True

    return _extract_contexts_via_grep(client, paper, target)


def _fallback_passage_summary(paper: MatchedCitingPaper) -> str:
    """Deterministic one-line summary from the first extracted passage."""
    if not paper.contexts:
        return ""
    first = paper.contexts[0]
    summary = (first.text or "").strip()
    if len(summary) > 400:
        summary = summary[:397] + "..."
    section = first.section or "body"
    return f"({section}) {summary}"


def _parse_map_output_summaries(output: str) -> dict[str, str]:
    """Best-effort parse of map stdout into ``{paper_id: summary}``."""
    summaries: dict[str, str] = {}
    current_id: str | None = None
    buf: list[str] = []
    id_re = re.compile(
        r"\b((?:PMC\d+)|(?:(?:bio|med|arx)_[0-9a-f]{8,})|(?:[0-9a-f]{8}-[0-9a-f-]{27}))\b",
        re.IGNORECASE,
    )

    def _flush() -> None:
        nonlocal current_id, buf
        if current_id and buf:
            text = "\n".join(line.strip() for line in buf if line.strip())
            if text:
                summaries[current_id] = text[:600]
        current_id = None
        buf = []

    for line in (output or "").splitlines():
        match = id_re.search(line)
        if match and (
            line.strip().startswith(match.group(1))
            or "document" in line.lower()
            or "[success]" in line.lower()
            or "[failed]" in line.lower()
            or line.strip().startswith("#")
            or line.strip().startswith("##")
        ):
            _flush()
            current_id = match.group(1)
            remainder = line[match.end() :].strip(" :-#")
            buf = [remainder] if remainder else []
            continue
        if current_id:
            buf.append(line)
    _flush()
    return summaries


def build_fulltext_map_question(target: TargetPaper) -> str:
    """Map prompt: specificity and importance of how one paper cites the target."""
    target_label = target.title or target.doi or "the target paper"
    doi_bit = f" (doi:{target.doi})" if target.doi else ""
    author_bit = f"; authors: {target.authors}" if target.authors else ""
    return (
        "CUSTOM CITATION AUDIT INSTRUCTION\n"
        f"TARGET: '{target_label}'{doi_bit}{author_bit}\n"
        "First identify the exact target in this paper's reference list. Match by DOI "
        "when present, then by title and authors. Record its citation key or marker. "
        "Do not use a neighboring reference and do not treat the reference-list entry "
        "itself as an in-text mention.\n"
        "Next find every place in the paper body where that exact citation key appears. "
        "For each place, report the section, line number or range, and an exact quote "
        "and keep the in-text citation marker. If there is no body use, classify it as "
        "bibliography_only. If the target reference cannot be identified, use not_found.\n"
        "Assess SPECIFICITY and IMPORTANCE. Assign exactly one primary ROLE:\n"
        "- significant: the citing paper materially depends on the target's method, "
        "finding, data, framework, or premise.\n"
        "- supporting: the target supports a concrete claim, comparison, or argument, "
        "but the citing paper does not materially depend on it.\n"
        "- critical: the citation is mainly about a gap, boundary, caveat, missing "
        "element, or limitation of the TARGET paper itself. This can be constructive "
        "and does not need to be negative. Example: the target did X but did not do Y.\n"
        "- cursory: a brief related-work mention, name-drop, or broad background citation.\n"
        "- unclassified: there is not enough body evidence to decide.\n"
        "Do not use critical when the target is evidence about weaknesses in FDA "
        "approvals, medical devices, or medical AI. A limitation in the target's subject "
        "matter is not a limitation of the target paper.\n"
        "Start the answer with these exact fields, one per line:\n"
        "CITATION_STATUS: in_text | bibliography_only | not_found\n"
        "CITATION_KEY: <exact marker or none>\n"
        "ROLE: significant | supporting | critical | cursory | unclassified\n"
        "LIMITATION_SIGNAL: yes only when ROLE is critical; otherwise no\n"
        "CENTRALITY: <0-10>\n"
        "Then write LOCATIONS with 1-2 strongest exact body passages. For each location, "
        "use exactly three lines: SECTION: <name>, LINES: <Lx-Ly>, and QUOTE: <exact text>. "
        "Finish with one RATIONALE line. "
        "Never invent a quote, citation marker, section, or line number."
    )


_MAP_ROLES = {
    "significant",
    "supporting",
    "critical",
    "cursory",
    "unclassified",
}
_MAP_STATUSES = {"in_text", "bibliography_only", "not_found"}


def _parse_map_assessment(text: str) -> tuple[str, bool, str]:
    """Parse fixed citation-audit fields from one map answer."""
    role_match = re.search(
        r"(?i)\bROLE\s*:\s*(significant|supporting|critical|cursory|unclassified|foundational|substantive|peripheral|nominal)\b",
        text or "",
    )
    limitation_match = re.search(
        r"(?i)\bLIMITATION_SIGNAL\s*:\s*(yes|no)\b",
        text or "",
    )
    status_match = re.search(
        r"(?i)\bCITATION_STATUS\s*:\s*(in_text|bibliography_only|not_found)\b",
        text or "",
    )
    role = role_match.group(1).lower() if role_match else "unclassified"
    role = {
        "foundational": "significant",
        "substantive": "significant",
        "peripheral": "cursory",
        "nominal": "cursory",
    }.get(role, role)
    status = status_match.group(1).lower() if status_match else "map_unparsed"
    if role not in _MAP_ROLES:
        role = "unclassified"
    if status not in _MAP_STATUSES:
        status = "map_unparsed"
    limitation = bool(
        limitation_match and limitation_match.group(1).lower() == "yes"
    )
    if limitation:
        role = "critical"
    if status == "bibliography_only":
        role = "cursory"
        limitation = False
    elif status == "not_found":
        role = "unclassified"
        limitation = False
    return role, limitation, status


def _full_map_outputs(client: Any, result_id: str | None) -> dict[str, str]:
    """Read complete per-paper outputs from a saved map result."""
    if not result_id:
        return {}
    getter = getattr(getattr(client, "results", None), "get", None)
    if not callable(getter):
        return {}
    try:
        result = getter(result_id, timeout=60)
    except Exception as exc:  # noqa: BLE001
        logger.debug("could not read full map result %s: %s", result_id, exc)
        return {}
    raw = getattr(result, "raw", None) or {}
    result_data = raw.get("result_data") or {}
    rows = result_data.get("papers") or []
    outputs: dict[str, str] = {}
    for row in rows:
        doc_id = str(row.get("document_id") or "").strip()
        output = str(row.get("output") or row.get("response") or "").strip()
        if doc_id and output:
            outputs[doc_id] = output
    return outputs


def _parse_map_contexts(text: str) -> list[CitationContext]:
    """Parse exact locations from one structured citation-audit answer."""
    key_match = re.search(r"(?i)\bCITATION_KEY\s*:\s*([^\n]+)", text or "")
    citation_key = (key_match.group(1).strip() if key_match else "")
    if citation_key.isdigit():
        citation_key = f"[{citation_key}]"
    contexts: list[CitationContext] = []
    section_re = re.compile(
        r"(?ims)^\s*(?:[-*]\s*)?\**Section\**\s*:\s*"
        r"(?P<section>[^\n|]+?)(?:\s*\|\s*|,\s*(?=\**Lines?\**\s*:)|\n)"
        r"\s*(?:[-*]\s*)?\**(?:Line range|Lines?)\**\s*:\s*"
        r"L?(?P<line>\d+)[^\n|]*(?:\s*\|\s*|\n)"
        r"\s*(?:[-*]\s*)?\**(?:Exact passage|Quote)\**\s*:\s*"
        r"(?P<quote>.*?)(?=\n\s*(?:[-*]\s*)?\**(?:Section|Rationale)\**\s*:|\Z)"
    )
    for match in section_re.finditer(text or ""):
        quote = match.group("quote").strip()
        if len(quote) >= 2 and quote[0] == quote[-1] == '"':
            quote = quote[1:-1].strip()
        if not quote:
            continue
        contexts.append(
            CitationContext(
                section=match.group("section").strip(),
                line=int(match.group("line")),
                text=quote,
                citation_key=citation_key,
            )
        )
    return contexts


def build_fulltext_reduce_question(target: TargetPaper) -> str:
    """Reduce prompt over all per-paper map answers."""
    target_label = target.title or target.doi or "the target paper"
    return (
        f"Synthesize how citing papers refer to '{target_label}'"
        + (f" (doi:{target.doi})" if target.doi else "")
        + " across ALL map answers. Organize by specificity and importance. "
        "Count the exclusive primary roles: significant, supporting, critical, "
        "cursory, and unclassified. Critical means that the citation is mainly about "
        "a gap, boundary, caveat, missing element, or limitation of the target paper "
        "itself. Highlight 2-4 representative citing papers for the strongest "
        "engagement. Keep claims grounded in the map answers."
    )


def _summarize_with_map_reduce(
    client: Any,
    papers: list[MatchedCitingPaper],
    target: TargetPaper,
    *,
    limit: int,
    on_event: EventCallback | None = None,
    cancel: CancelCheck | None = None,
) -> tuple[list[MatchedCitingPaper], str, str | None]:
    """Map every Paperclip full-text citing paper, then reduce the set."""
    usable = [
        p for p in papers if p.paperclip_id and p.has_fulltext
    ][:limit]
    if not usable:
        return papers, "", None

    target_label = target.title or target.doi or "the target paper"
    emit_event(
        on_event,
        "summary",
        status="started",
        paper_count=len(usable),
        message=(
            "Mapping Paperclip full-text citing papers for citation "
            "specificity and importance"
        ),
    )

    summaries: dict[str, str] = {}
    themes = ""
    doc_ids = [p.paperclip_id for p in usable if p.paperclip_id]
    map_question = build_fulltext_map_question(target)

    map_result_id: str | None = None
    if not _cancelled(cancel):
        try:
            # Prefer streaming map; fall back to execute.
            try:
                events = client.stream(
                    "map",
                    ["--document-ids", ",".join(doc_ids), "-n", str(len(doc_ids)), map_question],
                    timeout=900,
                )
                output = ""
                for event in events:
                    if _cancelled(cancel):
                        break
                    if hasattr(event, "result_id"):
                        map_result_id = getattr(event, "result_id", None) or map_result_id
                        output = getattr(event, "output", "") or output
                    elif hasattr(event, "completed"):
                        emit_event(
                            on_event,
                            "summary",
                            status="progress",
                            completed=getattr(event, "completed", 0),
                            total=getattr(event, "total", 0),
                            current_item=(
                                getattr(event, "title", None)
                                or getattr(event, "document_title", None)
                                or getattr(event, "document_id", None)
                                or "Full-text paper"
                            ),
                        )
                summaries.update(_parse_map_output_summaries(output))
            except (ValueError, TypeError, AttributeError):
                result = client.execute(
                    "map",
                    [
                        "--document-ids",
                        ",".join(doc_ids),
                        "-n",
                        str(len(doc_ids)),
                        map_question,
                    ],
                    timeout=900,
                )
                map_result_id = getattr(result, "result_id", None)
                summaries.update(
                    _parse_map_output_summaries(getattr(result, "output", "") or "")
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("map summary failed; using passage fallback: %s", exc)

    # The streamed map output contains short previews. Read the saved result to
    # retain complete per-paper fields, locations, and exact quotations.
    summaries.update(_full_map_outputs(client, map_result_id))
    mapped_summary_ids = set(summaries)
    # Passage fallback for any paper map did not cover
    for paper in usable:
        pid = paper.paperclip_id or ""
        if pid and pid not in summaries:
            summaries[pid] = _fallback_passage_summary(paper)

    for paper in papers:
        if paper.paperclip_id in summaries:
            paper.summary = summaries[paper.paperclip_id]
        if paper.paperclip_id in mapped_summary_ids:
            (
                paper.impact_role,
                paper.limitation_signal,
                paper.analysis_status,
            ) = _parse_map_assessment(paper.summary)
            if paper.analysis_status == "in_text":
                mapped_contexts = _parse_map_contexts(paper.summary)
                if mapped_contexts:
                    paper.contexts = mapped_contexts
                    paper.bibliography_only = False
            elif paper.analysis_status == "bibliography_only":
                paper.contexts = []
                paper.bibliography_only = True
        elif paper.has_fulltext:
            if paper.bibliography_only:
                paper.impact_role = "cursory"
                paper.analysis_status = "bibliography_only"
            elif paper.contexts:
                paper.analysis_status = "extraction_only"
            else:
                paper.analysis_status = "not_found"

    if map_result_id and not _cancelled(cancel):
        try:
            reduced = client.reduce(
                build_fulltext_reduce_question(target),
                from_map=map_result_id,
                strategy="themes",
                timeout=300,
            )
            themes = (getattr(reduced, "output", "") or "").strip()
        except Exception as exc:  # noqa: BLE001
            logger.warning("reduce themes failed: %s", exc)

    if not themes:
        theme_bits = [p.summary for p in papers if p.summary]
        if theme_bits:
            themes = (
                f"Mapped {len(theme_bits)} Paperclip full-text citing papers for "
                f"how they refer to '{target_label}'. "
                "See per-paper summaries for specificity and importance."
            )

    emit_event(
        on_event,
        "summary",
        status="ok",
        summarized=len([s for s in summaries.values() if s]),
        themes=themes,
        map_result_id=map_result_id,
    )
    return papers, themes, map_result_id


_SCORE_JSON_RE = re.compile(r"\{[^{}]*\"score\"\s*:\s*\d+[^{}]*\}", re.DOTALL)


def build_importance_prompt(
    target: TargetPaper,
    papers: list[MatchedCitingPaper],
    *,
    counts: dict[str, int],
    themes: str = "",
) -> str:
    """Build the Agent prompt for a 0-100 score from the reduce synthesis."""
    target_label = target.title or target.doi or "the target paper"
    summary_bits: list[str] = []
    for index, paper in enumerate(
        [p for p in papers if p.has_fulltext and p.summary][:12], 1
    ):
        summary = (paper.summary or "").strip()
        if len(summary) > 320:
            summary = summary[:317] + "..."
        summary_bits.append(
            f"{index}. {paper.title or paper.doi or paper.paperclip_id}: {summary}"
        )
    summaries_block = (
        "\n".join(summary_bits) if summary_bits else "(no per-paper map summaries)"
    )
    reduce_block = (themes or "").strip() or "(no reduce synthesis available)"
    return f"""Score how important TARGET is inside the citing literature.
Use ONLY the reduce synthesis and per-paper map summaries below. Do not invent passages.

SCORE SCALE
0-20  nominal: name-dropped or listed with no engagement with claims or methods
21-40 peripheral: brief supporting citation; not load-bearing
41-60 supporting: used for comparison, related work, or one concrete claim
61-80 substantive: methods, findings, framing, or evaluation depend on the target
81-100 foundational: multiple papers treat it as a core basis, primary motivation, or central method

LIMITATIONS SIGNAL
Treat limitations or criticism as a separate signal, not a sixth importance tier.
Lower the score only when the synthesis shows that later papers reject, invalidate,
or substantially qualify the target's main contribution.

PIPELINE COVERAGE
- total unique citing works found: {counts.get("unique_citing", 0)}
- Paperclip open-access full text mapped: {counts.get("readable_fulltext", 0)}
- citing works with in-text uses found: {counts.get("in_text_uses", 0)}
- bibliography-only in Paperclip sample: {counts.get("bibliography_only", 0)}

TARGET PAPER
- title: {target_label}
- doi: {target.doi or "n/a"}
- paperclip id: {target.paperclip_id or "n/a"}

REDUCE SYNTHESIS (primary evidence)
{reduce_block}

PER-PAPER MAP SUMMARIES (secondary)
{summaries_block}

Return ONLY compact JSON with this exact shape:
{{
  "score": <integer 0-100>,
  "label": "<nominal|peripheral|supporting|substantive|foundational>",
  "rationale": "<2-4 sentences grounded in the reduce synthesis>",
  "evidence": ["<short quote or paraphrase from the synthesis>", "..."]
}}
"""


def _label_for_score(score: int) -> str:
    if score <= 20:
        return "nominal"
    if score <= 40:
        return "peripheral"
    if score <= 60:
        return "supporting"
    if score <= 80:
        return "substantive"
    return "foundational"


def _parse_importance_payload(text: str) -> ImportanceScore | None:
    """Parse an importance JSON object from LLM output."""
    raw = _strip_ansi(text or "").strip()
    if not raw:
        return None
    candidates = [raw]
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, re.DOTALL)
    if fenced:
        candidates.insert(0, fenced.group(1))
    match = _SCORE_JSON_RE.search(raw)
    if match:
        candidates.insert(0, match.group(0))

    for candidate in candidates:
        try:
            data = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict) or "score" not in data:
            continue
        try:
            score = int(data["score"])
        except (TypeError, ValueError):
            continue
        score = max(0, min(100, score))
        # The numeric score is the canonical value. Reconcile the label with
        # its documented score band so cards cannot show "90 / nominal".
        label = _label_for_score(score)
        evidence_raw = data.get("evidence") or []
        evidence = [str(item).strip() for item in evidence_raw if str(item).strip()][:6]
        return ImportanceScore(
            score=score,
            label=label,
            rationale=str(data.get("rationale") or "").strip(),
            evidence=evidence,
            method="llm",
        )
    return None


def _heuristic_importance_score(
    papers: list[MatchedCitingPaper],
    counts: dict[str, int],
) -> ImportanceScore:
    """Deterministic fallback when the LLM score is unavailable."""
    total = max(0, int(counts.get("unique_citing") or 0))
    fulltext = max(0, int(counts.get("readable_fulltext") or 0))
    in_text = max(0, int(counts.get("in_text_uses") or 0))
    if total == 0:
        return ImportanceScore(
            score=0,
            label="unscored",
            rationale="No citing works were found, so importance cannot be assessed.",
            method="empty",
        )
    if in_text == 0:
        score = 8 if fulltext == 0 else 15
        return ImportanceScore(
            score=score,
            label="nominal",
            rationale=(
                "Citing works were found, but the Paperclip full-text sample shows "
                "only bibliographic or no in-text engagement with the target."
            ),
            method="heuristic",
        )

    coverage = in_text / max(1, fulltext)
    score = int(round(25 + 55 * coverage))
    foundational_hits = 0
    evidence: list[str] = []
    keywords = (
        "based on",
        "we use",
        "we follow",
        "building on",
        "inspired by",
        "our method",
        "we adopt",
        "extends",
        "foundation",
    )
    for paper in papers:
        if not paper.contexts:
            continue
        blob = " ".join(
            [(paper.summary or "")] + [c.text or "" for c in paper.contexts[:2]]
        ).lower()
        if any(key in blob for key in keywords):
            foundational_hits += 1
            quote = (paper.contexts[0].text or paper.summary or "")[:180]
            if quote:
                evidence.append(quote)
    score = score + min(20, foundational_hits * 8)
    # A small or weak fallback sample must not claim foundational impact.
    # The Agent scorer can exceed these caps when it has stronger evidence.
    if fulltext < 3:
        score = min(60, score)
    elif foundational_hits < 2:
        score = min(80, score)
    else:
        score = min(92, score)
    return ImportanceScore(
        score=score,
        label=_label_for_score(score),
        rationale=(
            f"Heuristic score from {in_text} in-text uses among "
            f"{fulltext} Paperclip full-text citing papers "
            f"(out of {total} unique citing works)."
        ),
        evidence=evidence[:4],
        method="heuristic",
    )


def _score_with_chat_agent(prompt: str) -> ImportanceScore | None:
    """Final score via the Paperclip chat Agent harness (inference Agent)."""
    if os.environ.get("CITATION_EXPLORER_USE_AGENT", "1").strip() in {
        "0",
        "false",
        "no",
    }:
        return None
    try:
        from gxl_inference_client import Agent
    except ImportError:
        logger.info("gxl_inference_client not installed; skip chat Agent scorer")
        return None

    session_id = f"citation-explorer-{uuid.uuid4().hex}"
    try:
        agent = Agent(
            model=SCORE_AGENT_MODEL,
            system_prompt=SCORE_AGENT_SYSTEM_PROMPT,
            session_id=session_id,
            agent_id="citation-explorer-scorer",
            max_iterations=1,
            timeout=180.0,
        )
        # No MCP tools: this is a pure synthesis/scoring turn.
        agent.tool_list = []
        text = agent(prompt)
        parsed = _parse_importance_payload(text)
        if parsed is not None:
            parsed.method = "agent"
        return parsed
    except Exception as exc:  # noqa: BLE001
        logger.warning("Paperclip chat Agent scoring failed: %s", exc)
        return None


def _score_with_reduce_extract(
    client: Any,
    *,
    map_result_id: str,
    prompt: str,
) -> ImportanceScore | None:
    """Fallback: ask Paperclip reduce/extract for the score JSON."""
    try:
        reduced = client.reduce(
            prompt,
            from_map=map_result_id,
            strategy="extract",
            timeout=300,
        )
        parsed = _parse_importance_payload(getattr(reduced, "output", "") or "")
        if parsed is not None:
            parsed.method = "reduce"
        return parsed
    except Exception as exc:  # noqa: BLE001
        logger.warning("reduce extract scoring failed: %s", exc)
        return None


def score_citation_importance(
    client: Any,
    target: TargetPaper,
    papers: list[MatchedCitingPaper],
    *,
    counts: dict[str, int],
    themes: str = "",
    map_result_id: str | None = None,
    on_event: EventCallback | None = None,
    cancel: CancelCheck | None = None,
) -> ImportanceScore:
    """Score importance (0-100) from reduce synthesis via the chat Agent."""
    prompt = build_importance_prompt(
        target, papers, counts=counts, themes=themes
    )
    emit_event(
        on_event,
        "score",
        status="started",
        message="Scoring citation importance from map/reduce via chat Agent",
        current_item=target.title or target.doi or "Target paper",
        prompt_chars=len(prompt),
        has_reduce_synthesis=bool(themes.strip()),
        map_result_id=map_result_id,
    )

    fulltext = [p for p in papers if p.paperclip_id and p.has_fulltext]
    if not fulltext or not (themes or "").strip():
        score = _heuristic_importance_score(papers, counts)
        score.prompt = prompt
        emit_event(
            on_event,
            "score",
            status="ok",
            score=score.score,
            label=score.label,
            method=score.method,
        )
        return score

    if _cancelled(cancel):
        score = _heuristic_importance_score(papers, counts)
        score.prompt = prompt
        return score

    parsed = _score_with_chat_agent(prompt)
    if parsed is None and map_result_id and not _cancelled(cancel):
        parsed = _score_with_reduce_extract(
            client, map_result_id=map_result_id, prompt=prompt
        )

    if parsed is None:
        parsed = _heuristic_importance_score(papers, counts)
    parsed.prompt = prompt
    emit_event(
        on_event,
        "score",
        status="ok",
        score=parsed.score,
        label=parsed.label,
        method=parsed.method,
        rationale=parsed.rationale,
    )
    return parsed


def run_analysis(
    client: Any,
    query: str,
    *,
    select_doi: str | None = None,
    limit: int = 200,
    skip_summary: bool = False,
    match_workers: int = DEFAULT_MATCH_WORKERS,
    on_event: EventCallback | None = None,
    cancel: CancelCheck | None = None,
    url_opener: Callable[[str], str] | None = None,
    provider_fetchers: dict[str, Callable[..., dict[str, Any]]] | None = None,
    collect_fn: Callable[..., ProviderBundle] | None = None,
) -> AnalysisResult:
    """Run the full citation-explorer pipeline and emit progress events."""
    target, candidates, err = resolve_target(
        client,
        query,
        select_doi=select_doi,
        url_opener=url_opener,
        on_event=on_event,
    )
    if candidates:
        result = AnalysisResult(
            target=TargetPaper(query=query),
            candidates=candidates,
        )
        emit_event(on_event, "done", result=result.to_dict())
        return result
    if err or target is None:
        result = AnalysisResult(
            target=TargetPaper(query=query),
            error=err or "Could not resolve target paper",
        )
        emit_event(on_event, "error", message=result.error)
        emit_event(on_event, "done", result=result.to_dict())
        return result

    if _cancelled(cancel):
        result = AnalysisResult(target=target, cancelled=True)
        emit_event(on_event, "done", result=result.to_dict())
        return result

    if not target.doi:
        result = AnalysisResult(
            target=target,
            error="Resolved paper has no DOI; citation APIs require a DOI",
        )
        emit_event(on_event, "error", message=result.error)
        emit_event(on_event, "done", result=result.to_dict())
        return result

    emit_event(
        on_event,
        "providers",
        status="started",
        doi=target.doi,
        current_item="OpenAlex + NIH iCite",
        message="Fetching citing records from OpenAlex and NIH iCite",
    )
    collector = collect_fn or collect_providers
    try:
        bundle = collector(
            target.doi,
            list_limit=limit,
            fetchers=provider_fetchers,
        )
    except Exception as exc:  # noqa: BLE001
        result = AnalysisResult(target=target, error=f"Provider fetch failed: {exc}")
        emit_event(on_event, "error", message=result.error)
        emit_event(on_event, "done", result=result.to_dict())
        return result

    if bundle.target_title and not target.title:
        target.title = bundle.target_title
    if bundle.target_pmid and not target.pmid:
        target.pmid = bundle.target_pmid

    # Drop self-edges (same DOI / PMID / Paperclip id as the target).
    target_doi = (target.doi or "").lower()
    target_pmid = str(target.pmid or "")
    bundle.citing = [
        rec
        for rec in bundle.citing
        if not (
            (rec.doi and target_doi and rec.doi.lower() == target_doi)
            or (rec.pmid and target_pmid and str(rec.pmid) == target_pmid)
        )
    ]

    emit_event(
        on_event,
        "providers",
        status="ok",
        provider_edge_counts=bundle.provider_edge_counts,
        unique_citing=len(bundle.citing),
        checks=bundle.checks.to_dict(),
        errors=bundle.errors,
    )

    if _cancelled(cancel):
        result = AnalysisResult(
            target=target,
            checks=bundle.checks.to_dict(),
            provider_edge_counts=bundle.provider_edge_counts,
            provider_errors=bundle.errors,
            cancelled=True,
        )
        emit_event(on_event, "done", result=result.to_dict())
        return result

    emit_event(
        on_event,
        "match",
        status="started",
        total=len(bundle.citing),
        message="Matching citing works into Paperclip full text",
    )

    matched: list[MatchedCitingPaper] = []
    with ThreadPoolExecutor(max_workers=max(1, match_workers)) as pool:
        futures = {
            pool.submit(match_citing_record, client, rec): rec for rec in bundle.citing
        }
        completed_matches = 0
        for fut in as_completed(futures):
            if _cancelled(cancel):
                break
            rec = futures[fut]
            try:
                matched.append(fut.result())
            except Exception as exc:  # noqa: BLE001
                matched.append(
                    MatchedCitingPaper(
                        title=rec.title,
                        doi=rec.doi,
                        pmid=rec.pmid,
                        providers=list(rec.providers),
                    )
                )
                logger.debug("match failed: %s", exc)
            completed_matches += 1
            emit_event(
                on_event,
                "match",
                status="progress",
                completed=completed_matches,
                total=len(futures),
                current_item=rec.title or rec.doi or rec.pmid or "Citing paper",
            )

    matched = _deduplicate_matched_papers(matched)
    if target.paperclip_id:
        matched = [
            paper
            for paper in matched
            if paper.paperclip_id != target.paperclip_id
        ]

    # Stable order: fulltext first, then matched, then by year desc
    matched.sort(
        key=lambda p: (
            0 if p.has_fulltext else 1 if p.paperclip_id else 2,
            -(p.year or 0),
            (p.title or "").lower(),
        )
    )

    paperclip_matches = sum(1 for p in matched if p.paperclip_id)
    fulltext_matches = sum(1 for p in matched if p.has_fulltext)
    emit_event(
        on_event,
        "match",
        status="ok",
        paperclip_matches=paperclip_matches,
        fulltext_matches=fulltext_matches,
        total=len(matched),
    )

    if _cancelled(cancel):
        result = AnalysisResult(
            target=target,
            checks=bundle.checks.to_dict(),
            provider_edge_counts=bundle.provider_edge_counts,
            provider_errors=bundle.errors,
            citing_papers=matched,
            cancelled=True,
            counts={
                "provider_edges": sum(bundle.provider_edge_counts.values()),
                "unique_citing": len(matched),
                "paperclip_matches": paperclip_matches,
                "readable_fulltext": fulltext_matches,
                "in_text_uses": 0,
            },
        )
        emit_event(on_event, "done", result=result.to_dict())
        return result

    emit_event(
        on_event,
        "context",
        status="started",
        total=fulltext_matches,
        message="Extracting bibliography entries and in-text uses",
    )

    fulltext_papers = [p for p in matched if p.has_fulltext and p.paperclip_id]
    with ThreadPoolExecutor(max_workers=DEFAULT_CONTEXT_WORKERS) as pool:
        futures = {
            pool.submit(extract_contexts, client, paper, target): paper
            for paper in fulltext_papers
        }
        done_map: dict[int, MatchedCitingPaper] = {}
        completed_contexts = 0
        for fut in as_completed(futures):
            if _cancelled(cancel):
                break
            original = futures[fut]
            try:
                done_map[id(original)] = fut.result()
            except Exception as exc:  # noqa: BLE001
                logger.debug("context extract failed: %s", exc)
                done_map[id(original)] = original
            completed_contexts += 1
            emit_event(
                on_event,
                "context",
                status="progress",
                completed=completed_contexts,
                total=len(futures),
                current_item=(
                    original.title
                    or original.doi
                    or original.paperclip_id
                    or "Full-text paper"
                ),
            )

    matched = [done_map.get(id(p), p) for p in matched]
    in_text = sum(1 for p in matched if p.contexts)
    bibliography_only = sum(1 for p in matched if p.bibliography_only and not p.contexts)
    emit_event(
        on_event,
        "context",
        status="ok",
        in_text_uses=in_text,
        bibliography_only=bibliography_only,
    )

    themes = ""
    map_result_id: str | None = None
    if not skip_summary and not _cancelled(cancel):
        matched, themes, map_result_id = _summarize_with_map_reduce(
            client,
            matched,
            target,
            limit=min(DEFAULT_MAP_LIMIT, limit),
            on_event=on_event,
            cancel=cancel,
        )

    counts = {
        "provider_edges": sum(bundle.provider_edge_counts.values()),
        "unique_citing": len(matched),
        "total_citations": len(matched),
        "paperclip_matches": sum(1 for p in matched if p.paperclip_id),
        "readable_fulltext": sum(1 for p in matched if p.has_fulltext),
        "paperclip_fulltext": sum(1 for p in matched if p.has_fulltext),
        "in_text_uses": sum(1 for p in matched if p.contexts),
        "bibliography_only": sum(
            1 for p in matched if p.bibliography_only and not p.contexts
        ),
    }

    importance: ImportanceScore | None = None
    if not skip_summary and not _cancelled(cancel):
        importance = score_citation_importance(
            client,
            target,
            matched,
            counts=counts,
            themes=themes,
            map_result_id=map_result_id,
            on_event=on_event,
            cancel=cancel,
        )

    result = AnalysisResult(
        target=target,
        counts=counts,
        checks=bundle.checks.to_dict(),
        provider_edge_counts=bundle.provider_edge_counts,
        provider_errors=bundle.errors,
        citing_papers=matched,
        themes=themes,
        importance=importance,
        cancelled=_cancelled(cancel),
    )
    emit_event(on_event, "done", result=result.to_dict())
    return result


def iter_ndjson_events(
    client: Any,
    query: str,
    **kwargs: Any,
) -> Iterator[str]:
    """Run analysis and yield NDJSON event lines (including the final done event)."""
    queue: list[dict[str, Any]] = []
    lock = threading.Lock()

    def _on_event(event: dict[str, Any]) -> None:
        with lock:
            queue.append(event)

    result = run_analysis(client, query, on_event=_on_event, **kwargs)
    del result
    with lock:
        events = list(queue)
    for event in events:
        yield json.dumps(event, ensure_ascii=False)


def register_cli(main_group: Any) -> None:
    """Register the ``citation-explorer`` Click command on the Paperclip group."""
    import click

    @main_group.command("citation-explorer")
    @click.argument("query", nargs=-1, required=True)
    @click.option(
        "--limit",
        default=200,
        show_default=True,
        type=int,
        help="Max citing works to fetch/match per provider.",
    )
    @click.option(
        "--select-doi",
        default=None,
        help="Disambiguate a title query by choosing this DOI.",
    )
    @click.option(
        "--skip-summary",
        is_flag=True,
        help="Skip per-paper summary synthesis.",
    )
    @click.option(
        "--events/--no-events",
        default=True,
        help="Emit newline-delimited JSON progress events (default: on).",
    )
    @click.pass_context
    def citation_explorer_cmd(
        ctx: Any,
        query: tuple[str, ...],
        limit: int,
        select_doi: str | None,
        skip_summary: bool,
        events: bool,
    ) -> None:
        """Resolve a paper, find citing works, and summarize Paperclip full-text uses.

        \b
        Examples:
            paperclip citation-explorer 10.1038/s41467-025-62346-0
            paperclip citation-explorer "https://www.nature.com/articles/s41586-019-1799-6"
            paperclip citation-explorer "ROSIE antibody design" --select-doi 10.1038/...
        """
        from .app import _get_client

        q = " ".join(query).strip()
        client = _get_client()

        def _print_event(event: dict[str, Any]) -> None:
            if events:
                click.echo(json.dumps(event, ensure_ascii=False))
            else:
                et = event.get("type")
                if et == "error":
                    click.echo(f"error: {event.get('message')}", err=True)
                elif et == "candidates":
                    click.echo("Multiple title matches:")
                    for c in event.get("candidates") or []:
                        click.echo(
                            f"  - {c.get('doi') or '(no doi)'}  {c.get('title', '')[:80]}"
                        )
                    click.echo("Re-run with --select-doi <DOI>")
                elif et == "done":
                    result = event.get("result") or {}
                    counts = result.get("counts") or {}
                    click.echo(
                        "done: "
                        + ", ".join(f"{k}={v}" for k, v in counts.items())
                    )
                    if not events:
                        click.echo(json.dumps(result, ensure_ascii=False, indent=2))

        result = run_analysis(
            client,
            q,
            select_doi=select_doi,
            limit=limit,
            skip_summary=skip_summary,
            on_event=_print_event,
        )
        if result.error and not result.candidates:
            raise SystemExit(1)
        if result.candidates and not select_doi:
            raise SystemExit(2)
