"""CLI subpackage for the ``paperclip`` command.

This subpackage hosts the Click entrypoint plus local-only support modules
(interactive OAuth login, PKCE helpers, skill installer, self-updater). It is
intentionally a thin wrapper around :mod:`gxl_paperclip.client` — all transport
and command logic lives in the SDK.

The ``paperclip`` console script resolves to :func:`main` via
``gxl_paperclip.cli:main`` (see ``pyproject.toml``).
"""

from __future__ import annotations

from .app import main

__all__ = ["main"]
