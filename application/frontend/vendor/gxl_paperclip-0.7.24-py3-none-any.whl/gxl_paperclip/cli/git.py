"""Git-like tracking of papers and claims.

Wraps the paper-repo backend API. A named repo becomes "git-tracked" when you
run `paperclip git init` on it. Repos are independent of the clipboard: adding
a paper to a repo does not copy it into ``/clipboard/`` (use ``paperclip cp``).
"""

from __future__ import annotations

import click

from . import repo

GREEN = "\033[32m"
RED = "\033[31m"
CYAN = "\033[36m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"


def _normalize_folder(path: str) -> str:
    """Strip /clipboard/ prefix and trailing slash to get bare folder name."""
    path = path.strip().rstrip("/")
    for prefix in ("/clipboard/", "clipboard/"):
        if path.startswith(prefix):
            path = path[len(prefix):]
            break
    return path


def _ensure_folder_tracked(folder: str) -> None:
    """Set the folder as the active repo context."""
    repo.set_active_repo(folder)


def _repo_name(active: str) -> str:
    """Normalized repo display name (lowercased, spaces→dashes).

    Matches ``init_repo``'s normalization so the name shown to the user is the
    same one the backend stores.
    """
    return active.strip().replace(" ", "-").lower()


@click.group("git")
def git_cmd():
    """Git-like version tracking of papers and claims.

    Repos track paper membership and claims/citations for verification. They
    are independent of your clipboard — ``git add`` does not copy papers into
    ``/clipboard/``; use ``paperclip cp`` for that.

    \b
    Examples:
        paperclip git init lit-review
        paperclip git add PMC10777452 "SGLT2 reduces HF hospitalization by 30%"
        paperclip git commit -m "Initial review papers"
        paperclip git status
        paperclip git log
    """
    pass


@git_cmd.command("init")
@click.argument("folder_path")
@click.argument("description", required=False, default="")
def git_init(folder_path: str, description: str):
    """Enable git tracking for a named repo.

    Initializes claim/version tracking under the given name. This does not
    create or touch any ``/clipboard/`` folder.

    \b
    Examples:
        paperclip git init lit-review
        paperclip git init my-review "KRAS resistance mechanisms"
    """
    folder = _normalize_folder(folder_path)

    try:
        result = repo.init_repo(folder, description)
        click.echo(f"{GREEN}✓{RESET} Git tracking enabled: {BOLD}{_repo_name(folder)}{RESET}")
        if description:
            click.echo(f"  {DIM}{description}{RESET}")
        click.echo(f"  {DIM}Branch: {result.get('active_branch', 'main')}{RESET}")
    except ValueError as e:
        if "already exists" in str(e):
            repo.set_active_repo(folder)
            click.echo(f"{DIM}Already tracked. Switched to: {_repo_name(folder)}{RESET}")
        else:
            click.echo(f"{RED}✗{RESET} {e}", err=True)
            raise SystemExit(1)


@git_cmd.command("add")
@click.argument("paper_id")
@click.argument("claim", required=False, default=None)
@click.option("--folder", "-f", default=None, help="Repo name (defaults to active)")
def git_add(paper_id: str, claim: str | None, folder: str | None):
    """Add a paper (with optional claim) to the tracked folder.

    If a claim is provided, it will be verified against the paper's
    full text on the next commit.

    \b
    Examples:
        paperclip git add PMC10777452
        paperclip git add PMC10777452 "Cholera vaccines reduce mortality by 50%"
        paperclip git add bio_dca47d15 "CRISPR efficiency >90% in vivo"
    """
    if folder:
        _ensure_folder_tracked(_normalize_folder(folder))

    active = repo.get_active_repo()
    if not active:
        click.echo(f"{RED}✗{RESET} No active tracked repo. Run: paperclip git init <name>", err=True)
        raise SystemExit(1)

    try:
        repo.add_papers([paper_id])
        click.echo(f"{GREEN}✓{RESET} Tracked {paper_id} in {_repo_name(active)}")

        if claim:
            repo.annotate_paper(paper_id, claim)
            click.echo(f"  {DIM}Claim: \"{claim}\"{RESET}")
    except ValueError as e:
        click.echo(f"{RED}✗{RESET} {e}", err=True)
        raise SystemExit(1)


@git_cmd.command("commit")
@click.option("-m", "--message", required=True, help="Commit message")
@click.option("--folder", "-f", default=None, help="Repo name (defaults to active)")
def git_commit(message: str, folder: str | None):
    """Snapshot the current state and verify all claims.

    Each claim attached to a paper is checked against the paper's full text.
    Results are stored in the commit.

    \b
    Examples:
        paperclip git commit -m "Initial literature review"
        paperclip git commit -m "Added SGLT2 papers" -f /clipboard/cardio-review
    """
    if folder:
        _ensure_folder_tracked(_normalize_folder(folder))

    active = repo.get_active_repo()
    if not active:
        click.echo(f"{RED}✗{RESET} No active tracked folder.", err=True)
        raise SystemExit(1)

    try:
        result = repo.commit(message)
        sha = result.get("sha", "")[:8]
        papers = result.get("paper_count", 0)
        click.echo(f"{GREEN}✓{RESET} [{CYAN}{sha}{RESET}] {message}")
        click.echo(f"  {papers} paper(s) in {active}")
        if result.get("added"):
            click.echo(f"  {DIM}+{len(result['added'])} new{RESET}")
    except ValueError as e:
        click.echo(f"{RED}✗{RESET} {e}", err=True)
        raise SystemExit(1)


@git_cmd.command("status")
@click.option("--folder", "-f", default=None, help="Repo name (defaults to active)")
def git_status(folder: str | None):
    """Show papers, claims, and verification status.

    \b
    Examples:
        paperclip git status
        paperclip git status -f /clipboard/lit-review
    """
    if folder:
        _ensure_folder_tracked(_normalize_folder(folder))

    active = repo.get_active_repo()
    if not active:
        click.echo(f"{RED}✗{RESET} No active tracked folder.", err=True)
        raise SystemExit(1)

    try:
        status = repo.get_status()
        if not status.get("name"):
            click.echo(f"{DIM}Repo {active} is not git-tracked.{RESET}")
            return

        click.echo(f"{BOLD}{active}{RESET} ({status.get('active_branch', 'main')})")
        click.echo(f"  Papers: {status.get('paper_count', 0)}")
        click.echo(f"  Commits: {status.get('commit_count', 0)}")

        papers = status.get("papers", {})
        if papers:
            click.echo(f"\n  {'ID':<20} {'Title':<40} {'Claims':>6}")
            click.echo(f"  {'─'*20} {'─'*40} {'─'*6}")
            for pid, info in list(papers.items())[:20]:
                title = (info.get("title") or pid)[:38]
                annotations = info.get("annotations", [])
                n_claims = len(annotations)
                click.echo(f"  {pid:<20} {title:<40} {n_claims:>6}")

        verification = repo.load_verification()
        if verification:
            total = sum(len(v) for v in verification.values())
            supported = sum(
                1 for claims in verification.values()
                for c in claims if c.get("supported")
            )
            click.echo(f"\n  Verification: {GREEN}{supported}{RESET}/{total} claims supported")

    except ValueError as e:
        click.echo(f"{RED}✗{RESET} {e}", err=True)
        raise SystemExit(1)


@git_cmd.command("log")
@click.option("-n", "limit", type=int, default=10, help="Number of commits to show")
@click.option("--folder", "-f", default=None, help="Repo name (defaults to active)")
def git_log(limit: int, folder: str | None):
    """Show commit history.

    \b
    Examples:
        paperclip git log
        paperclip git log -n 5
    """
    if folder:
        _ensure_folder_tracked(_normalize_folder(folder))

    active = repo.get_active_repo()
    if not active:
        click.echo(f"{RED}✗{RESET} No active tracked folder.", err=True)
        raise SystemExit(1)

    try:
        commits = repo.get_log(limit=limit)
        if not commits:
            click.echo(f"{DIM}No commits in {active}.{RESET}")
            return

        click.echo(f"{BOLD}{active}{RESET} — commit log\n")
        for c in commits:
            sha = c.get("sha", "")[:8]
            msg = c.get("message", "")
            ts = c.get("timestamp", "")[:10]
            papers = c.get("paper_count", 0)
            click.echo(f"  {CYAN}{sha}{RESET} {msg}")
            click.echo(f"         {DIM}{ts} • {papers} papers{RESET}")
    except ValueError as e:
        click.echo(f"{RED}✗{RESET} {e}", err=True)
        raise SystemExit(1)


@git_cmd.command("branch")
@click.argument("name", required=False, default=None)
@click.option("--from", "from_branch", default=None, help="Branch to fork from")
@click.option("--folder", "-f", default=None, help="Repo name (defaults to active)")
def git_branch(name: str | None, from_branch: str | None, folder: str | None):
    """List or create branches.

    \b
    Examples:
        paperclip git branch                    # list branches
        paperclip git branch experimental       # create new branch
        paperclip git branch alt --from main    # fork from specific branch
    """
    if folder:
        _ensure_folder_tracked(_normalize_folder(folder))

    active = repo.get_active_repo()
    if not active:
        click.echo(f"{RED}✗{RESET} No active tracked folder.", err=True)
        raise SystemExit(1)

    try:
        if name:
            result = repo.create_branch(name, from_branch=from_branch)
            click.echo(f"{GREEN}✓{RESET} Branch '{name}' created ({result.get('papers', 0)} papers)")
        else:
            branches = repo.list_branches()
            if not branches:
                click.echo(f"{DIM}No branches.{RESET}")
                return
            for b in branches:
                marker = f"{GREEN}*{RESET} " if b.get("active") else "  "
                click.echo(f"{marker}{b['name']} ({b.get('paper_count', 0)} papers)")
    except ValueError as e:
        click.echo(f"{RED}✗{RESET} {e}", err=True)
        raise SystemExit(1)


@git_cmd.command("switch")
@click.argument("branch_name")
@click.option("--folder", "-f", default=None, help="Repo name (defaults to active)")
def git_switch(branch_name: str, folder: str | None):
    """Switch to a different branch.

    \b
    Examples:
        paperclip git switch experimental
        paperclip git switch main
    """
    if folder:
        _ensure_folder_tracked(_normalize_folder(folder))

    active = repo.get_active_repo()
    if not active:
        click.echo(f"{RED}✗{RESET} No active tracked folder.", err=True)
        raise SystemExit(1)

    try:
        result = repo.switch_branch(branch_name)
        click.echo(f"{GREEN}✓{RESET} Switched to branch '{branch_name}' ({result.get('paper_count', 0)} papers)")
    except ValueError as e:
        click.echo(f"{RED}✗{RESET} {e}", err=True)
        raise SystemExit(1)


@git_cmd.command("merge")
@click.argument("source_branch")
@click.option("--folder", "-f", default=None, help="Repo name (defaults to active)")
def git_merge(source_branch: str, folder: str | None):
    """Merge a branch into the current branch.

    \b
    Examples:
        paperclip git merge experimental
    """
    if folder:
        _ensure_folder_tracked(_normalize_folder(folder))

    active = repo.get_active_repo()
    if not active:
        click.echo(f"{RED}✗{RESET} No active tracked folder.", err=True)
        raise SystemExit(1)

    try:
        result = repo.merge_branch(source_branch)
        merged = result.get("merged", 0)
        click.echo(f"{GREEN}✓{RESET} Merged '{source_branch}' → {result.get('target', 'main')} ({merged} new papers)")
    except ValueError as e:
        click.echo(f"{RED}✗{RESET} {e}", err=True)
        raise SystemExit(1)
