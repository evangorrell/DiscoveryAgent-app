"""Citation data for PaperCLIP papers via Semantic Scholar API.

With API key: 1 req/s per-paper endpoints, higher batch limits.
Key can be overridden via S2_API_KEY env var.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
import urllib.error
import urllib.request

logger = logging.getLogger(__name__)

S2_BATCH_URL = "https://api.semanticscholar.org/graph/v1/paper/batch"
S2_PAPER_URL = "https://api.semanticscholar.org/graph/v1/paper"
S2_FIELDS = "citationCount,title,year,externalIds"

def _s2_api_key() -> str | None:
    """Return S2 API key from env, or None for unauthenticated access."""
    return os.environ.get("S2_API_KEY")


def _fetch_doi_single(pid: str) -> tuple[str, str | None]:
    """Fetch DOI for a single paper ID via paperclip. Returns (paper_id, doi_or_None)."""
    import subprocess

    try:
        result = subprocess.run(
            ["paperclip", "cat", f"/papers/{pid}/meta.json"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip():
            match = re.search(r"\{.*\}", result.stdout, re.DOTALL)
            if match:
                meta = json.loads(match.group())
                return pid, meta.get("doi") or None
    except Exception:
        pass
    return pid, None


def fetch_dois(paper_ids: list[str]) -> dict[str, str]:
    """Fetch DOIs for paper IDs from PaperCLIP server (parallel). Returns {paper_id: doi}."""
    from concurrent.futures import ThreadPoolExecutor

    if not paper_ids:
        return {}
    dois: dict[str, str] = {}
    with ThreadPoolExecutor(max_workers=min(len(paper_ids), 20)) as pool:
        for pid, doi in pool.map(_fetch_doi_single, paper_ids):
            if doi:
                dois[pid] = doi
    return dois


def get_citation_counts(
    paper_ids: list[str],
    known_dois: dict[str, str] | None = None,
) -> list[dict]:
    """Look up citation counts via Semantic Scholar batch API.

    If known_dois is provided, uses those DOIs directly (skips slow fetch).
    """
    if not paper_ids:
        return []

    all_known = dict(known_dois) if known_dois else {}
    dois: dict[str, str] = {}
    missing: list[str] = []
    for pid in paper_ids:
        if pid in all_known:
            dois[pid] = all_known[pid]
        else:
            missing.append(pid)
    if missing:
        dois.update(fetch_dois(missing))

    if not dois:
        return []

    doi_to_pid = {doi: pid for pid, doi in dois.items()}
    id_list = [f"DOI:{doi}" for doi in dois.values()]

    results: list[dict] = []
    for i in range(0, len(id_list), 500):
        batch = id_list[i : i + 500]
        try:
            payload = json.dumps({"ids": batch}).encode()
            headers = {"Content-Type": "application/json"}
            key = _s2_api_key()
            if key:
                headers["x-api-key"] = key
            req = urllib.request.Request(
                f"{S2_BATCH_URL}?fields={S2_FIELDS}",
                data=payload,
                headers=headers,
            )
            resp = urllib.request.urlopen(req, timeout=15)
            data = json.loads(resp.read())
        except Exception as e:
            if "429" in str(e):
                logger.warning("Semantic Scholar rate limit hit — try again in a minute")
            else:
                logger.warning("S2 batch lookup failed: %s", e)
            continue

        for j, entry in enumerate(data):
            if entry is None:
                continue
            doi = batch[j].replace("DOI:", "")
            pid = doi_to_pid.get(doi)
            if not pid:
                continue
            results.append({
                "paper_id": pid,
                "cited_by_count": entry.get("citationCount", 0) or 0,
                "pub_year": entry.get("year"),
                "title": entry.get("title", ""),
                "doi": doi,
                "s2_id": entry.get("paperId", ""),
            })

    return results


def _s2_get(url: str, retries: int = 3) -> dict | None:
    """GET from S2 API with retry on rate limit."""
    for i in range(retries):
        try:
            req = urllib.request.Request(url)
            key = _s2_api_key()
            if key:
                req.add_header("x-api-key", key)
            resp = urllib.request.urlopen(req, timeout=15)
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            if e.code == 429 and i < retries - 1:
                time.sleep(3 * (i + 1))
            else:
                logger.warning("S2 API error %s: %s", url.split("?")[0][-20:], e)
                return None
        except Exception as e:
            logger.warning("S2 API error: %s", e)
            return None
    return None


def get_citation_graph(
    paper_ids: list[str],
    known_dois: dict[str, str] | None = None,
) -> dict:
    """Build intra-repo citation graph.

    For each paper, queries S2 for its references and checks which ones
    are also in the repo. Returns nodes + directed edges.

    Returns:
        {
            "nodes": [{"id": str, "doi": str, "title": str, "cited_by_count": int}],
            "edges": [{"source": str, "target": str, "influential": bool}],
        }
    """
    if not paper_ids:
        return {"nodes": [], "edges": []}

    counts = get_citation_counts(paper_ids, known_dois)
    if not counts:
        return {"nodes": [], "edges": []}

    doi_to_pid: dict[str, str] = {}
    s2_to_pid: dict[str, str] = {}
    nodes = []
    for c in counts:
        doi_to_pid[c["doi"].lower()] = c["paper_id"]
        if c.get("s2_id"):
            s2_to_pid[c["s2_id"]] = c["paper_id"]
        nodes.append({
            "id": c["paper_id"],
            "doi": c["doi"],
            "title": c["title"],
            "cited_by_count": c["cited_by_count"],
        })

    edges: list[dict] = []
    seen_edges: set[tuple[str, str]] = set()

    for c in counts:
        s2_id = c.get("s2_id")
        if not s2_id:
            continue

        url = (
            f"{S2_PAPER_URL}/{s2_id}/references"
            f"?fields=externalIds,isInfluential&limit=1000"
        )
        data = _s2_get(url)
        if not data:
            continue

        for ref in data.get("data", []):
            cited = ref.get("citedPaper") or {}
            ext_ids = cited.get("externalIds") or {}
            ref_doi = (ext_ids.get("DOI") or "").lower()
            ref_s2 = cited.get("paperId", "")

            target_pid = doi_to_pid.get(ref_doi) or s2_to_pid.get(ref_s2)
            if target_pid and target_pid != c["paper_id"]:
                edge_key = (c["paper_id"], target_pid)
                if edge_key not in seen_edges:
                    seen_edges.add(edge_key)
                    edges.append({
                        "source": c["paper_id"],
                        "target": target_pid,
                        "influential": ref.get("isInfluential", False),
                    })

        time.sleep(0.2 if _s2_api_key() else 1.0)

    return {"nodes": nodes, "edges": edges}


def get_paper_references(paper_id: str, known_doi: str | None = None) -> list[dict]:
    """Fetch all references for a paper via Semantic Scholar.

    Returns list of dicts with keys: doi, pmc, pmid, title, year, citation_count, s2_id.
    """
    doi = known_doi

    # Try repo-stored DOIs first
    if not doi:
        try:
            from . import repo
            stored = repo.get_repo_dois()
            doi = stored.get(paper_id)
        except Exception:
            pass

    # Fall back to MCP server meta.json lookup
    if not doi:
        _, d = _fetch_doi_single(paper_id)
        doi = d

    if not doi:
        raise ValueError(f"Cannot resolve DOI for {paper_id}. Try: --doi <doi>")

    # Resolve S2 paper ID
    data = _s2_get(f"{S2_PAPER_URL}/DOI:{doi}?fields=paperId")
    if not data or not data.get("paperId"):
        raise ValueError(f"Paper DOI:{doi} not found on Semantic Scholar.")

    s2_id = data["paperId"]

    refs: list[dict] = []
    offset = 0
    while True:
        url = (
            f"{S2_PAPER_URL}/{s2_id}/references"
            f"?fields=externalIds,title,year,citationCount&limit=1000&offset={offset}"
        )
        page = _s2_get(url)
        if not page:
            break
        items = page.get("data", [])
        if not items:
            break

        for item in items:
            cited = item.get("citedPaper") or {}
            ext = cited.get("externalIds") or {}
            refs.append({
                "doi": ext.get("DOI") or "",
                "pmc": ext.get("PubMedCentral") or "",
                "pmid": ext.get("PubMed") or "",
                "title": cited.get("title") or "",
                "year": cited.get("year"),
                "citation_count": cited.get("citationCount") or 0,
                "s2_id": cited.get("paperId") or "",
            })

        if len(items) < 1000:
            break
        offset += 1000
        time.sleep(0.2 if _s2_api_key() else 1.0)

    return refs


def match_references_in_corpus(refs: list[dict]) -> list[dict]:
    """Match references against the paperclip corpus.

    Strategy:
    1. PMC IDs from S2 → directly assumed in corpus (PMC papers are fully indexed)
    2. DOI batch lookup via SQL for remaining refs
    3. PMID batch lookup via SQL for still-unmatched refs

    Returns refs augmented with a 'corpus_id' field (the paperclip paper ID) if matched.
    """
    import subprocess

    def _sql(query: str) -> list[list[str]]:
        """Run SQL and parse the table-formatted output into rows of strings."""
        try:
            result = subprocess.run(
                ["paperclip", "sql", query],
                capture_output=True, text=True, timeout=20,
            )
            if result.returncode != 0 or not result.stdout.strip():
                return []
        except Exception:
            return []

        rows: list[list[str]] = []
        for line in result.stdout.strip().split("\n"):
            if not line.strip() or line.strip().startswith("-"):
                continue
            cells = [c.strip() for c in line.split(" | ")]
            rows.append(cells)
        # Skip header row (first row is column names)
        return rows[1:] if len(rows) > 1 else []

    matched: dict[int, str] = {}  # ref index → corpus_id

    # 1. Direct PMC ID match — S2 gives PubMedCentral IDs for PMC papers.
    #    These map 1:1 to paperclip IDs.
    for i, r in enumerate(refs):
        pmc = r.get("pmc", "")
        if pmc:
            matched[i] = f"PMC{pmc}"

    # 2. DOI batch lookup for non-PMC refs
    unmatched_doi = [(i, r) for i, r in enumerate(refs) if i not in matched and r.get("doi")]
    if unmatched_doi:
        for batch_start in range(0, len(unmatched_doi), 100):
            batch = unmatched_doi[batch_start:batch_start + 100]
            doi_lookup = {r["doi"].lower(): i for i, r in batch}
            escaped = [r["doi"].replace("'", "''") for _, r in batch]
            vals = ",".join(f"'{d}'" for d in escaped)
            rows = _sql(f"SELECT id, doi FROM documents WHERE doi IN ({vals}) LIMIT 200")
            for cells in rows:
                if len(cells) >= 2:
                    pid, doi_val = cells[0], cells[1].lower()
                    if doi_val in doi_lookup:
                        matched[doi_lookup[doi_val]] = pid

    # 3. PMID batch lookup for remaining
    unmatched_pmid = [(i, r) for i, r in enumerate(refs) if i not in matched and r.get("pmid")]
    if unmatched_pmid:
        for batch_start in range(0, len(unmatched_pmid), 100):
            batch = unmatched_pmid[batch_start:batch_start + 100]
            pmid_lookup = {r["pmid"]: i for i, r in batch}
            vals = ",".join(f"'{r['pmid']}'" for _, r in batch)
            rows = _sql(f"SELECT id, pmid FROM documents WHERE pmid::text IN ({vals}) LIMIT 200")
            for cells in rows:
                if len(cells) >= 2:
                    pid, pmid_val = cells[0], cells[1]
                    if pmid_val in pmid_lookup:
                        matched[pmid_lookup[pmid_val]] = pid

    for i, ref in enumerate(refs):
        ref["corpus_id"] = matched.get(i)

    return refs


def match_bib_entries_in_corpus(
    entries: list[dict],
    *,
    on_progress: "callable | None" = None,
) -> list[dict]:
    """Match parsed bib/ris entries against the paperclip corpus.

    Strategy:
    1. PMC IDs (from bib metadata) → direct corpus ID
    1b. arXiv IDs (parsed from bib) → lookup via SDK
    2. DOI batch lookup via SQL
    3. Title fuzzy-match fallback via SDK lookup

    Uses the PaperclipClient SDK directly (single HTTP connection, no subprocess
    spawning) with retry-on-429 to handle rate limits gracefully.
    """
    from ..client import PaperclipClient, RateLimitError, PaperclipError

    _ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
    _CORPUS_ID_RE = re.compile(r"(PMC\d+|bio_[a-f0-9]+|med_[a-f0-9]+|arx_[a-zA-Z0-9_.]+)")
    _FOUND_RE = re.compile(r"Found (\d+) papers?")
    _NUMBERED_TITLE_RE = re.compile(r"^\s*\d+\.\s+(.+)")

    def _strip_ansi(text: str) -> str:
        return _ANSI_RE.sub("", text)

    def _normalize_title(t: str) -> set[str]:
        t = re.sub(r"[^\w\s]", " ", t.lower())
        return {w for w in t.split() if len(w) > 1}

    def _title_similarity(a: str, b: str) -> float:
        ta, tb = _normalize_title(a), _normalize_title(b)
        if not ta or not tb:
            return 0.0
        return len(ta & tb) / len(ta | tb)

    def _call_with_retry(fn, *, retries: int = 3):
        """Call fn(), retrying on RateLimitError with backoff."""
        for attempt in range(retries):
            try:
                return fn()
            except RateLimitError:
                if attempt < retries - 1:
                    time.sleep(1.0 * (attempt + 1))
                else:
                    return None
            except PaperclipError:
                return None
        return None

    def _parse_sql_output(output: str) -> list[list[str]]:
        rows: list[list[str]] = []
        for line in output.strip().split("\n"):
            if not line.strip() or line.strip().startswith("-"):
                continue
            cells = [c.strip() for c in line.split(" | ")]
            rows.append(cells)
        return rows[1:] if len(rows) > 1 else []

    # Build client — from_env() handles PAPERCLIP_BEARER_TOKEN > API key >
    # file credentials in the correct priority order.
    try:
        client = PaperclipClient.from_env()
    except Exception as _exc:
        logger.warning("Cannot build PaperclipClient; matching will be limited: %s", _exc)
        for entry in entries:
            entry["corpus_id"] = None
        return entries

    from .. import config as _config
    _base_url = _config.get_base_url()
    is_local = "localhost" in _base_url or "127.0.0.1" in _base_url

    matched: dict[int, str] = {}
    total = len(entries)

    # Phase 1: Direct PMC ID match
    for i, e in enumerate(entries):
        pmc = e.get("pmc", "")
        if pmc:
            cid = f"PMC{pmc}" if not pmc.startswith("PMC") else pmc
            matched[i] = cid

    if on_progress:
        on_progress(len(matched), total, "PMC IDs")

    # Phase 1b: arXiv ID lookup (parallelized with retry)
    unmatched_arxiv = [(i, e) for i, e in enumerate(entries) if i not in matched and e.get("arxiv")]
    if unmatched_arxiv:
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _match_arxiv(idx_entry):
            i, e = idx_entry
            arxiv_id = e["arxiv"]
            result = _call_with_retry(lambda aid=arxiv_id: client.lookup("arxiv", aid, limit=1))
            if result and result.output:
                output = _strip_ansi(result.output)
                fm = _FOUND_RE.search(output)
                if fm and int(fm.group(1)) > 0:
                    m = _CORPUS_ID_RE.search(output)
                    return i, m.group(1) if m else f"arx_{arxiv_id}"
            return i, None

        workers = min(len(unmatched_arxiv), 8 if is_local else 4)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = {pool.submit(_match_arxiv, ie): ie for ie in unmatched_arxiv}
            for fut in as_completed(futs):
                try:
                    i, cid = fut.result()
                    if cid:
                        matched[i] = cid
                except Exception:
                    pass

    if on_progress:
        on_progress(len(matched), total, "arXiv IDs")

    # Phase 2: DOI batch lookup via SQL
    unmatched_doi = [(i, e) for i, e in enumerate(entries) if i not in matched and e.get("doi")]
    if unmatched_doi:
        for batch_start in range(0, len(unmatched_doi), 100):
            batch = unmatched_doi[batch_start : batch_start + 100]
            doi_lookup = {e["doi"].lower().rstrip("."): i for i, e in batch}
            escaped = [e["doi"].replace("'", "''").rstrip(".") for _, e in batch]
            lower_vals = ",".join("'" + d.lower() + "'" for d in escaped)
            query = f"SELECT id, doi FROM documents WHERE LOWER(doi) IN ({lower_vals}) LIMIT 200"
            result = _call_with_retry(lambda q=query: client.sql(q))
            if result and result.output:
                for cells in _parse_sql_output(result.output):
                    if len(cells) >= 2:
                        pid, doi_val = cells[0], cells[1].lower().rstrip(".")
                        if doi_val in doi_lookup:
                            matched[doi_lookup[doi_val]] = pid

    if on_progress:
        on_progress(len(matched), total, "DOI lookup")

    # Phase 3: Title fuzzy-match via lookup (parallelized with retry)
    unmatched_title = [
        (i, e) for i, e in enumerate(entries)
        if i not in matched and e.get("title") and len(e.get("title", "")) >= 10
    ]
    if unmatched_title:
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _match_title(idx_entry):
            i, e = idx_entry
            title = e["title"]
            result = _call_with_retry(lambda t=title: client.lookup("title", t, limit=3))
            if not result or not result.output:
                return i, None

            output = _strip_ansi(result.output)
            lines = output.split("\n")
            current_title = ""
            for line in lines:
                tm = _NUMBERED_TITLE_RE.match(line)
                if tm:
                    current_title = tm.group(1).strip()
                elif current_title:
                    cm = _CORPUS_ID_RE.search(line)
                    if cm:
                        if _title_similarity(title, current_title) >= 0.7:
                            return i, cm.group(1)
                        current_title = ""
            return i, None

        workers = min(len(unmatched_title), 4 if is_local else 2)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = {pool.submit(_match_title, ie): ie for ie in unmatched_title}
            for fut in as_completed(futs):
                try:
                    i, cid = fut.result()
                    if cid:
                        matched[i] = cid
                except Exception:
                    pass

    if on_progress:
        on_progress(len(matched), total, "title search")

    for i, entry in enumerate(entries):
        entry["corpus_id"] = matched.get(i)

    return entries
