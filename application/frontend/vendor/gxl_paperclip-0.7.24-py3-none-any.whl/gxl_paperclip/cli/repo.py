"""Paper repository management — uses HTTP API exclusively.

No database connections. All operations go through the backend API.
"""

from __future__ import annotations

import json as _json
import logging
import os
from pathlib import Path
from typing import Any

from .. import config
from ..client.client import PaperclipClient
from ..client.errors import NotFoundError, PaperclipError, AuthError

logger = logging.getLogger(__name__)

REPOS_DIR = config.PAPERCLIP_DIR / "repos"

# ── Client helper ────────────────────────────────────────────────


_client_override: PaperclipClient | None = None


def set_client(client: PaperclipClient | None) -> None:
    """Override the module-level client (e.g. for MCP internal routing)."""
    global _client_override
    _client_override = client


def _get_client() -> PaperclipClient:
    """Get a PaperclipClient: explicit override > env (bearer/api-key/file/localhost)."""
    if _client_override is not None:
        return _client_override

    return PaperclipClient.from_env()


def validate_auth() -> bool:
    """Test if authentication is valid by making a lightweight API call."""
    client = _get_client()
    try:
        # Lightweight call that requires auth
        client.library.list_papers(per_page=1)
        return True
    except AuthError:
        return False


def _repos_dir() -> Path:
    REPOS_DIR.mkdir(parents=True, exist_ok=True)
    return REPOS_DIR


# ── Active repo tracking ────────────────────────────────────────

_override_repo: str | None = None


def set_repo_override(name: str | None) -> None:
    global _override_repo
    _override_repo = name


def _stateless_repo() -> bool:
    """Repo selection is always stateless now (flag/env only)."""
    return True


def _active_repo_file() -> Path:
    return _repos_dir() / ".active"


def get_active_repo() -> str | None:
    """Resolve the target repo.

    Precedence: ``--repo`` flag (per command) > ``PAPERCLIP_REPO`` env var
    (per session) > the persisted ``checkout`` selection (``.active`` file).

    The flag/env always win, so concurrent agents that scope themselves with
    ``PAPERCLIP_REPO``/``--repo`` never collide with (or get clobbered by) an
    interactive ``checkout``. The ``.active`` file just makes ``checkout`` sticky
    for a single interactive session, like ``git`` does with the current branch.
    """
    if _override_repo:
        return _override_repo
    env_repo = os.getenv("PAPERCLIP_REPO", "").strip()
    if env_repo:
        return env_repo
    f = _active_repo_file()
    if f.exists():
        try:
            name = f.read_text().strip()
            if name:
                return name
        except OSError:
            pass
    return None


def set_active_repo(name: str | None):
    """Persist (or clear) the interactive ``checkout`` selection in ``.active``.

    ``--repo``/``PAPERCLIP_REPO`` still override this at resolution time, so this
    only affects bare interactive commands.
    """
    f = _active_repo_file()
    if not name:
        if f.exists():
            try:
                f.unlink()
            except OSError:
                pass
        return
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(name.strip())
    except OSError as e:
        logger.debug("Failed to persist active repo: %s", e)


# ── Verification cache ────────────────────────────────────────


def _verification_file() -> Path:
    return _repos_dir() / ".last_verification.json"


def save_verification(repo_name: str, results: dict) -> None:
    """Persist verification results, merging with previous results.

    New conclusive results (supported=True/False) always replace old ones.
    New infra errors (supported=None) do NOT overwrite previous conclusive
    results — a transient failure should never erase a prior real verdict.
    Papers not in the new results keep their previous verification.
    """
    f = _verification_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    merged = {}
    if f.exists():
        try:
            prev = _json.loads(f.read_text())
            if prev.get("repo") == repo_name:
                merged = prev.get("results", {})
        except Exception:
            pass

    for pid, new_val in results.items():
        old_val = merged.get(pid)
        if old_val is None:
            merged[pid] = new_val
            continue

        old_list = old_val if isinstance(old_val, list) else [old_val]
        new_list = new_val if isinstance(new_val, list) else [new_val]

        merged_list = list(old_list)
        for i, new_entry in enumerate(new_list):
            new_supported = new_entry.get("supported") if isinstance(new_entry, dict) else None
            if i < len(merged_list):
                old_entry = merged_list[i]
                old_supported = old_entry.get("supported") if isinstance(old_entry, dict) else None
                if new_supported is None and old_supported is not None:
                    continue
                merged_list[i] = new_entry
            else:
                merged_list.append(new_entry)

        merged[pid] = merged_list

    f.write_text(_json.dumps({"repo": repo_name, "results": merged}))


def load_verification(repo_name: str | None = None) -> dict | None:
    """Load cached verification results for a specific or the active repo.

    Returns {doc_id: [{claim, supported, reason, lines}, ...]} or None.
    Each paper maps to a list of per-claim results.
    """
    f = _verification_file()
    if not f.exists():
        return None
    try:
        data = _json.loads(f.read_text())
        target = repo_name or get_active_repo()
        if data.get("repo") != target:
            return None
        return data.get("results")
    except Exception:
        return None


def push_verification_to_server(results: dict) -> None:
    """Push verification results to the server DB for the active repo."""
    try:
        name = get_active_repo()
        if not name:
            return
        client = _get_client()
        repo_id = _resolve_repo_id(client, name)
        if not repo_id:
            return
        client.repos._request("PUT", f"/api/paper-repos/{repo_id}/verification", json={"results": results})
    except Exception as e:
        logger.debug("Failed to push verification to server: %s", e)


def load_server_verification(repo_name: str | None = None) -> dict | None:
    """Load the SERVER-side merged verification for a repo.

    Unlike :func:`load_verification` (the local per-config-dir cache holding only
    THIS process's verdicts), this returns the authoritative blob the server has
    merged across ALL agents/subagents that committed to the repo. Use it when
    compiling after parallel / multi-subagent extraction: each subagent runs in
    its own config dir and pushes only its own papers' verdicts, so only the
    server has the complete, merged set. Shape matches load_verification:
    ``{doc_id: [{claim, supported, reason, ...}, ...]}``.
    """
    name = repo_name or get_active_repo()
    if not name:
        return None
    try:
        client = _get_client()
        repo_id = _resolve_repo_id(client, name)
        if not repo_id:
            return None
        status = client.repos.get_status(repo_id)
        return status.get("verification") or {}
    except Exception as e:
        logger.debug("Failed to load server verification: %s", e)
        return None


# ── Repo lookup helpers ────────────────────────────────────────


def _resolve_repo_id(client: PaperclipClient, name: str) -> str | None:
    """Get repo UUID by name. Returns None if not found."""
    try:
        repo = client.repos.get_repo_by_name(name)
        if repo:
            return str(repo.get("id"))
    except Exception as e:
        logger.debug("Failed to resolve repo '%s': %s", name, e)
    return None


# ── Public API ───────────────────────────────────────────────────


def list_repos() -> list[dict]:
    """List all repos for the current user."""
    client = _get_client()
    try:
        return client.repos.list_repos()
    except Exception as e:
        logger.debug("list_repos failed: %s", e)
        return []


def init_repo(name: str, description: str = "") -> dict:
    """Create a new repo."""
    name = name.strip().replace(" ", "-").lower()
    client = _get_client()

    # Check if exists first
    existing = client.repos.get_repo_by_name(name)
    if existing:
        raise ValueError(f"Repo '{name}' already exists. Use: paperclip checkout {name}")

    repo = client.repos.create_repo(name, description)
    # Make the new repo the active (checked-out) repo for subsequent bare
    # commands. --repo/PAPERCLIP_REPO still override this at resolution time,
    # so concurrent agents scoped via env/flag are unaffected.
    set_active_repo(name)
    return {
        "name": repo.get("name", name),
        "description": repo.get("description", description),
        "active_branch": repo.get("active_branch", "main"),
        "created_at": repo.get("created_at", ""),
    }


def checkout_repo(name: str) -> dict:
    """Switch to an existing repo."""
    name = name.strip().replace(" ", "-").lower()
    client = _get_client()

    repo = client.repos.get_repo_by_name(name)
    if not repo:
        raise ValueError(f"Repo '{name}' not found. Use: paperclip init {name}")

    set_active_repo(name)
    return {
        "name": repo.get("name", name),
        "active_branch": repo.get("active_branch", "main"),
    }


def add_papers(
    paper_ids: list[str],
    titles: dict[str, str] | None = None,
    dois: dict[str, str] | None = None,
    path: str | None = None,
) -> dict:
    """Add papers to the active repo (optionally into a folder via ``path``)."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo. Use: paperclip init <name> or paperclip checkout <name>")

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")

    # Build items from paper_ids
    items: list[dict[str, Any]] = []
    for pid in paper_ids:
        item: dict[str, Any] = {"paper_id": pid}
        if titles and pid in titles:
            item["title"] = titles[pid]
        if dois and pid in dois:
            item["doi"] = dois[pid]
        if path:
            item["path"] = path
        items.append(item)

    result = client.repos.add_papers(repo_id, items)
    return {
        "added": result.get("added", []),
        "total": result.get("total", 0),
    }


def make_folder(path: str, branch: str | None = None) -> dict:
    """Create an (empty) folder in the active repo's active branch."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo. Use: paperclip init <name> or paperclip checkout <name>")
    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")
    result = client.repos.mkdir(repo_id, path, branch=branch)
    return {
        "branch": result.get("branch", ""),
        "folders": result.get("folders", []),
    }


def remove_folder(path: str, branch: str | None = None) -> dict:
    """Remove an empty folder from the active repo's active branch."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo.")
    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")
    result = client.repos.rmdir(repo_id, path, branch=branch)
    return {
        "branch": result.get("branch", ""),
        "folders": result.get("folders", []),
    }


def list_folders(branch: str | None = None) -> list[str]:
    """List organizational folders in the active repo's active branch."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo.")
    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")
    result = client.repos.list_folders(repo_id, branch=branch)
    return result.get("folders", [])


# Source prefixes the server strips when it stores a short paper ID
# (e.g. ``arx_2203.11171`` is stored as ``2203.11171``). Callers still pass the
# prefixed form, so entry lookup must compare prefix-normalized ids on both
# sides — otherwise ``annotate_paper`` / ``remove_paper`` silently fail to find
# the just-added paper and their claims are dropped.
_SOURCE_ID_PREFIXES = ("arx_", "arxiv_", "bio_", "biorxiv_", "med_", "medrxiv_")


def _norm_pid(pid: object) -> str:
    """Strip a leading source prefix from a paper id for matching."""
    if not pid:
        return ""
    p = str(pid)
    for pre in _SOURCE_ID_PREFIXES:
        if p.startswith(pre):
            return p[len(pre):]
    return p


def _find_entry_id(client: PaperclipClient, repo_id: str, paper_id: str) -> str | None:
    """Find entry_id (UUID) for a paper_id in a repo.

    Matches on paper_id, custom_paper_id, source_key, pmc_id, or pmid
    to handle cases where the server resolved a short ID (bio_/med_/arx_)
    to a full UUID on add. Matching is prefix-normalized: the server stores
    arxiv/biorxiv/medrxiv ids with their source prefix stripped, but callers
    pass the prefixed form, so an exact-only compare would never match.
    """
    result = client.repos._request(
        "GET",
        f"/api/paper-repos/{repo_id}/papers",
        params={"per_page": 200},
    )
    target = _norm_pid(paper_id)
    papers = result.get("papers", [])
    for p in papers:
        candidates = (
            p.get("paper_id"),
            p.get("custom_paper_id"),
            p.get("id"),
            p.get("source_key"),
            p.get("pmc_id"),
            p.get("pmid"),
        )
        for cand in candidates:
            if cand is None:
                continue
            if str(cand) == paper_id or _norm_pid(cand) == target:
                return str(p.get("id"))
    return None


def remove_paper(paper_id: str) -> dict:
    """Remove a paper from the active repo."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo.")

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")

    # Find entry_id for this paper_id
    entry_id = _find_entry_id(client, repo_id, paper_id)
    if not entry_id:
        raise ValueError(f"Paper '{paper_id}' not found in repo.")

    # Remove using entry_id
    result = client.repos.remove_paper(repo_id, entry_id)
    return {"total": result.get("total", 0)}


def commit(message: str, repo_name: str | None = None) -> dict:
    """Commit changes to an explicit repo or the active repo."""
    repo = repo_name or get_active_repo()
    if not repo:
        raise ValueError("No active repo.")

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")

    result = client.repos.commit(repo_id, message)
    return {
        "sha": result.get("sha", ""),
        "parent_sha": result.get("parent_sha"),
        "message": result.get("message", ""),
        "paper_count": result.get("paper_count", 0),
        "added": result.get("added", []),
        "removed": result.get("removed", []),
        "timestamp": result.get("timestamp", ""),
    }


def get_status() -> dict:
    """Get status of the active repo."""
    repo = get_active_repo()
    if not repo:
        return {"repo": None}

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        return {"repo": None}

    result = client.repos.get_status(repo_id)
    return {
        "name": result.get("name", repo),
        "description": result.get("description", ""),
        "active_branch": result.get("active_branch", "main"),
        "paper_count": result.get("paper_count", 0),
        "commit_count": result.get("commit_count", 0),
        "papers": result.get("papers", {}),
    }


def get_repo_info(repo_name: str | None = None) -> dict | None:
    """Get full info about a repo including papers and commits."""
    name = repo_name or get_active_repo()
    if not name:
        return None

    name = name.strip().replace(" ", "-").lower()
    client = _get_client()

    try:
        repo = client.repos.get_repo_by_name(name)
    except NotFoundError:
        return None

    if not repo:
        return None

    repo_id = str(repo.get("id"))

    # Get papers
    papers_resp = client.repos.get_status(repo_id)
    papers = papers_resp.get("papers", {})

    # Get commits
    commits_resp = client.repos.list_commits(repo_id)
    commits = commits_resp.get("commits", [])

    # Calculate annotation count from papers
    annotation_count = sum(len(p.get("annotations", [])) for p in papers.values())

    return {
        "name": repo.get("name", name),
        "description": repo.get("description", ""),
        "active_branch": repo.get("active_branch", "main"),
        "branches": [b.get("name") for b in repo.get("branches", [])],
        "papers": papers,
        "commits": commits,
        "created_at": repo.get("created_at", ""),
        "paper_count": len(papers),
        "commit_count": len(commits),
        "branch_count": len(repo.get("branches", [])),
        "annotation_count": annotation_count,
    }


def get_repo_paper_ids(repo_name: str | None = None) -> list[str]:
    """Get list of paper IDs in a repo."""
    info = get_repo_info(repo_name)
    if not info:
        return []
    papers = info.get("papers", {})
    return list(papers.keys())


def get_repo_dois(repo_name: str | None = None) -> dict[str, str]:
    """Get mapping of paper IDs to DOIs."""
    info = get_repo_info(repo_name)
    if not info:
        return {}
    papers = info.get("papers", {})
    return {k: v.get("doi", "") for k, v in papers.items() if v.get("doi")}


def lookup_citations(
    paper_ids: list[str],
    dois: dict[str, str] | None = None,
) -> dict:
    """Look up citation counts + DOIs from the internal OpenAlex database.

    Returns {"counts": {pid: int}, "dois": {pid: doi}, "matched": int}.
    DOIs are resolved server-side in the same call.
    """
    client = _get_client()
    try:
        return client.repos.lookup_citation_counts(paper_ids, dois=dois, resolve_dois=True)
    except Exception:
        return {}


def update_paper_dois(dois: dict[str, str]) -> None:
    """Update DOIs for papers in the active repo."""
    metadata = {pid: {"doi": doi} for pid, doi in dois.items()}
    update_paper_metadata(metadata)


def update_paper_citations(citations: dict[str, dict]) -> None:
    """Update citation counts for papers."""
    metadata = {}
    for pid, data in citations.items():
        fields: dict[str, Any] = {}
        if "cited_by_count" in data:
            fields["cited_by_count"] = data["cited_by_count"]
        if "s2_id" in data:
            fields["s2_id"] = data["s2_id"]
        if fields:
            metadata[pid] = fields
    if metadata:
        update_paper_metadata(metadata)


def update_paper_metadata(metadata: dict[str, dict]) -> None:
    """Update metadata (doi, cited_by_count, s2_id) for papers in active repo."""
    repo = get_active_repo()
    if not repo:
        return

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        return

    for pid, fields in metadata.items():
        entry_id = _find_entry_id(client, repo_id, pid)
        if not entry_id:
            continue

        patch_body: dict[str, Any] = {}
        if "doi" in fields:
            patch_body["doi"] = fields["doi"]
        if "cited_by_count" in fields:
            patch_body["cited_by_count"] = fields["cited_by_count"]
        if "s2_id" in fields:
            patch_body["s2_id"] = fields["s2_id"]

        if patch_body:
            try:
                client.repos.annotate_paper(repo_id, entry_id, "", **patch_body)
            except Exception as e:
                logger.debug("Failed to update metadata for %s: %s", pid, e)


def get_repo_citations(repo_name: str | None = None) -> dict:
    """Get citation stats for a repo."""
    info = get_repo_info(repo_name)
    if not info:
        return {"citations": {}}
    papers = info.get("papers", {})
    citations = {k: v.get("cited_by_count", 0) for k, v in papers.items()}
    return {"citations": citations}


def record_search(query: str, result_id: str) -> None:
    """Record a search query for the active repo. Delegates to record_command."""
    record_command(
        "search_papers",
        arguments={"query": query},
        result_id=result_id,
    )


def _get_active_branch_name() -> str:
    """Resolve the active branch for the active repo."""
    repo = get_active_repo()
    if not repo:
        return "main"
    try:
        client = _get_client()
        info = client.repos.get_repo_by_name(repo)
        if info:
            return info.get("active_branch", "main")
    except Exception:
        pass
    return "main"


def record_command(
    tool_name: str,
    arguments: dict | None = None,
    *,
    result_summary: str | None = None,
    result_id: str | None = None,
    document_ids: list[str] | None = None,
    exit_code: int = 0,
) -> None:
    """Record a CLI command for the active repo, tagged to the active branch."""
    repo = get_active_repo()
    if not repo:
        return

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        return

    args = arguments or {}
    cmd = f"{tool_name}({', '.join(f'{k}={v!r}' for k, v in args.items())})"
    branch = _get_active_branch_name()

    try:
        client.repos.record_command(
            repo_id,
            branch=branch,
            command=cmd[:5000],
            tool_name=tool_name,
            arguments=args,
            document_ids=document_ids or [],
            result_summary=result_summary,
            result_id=result_id,
            exit_code=exit_code,
        )
    except Exception as e:
        logger.debug("record_command failed: %s", e)


def get_history(
    repo_name: str | None = None,
    *,
    branch: str | None = None,
    tool_name: str | None = None,
    page: int = 1,
    per_page: int = 50,
) -> dict:
    """Get command history for a repo, optionally scoped to a branch/session."""
    name = repo_name or get_active_repo()
    if not name:
        return {"entries": [], "total": 0, "page": 1, "per_page": per_page}

    empty = {"entries": [], "total": 0, "page": 1, "per_page": per_page}
    client = _get_client()
    repo_id = _resolve_repo_id(client, name)
    if not repo_id:
        return empty

    # The command-history endpoint may not be available on every backend; degrade
    # gracefully to an empty history rather than raising.
    list_history = getattr(client.repos, "list_history", None)
    if not callable(list_history):
        return empty
    try:
        return list_history(
            repo_id,
            branch=branch,
            tool_name=tool_name,
            page=page,
            per_page=per_page,
        )
    except Exception as e:
        logger.debug("list_history failed: %s", e)
        return empty


def create_branch(branch_name: str, from_branch: str | None = None) -> dict:
    """Create a new branch in the active repo."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo.")

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")

    result = client.repos.create_branch(repo_id, branch_name, from_branch=from_branch)
    # Switch to new branch
    client.repos.patch_repo(repo_id, active_branch=branch_name)
    set_active_repo(repo)

    return {
        "branch": result.get("branch", branch_name),
        "papers": result.get("papers", 0),
    }


def list_branches(repo_name: str | None = None) -> list[dict]:
    """List branches for a repo."""
    info = get_repo_info(repo_name)
    if not info:
        return []

    client = _get_client()
    repo_id = _resolve_repo_id(client, info.get("name", repo_name or get_active_repo() or ""))
    if not repo_id:
        return []

    repo = client.repos.get_repo_by_name(info.get("name", repo_name or get_active_repo() or ""))
    if not repo:
        return []

    return [
        {
            "name": b.get("name"),
            "active": b.get("active", False),
            "paper_count": b.get("paper_count", 0),
            "commit_count": b.get("commit_count", 0),
        }
        for b in repo.get("branches", [])
    ]


def switch_branch(branch_name: str) -> dict:
    """Switch to a different branch."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo.")

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")

    client.repos.patch_repo(repo_id, active_branch=branch_name)

    # Get status for paper count
    status = client.repos.get_status(repo_id, branch=branch_name)
    return {
        "branch": branch_name,
        "paper_count": status.get("paper_count", 0),
    }


def merge_branch(source: str, target: str | None = None) -> dict:
    """Merge source branch into target."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo.")

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")

    # Get active branch if target not specified
    if not target:
        repo_info = client.repos.get_repo_by_name(repo)
        target = repo_info.get("active_branch", "main") if repo_info else "main"

    from gxl_paperclip.client.errors import ServerError

    try:
        result = client.repos.merge_branches(repo_id, source, target)
    except ServerError as e:
        # Extract detail message from JSON body if available
        msg = "Merge failed"
        if e.body:
            try:
                import json

                data = json.loads(e.body)
                msg = data.get("detail", str(e))
            except (json.JSONDecodeError, AttributeError):
                msg = e.body if e.body else str(e)
        raise ValueError(msg)

    return {
        "merged": result.get("merged", 0),
        "total": result.get("total", 0),
        "source": result.get("source", source),
        "target": result.get("target", target),
        "added": result.get("added", []),
    }


def get_log(branch: str | None = None, limit: int = 50) -> list[dict]:
    """Get commit log for the active repo."""
    repo = get_active_repo()
    if not repo:
        return []

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        return []

    result = client.repos.list_commits(repo_id, branch=branch, per_page=limit)
    commits = result.get("commits", [])
    return [
        {
            "sha": c.get("sha", ""),
            "parent_sha": c.get("parent_sha"),
            "message": c.get("message", ""),
            "paper_count": c.get("paper_count", 0),
            "timestamp": c.get("committed_at", ""),
        }
        for c in commits
    ]


def annotate_paper(
    paper_id: str,
    note: str,
    lines: list[str] | None = None,
    source_locations: list[dict[str, str]] | None = None,
) -> dict:
    """Add an annotation to a paper in the active repo."""
    repo = get_active_repo()
    if not repo:
        raise ValueError("No active repo.")

    client = _get_client()
    repo_id = _resolve_repo_id(client, repo)
    if not repo_id:
        raise ValueError(f"Repo '{repo}' not found.")

    # Find entry_id for this paper_id
    entry_id = _find_entry_id(client, repo_id, paper_id)
    if not entry_id:
        raise ValueError(f"Paper '{paper_id}' not found in repo.")

    # Build annotation
    lines_str = ",".join(lines) if lines else None
    result = client.repos.annotate_paper(
        repo_id,
        entry_id,
        note,
        lines=lines_str,
        source_locations=source_locations,
    )
    return {
        "entry_id": result.get("entry_id"),
        "branch": result.get("branch", repo),
        "paper_id": paper_id,
        "index": result.get("index"),
        "lines": lines_str,
        "source_locations": source_locations,
    }




_FORMAT_ALIASES = {"bib": "bibtex", "md": "markdown"}
_VALID_FORMATS = frozenset({"bibtex", "ris", "markdown", "csv"})


def export_repo(
    fmt: str,
    repo_name: str | None = None,
    branch: str | None = None,
) -> str:
    """Export repo in the given format. Accepts aliases (bib→bibtex, md→markdown)."""
    canonical = _FORMAT_ALIASES.get(fmt, fmt)
    if canonical not in _VALID_FORMATS:
        raise ValueError(f"Unknown format '{fmt}'. Use: bibtex, ris, markdown, csv")

    name = repo_name or get_active_repo()
    if not name:
        raise ValueError("No repo specified.")

    client = _get_client()
    repo_id = _resolve_repo_id(client, name)
    if not repo_id:
        raise ValueError(f"Repo '{name}' not found.")

    content = client.repos.export(repo_id, canonical, branch=branch)
    return content.decode("utf-8")


def export_bib(repo_name: str | None = None, branch: str | None = None) -> str:
    return export_repo("bibtex", repo_name, branch)


def export_ris(repo_name: str | None = None, branch: str | None = None) -> str:
    return export_repo("ris", repo_name, branch)


def export_markdown(repo_name: str | None = None, branch: str | None = None) -> str:
    return export_repo("markdown", repo_name, branch)


def export_csv(repo_name: str | None = None, branch: str | None = None) -> str:
    return export_repo("csv", repo_name, branch)


def _load_manifest(name: str) -> dict | None:
    """Load repo manifest by name. Used by CLI for validation."""
    client = _get_client()
    try:
        return client.repos.get_repo_by_name(name)
    except NotFoundError:
        return None


def update_paper_bib_metadata(metadata: dict[str, dict]) -> None:
    """Store extra bib/ris metadata on papers. Alias for update_paper_metadata."""
    update_paper_metadata(metadata)


# ── Library API ───────────────────────────────────────────────────


def library_add_papers(
    paper_ids: list[str],
    titles: dict[str, str] | None = None,
    dois: dict[str, str] | None = None,
    source_file: str | None = None,
) -> dict:
    """Add papers to the personal library."""
    client = _get_client()

    # Build items from paper_ids
    items: list[dict[str, Any]] = []
    for pid in paper_ids:
        item: dict[str, Any] = {"paper_id": pid}
        if titles and pid in titles:
            item["title"] = titles[pid]
        if dois and pid in dois:
            item["doi"] = dois[pid]
        if source_file:
            item["import_source"] = f"cli_{source_file}"
        items.append(item)

    result = client.library.add_papers(items)
    return {
        "added": result.get("added", []),
        "total": result.get("total", 0),
    }


def library_update_metadata(paper_ids: list[str], metadata: dict[str, dict]) -> None:
    """Update metadata for library papers."""
    client = _get_client()
    for pid in paper_ids:
        if pid in metadata:
            try:
                client.library.update_paper(pid, metadata[pid])
            except Exception as e:
                logger.debug("Failed to update paper %s: %s", pid, e)


def library_get_papers() -> dict[str, dict]:
    """Get all papers from the personal library."""
    client = _get_client()
    try:
        result = client.library.list_papers()
        papers = result.get("papers", [])
        return {
            p.get("id", p.get("paper_id", "")): {
                "title": p.get("title", ""),
                "authors": p.get("authors", ""),
                "year": p.get("year"),
                "journal": p.get("journal"),
                "doi": p.get("doi"),
                "cited_by_count": p.get("cited_by_count"),
                "s2_id": p.get("s2_id"),
                "entry_type": p.get("entry_type"),
                "source_key": p.get("source_key"),
                "created_at": p.get("created_at"),
            }
            for p in papers
        }
    except Exception as e:
        logger.debug("library_get_papers failed: %s", e)
        return {}


def library_get_corpus_ids() -> list[str]:
    """Get list of corpus paper IDs from library."""
    client = _get_client()
    try:
        result = client.library.list_papers()
        papers = result.get("papers", [])
        return [p.get("paper_id") for p in papers if p.get("paper_id")]
    except Exception as e:
        logger.debug("library_get_corpus_ids failed: %s", e)
        return []


def library_get_info() -> dict | None:
    """Get info about the personal library."""
    client = _get_client()
    try:
        result = client.library.list_papers()
        papers = result.get("papers", [])
        total = len(papers)
        corpus = len([p for p in papers if p.get("paper_id")])
        custom = len([p for p in papers if p.get("custom_paper_id")])
        # Build papers dict keyed by paper ID
        papers_dict = {}
        for p in papers:
            pid = p.get("paper_id") or p.get("custom_paper_id") or p.get("id")
            if pid:
                papers_dict[str(pid)] = p

        return {
            "total": total,
            "matched": corpus,
            "unmatched": custom,
            "papers": papers_dict,
        }
    except Exception as e:
        logger.debug("library_get_info failed: %s", e)
        return None


def library_remove_papers(paper_ids: list[str]) -> int:
    """Remove papers from the personal library."""
    client = _get_client()
    count = 0
    for pid in paper_ids:
        try:
            client.library.delete_paper(pid)
            count += 1
        except Exception as e:
            logger.debug("Failed to delete paper %s: %s", pid, e)
    return count
