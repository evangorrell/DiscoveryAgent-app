"""paperclip fetch — download papers using the user's browser cookies and upload to clipboard."""

import os
import re
import tempfile
from pathlib import Path
from urllib.parse import urljoin, urlparse

import click
import requests

from .. import config
from .sync import upload_file, _load_config

DOI_RE = re.compile(r"^10\.\d{4,}/")
DOI_URL_RE = re.compile(r"https?://(?:dx\.)?doi\.org/(10\.\d{4,}/.+)")

_BROWSER_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
)

# <meta name="citation_pdf_url" content="..."> is the Google-Scholar metadata
# tag most publishers embed; it points straight at the full-text PDF and is by
# far the most reliable cross-publisher signal. Match either attribute order.
_CITATION_PDF_RE = re.compile(
    r"""<meta[^>]+?(?:name|property)=["']citation_pdf_url["'][^>]+?content=["']([^"']+)["']"""
    r"""|<meta[^>]+?content=["']([^"']+)["'][^>]+?(?:name|property)=["']citation_pdf_url["']""",
    re.IGNORECASE,
)


def _resolve_doi(doi: str) -> str:
    """Resolve a DOI to its target URL (publisher page)."""
    url = f"https://doi.org/{doi}"
    try:
        resp = requests.get(url, allow_redirects=True, timeout=10,
                           headers={"User-Agent": _BROWSER_UA})
        return resp.url
    except Exception:
        return url


def _get_chrome_cookies(domain: str | None) -> dict:
    """Extract cookies from the local Chrome store for the given domain."""
    if not domain:
        return {}
    try:
        import rookiepy
    except ImportError:
        click.echo("  rookiepy is not installed — needed to read your browser cookies", err=True)
        click.echo("  for paywalled/institutional access. Install it with:", err=True)
        click.echo("      pip install rookiepy", err=True)
        click.echo("  Continuing without cookies (open-access papers still work)...", err=True)
        return {}
    try:
        cookies = rookiepy.chrome(domains=[domain])
        return {c["name"]: c["value"] for c in cookies}
    except Exception as e:
        click.echo(f"  Could not read Chrome cookies: {e}", err=True)
        click.echo("  Trying without cookies (works for open-access papers)...", err=True)
        return {}


def _extract_pdf_url_from_landing(url: str, cookies: dict) -> str | None:
    """Fetch the landing page and pull the citation_pdf_url meta tag, if present.

    This resolves the direct PDF link for the many publishers that don't follow
    a guessable URL pattern, using the user's cookies so paywalled pages load.
    """
    try:
        resp = requests.get(
            url, cookies=cookies, timeout=20, allow_redirects=True,
            headers={"User-Agent": _BROWSER_UA, "Accept": "text/html,*/*"},
        )
    except Exception:
        return None
    ctype = resp.headers.get("content-type", "")
    if "html" not in ctype and not resp.text.lstrip().startswith("<"):
        return None
    # Only scan the <head>-ish prefix; meta tags live there and pages can be huge.
    match = _CITATION_PDF_RE.search(resp.text[:200_000])
    if not match:
        return None
    pdf_url = match.group(1) or match.group(2)
    if not pdf_url:
        return None
    # Resolve against the *final* URL after redirects so relative links work.
    return urljoin(resp.url, pdf_url.strip())


def _guess_pdf_url(url: str) -> list[str]:
    """Given a publisher page URL, generate candidate PDF URLs (heuristics)."""
    candidates: list[str] = [url]
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()

    if re.search(r"\.pdf([?#]|$)", url, re.IGNORECASE):
        return [url]

    if "nature.com" in host:
        candidates.append(url.rstrip("/") + ".pdf")
    if "sciencedirect.com" in host:
        pii = parsed.path.rstrip("/").split("/")[-1]
        candidates.append(f"https://www.sciencedirect.com/science/article/pii/{pii}/pdfft")
    if "wiley.com" in host:
        candidates.append(url.replace("/abs/", "/pdfdirect/").replace("/full/", "/pdfdirect/"))
    if "arxiv.org" in host:
        arxiv_id = parsed.path.rstrip("/").split("/")[-1]
        candidates.append(f"https://arxiv.org/pdf/{arxiv_id}.pdf")
    if "ncbi.nlm.nih.gov" in host and "/pmc/" in url.lower():
        pmc_id = re.search(r"PMC\d+", url)
        if pmc_id:
            candidates.append(f"https://www.ncbi.nlm.nih.gov/pmc/articles/{pmc_id.group()}/pdf/")
    if "biorxiv.org" in host or "medrxiv.org" in host:
        candidates.append(url.rstrip("/") + ".full.pdf")
    if "pnas.org" in host or "science.org" in host:
        candidates.append(url.rstrip("/") + "?format=pdf")
    if "acs.org" in host:
        candidates.append(url.replace("/doi/abs/", "/doi/pdf/").replace("/doi/full/", "/doi/pdf/"))
    if host == "proceedings.neurips.cc":
        candidates.append(re.sub(r"-Paper.*$", "-Paper.pdf", url))
        candidates.append(url.replace("/hash/", "/file/").replace("Abstract", "Paper").replace(".html", ".pdf"))
    if host == "proceedings.mlr.press":
        slug = parsed.path.rstrip("/").split("/")[-1].replace(".html", "")
        if slug:
            base_dir = parsed.path.rsplit("/", 1)[0]
            candidates.append(f"https://{host}{base_dir}/{slug}/{slug}.pdf")
    if "openreview.net" in host:
        m = re.search(r"[?&]id=([^&]+)", url)
        if m:
            candidates.append(f"https://openreview.net/pdf?id={m.group(1)}")
    if "frontiersin.org" in host:
        candidates.append(re.sub(r"/full/?$", "/pdf", url))
    if "ieeexplore.ieee.org" in host:
        doc = re.search(r"/(\d+)/?$", parsed.path)
        if doc:
            candidates.append(f"https://ieeexplore.ieee.org/stampPDF/getPDF.jsp?arnumber={doc.group(1)}")
    if "dl.acm.org" in host:
        candidates.append(url.replace("/doi/", "/doi/pdf/"))

    # Generic last resort: append .pdf
    if not url.endswith(".pdf"):
        candidates.append(url.rstrip("/") + ".pdf")

    # Dedupe, preserve order.
    seen: set[str] = set()
    deduped: list[str] = []
    for c in candidates:
        if c and c not in seen:
            seen.add(c)
            deduped.append(c)
    return deduped


def _download_pdf(url: str, cookies: dict) -> bytes | None:
    """Try to download a PDF from the URL using provided cookies."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Accept": "application/pdf,*/*",
    }
    try:
        resp = requests.get(url, cookies=cookies, headers=headers, timeout=30,
                           allow_redirects=True, stream=True)
        content_type = resp.headers.get("content-type", "")

        if resp.status_code == 200 and ("pdf" in content_type or resp.content[:4] == b"%PDF"):
            return resp.content
    except Exception:
        pass
    return None


def _slugify_title(title: str) -> str:
    """Filesystem-safe slug from a page title (keeps unicode letters/digits)."""
    slug = re.sub(r"[^\w\s-]", "", (title or ""), flags=re.UNICODE).strip().lower()
    slug = re.sub(r"[\s]+", "-", slug)[:80]
    return slug or "page"


def _download_html(url: str, cookies: dict) -> tuple[bytes, str] | None:
    """Fetch the page HTML (raw, no JS) with the user's cookies.

    Returns (html_bytes, title) or None. Mirrors the extension's HTML fallback,
    except the CLI can only see the raw server HTML (it can't run JavaScript).
    """
    try:
        resp = requests.get(
            url, cookies=cookies, timeout=30, allow_redirects=True,
            headers={"User-Agent": _BROWSER_UA, "Accept": "text/html,*/*"},
        )
    except Exception:
        return None
    ctype = resp.headers.get("content-type", "")
    text = resp.text or ""
    if resp.status_code != 200 or ("html" not in ctype and not text.lstrip().startswith("<")):
        return None
    # Inject <base href> against the final URL so relative links resolve, and
    # keep the parser (Datalab) anchored to the real page — matches the extension.
    base_href = resp.url.replace("&", "&amp;").replace('"', "&quot;")
    text = re.sub(r"(<head[^>]*>)", r"\1" + f'<base href="{base_href}">',
                  text, count=1, flags=re.IGNORECASE)
    m = re.search(r"<title[^>]*>(.*?)</title>", text, re.IGNORECASE | re.DOTALL)
    title = (m.group(1).strip() if m else "") or (urlparse(resp.url).hostname or "page")
    return text.encode("utf-8", "replace"), title


def _upload_multipart(
    base_url: str, headers: dict, blob: bytes, filename: str,
    folder_path: str, mime: str, prefer_datalab: bool = False,
) -> dict:
    """Direct multipart POST to /api/user/upload (supports prefer_datalab).

    Used for the HTML fallback so captured pages are parsed by Datalab into
    clean text, exactly like the browser extension's ``prefer_datalab`` path.
    """
    files = {"file": (filename, blob, mime)}
    data = {"folder_path": folder_path}
    if prefer_datalab:
        data["prefer_datalab"] = "true"
    try:
        resp = requests.post(
            f"{base_url}/api/user/upload", headers=headers,
            files=files, data=data, timeout=180,
        )
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": f"Upload failed: {str(e)[:120]}"}
    if resp.ok:
        return resp.json()
    detail = ""
    try:
        detail = resp.json().get("detail", "")
    except Exception:
        detail = resp.text[:200]
    return {"status": "error", "message": detail or f"HTTP {resp.status_code}"}


@click.command("fetch")
@click.argument("url_or_doi")
@click.option("--into", default="", help="Clipboard folder to upload into (e.g. /clipboard/my-review/)")
def fetch_command(url_or_doi: str, into: str):
    """Download a paper using your browser cookies and add it to your clipboard.

    \b
    Examples:
        paperclip fetch https://www.nature.com/articles/s41586-023-05724-2
        paperclip fetch 10.1038/s41586-023-05724-2
        paperclip fetch https://arxiv.org/abs/2301.00001 --into /clipboard/my-review/
    """
    # Resolve DOI if needed
    url = url_or_doi.strip()
    doi_match = DOI_URL_RE.match(url)
    if doi_match:
        doi = doi_match.group(1)
        click.echo(f"  Resolving DOI: {doi}")
        url = _resolve_doi(doi)
    elif DOI_RE.match(url):
        click.echo(f"  Resolving DOI: {url}")
        url = _resolve_doi(url)

    click.echo(f"  Target: {url}")

    # Get cookies from Chrome for this domain
    domain = urlparse(url).hostname
    click.echo(f"  Reading Chrome cookies for {domain}...")
    cookies = _get_chrome_cookies(domain)
    if cookies:
        click.echo(f"  Found {len(cookies)} cookies")

    # Build the candidate list. citation_pdf_url (parsed from the landing page)
    # is the most reliable signal, so try it first, then fall back to per-
    # publisher URL heuristics.
    candidates: list[str] = []
    if not re.search(r"\.pdf([?#]|$)", url, re.IGNORECASE):
        meta_pdf = _extract_pdf_url_from_landing(url, cookies)
        if meta_pdf:
            click.echo(f"  Found citation_pdf_url: {meta_pdf}")
            candidates.append(meta_pdf)
    for c in _guess_pdf_url(url):
        if c not in candidates:
            candidates.append(c)

    pdf_bytes = None
    success_url = None

    click.echo(f"  Trying {len(candidates)} URL candidates...")
    for candidate in candidates:
        pdf_bytes = _download_pdf(candidate, cookies)
        if pdf_bytes:
            success_url = candidate
            break

    # Resolve auth + destination once (needed for either upload path).
    folder_path = into.strip("/").replace("clipboard/", "").replace("/clipboard", "") if into else ""
    cfg_data = _load_config()
    base_url = cfg_data.get("base_url", "https://paperclip.gxl.ai")
    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.get_id_token()}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    dest_label = f"/clipboard/{folder_path + '/' if folder_path else ''}"

    if pdf_bytes:
        size_mb = len(pdf_bytes) / (1024 * 1024)
        click.echo(f"  ✓ Downloaded {size_mb:.1f} MB from {success_url}")

        filename = urlparse(success_url).path.split("/")[-1]
        if not filename.endswith(".pdf"):
            filename = f"{domain}_{filename}.pdf"
        filename = re.sub(r"[^\w.\-]", "_", filename)

        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp.write(pdf_bytes)
            tmp_path = Path(tmp.name)
        try:
            click.echo(f"  Uploading to {dest_label}{filename}...")
            result = upload_file(base_url, headers, tmp_path, folder_path)
        finally:
            tmp_path.unlink(missing_ok=True)
    else:
        # No PDF. If the target itself is a PDF, an HTML capture is meaningless —
        # fail clearly (matches the extension, which can't script the PDF viewer).
        if re.search(r"\.pdf([?#]|$)", url, re.IGNORECASE):
            click.echo("  ✗ Could not download this PDF.", err=True)
            click.echo("    Make sure you've recently visited it in Chrome while", err=True)
            click.echo("    logged into your institution, then try again.", err=True)
            raise SystemExit(1)

        # Fall back to capturing the page HTML and letting Datalab parse it into
        # clean text — the same behavior as the extension's "Add to Paperclip".
        click.echo("  No PDF found — capturing page HTML instead...")
        captured = _download_html(url, cookies)
        if not captured:
            click.echo("  ✗ Could not download a PDF or capture this page.", err=True)
            click.echo("    Make sure you've recently visited it in Chrome while", err=True)
            click.echo("    logged into your institution, then try again.", err=True)
            raise SystemExit(1)
        html_bytes, title = captured
        filename = f"{_slugify_title(title)}.html"
        click.echo(f"  ✓ Captured page ({len(html_bytes) / 1024:.0f} KB): {title[:60]}")
        click.echo(f"  Uploading to {dest_label}{filename} (parsed via Datalab)...")
        result = _upload_multipart(
            base_url, headers, html_bytes, filename, folder_path,
            mime="text/html", prefer_datalab=True,
        )

    # The server reports success as "success" (immediate), "added" (accepted;
    # rich-text parsing + indexing continue in the background), or "duplicate".
    status = result.get("status")
    if status in ("success", "added", "duplicate"):
        click.echo(f"  ✓ Added to clipboard: {result.get('title', filename)}")
        short_id = result.get("short_id") or result.get("doc_id")
        if status == "duplicate":
            click.echo("    (already in your clipboard)")
        elif status == "added":
            click.echo("    (rich-text extraction + indexing continue in the background)")
        if short_id:
            click.echo(f"    {short_id}")
    else:
        click.echo(f"  ✗ Upload failed: {result.get('message', 'unknown error')}", err=True)
        raise SystemExit(1)
