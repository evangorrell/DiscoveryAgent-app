"""Paperclip sync — upload local PDFs to your paperclip user filesystem.

This module implements the `paperclip sync` command group which allows users
to register local folders and sync their PDFs to the /user/ virtual filesystem.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any

import click
import requests

from .. import config

logger = logging.getLogger(__name__)

# ── Constants ──

SYNC_STATE_FILE = config.PAPERCLIP_DIR / "sync_state.json"
SYNC_CONFIG_KEY = "sync_folders"
_SUPPORTED_EXTENSIONS = None  # Accept any file type


# ── State management ──


def _load_sync_state() -> dict:
    """Load the sync state (manifest of tracked files)."""
    if not SYNC_STATE_FILE.exists():
        return {"files": {}, "folders": []}
    try:
        return json.loads(SYNC_STATE_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {"files": {}, "folders": []}


def _save_sync_state(state: dict) -> None:
    """Save sync state to disk."""
    config.PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
    SYNC_STATE_FILE.write_text(json.dumps(state, indent=2))


def _load_config() -> dict:
    """Load paperclip config."""
    if not config.CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(config.CONFIG_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _save_config(cfg: dict) -> None:
    """Save paperclip config."""
    config.PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
    config.CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


# ── File discovery ──


def discover_pdfs(folder: Path, ignore_patterns: list[str] | None = None) -> list[Path]:
    """Recursively discover PDF files in a folder."""
    pdfs = []
    ignore_file = folder / ".paperclipignore"
    if ignore_file.exists() and ignore_patterns is None:
        ignore_patterns = [
            line.strip()
            for line in ignore_file.read_text().splitlines()
            if line.strip() and not line.startswith("#")
        ]

    for item in sorted(folder.rglob("*")):
        if not item.is_file():
            continue
        # Skip files with no extension (likely not documents)
        if not item.suffix:
            continue
        # Skip hidden files/dirs
        if any(part.startswith(".") for part in item.relative_to(folder).parts):
            continue
        # Skip ignored patterns
        if ignore_patterns:
            rel = str(item.relative_to(folder))
            if any(_matches_pattern(rel, pat) for pat in ignore_patterns):
                continue
        pdfs.append(item)

    return pdfs


def _matches_pattern(path: str, pattern: str) -> bool:
    """Simple glob-like pattern matching (supports * and **)."""
    import fnmatch
    return fnmatch.fnmatch(path, pattern)


def compute_file_hash(filepath: Path) -> str:
    """Compute SHA-256 of a file."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()


# ── Sync logic ──


def diff_state(
    folder: Path, remote_prefix: str, files: list[Path], state: dict
) -> tuple[list[Path], list[Path], list[str]]:
    """Compare discovered files against saved state.

    Returns (new_files, modified_files, deleted_remote_ids).
    """
    tracked = state.get("files", {})
    new_files = []
    modified_files = []
    seen_paths = set()

    for f in files:
        rel_path = str(f.relative_to(folder))
        key = f"{remote_prefix}/{rel_path}"
        seen_paths.add(key)

        if key not in tracked:
            new_files.append(f)
        else:
            # Check mtime for quick change detection
            mtime = f.stat().st_mtime
            if mtime > tracked[key].get("synced_at", 0):
                # Confirm with hash
                current_hash = compute_file_hash(f)
                if current_hash != tracked[key].get("hash"):
                    modified_files.append(f)

    # Find deleted files
    deleted_ids = []
    for key, info in tracked.items():
        if key.startswith(f"{remote_prefix}/") and key not in seen_paths:
            if info.get("doc_id"):
                deleted_ids.append(info["doc_id"])

    return new_files, modified_files, deleted_ids


def _retry_429(func):
    """Run func() retrying on rate-limit HTTP 429s with backoff.

    Only 429s carrying a Retry-After header are retried (the rate limiter
    sets it). Quota-exceeded responses are also 429 but have no Retry-After
    and will never succeed on retry, so they surface immediately.

    func returns a requests.Response or an error dict; the wrapper returns
    whichever it got once the response is not retryable (or retries are spent).
    """
    max_429_retries = 4
    for rate_attempt in range(max_429_retries + 1):
        resp = func()
        if isinstance(resp, dict):
            return resp
        retry_after = resp.headers.get("Retry-After")
        if resp.status_code == 429 and retry_after and rate_attempt < max_429_retries:
            if retry_after.isdigit():
                wait = min(int(retry_after), 30)
            else:
                wait = min(2 ** rate_attempt, 16)
            time.sleep(wait)
            continue
        return resp
    return resp


def _post_json_with_retry(url: str, headers: dict, payload: dict, timeout: int = 60):
    """POST JSON with network retry; returns Response or error dict."""
    def _once():
        for attempt in range(3):
            try:
                return requests.post(url, headers=headers, json=payload, timeout=timeout)
            except requests.exceptions.RequestException as e:
                if attempt == 2:
                    return {"status": "error", "message": str(e)[:100]}
                time.sleep(2 * (attempt + 1))
    return _retry_429(_once)


def upload_file(
    base_url: str,
    headers: dict,
    filepath: Path,
    folder_path: str,
    mime: str = "application/pdf",
) -> dict:
    """Upload a single file to the user's clipboard.

    Primary path: direct-to-GCS via signed URL (init → PUT to GCS → complete),
    which bypasses Cloud Run's 32 MiB HTTP/1 request cap. Falls back to the
    legacy multipart POST when the server doesn't support /upload/init yet.
    """
    result = _upload_via_signed_url(base_url, headers, filepath, folder_path, mime)
    if result is not None:
        return result
    return _upload_file_multipart(base_url, headers, filepath, folder_path, mime)


def _upload_via_signed_url(
    base_url: str,
    headers: dict,
    filepath: Path,
    folder_path: str,
    mime: str,
) -> dict | None:
    """Signed-URL upload flow. Returns None if the server lacks /upload/init."""
    size_bytes = filepath.stat().st_size

    init_resp = _post_json_with_retry(
        f"{base_url}/api/user/upload/init",
        headers,
        {
            "filename": filepath.name,
            "size_bytes": size_bytes,
            "folder_path": folder_path,
            "content_type": mime,
        },
    )
    if isinstance(init_resp, dict):
        return init_resp
    if init_resp.status_code in (404, 405, 501):
        # 404/405: older server without /upload/init.
        # 501: server can't sign GCS URLs (e.g. local dev without ADC).
        # Either way the caller falls back to legacy multipart upload.
        return None
    if init_resp.status_code != 200:
        return _error_from_response(init_resp, filepath)
    init_data = init_resp.json()

    put_headers = init_data.get("required_headers") or {"Content-Type": mime}
    for attempt in range(3):
        try:
            with open(filepath, "rb") as f:
                put_resp = requests.put(
                    init_data["upload_url"],
                    data=f,
                    headers=put_headers,
                    timeout=1800,
                )
            break
        except requests.exceptions.RequestException as e:
            if attempt == 2:
                return {"status": "error", "message": f"GCS upload failed: {str(e)[:100]}"}
            time.sleep(2 * (attempt + 1))
    if put_resp.status_code not in (200, 201):
        return {
            "status": "error",
            "message": f"GCS upload failed (HTTP {put_resp.status_code})",
        }

    complete_resp = _post_json_with_retry(
        f"{base_url}/api/user/upload/complete",
        headers,
        {
            "upload_id": init_data["upload_id"],
            "filename": filepath.name,
            "folder_path": folder_path,
        },
        timeout=600,  # ingestion includes the Datalab parse
    )
    if isinstance(complete_resp, dict):
        return complete_resp
    if complete_resp.status_code != 200:
        return _error_from_response(complete_resp, filepath)
    return complete_resp.json()


def _error_from_response(resp, filepath: Path) -> dict:
    """Map an HTTP error response to the upload result dict format."""
    try:
        detail = resp.json().get("detail", "")
    except Exception:
        detail = ""
    if resp.status_code == 413:
        size_mb = filepath.stat().st_size / (1024 * 1024)
        limit_desc = detail or "max 200 MB"
        return {"status": "error", "message": f"File too large ({size_mb:.1f} MB, {limit_desc})"}
    if resp.status_code == 400:
        return {"status": "error", "message": detail or "Bad request"}
    if resp.status_code == 429:
        return {"status": "error", "message": detail or "Rate limit exceeded. Try again shortly."}
    if not detail:
        detail = resp.text[:100]
    return {"status": "error", "message": f"HTTP {resp.status_code}: {detail}"}


def _upload_file_multipart(
    base_url: str,
    headers: dict,
    filepath: Path,
    folder_path: str,
    mime: str = "application/pdf",
) -> dict:
    """Legacy multipart upload with retry (servers without /upload/init).

    Retries on network errors (3 attempts) and on HTTP 429 with
    exponential backoff (up to 4 retries, honoring Retry-After header).
    `mime` defaults to application/pdf for the sync/cp PDF paths; the generic
    `paperclip upload` command passes the file's detected MIME type.
    """
    max_429_retries = 4

    for rate_attempt in range(max_429_retries + 1):
        resp = None
        for attempt in range(3):
            try:
                with open(filepath, "rb") as f:
                    resp = requests.post(
                        f"{base_url}/api/user/upload",
                        headers=headers,
                        files={"file": (filepath.name, f, mime)},
                        data={"folder_path": folder_path},
                        timeout=300,
                    )
                break
            except requests.exceptions.RequestException as e:
                if attempt == 2:
                    return {"status": "error", "message": str(e)[:100]}
                time.sleep(2 * (attempt + 1))

        if resp is None:
            return {"status": "error", "message": "Upload failed after retries"}

        if resp.status_code == 413:
            size_mb = filepath.stat().st_size / (1024 * 1024)
            try:
                detail = resp.json().get("detail", "")
            except Exception:
                detail = ""
            limit_desc = detail or "max 200 MB"
            return {"status": "error", "message": f"File too large ({size_mb:.1f} MB, {limit_desc})"}
        if resp.status_code == 400:
            try:
                detail = resp.json().get("detail", "Bad request")
            except Exception:
                detail = "Bad request"
            return {"status": "error", "message": detail}
        if resp.status_code == 429:
            # Only retry rate-limit 429s (they carry Retry-After); quota 429s
            # never succeed on retry and should surface immediately.
            retry_after = resp.headers.get("Retry-After")
            if retry_after and rate_attempt < max_429_retries:
                if retry_after.isdigit():
                    wait = min(int(retry_after), 30)
                else:
                    wait = min(2 ** rate_attempt, 16)
                time.sleep(wait)
                continue
            try:
                detail = resp.json().get("detail", "Rate limit exceeded. Try again shortly.")
            except Exception:
                detail = "Rate limit exceeded. Try again shortly."
            return {"status": "error", "message": detail}
        if resp.status_code != 200:
            try:
                detail = resp.json().get("detail", resp.text[:100])
            except Exception:
                detail = resp.text[:100]
            return {"status": "error", "message": f"HTTP {resp.status_code}: {detail}"}

        return resp.json()

    return {"status": "error", "message": "Upload failed after retries"}


def delete_remote_doc(base_url: str, headers: dict, doc_id: str) -> bool:
    """Delete a document from the remote."""
    resp = requests.delete(
        f"{base_url}/api/user/documents/{doc_id}",
        headers=headers,
        timeout=30,
    )
    return resp.status_code == 200


# ── Click commands ──


@click.group("sync", invoke_without_command=True)
@click.pass_context
def sync_group(ctx):
    """Upload local PDFs to your paperclip clipboard.

    \b
    Upload (file or folder):
        paperclip sync upload ~/my_papers/
        paperclip sync upload paper.pdf

    \b
    Manage clipboard:
        paperclip sync rm my_papers
        paperclip sync rm --all
        paperclip sync status
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@sync_group.command("status")
def sync_status():
    """Show clipboard status including background processing progress."""
    cfg_data = _load_config()
    base_url = cfg_data.get("base_url", "https://paperclip.gxl.ai")
    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.get_id_token()}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    try:
        resp = requests.get(f"{base_url}/api/user/status", headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(1)

    total = data.get("total_documents", 0)
    pages = data.get("total_pages", 0)
    bytes_ = data.get("total_bytes", 0)
    folders = data.get("folders", 0)
    enhanced = data.get("enhanced", 0)
    pending = data.get("pending_enhancement", 0)
    limit_bytes = data.get("storage_limit_bytes", 0)

    size_mb = bytes_ / (1024 * 1024)
    click.echo(f"  Documents: {total} ({size_mb:.1f} MB, {pages} pages)")
    if limit_bytes:
        pct = 100 * bytes_ / limit_bytes
        limit_gb = limit_bytes / (1024**3)
        filled = min(20, round(pct / 5))
        bar = "█" * filled + "░" * (20 - filled)
        click.echo(f"  Storage:   [{bar}] {pct:.0f}% of {limit_gb:.0f} GB")
    click.echo(f"  Folders:   {folders}")
    click.echo(f"  Enhanced:  {enhanced}/{total}", nl=False)
    if pending > 0:
        click.echo(f"  ⏳ {pending} still processing (figures + high-quality text)")
    else:
        click.echo(f"  ✓ all done")


@sync_group.command("upload")
@click.argument("path", type=click.Path(exists=True, resolve_path=True))
def sync_upload(path: str):
    """Upload a file or folder of PDFs to your clipboard.

    \b
    Examples:
        paperclip sync upload ~/my_papers/
        paperclip sync upload paper.pdf
    """
    from pathlib import Path as _Path

    target = _Path(path)

    if not target.exists():
        click.echo(f"Not found: {path}", err=True)
        raise SystemExit(1)

    # Collect files
    if target.is_file():
        pdfs = [target]
        folder_name = ""
    else:
        pdfs = sorted(target.rglob("*.pdf"))
        folder_name = target.name
        if not pdfs:
            click.echo(f"No PDF files found in {target}")
            return

    click.echo(f"Uploading {len(pdfs)} PDF{'s' if len(pdfs) != 1 else ''} to /clipboard/{folder_name + '/' if folder_name else ''}...")

    base_url = _load_config().get("base_url") or config.CONFIG_FILE.parent.joinpath("config.json").read_text() if False else None
    # Use the config module to get base_url
    from .. import config as _cfg
    cfg_data = _load_config()
    base_url = cfg_data.get("base_url", "https://paperclip.gxl.ai")

    # Get auth headers (same as other sync commands)
    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.get_id_token()}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    success = 0
    errors = 0

    from concurrent.futures import ThreadPoolExecutor, as_completed
    import threading as _threading

    _upload_gate = _threading.Semaphore(4)

    def _upload_one(pdf):
        with _upload_gate:
            rel = pdf.relative_to(target) if target.is_dir() else pdf
            parts = list(rel.parent.parts) if target.is_dir() else []
            upload_folder = "/".join([folder_name] + [p for p in parts if p != "."]) if folder_name else ""
            result = upload_file(base_url, headers, pdf, upload_folder)
            time.sleep(0.25)
            return rel, result

    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(_upload_one, pdf): pdf for pdf in pdfs}
        failed = []
        dupes = 0
        new = 0
        for future in as_completed(futures):
            rel, result = future.result()
            if result.get("status") == "success":
                new += 1
                success += 1
            elif result.get("status") == "duplicate":
                dupes += 1
                success += 1
            else:
                errors += 1
                failed.append((rel, result.get("message", "unknown error")))

    parts = []
    if new:
        parts.append(f"{new} new")
    if dupes:
        parts.append(f"{dupes} already existed")
    if errors:
        parts.append(f"{errors} failed")
    click.echo(f"\n{'✓ ' if errors == 0 else ''}{', '.join(parts)}")
    if new > 0:
        eta = max(10, int(new * 1.3))
        click.echo(f"  Full processing (figures + enhanced text) in ~{eta}s")
    if failed:
        for rel, msg in failed:
            click.echo(f"  ✗ {rel}: {msg}")
    if folder_name:
        click.echo(f"View with: paperclip ls /clipboard/{folder_name}/")


@sync_group.command("add")
@click.argument("folder", type=click.Path(exists=True, file_okay=False, resolve_path=True))
@click.option("--prefix", default=None, help="Remote folder prefix (default: folder name)")
def sync_add(folder: str, prefix: str | None):
    """Register a local folder for syncing.

    \b
    Examples:
        paperclip sync add ~/Documents/research
        paperclip sync add ~/papers --prefix oncology
    """
    folder_path = Path(folder).resolve()
    remote_prefix = prefix or folder_path.name

    cfg = _load_config()
    folders = cfg.get(SYNC_CONFIG_KEY, [])

    # Check if already registered
    for f in folders:
        if f["path"] == str(folder_path):
            click.echo(f"Already registered: {folder_path} → /user/{f['prefix']}/")
            return

    folders.append({
        "path": str(folder_path),
        "prefix": remote_prefix,
        "added_at": time.time(),
    })
    cfg[SYNC_CONFIG_KEY] = folders
    _save_config(cfg)

    pdfs = discover_pdfs(folder_path)
    click.echo(f"✓ Registered: {folder_path} → /user/{remote_prefix}/")
    click.echo(f"  Found {len(pdfs)} PDF files")
    click.echo(f"  Run 'paperclip sync run' to upload")


@sync_group.command("remove")
@click.argument("folder", type=click.Path(resolve_path=True))
def sync_remove(folder: str):
    """Unregister a folder from syncing (does not delete remote docs)."""
    folder_path = Path(folder).resolve()

    cfg = _load_config()
    folders = cfg.get(SYNC_CONFIG_KEY, [])
    original_len = len(folders)
    folders = [f for f in folders if f["path"] != str(folder_path)]

    if len(folders) == original_len:
        click.echo(f"Not registered: {folder_path}")
        return

    cfg[SYNC_CONFIG_KEY] = folders
    _save_config(cfg)
    click.echo(f"✓ Removed: {folder_path}")


@sync_group.command("run")
@click.option("--dry-run", is_flag=True, help="Show what would be synced without uploading")
@click.option("--force", is_flag=True, help="Re-upload all files (ignore sync state)")
def sync_run(dry_run: bool, force: bool):
    """Sync registered folders — upload new/modified PDFs, detect deletions.

    \b
    Examples:
        paperclip sync run
        paperclip sync run --dry-run
        paperclip sync run --force
    """
    from ..client.client import PaperclipClient

    cfg = _load_config()
    folders = cfg.get(SYNC_CONFIG_KEY, [])

    if not folders:
        click.echo("No folders registered. Use 'paperclip sync add <folder>' first.")
        return

    state = _load_sync_state() if not force else {"files": {}, "folders": []}

    # Get auth
    client = PaperclipClient()
    base_url = client.base_url
    headers = client._get_headers()

    total_new = 0
    total_modified = 0
    total_deleted = 0
    total_errors = 0

    for folder_cfg in folders:
        folder_path = Path(folder_cfg["path"])
        remote_prefix = folder_cfg["prefix"]

        if not folder_path.exists():
            click.echo(f"⚠ Folder not found: {folder_path} (skipping)")
            continue

        pdfs = discover_pdfs(folder_path)
        new_files, modified_files, deleted_ids = diff_state(
            folder_path, remote_prefix, pdfs, state
        )

        click.echo(f"\n📁 {folder_path} → /user/{remote_prefix}/")
        click.echo(f"   {len(new_files)} new, {len(modified_files)} modified, {len(deleted_ids)} deleted")

        if dry_run:
            for f in new_files[:10]:
                click.echo(f"   + {f.relative_to(folder_path)}")
            if len(new_files) > 10:
                click.echo(f"   ... and {len(new_files) - 10} more")
            continue

        # Upload new files
        for f in new_files:
            rel = f.relative_to(folder_path)
            # Folder path = remote_prefix + parent dirs
            parts = list(rel.parent.parts)
            upload_folder = "/".join([remote_prefix] + list(parts)) if parts and parts != ["."] else remote_prefix

            try:
                result = upload_file(base_url, headers, f, upload_folder)
                if result.get("status") == "success":
                    total_new += 1
                    key = f"{remote_prefix}/{rel}"
                    state.setdefault("files", {})[key] = {
                        "doc_id": result["doc_id"],
                        "hash": compute_file_hash(f),
                        "synced_at": time.time(),
                    }
                    click.echo(f"   ✓ {rel}")
                elif result.get("status") == "duplicate":
                    key = f"{remote_prefix}/{rel}"
                    state.setdefault("files", {})[key] = {
                        "doc_id": result["doc_id"],
                        "hash": compute_file_hash(f),
                        "synced_at": time.time(),
                    }
                    click.echo(f"   = {rel} (already uploaded)")
                else:
                    total_errors += 1
                    click.echo(f"   ✗ {rel}: {result.get('message', 'unknown error')}")
            except Exception as e:
                total_errors += 1
                click.echo(f"   ✗ {rel}: {e}")

        # Upload modified files (delete + re-upload)
        for f in modified_files:
            rel = f.relative_to(folder_path)
            key = f"{remote_prefix}/{rel}"
            old_info = state.get("files", {}).get(key, {})

            # Delete old version
            if old_info.get("doc_id"):
                delete_remote_doc(base_url, headers, old_info["doc_id"])

            parts = list(rel.parent.parts)
            upload_folder = "/".join([remote_prefix] + list(parts)) if parts and parts != ["."] else remote_prefix

            try:
                result = upload_file(base_url, headers, f, upload_folder)
                if result.get("status") == "success":
                    total_modified += 1
                    state.setdefault("files", {})[key] = {
                        "doc_id": result["doc_id"],
                        "hash": compute_file_hash(f),
                        "synced_at": time.time(),
                    }
                    click.echo(f"   ↻ {rel}")
                else:
                    total_errors += 1
                    click.echo(f"   ✗ {rel}: {result.get('message', 'unknown error')}")
            except Exception as e:
                total_errors += 1
                click.echo(f"   ✗ {rel}: {e}")

        # Handle deletions
        for doc_id in deleted_ids:
            if delete_remote_doc(base_url, headers, doc_id):
                total_deleted += 1
            # Remove from state
            state["files"] = {
                k: v for k, v in state.get("files", {}).items()
                if v.get("doc_id") != doc_id
            }

    if not dry_run:
        _save_sync_state(state)
        click.echo(f"\n{'─' * 40}")
        click.echo(
            f"Done: {total_new} uploaded, {total_modified} updated, "
            f"{total_deleted} deleted, {total_errors} errors"
        )


@sync_group.command("import")
@click.argument("bibfile", type=click.Path(exists=True, dir_okay=False, resolve_path=True))
@click.option("--folder", default="", help="Clipboard folder for the entries (default: bib filename)")
def sync_import(bibfile: str, folder: str):
    """Import a .bib/.ris file into your clipboard.

    Each citation becomes a folder under /clipboard/. Entries found in the
    paperclip corpus are populated with full text or abstract; the rest keep
    their citation in meta.json.

    \b
    Examples:
        paperclip sync import refs.bib
        paperclip sync import refs.bib --folder thesis-refs
    """
    from ..client.client import PaperclipClient

    client = PaperclipClient()
    path = Path(bibfile)

    click.echo(f"Importing {path.name}...")
    with open(path, "rb") as f:
        resp = requests.post(
            f"{client.base_url}/api/user/import",
            headers=client._get_headers(),
            files={"file": (path.name, f, "text/plain")},
            data={"folder_path": folder},
            timeout=300,
        )

    if resp.status_code != 200:
        detail = resp.json().get("detail", f"HTTP {resp.status_code}") if resp.headers.get("content-type", "").startswith("application/json") else f"HTTP {resp.status_code}"
        click.echo(f"✗ Import failed: {detail}", err=True)
        raise SystemExit(1)

    result = resp.json()
    s = result["summary"]
    click.echo(f"\n✓ Imported {s['total']} entries → /clipboard/{result['folder']}/")
    click.echo(f"  Full text:     {s['fulltext']}")
    click.echo(f"  Abstract only: {s['abstract']}")
    click.echo(f"  Citation only: {s['citation_only']}")
    if s["duplicates"]:
        click.echo(f"  Skipped (already imported): {s['duplicates']}")


@sync_group.command("status")
def sync_status():
    """Show sync status — registered folders and document counts."""
    from ..client.client import PaperclipClient

    cfg = _load_config()
    folders = cfg.get(SYNC_CONFIG_KEY, [])
    state = _load_sync_state()

    if not folders:
        click.echo("No folders registered. Use 'paperclip sync add <folder>' first.")
        return

    click.echo("Registered folders:\n")
    for f in folders:
        folder_path = Path(f["path"])
        prefix = f["prefix"]
        exists = folder_path.exists()
        status_icon = "✓" if exists else "✗"

        # Count tracked files for this prefix
        tracked = sum(
            1 for k in state.get("files", {})
            if k.startswith(f"{prefix}/")
        )
        # Count local files
        local_count = len(discover_pdfs(folder_path)) if exists else 0

        click.echo(f"  {status_icon} {folder_path}")
        click.echo(f"    → /user/{prefix}/")
        click.echo(f"    Local: {local_count} PDFs | Synced: {tracked}")
        click.echo()

    # Try to get remote stats
    try:
        client = PaperclipClient()
        resp = requests.get(
            f"{client.base_url}/api/user/status",
            headers=client._get_headers(),
            timeout=10,
        )
        if resp.status_code == 200:
            stats = resp.json()
            click.echo(f"Remote ({client.base_url}):")
            click.echo(f"  Documents: {stats['total_documents']}")
            click.echo(f"  Pages: {stats['total_pages']}")
            click.echo(f"  Size: {stats['total_bytes'] / 1024 / 1024:.1f} MB")
            click.echo(f"  Folders: {stats['folders']}")
    except Exception:
        pass


@sync_group.command("list")
def sync_list():
    """List all registered sync folders."""
    cfg = _load_config()
    folders = cfg.get(SYNC_CONFIG_KEY, [])

    if not folders:
        click.echo("No folders registered.")
        return

    for f in folders:
        click.echo(f"  {f['path']} → /user/{f['prefix']}/")


@sync_group.command("rm")
@click.argument("target")
def sync_rm(target: str):
    """Delete a document or folder from your clipboard.

    \b
    Examples:
        paperclip sync rm my_papers                    # delete folder
        paperclip sync rm usr_c1f9c5eac891             # delete single doc by ID
        paperclip sync rm --all                        # delete everything
    """
    from .. import config as _cfg
    cfg_data = _load_config()
    base_url = cfg_data.get("base_url", "https://paperclip.gxl.ai")

    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.get_id_token()}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    if target == "--all":
        if not click.confirm("Delete ALL documents in your clipboard?"):
            return
        # Delete all folders by getting the tree first
        resp = requests.get(f"{base_url}/api/user/tree?path=", headers=headers, timeout=30)
        if resp.status_code != 200:
            click.echo(f"✗ Failed to list clipboard: {resp.status_code}")
            return
        tree = resp.json()
        # Delete each folder
        for folder in tree.get("folders", []):
            requests.delete(f"{base_url}/api/user/folders/{folder['name']}", headers=headers, timeout=30)
        # Delete root-level docs
        for doc in tree.get("documents", []):
            requests.delete(f"{base_url}/api/user/documents/{doc['id']}", headers=headers, timeout=30)
        click.echo("✓ Clipboard cleared")
        return

    # Try as folder first
    resp = requests.delete(f"{base_url}/api/user/folders/{target}", headers=headers, timeout=30)
    if resp.status_code == 200:
        data = resp.json()
        click.echo(f"✓ Deleted folder '{target}' ({data.get('deleted_count', '?')} docs)")
        return

    # Try as document ID
    doc_id = target
    if target.startswith("usr_"):
        doc_id = target  # the backend resolves usr_ IDs
    resp = requests.delete(f"{base_url}/api/user/documents/{doc_id}", headers=headers, timeout=30)
    if resp.status_code == 200:
        click.echo(f"✓ Deleted {target}")
    elif resp.status_code == 404:
        click.echo(f"✗ Not found: {target}")
    else:
        click.echo(f"✗ Delete failed: {resp.status_code}")


@click.command("upload")
@click.argument("files", nargs=-1, required=True,
                type=click.Path(exists=True, resolve_path=True, dir_okay=False))
@click.option("--into", "folder", default="",
              help="Destination clipboard folder, e.g. analyses/<slug>")
def upload_command(files: tuple, folder: str):
    """Upload generated file(s) into your paperclip clipboard.

    \b
    Examples:
        paperclip upload analysis.json --into analyses/my-topic
        paperclip upload index.html render_qa.json --into analyses/my-topic

    Persists analysis artifacts and reports (JSON/HTML/CSV/MD/PDF) to
    /clipboard/<folder>/. This is how you save generated files — the repo
    (`git`/`repo commit`) only stores the corpus + verified claims, NOT files.
    """
    import mimetypes

    folder = (folder or "").strip("/").replace("clipboard/", "").replace("/clipboard", "")

    # Resolve base_url honoring PAPERCLIP_BASE_URL env (matches the rest of the
    # CLI); reading the config file alone would ignore staging/local overrides.
    base_url = config.get_base_url()

    # Auth — Credentials.get_id_token() auto-refreshes an expired token.
    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.get_id_token()}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    total = len(files)
    success = 0
    failed: list[tuple] = []
    dest_label = f"/clipboard/{folder + '/' if folder else ''}"

    for fp in files:
        p = Path(fp)
        mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        result = upload_file(base_url, headers, p, folder, mime=mime)
        if result.get("status") in ("success", "duplicate"):
            success += 1
            stored = result.get("filename")
            renamed = f" (stored as '{stored}')" if stored and stored != p.name else ""
            click.echo(f"  ✓ {p.name} → {dest_label}{renamed}")
        else:
            msg = result.get("message", "unknown error")
            failed.append((p.name, msg))
            click.echo(f"  ✗ {p.name}: {msg}", err=True)

    click.echo("")
    if failed:
        click.echo(f"{success}/{total} uploaded, {len(failed)} failed", err=True)
        raise SystemExit(1)
    click.echo(f"✓ {success}/{total} uploaded to {dest_label}")
    if folder:
        click.echo(f"  paperclip ls /clipboard/{folder}/")


@click.command(
    "cp",
    context_settings=dict(
        ignore_unknown_options=True,
        allow_extra_args=True,
        help_option_names=[],
    ),
)
@click.argument("args", nargs=-1, type=click.UNPROCESSED)
def cp_command(args: tuple):
    """Copy files into your paperclip clipboard.

    \b
    Local files are uploaded; corpus/clipboard paths are linked server-side.
        paperclip cp ~/my_papers/            → uploads to /clipboard/my_papers/
        paperclip cp paper.pdf               → uploads to /clipboard/paper.pdf
        paperclip cp /papers/PMC123 /clipboard/oa/   → links a corpus paper
        paperclip cp /clipboard/usr_abc /clipboard/other/  → links an existing doc

    Uploaded originals stay on disk; duplicates are skipped automatically.
    """
    from pathlib import Path as _Path

    positionals = [a for a in args if not str(a).startswith("-")]
    source = positionals[0] if positionals else None

    # A local filesystem path (that exists) is uploaded; anything else
    # (/papers, /fda, /trials, /clipboard, corpus IDs) is a server-side link.
    local_path = None
    if source is not None:
        candidate = _Path(source).expanduser()
        if candidate.exists():
            local_path = str(candidate.resolve())

    if local_path is None:
        from .app import _execute_argv

        _execute_argv("cp", list(args))
        return

    dest = positionals[1] if len(positionals) > 1 else "/clipboard/"
    _cp_upload_local(local_path, dest)


def _cp_upload_local(source: str, dest: str):
    """Upload local files/directories into the remote clipboard."""
    from pathlib import Path as _Path
    from concurrent.futures import ThreadPoolExecutor, as_completed

    target = _Path(source)

    # Determine folder name
    if dest and dest != "/clipboard/":
        folder_name = dest.strip("/").replace("clipboard/", "").replace("/clipboard", "")
    elif target.is_dir():
        folder_name = target.name
    else:
        folder_name = ""

    # Collect files
    if target.is_file():
        pdfs = [target]
    else:
        pdfs = sorted(f for f in target.rglob("*") if f.is_file() and f.suffix and not any(p.startswith(".") for p in f.relative_to(target).parts))
        if not pdfs:
            click.echo(f"No files found in {target}")
            return

    click.echo(f"Copying {len(pdfs)} file{'s' if len(pdfs) != 1 else ''} → /clipboard/{folder_name + '/' if folder_name else ''}")

    # Auth — use Credentials.get_id_token() which auto-refreshes expired tokens
    cfg_data = _load_config()
    base_url = cfg_data.get("base_url", "https://paperclip.gxl.ai")
    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            token = creds.get_id_token()
            headers["Authorization"] = f"Bearer {token}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    # Upload with progress
    total = len(pdfs)
    success = 0
    errors = 0
    failed_files: list[tuple] = []

    import threading as _threading

    _cp_gate = _threading.Semaphore(4)

    def _upload_one(pdf):
        with _cp_gate:
            rel = pdf.relative_to(target) if target.is_dir() else pdf
            parts = list(rel.parent.parts) if target.is_dir() else []
            upload_folder = "/".join([folder_name] + [p for p in parts if p != "."]) if folder_name else ""
            result = upload_file(base_url, headers, pdf, upload_folder)
            time.sleep(0.25)
            return rel, result

    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(_upload_one, pdf): pdf for pdf in pdfs}
        for future in as_completed(futures):
            rel, result = future.result()
            if result.get("status") in ("success", "duplicate"):
                success += 1
                stored = result.get("filename")
                renamed = f" (stored as '{stored}')" if stored and stored != rel.name else ""
                click.echo(f"  ✓ [{success + errors}/{total}] {rel}{renamed}")
            else:
                errors += 1
                msg = result.get("message", "unknown error")
                failed_files.append((rel, msg))
                click.echo(f"  ✗ [{success + errors}/{total}] {rel}: {msg}")

    click.echo("")
    if errors == 0:
        click.echo(f"✓ {success}/{total} files in /clipboard/{folder_name + '/' if folder_name else ''}")
    else:
        click.echo(f"{success} copied, {errors} failed")
        for rel, msg in failed_files:
            click.echo(f"  ✗ {rel}: {msg}", err=True)
    if folder_name:
        click.echo(f"  paperclip ls /clipboard/{folder_name}/")


@click.command(
    "mv",
    context_settings=dict(
        ignore_unknown_options=True,
        allow_extra_args=True,
        help_option_names=[],
    ),
)
@click.argument("args", nargs=-1, type=click.UNPROCESSED)
def mv_command(args: tuple):
    """Move or rename documents/folders within your clipboard.

    \b
    Clipboard paths are moved/renamed server-side (metadata only):
        paperclip mv /clipboard/my_papers /clipboard/archive/   → move/rename a folder
        paperclip mv /clipboard/a/usr_abc /clipboard/b/         → move a document
        paperclip mv /clipboard/a/usr_abc /clipboard/a/new.pdf  → rename a document
    A local filesystem path is uploaded instead (like cp):
        paperclip mv ./report.pdf /clipboard/analyses/
    """
    from pathlib import Path as _Path

    positionals = [a for a in args if not str(a).startswith("-")]
    source = positionals[0] if positionals else None

    # A local filesystem path (that exists) is uploaded; anything else
    # (/clipboard, corpus paths, usr_ IDs) is a server-side move/rename.
    local_path = None
    if source is not None:
        candidate = _Path(source).expanduser()
        if candidate.exists():
            local_path = str(candidate.resolve())

    if local_path is None:
        from .app import _execute_argv

        _execute_argv("mv", list(args))
        return

    dest = positionals[1] if len(positionals) > 1 else "/clipboard/"
    _cp_upload_local(local_path, dest)


@click.command("share")
@click.argument("folder_path")
@click.argument("email")
@click.option("--role", type=click.Choice(["viewer", "editor"]), default="viewer", help="Permission level")
def share_command(folder_path: str, email: str, role: str):
    """Share a clipboard folder with a user by email.

    \b
    Examples:
        paperclip share my_papers bob@company.com
        paperclip share my_papers bob@company.com --role editor
    """
    folder_path = folder_path.strip("/").replace("clipboard/", "").replace("/clipboard", "")
    if not folder_path:
        click.echo("Usage: paperclip share <folder> <email>", err=True)
        raise SystemExit(1)

    cfg_data = _load_config()
    base_url = cfg_data.get("base_url", "https://paperclip.gxl.ai")
    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.get_id_token()}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    resp = requests.post(
        f"{base_url}/api/user/shares",
        headers={**headers, "Content-Type": "application/json"},
        json={"folder_path": folder_path, "email": email, "role": role},
        timeout=15,
    )

    if resp.status_code == 400:
        click.echo(f"Error: {resp.json().get('detail', 'Bad request')}", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo(f"Error: HTTP {resp.status_code}", err=True)
        raise SystemExit(1)

    data = resp.json()
    name = data.get("shared_with_name") or email
    click.echo(f"✓ Shared /clipboard/{folder_path}/ with {name} ({role})")


@click.command("unshare")
@click.argument("folder_path")
@click.argument("email")
def unshare_command(folder_path: str, email: str):
    """Remove a user's access to a shared folder.

    \b
    Examples:
        paperclip unshare my_papers bob@company.com
    """
    folder_path = folder_path.strip("/").replace("clipboard/", "").replace("/clipboard", "")
    if not folder_path:
        click.echo("Usage: paperclip unshare <folder> <email>", err=True)
        raise SystemExit(1)

    cfg_data = _load_config()
    base_url = cfg_data.get("base_url", "https://paperclip.gxl.ai")
    headers: dict = {}
    api_key = os.environ.get("PAPERCLIP_API_KEY", "")
    if api_key:
        headers["X-API-Key"] = api_key
    else:
        from ..client.credentials import Credentials
        creds = Credentials.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.get_id_token()}"
        else:
            click.echo("Not authenticated. Run: paperclip login", err=True)
            raise SystemExit(1)

    # List shares to find the one matching the email
    resp = requests.get(
        f"{base_url}/api/user/shares",
        headers=headers,
        params={"folder_path": folder_path},
        timeout=15,
    )
    if not resp.ok:
        click.echo(f"Error: HTTP {resp.status_code}", err=True)
        raise SystemExit(1)

    shares = resp.json()
    match = next((s for s in shares if s.get("shared_with_email", "").lower() == email.lower()), None)
    if not match:
        click.echo(f"No share found for {email} on /clipboard/{folder_path}/", err=True)
        raise SystemExit(1)

    # Revoke
    resp = requests.delete(
        f"{base_url}/api/user/shares/{match['id']}",
        headers=headers,
        timeout=15,
    )
    if not resp.ok:
        click.echo(f"Error: HTTP {resp.status_code}", err=True)
        raise SystemExit(1)

    click.echo(f"✓ Removed {email}'s access to /clipboard/{folder_path}/")