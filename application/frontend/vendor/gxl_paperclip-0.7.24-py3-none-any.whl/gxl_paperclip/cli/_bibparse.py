"""Zero-dependency .bib and .ris file parsers.

Each parser returns a list of dicts with normalized keys:
    doi, title, authors, year, journal, entry_key, raw_type
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path


def parse_file(path: str) -> list[dict]:
    """Auto-detect format and parse a bibliography file."""
    p = Path(path)
    suffix = p.suffix.lower()
    text = p.read_text(encoding="utf-8", errors="replace")

    if suffix == ".bib":
        return parse_bib(text)
    elif suffix == ".ris":
        return parse_ris(text)
    else:
        if text.lstrip().startswith("@"):
            return parse_bib(text)
        if text.lstrip().startswith("TY  -"):
            return parse_ris(text)
        raise ValueError(f"Cannot detect format for '{p.name}'. Use a .bib or .ris file.")


# ── BibTeX parser ────────────────────────────────────────────────


_BIB_ENTRY_RE = re.compile(
    r"@(\w+)\s*\{\s*([^,]*?)\s*,", re.IGNORECASE
)
_BIB_FIELD_RE = re.compile(
    r"(\w+)\s*=\s*(?:\{((?:[^{}]|\{[^{}]*\})*)\}|\"([^\"]*)\"|(\d+))\s*[,}]",
    re.DOTALL,
)


def parse_bib(text: str) -> list[dict]:
    entries: list[dict] = []
    for block in _split_bib_entries(text):
        m = _BIB_ENTRY_RE.match(block)
        if not m:
            continue
        raw_type = m.group(1).lower()
        entry_key = m.group(2).strip()

        fields: dict[str, str] = {}
        for fm in _BIB_FIELD_RE.finditer(block[m.end():]):
            key = fm.group(1).lower()
            val = fm.group(2) or fm.group(3) or fm.group(4) or ""
            fields[key] = _clean_latex(val.strip())

        doi = fields.get("doi", "")
        if not doi:
            url = fields.get("url", "")
            doi_m = re.search(r"10\.\d{4,}/[^\s]+", url)
            if doi_m:
                doi = doi_m.group()

        entries.append({
            "doi": doi,
            "title": fields.get("title", ""),
            "authors": fields.get("author", ""),
            "year": fields.get("year", ""),
            "journal": fields.get("journal", fields.get("booktitle", "")),
            "entry_key": entry_key,
            "raw_type": raw_type,
            "pmid": fields.get("pmid", ""),
            "pmc": _extract_pmc(fields),
            "arxiv": _extract_arxiv(fields),
        })
    return entries


def _split_bib_entries(text: str) -> list[str]:
    """Split BibTeX text into individual entry blocks."""
    entries: list[str] = []
    i = 0
    while i < len(text):
        start = text.find("@", i)
        if start == -1:
            break
        depth = 0
        j = start
        in_entry = False
        while j < len(text):
            if text[j] == "{":
                depth += 1
                in_entry = True
            elif text[j] == "}":
                depth -= 1
                if in_entry and depth == 0:
                    entries.append(text[start : j + 1])
                    break
            j += 1
        i = j + 1
    return entries


def _clean_latex(s: str) -> str:
    s = re.sub(r"\\[`'^\"~Hcvudbt]\{([a-zA-Z])\}", r"\1", s)
    s = re.sub(r"\\[`'^\"~Hcvudbt]([a-zA-Z])", r"\1", s)
    s = s.replace("\\&", "&").replace("\\%", "%")
    s = re.sub(r"[{}]", "", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def _extract_pmc(fields: dict[str, str]) -> str:
    for key in ("pmc", "pmcid"):
        val = fields.get(key, "")
        if val:
            m = re.search(r"PMC(\d+)", val, re.IGNORECASE)
            return m.group(1) if m else val
    url = fields.get("url", "")
    m = re.search(r"PMC(\d+)", url)
    if m:
        return m.group(1)
    return ""


def _extract_arxiv(fields: dict[str, str]) -> str:
    """Extract arXiv ID from eprint/arxivid fields or journal string."""
    for key in ("eprint", "arxivid", "arxiv"):
        val = fields.get(key, "")
        if val:
            m = re.search(r"(\d{4}\.\d{4,5})", val)
            if m:
                return m.group(1)
            # Older format: hep-ph/9901234
            m = re.search(r"([a-z-]+/\d{7})", val)
            if m:
                return m.group(1)

    journal = fields.get("journal", "") + " " + fields.get("booktitle", "")
    m = re.search(r"arXiv[:\s]+(?:preprint\s+)?(?:arXiv[:\s]*)?\s*(\d{4})\.\s*(\d{4,5})", journal, re.IGNORECASE)
    if m:
        return f"{m.group(1)}.{m.group(2)}"

    return ""


# ── RIS parser ───────────────────────────────────────────────────


def parse_ris(text: str) -> list[dict]:
    entries: list[dict] = []
    current: dict[str, list[str]] = {}

    for line in text.split("\n"):
        line = line.rstrip()
        if not line:
            continue

        tag_m = re.match(r"^([A-Z][A-Z0-9])\s{2}-\s?(.*)", line)
        if not tag_m:
            continue

        tag, value = tag_m.group(1), tag_m.group(2).strip()

        if tag == "TY":
            current = {"TY": [value]}
        elif tag == "ER":
            if current:
                entries.append(_ris_record_to_entry(current))
                current = {}
        else:
            current.setdefault(tag, []).append(value)

    if current:
        entries.append(_ris_record_to_entry(current))

    return entries


def _ris_record_to_entry(rec: dict[str, list[str]]) -> dict:
    def first(tag: str) -> str:
        return rec.get(tag, [""])[0]

    doi = first("DO") or first("DI")
    if not doi:
        url = first("UR") or first("L1")
        m = re.search(r"10\.\d{4,}/[^\s]+", url)
        if m:
            doi = m.group()

    authors = "; ".join(rec.get("AU", []) or rec.get("A1", []))

    pmc = ""
    for tag in ("C1", "N1", "UR", "ID"):
        for val in rec.get(tag, []):
            m = re.search(r"PMC(\d+)", val)
            if m:
                pmc = m.group(1)
                break
        if pmc:
            break

    arxiv = ""
    for tag in ("M1", "N1", "UR", "L1", "ID"):
        for val in rec.get(tag, []):
            m = re.search(r"(\d{4}\.\d{4,5})", val)
            if m and "arxiv" in val.lower():
                arxiv = m.group(1)
                break
        if arxiv:
            break

    return {
        "doi": doi,
        "title": first("TI") or first("T1"),
        "authors": authors,
        "year": (first("PY") or first("Y1") or first("DA"))[:4],
        "journal": first("JO") or first("JF") or first("T2") or first("JA"),
        "entry_key": first("ID") or first("AN") or "",
        "raw_type": first("TY").lower() if rec.get("TY") else "",
        "pmid": first("PM") or "",
        "pmc": pmc,
        "arxiv": arxiv,
    }


# ── Helpers ──────────────────────────────────────────────────────


def make_ref_id(entry: dict) -> str:
    """Generate a stable synthetic ID for an unmatched bib/ris entry."""
    key = entry.get("doi") or entry.get("title") or entry.get("entry_key") or ""
    h = hashlib.sha256(key.encode()).hexdigest()[:12]
    return f"ref_{h}"
