"""Deterministic planning and merge contracts for dense-paper extraction."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .contracts import (
    COLLECTION_SPEC_FILENAME,
    PLANNED_OUTPUTS_FILENAME,
    validate_collection_spec,
    validate_planned_outputs,
)
from .models import AnalysisProject
from .schema_optimization import (
    SCHEMA_OPTIMIZATION_FILENAME,
    schema_lock_is_current,
)
from .store import atomic_write_json, sha256_file

EXTRACTION_PLAN_SCHEMA_VERSION = 1
EXTRACTION_SHARD_SCHEMA_VERSION = 1
EXTRACTION_MERGE_SCHEMA_VERSION = 1
PAPER_INVENTORY_SCHEMA_VERSION = 1

EXTRACTION_PLAN_FILENAME = "extraction_plan.json"
EXTRACTION_MERGE_FILENAME = "extraction_merge.json"

# Defaults are deliberately conservative and domain-agnostic. A paper is dense
# when any direct threshold is reached, or when the weighted structural score
# reaches ``structural_score``. Callers may override any value in a plan build.
DEFAULT_DENSE_THRESHOLDS: dict[str, int] = {
    "readable_line_count": 1200,
    "readable_block_count": 240,
    "table_count": 8,
    "figure_count": 10,
    "supplement_count": 2,
    "structural_score": 16,
    "max_categories_per_shard": 3,
    "max_dense_shards": 8,
}
STRUCTURAL_WEIGHTS: dict[str, int] = {
    "table_count": 2,
    "figure_count": 1,
    "supplement_count": 4,
}
TERMINAL_SUCCESS_STATUSES = frozenset({"saved", "success", "completed"})
UNIVERSAL_SHARED_FIELDS = (
    "paper_id",
    "card_type",
    "record_type",
    "source_locations",
)
_COUNT_ALIASES = {
    "readable_line_count": ("readable_line_count", "line_count"),
    "readable_block_count": ("readable_block_count", "block_count"),
    "table_count": ("table_count", "tables"),
    "figure_count": ("figure_count", "figures"),
    "supplement_count": ("supplement_count", "supplements"),
}
_SHA256_CHARS = frozenset("0123456789abcdef")


class ExtractionPlanningError(RuntimeError):
    """An actionable extraction-plan or shard-merge failure."""


@dataclass
class ExtractionValidation:
    """Validation result shared by inventory and extraction-plan contracts."""

    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "errors": self.errors, "warnings": self.warnings}


def _canonical_json(value: object) -> bytes:
    return json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def _canonical_sha256(value: object) -> str:
    return hashlib.sha256(_canonical_json(value)).hexdigest()


def _valid_sha256(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in _SHA256_CHARS for character in value)
    )


def _nonempty_string(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _count_value(row: Mapping[str, Any], canonical_name: str) -> object:
    names = _COUNT_ALIASES[canonical_name]
    supplied = [row[name] for name in names if name in row]
    if len(supplied) > 1 and any(value != supplied[0] for value in supplied[1:]):
        raise ValueError(f"conflicting aliases supplied for {canonical_name}")
    return supplied[0] if supplied else None


def validate_paper_inventory(value: object) -> ExtractionValidation:
    """Validate authored paper complexity measurements without inferring counts."""
    result = ExtractionValidation()
    papers = value.get("papers") if isinstance(value, Mapping) else value
    if isinstance(value, Mapping):
        version = value.get("schema_version", PAPER_INVENTORY_SCHEMA_VERSION)
        if version != PAPER_INVENTORY_SCHEMA_VERSION:
            result.errors.append(
                f"paper inventory schema_version must equal {PAPER_INVENTORY_SCHEMA_VERSION}"
            )
    if not isinstance(papers, list) or not papers:
        result.errors.append("paper inventory must contain a non-empty papers array")
        return result
    seen: set[str] = set()
    for index, row in enumerate(papers):
        prefix = f"papers[{index}]"
        if not isinstance(row, Mapping):
            result.errors.append(f"{prefix} must be an object")
            continue
        paper_id = row.get("paper_id")
        if not _nonempty_string(paper_id):
            result.errors.append(f"{prefix}.paper_id must be a non-empty string")
        elif str(paper_id) in seen:
            result.errors.append(f"duplicate paper_id {paper_id!r}")
        else:
            seen.add(str(paper_id))
        supplied_count = False
        for canonical_name in _COUNT_ALIASES:
            try:
                count = _count_value(row, canonical_name)
            except ValueError as exc:
                result.errors.append(f"{prefix}: {exc}")
                continue
            if count is None:
                continue
            supplied_count = True
            if not isinstance(count, int) or isinstance(count, bool) or count < 0:
                result.errors.append(f"{prefix}.{canonical_name} must be a non-negative integer")
        if not supplied_count:
            result.errors.append(f"{prefix} must provide at least one measurable complexity count")
        source_path = row.get("source_path")
        if source_path is not None and not _nonempty_string(source_path):
            result.errors.append(f"{prefix}.source_path must be non-empty when present")
        source_scope = row.get("source_scope")
        if source_scope is not None and not isinstance(source_scope, Mapping):
            result.errors.append(f"{prefix}.source_scope must be an object when present")
        metadata = row.get("metadata")
        if metadata is not None and not isinstance(metadata, Mapping):
            result.errors.append(f"{prefix}.metadata must be an object when present")
    return result


def _normalize_inventory(value: object) -> dict[str, Any]:
    validation = validate_paper_inventory(value)
    if not validation.ok:
        raise ExtractionPlanningError("; ".join(validation.errors))
    source = value if isinstance(value, Mapping) else {"papers": value}
    papers = source["papers"]
    normalized: list[dict[str, Any]] = []
    for row in papers:
        assert isinstance(row, Mapping)
        item: dict[str, Any] = {"paper_id": str(row["paper_id"]).strip()}
        for canonical_name in _COUNT_ALIASES:
            count = _count_value(row, canonical_name)
            if count is not None:
                item[canonical_name] = count
        for name in ("source_path", "source_scope", "metadata"):
            if name in row:
                item[name] = deepcopy(row[name])
        normalized.append(item)
    metadata = {
        str(key): deepcopy(item)
        for key, item in source.items()
        if key not in {"papers", "schema_version"}
    }
    return {
        "schema_version": PAPER_INVENTORY_SCHEMA_VERSION,
        "metadata": metadata,
        "papers": sorted(normalized, key=lambda row: row["paper_id"].casefold()),
    }


def _thresholds(overrides: Mapping[str, Any] | None) -> dict[str, int]:
    thresholds = dict(DEFAULT_DENSE_THRESHOLDS)
    for name, value in (overrides or {}).items():
        if name not in thresholds:
            raise ExtractionPlanningError(f"unknown extraction threshold {name!r}")
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise ExtractionPlanningError(
                f"extraction threshold {name!r} must be a positive integer"
            )
        thresholds[name] = value
    return thresholds


def classify_paper_complexity(
    paper: Mapping[str, Any],
    *,
    thresholds: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Classify one validated inventory row using explicit configurable defaults."""
    configured = _thresholds(thresholds)
    direct_names = (
        "readable_line_count",
        "readable_block_count",
        "table_count",
        "figure_count",
        "supplement_count",
    )
    reasons = [
        name
        for name in direct_names
        if isinstance(paper.get(name), int) and int(paper[name]) >= configured[name]
    ]
    structural_score = sum(
        int(paper.get(name, 0)) * weight for name, weight in STRUCTURAL_WEIGHTS.items()
    )
    if structural_score >= configured["structural_score"]:
        reasons.append("structural_score")
    ratios = [
        int(paper[name]) / configured[name]
        for name in direct_names
        if isinstance(paper.get(name), int)
    ]
    ratios.append(structural_score / configured["structural_score"])
    density_ratio = max(ratios, default=0.0)
    return {
        "classification": "dense" if reasons else "simple",
        "dense_reasons": reasons,
        "structural_score": structural_score,
        "density_ratio": round(density_ratio, 6),
        "measurements": {name: paper[name] for name in direct_names if name in paper},
    }


def _named_rows(value: object) -> list[tuple[str, Mapping[str, Any]]]:
    if isinstance(value, Mapping):
        return [
            (str(name), details if isinstance(details, Mapping) else {})
            for name, details in value.items()
        ]
    if not isinstance(value, list):
        return []
    rows: list[tuple[str, Mapping[str, Any]]] = []
    for item in value:
        if isinstance(item, str) and item.strip():
            rows.append((item.strip(), {}))
        elif isinstance(item, Mapping):
            name = item.get("id") or item.get("name") or item.get("field") or item.get("key")
            if _nonempty_string(name):
                rows.append((str(name).strip(), item))
    return rows


def _string_values(value: object) -> list[str]:
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [str(item).strip() for item in value if _nonempty_string(item)]
    return []


def _required_data(planned_outputs: Mapping[str, Any]) -> set[str]:
    required: set[str] = set()
    for section in ("analyses", "visualizations"):
        rows = planned_outputs.get(section)
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            for item in row.get("required_data", []):
                if isinstance(item, str) and item.strip():
                    required.add(item.strip())
                elif isinstance(item, Mapping):
                    name = item.get("field") or item.get("concept") or item.get("name")
                    if _nonempty_string(name):
                        required.add(str(name).strip())
    return required


def _collection_scope(
    collection_spec: Mapping[str, Any],
    planned_outputs: Mapping[str, Any],
) -> tuple[list[str], dict[str, list[str]], list[str]]:
    categories = sorted(
        {name for name, _details in _named_rows(collection_spec.get("categories"))},
        key=str.casefold,
    )
    if not categories:
        raise ExtractionPlanningError("collection_spec.json declares no categories")
    category_lookup = {name.casefold(): name for name in categories}
    category_fields: dict[str, set[str]] = {name: set() for name in categories}
    shared = set(UNIVERSAL_SHARED_FIELDS)
    for key in (
        "shared_fields",
        "identity_fields",
        "shared_identity_fields",
        "context_fields",
    ):
        shared.update(_string_values(collection_spec.get(key)))

    field_categories: dict[str, list[str]] = {}
    for field_name, details in _named_rows(collection_spec.get("fields")):
        declared = _string_values(details.get("categories"))
        declared.extend(_string_values(details.get("category")))
        normalized = [
            category_lookup[name.casefold()]
            for name in declared
            if name.casefold() in category_lookup
        ]
        scope = str(details.get("scope", "")).strip().casefold()
        if details.get("shared") is True or scope in {
            "shared",
            "identity",
            "context",
            "identity_context",
        }:
            shared.add(field_name)
            field_categories[field_name] = []
        elif normalized:
            field_categories[field_name] = sorted(set(normalized), key=str.casefold)
            for category in normalized:
                category_fields[category].add(field_name)
        else:
            shared.add(field_name)
            field_categories[field_name] = []

    for category, details in _named_rows(collection_spec.get("categories")):
        canonical = category_lookup.get(category.casefold())
        if canonical is not None:
            category_fields[canonical].update(_string_values(details.get("fields")))

    for field_name in _required_data(planned_outputs):
        owners = field_categories.get(field_name, [])
        if owners:
            for category in owners:
                category_fields[category].add(field_name)
        else:
            shared.add(field_name)
    return (
        categories,
        {
            category: sorted(fields, key=str.casefold)
            for category, fields in category_fields.items()
        },
        sorted(shared, key=str.casefold),
    )


def _partition_categories(
    categories: Sequence[str],
    paper: Mapping[str, Any],
    complexity: Mapping[str, Any],
    thresholds: Mapping[str, int],
) -> list[list[str]]:
    if complexity["classification"] == "simple":
        return [list(categories)]
    desired = max(2, math.ceil(float(complexity["density_ratio"])))
    minimum_for_size = math.ceil(len(categories) / thresholds["max_categories_per_shard"])
    category_shards = min(
        len(categories),
        thresholds["max_dense_shards"],
        max(desired, minimum_for_size),
    )
    category_shards = max(1, category_shards)
    groups: list[list[str]] = [[] for _ in range(category_shards)]
    for index, category in enumerate(categories):
        groups[index % category_shards].append(category)
    if len(groups) == 1:
        # A dense one-category paper still has separate context and category
        # extraction sessions; the context shard cannot emit category records.
        groups.insert(0, [])
    return groups


def _stable_id(prefix: str, value: object, length: int = 20) -> str:
    return f"{prefix}_{_canonical_sha256(value)[:length]}"


def make_shard_card_id(claim_id_namespace: str, local_key: str) -> str:
    """Build a stable card ID inside an extraction shard's namespace."""
    if not claim_id_namespace or not local_key.strip():
        raise ValueError("claim namespace and local key must be non-empty")
    return f"{claim_id_namespace}:{_canonical_sha256(local_key.strip())[:20]}"


def _task_prompt(shard: Mapping[str, Any]) -> str:
    categories = json.dumps(shard["owned_categories"], ensure_ascii=False)
    fields = json.dumps(shard["required_fields"], ensure_ascii=False)
    shared = json.dumps(shard["shared_identity_context_fields"], ensure_ascii=False)
    return (
        f"Extract paper {shard['paper_id']} for private shard {shard['shard_id']}. "
        "You may read the full paper for context, but emit only records owned by "
        f"this shard. Owned categories: {categories}. Required fields: {fields}. "
        f"Shared identity/context fields: {shared}. "
        f"Source-context ownership: {str(shard['owns_source_context']).lower()}. "
        f"Every card must use paper_id {shard['paper_id']}, claim_id_namespace "
        f"{shard['claim_id_namespace']}, and a stable_id beginning with that "
        "namespace plus ':'. Preserve exact source locations and do not infer "
        "unreported facts. Return one saved shard JSON object with completed_categories, "
        "completed_source_context, and source_cards."
    )


def _plan_payload(plan: Mapping[str, Any]) -> dict[str, Any]:
    return {str(key): deepcopy(value) for key, value in plan.items() if key != "plan_sha256"}


def build_extraction_plan(
    collection_spec: Mapping[str, Any],
    planned_outputs: Mapping[str, Any],
    paper_inventory: object,
    *,
    collection_spec_sha256: str | None = None,
    planned_outputs_sha256: str | None = None,
    thresholds: Mapping[str, Any] | None = None,
    project_id: str | None = None,
    project_revision: int | None = None,
    previous_plan: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a deterministic extraction plan from approved dynamic contracts."""
    collection_validation = validate_collection_spec(collection_spec)
    if not collection_validation.ok:
        raise ExtractionPlanningError(
            f"{COLLECTION_SPEC_FILENAME}: " + "; ".join(collection_validation.errors)
        )
    outputs_validation = validate_planned_outputs(planned_outputs)
    if not outputs_validation.ok:
        raise ExtractionPlanningError(
            f"{PLANNED_OUTPUTS_FILENAME}: " + "; ".join(outputs_validation.errors)
        )
    inventory = _normalize_inventory(paper_inventory)
    configured = _thresholds(thresholds)
    collection_hash = collection_spec_sha256 or _canonical_sha256(collection_spec)
    outputs_hash = planned_outputs_sha256 or _canonical_sha256(planned_outputs)
    if not _valid_sha256(collection_hash) or not _valid_sha256(outputs_hash):
        raise ExtractionPlanningError("source artifact hashes must be lowercase SHA-256 strings")
    categories, category_fields, shared_fields = _collection_scope(
        collection_spec,
        planned_outputs,
    )
    inventory_hash = _canonical_sha256(inventory)
    input_binding = {
        "collection_spec_sha256": collection_hash,
        "planned_outputs_sha256": outputs_hash,
        "paper_inventory_sha256": inventory_hash,
        "thresholds": configured,
        "project_id": project_id,
        "project_revision": project_revision,
    }
    input_sha = _canonical_sha256(input_binding)
    if isinstance(previous_plan, Mapping) and previous_plan.get("input_sha256") == input_sha:
        validation = validate_extraction_plan(
            previous_plan,
            collection_spec_sha256=collection_hash,
            planned_outputs_sha256=outputs_hash,
            project_id=project_id,
            project_revision=project_revision,
        )
        if validation.ok:
            return deepcopy(dict(previous_plan))

    revision = (
        int(previous_plan.get("revision", 0)) + 1
        if isinstance(previous_plan, Mapping) and isinstance(previous_plan.get("revision"), int)
        else 1
    )
    previous_hash = (
        previous_plan.get("plan_sha256")
        if isinstance(previous_plan, Mapping) and _valid_sha256(previous_plan.get("plan_sha256"))
        else None
    )
    plan_id = _stable_id("xplan", input_binding)
    papers: list[dict[str, Any]] = []
    tasks: list[dict[str, Any]] = []
    for paper in inventory["papers"]:
        complexity = classify_paper_complexity(paper, thresholds=configured)
        groups = _partition_categories(categories, paper, complexity, configured)
        shards: list[dict[str, Any]] = []
        for index, owned in enumerate(groups):
            owns_context = index == 0
            shard_seed = {
                "plan_id": plan_id,
                "paper_id": paper["paper_id"],
                "owned_categories": owned,
                "owns_source_context": owns_context,
            }
            shard_id = _stable_id("xshard", shard_seed)
            namespace = f"{plan_id}/{paper['paper_id']}/{shard_id}"
            required_fields = sorted(
                {field for category in owned for field in category_fields.get(category, [])},
                key=str.casefold,
            )
            source_scope = {
                "read_scope": "full_paper",
                "emit_scope": "owned_categories_only",
            }
            if "source_path" in paper:
                source_scope["source_path"] = paper["source_path"]
            if "source_scope" in paper:
                source_scope["inventory_scope"] = deepcopy(paper["source_scope"])
            shard = {
                "shard_id": shard_id,
                "paper_id": paper["paper_id"],
                "owned_categories": owned,
                "required_fields": required_fields,
                "shared_identity_context_fields": shared_fields,
                "owns_source_context": owns_context,
                "claim_id_namespace": namespace,
                "source_scope": source_scope,
                "output_path": f"extraction_shards/{shard_id}.json",
                "instruction": (
                    "May read the full paper for context; emits only source_context "
                    "and category records explicitly owned by this shard."
                    if owns_context
                    else "May read the full paper for context; emits only category "
                    "records explicitly owned by this shard."
                ),
            }
            task = {
                "task_id": shard_id,
                "shard_id": shard_id,
                "paper_id": paper["paper_id"],
                "description": (
                    f"Extract {paper['paper_id']} categories "
                    f"{', '.join(owned) if owned else '[source_context only]'}"
                ),
                "prompt": _task_prompt(shard),
                "expected_output": shard["output_path"],
            }
            shard["task_id"] = task["task_id"]
            shards.append(shard)
            tasks.append(task)
        papers.append(
            {
                "paper_id": paper["paper_id"],
                "classification": complexity["classification"],
                "complexity": complexity,
                "inventory": deepcopy(paper),
                "shards": shards,
                "category_ownership": {
                    category: next(
                        shard["shard_id"]
                        for shard in shards
                        if category in shard["owned_categories"]
                    )
                    for category in categories
                },
                "source_context_shard_id": shards[0]["shard_id"],
            }
        )
    history = (
        [
            deepcopy(item)
            for item in previous_plan.get("revision_history", [])
            if isinstance(item, Mapping)
        ]
        if isinstance(previous_plan, Mapping)
        else []
    )
    history.append(
        {
            "revision": revision,
            "plan_id": plan_id,
            "input_sha256": input_sha,
            "previous_plan_sha256": previous_hash,
            "reason": "initial_plan" if revision == 1 else "source_or_inventory_changed",
        }
    )
    plan: dict[str, Any] = {
        "schema_version": EXTRACTION_PLAN_SCHEMA_VERSION,
        "plan_id": plan_id,
        "revision": revision,
        "project_id": project_id,
        "project_revision": project_revision,
        "source_hashes": {
            "collection_spec.json": collection_hash,
            "planned_outputs.json": outputs_hash,
            "paper_inventory": inventory_hash,
        },
        "input_sha256": input_sha,
        "previous_plan_sha256": previous_hash,
        "revision_history": history,
        "thresholds": configured,
        "classification_policy": {
            "dense_when": (
                "any direct metric reaches its threshold or weighted structural "
                "score reaches structural_score"
            ),
            "structural_weights": STRUCTURAL_WEIGHTS,
            "simple_scope": "one exhaustive shard",
            "dense_scope": "multiple disjoint category-owned shards",
        },
        "approved_categories": categories,
        "category_fields": category_fields,
        "shared_identity_context_fields": shared_fields,
        "paper_inventory": inventory,
        "papers": papers,
        "tasks": sorted(tasks, key=lambda task: task["task_id"]),
    }
    plan["plan_sha256"] = _canonical_sha256(_plan_payload(plan))
    validation = validate_extraction_plan(
        plan,
        collection_spec_sha256=collection_hash,
        planned_outputs_sha256=outputs_hash,
        project_id=project_id,
        project_revision=project_revision,
    )
    if not validation.ok:
        raise ExtractionPlanningError("; ".join(validation.errors))
    return plan


def validate_extraction_plan(
    value: object,
    *,
    collection_spec_sha256: str | None = None,
    planned_outputs_sha256: str | None = None,
    project_id: str | None = None,
    project_revision: int | None = None,
) -> ExtractionValidation:
    """Validate plan integrity, source bindings, IDs, and exact ownership."""
    result = ExtractionValidation()
    if not isinstance(value, Mapping):
        result.errors.append("extraction plan must contain an object")
        return result
    if value.get("schema_version") != EXTRACTION_PLAN_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {EXTRACTION_PLAN_SCHEMA_VERSION}")
    plan_id = value.get("plan_id")
    if not _nonempty_string(plan_id):
        result.errors.append("plan_id must be a non-empty string")
    revision = value.get("revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        result.errors.append("revision must be a positive integer")
    source_hashes = value.get("source_hashes")
    if not isinstance(source_hashes, Mapping):
        result.errors.append("source_hashes must be an object")
        source_hashes = {}
    for name in (
        COLLECTION_SPEC_FILENAME,
        PLANNED_OUTPUTS_FILENAME,
        "paper_inventory",
    ):
        if not _valid_sha256(source_hashes.get(name)):
            result.errors.append(f"source_hashes.{name} must be a lowercase SHA-256")
    comparisons = (
        (COLLECTION_SPEC_FILENAME, collection_spec_sha256),
        (PLANNED_OUTPUTS_FILENAME, planned_outputs_sha256),
    )
    for name, expected in comparisons:
        if expected is not None and source_hashes.get(name) != expected:
            result.errors.append(f"stale extraction plan: {name} hash changed")
    if project_id is not None and value.get("project_id") != project_id:
        result.errors.append("stale extraction plan: project_id changed")
    if project_revision is not None and value.get("project_revision") != project_revision:
        result.errors.append("stale extraction plan: project revision changed")
    inventory = value.get("paper_inventory")
    inventory_validation = validate_paper_inventory(inventory)
    if not inventory_validation.ok:
        result.errors.extend(f"paper_inventory: {error}" for error in inventory_validation.errors)
    elif source_hashes.get("paper_inventory") != _canonical_sha256(inventory):
        result.errors.append(
            "source_hashes.paper_inventory does not match the normalized inventory"
        )
    try:
        configured = _thresholds(
            value.get("thresholds") if isinstance(value.get("thresholds"), Mapping) else None
        )
    except ExtractionPlanningError as exc:
        result.errors.append(str(exc))
        configured = dict(DEFAULT_DENSE_THRESHOLDS)
    input_binding = {
        "collection_spec_sha256": source_hashes.get(COLLECTION_SPEC_FILENAME),
        "planned_outputs_sha256": source_hashes.get(PLANNED_OUTPUTS_FILENAME),
        "paper_inventory_sha256": source_hashes.get("paper_inventory"),
        "thresholds": configured,
        "project_id": value.get("project_id"),
        "project_revision": value.get("project_revision"),
    }
    expected_input_sha = _canonical_sha256(input_binding)
    if value.get("input_sha256") != expected_input_sha:
        result.errors.append("input_sha256 does not match the extraction-plan inputs")
    expected_plan_id = _stable_id("xplan", input_binding)
    if plan_id != expected_plan_id:
        result.errors.append("plan_id is not deterministic for the bound inputs")
    expected_plan_hash = _canonical_sha256(_plan_payload(value))
    if value.get("plan_sha256") != expected_plan_hash:
        result.errors.append("plan_sha256 does not match the extraction plan")

    categories = value.get("approved_categories")
    if (
        not isinstance(categories, list)
        or not categories
        or not all(_nonempty_string(item) for item in categories)
    ):
        result.errors.append("approved_categories must be a non-empty string array")
        categories = []
    elif len(set(categories)) != len(categories):
        result.errors.append("approved_categories must not contain duplicates")
    papers = value.get("papers")
    if not isinstance(papers, list) or not papers:
        result.errors.append("papers must be a non-empty array")
        return result
    expected_tasks: set[str] = set()
    seen_papers: set[str] = set()
    inventory_by_paper = {
        str(paper.get("paper_id")): paper
        for paper in (inventory.get("papers", []) if isinstance(inventory, Mapping) else [])
        if isinstance(paper, Mapping) and _nonempty_string(paper.get("paper_id"))
    }
    task_by_id = (
        {
            str(task.get("task_id")): task
            for task in value.get("tasks", [])
            if isinstance(task, Mapping) and _nonempty_string(task.get("task_id"))
        }
        if isinstance(value.get("tasks"), list)
        else {}
    )
    for paper_index, paper in enumerate(papers):
        prefix = f"papers[{paper_index}]"
        if not isinstance(paper, Mapping):
            result.errors.append(f"{prefix} must be an object")
            continue
        paper_id = paper.get("paper_id")
        if not _nonempty_string(paper_id):
            result.errors.append(f"{prefix}.paper_id must be non-empty")
            continue
        if str(paper_id) in seen_papers:
            result.errors.append(f"duplicate planned paper {paper_id!r}")
        seen_papers.add(str(paper_id))
        classification = paper.get("classification")
        if classification not in {"simple", "dense"}:
            result.errors.append(f"{prefix}.classification must be simple or dense")
        inventory_paper = inventory_by_paper.get(str(paper_id))
        expected_complexity = (
            classify_paper_complexity(inventory_paper, thresholds=configured)
            if inventory_paper is not None
            else None
        )
        if expected_complexity is None:
            result.errors.append(f"{prefix} has no matching inventory row")
        else:
            if paper.get("complexity") != expected_complexity:
                result.errors.append(f"{prefix}.complexity is not deterministic")
            if classification != expected_complexity["classification"]:
                result.errors.append(f"{prefix}.classification is not deterministic")
        shards = paper.get("shards")
        if not isinstance(shards, list) or not shards:
            result.errors.append(f"{prefix}.shards must be non-empty")
            continue
        if classification == "simple" and len(shards) != 1:
            result.errors.append(f"{prefix} simple paper must have exactly one shard")
        if classification == "dense" and len(shards) < 2:
            result.errors.append(f"{prefix} dense paper must have at least two shards")
        if expected_complexity is not None and inventory_paper is not None:
            expected_groups = _partition_categories(
                [str(category) for category in categories],
                inventory_paper,
                expected_complexity,
                configured,
            )
            actual_groups = [
                shard.get("owned_categories") for shard in shards if isinstance(shard, Mapping)
            ]
            if actual_groups != expected_groups:
                result.errors.append(f"{prefix} category partition is not deterministic")
        ownership: dict[str, list[str]] = {str(category): [] for category in categories}
        context_owners: list[str] = []
        seen_shards: set[str] = set()
        for shard_index, shard in enumerate(shards):
            shard_prefix = f"{prefix}.shards[{shard_index}]"
            if not isinstance(shard, Mapping):
                result.errors.append(f"{shard_prefix} must be an object")
                continue
            shard_id = shard.get("shard_id")
            if not _nonempty_string(shard_id):
                result.errors.append(f"{shard_prefix}.shard_id must be non-empty")
                continue
            if str(shard_id) in seen_shards:
                result.errors.append(f"{prefix} has duplicate shard_id {shard_id!r}")
            seen_shards.add(str(shard_id))
            expected_tasks.add(str(shard_id))
            if shard.get("paper_id") != paper_id:
                result.errors.append(f"{shard_prefix}.paper_id does not match its paper")
            owned = shard.get("owned_categories")
            if not isinstance(owned, list) or not all(_nonempty_string(item) for item in owned):
                result.errors.append(f"{shard_prefix}.owned_categories must be a string array")
                owned = []
            for category in owned:
                if category not in ownership:
                    result.errors.append(f"{shard_prefix} owns unknown category {category!r}")
                else:
                    ownership[str(category)].append(str(shard_id))
            owns_context = shard.get("owns_source_context")
            if not isinstance(owns_context, bool):
                result.errors.append(f"{shard_prefix}.owns_source_context must be boolean")
            elif owns_context:
                context_owners.append(str(shard_id))
            namespace = shard.get("claim_id_namespace")
            expected_namespace = f"{plan_id}/{paper_id}/{shard_id}"
            if namespace != expected_namespace:
                result.errors.append(f"{shard_prefix}.claim_id_namespace is not deterministic")
            expected_shard = _stable_id(
                "xshard",
                {
                    "plan_id": plan_id,
                    "paper_id": paper_id,
                    "owned_categories": owned,
                    "owns_source_context": owns_context,
                },
            )
            if shard_id != expected_shard:
                result.errors.append(f"{shard_prefix}.shard_id is not deterministic")
            for key in (
                "required_fields",
                "shared_identity_context_fields",
            ):
                if not isinstance(shard.get(key), list) or not all(
                    _nonempty_string(item) for item in shard.get(key, [])
                ):
                    result.errors.append(f"{shard_prefix}.{key} must be a string array")
            if not isinstance(shard.get("source_scope"), Mapping):
                result.errors.append(f"{shard_prefix}.source_scope must be an object")
            task = task_by_id.get(str(shard_id))
            if task is not None:
                expected_task = {
                    "task_id": shard_id,
                    "shard_id": shard_id,
                    "paper_id": paper_id,
                    "description": (
                        f"Extract {paper_id} categories "
                        f"{', '.join(owned) if owned else '[source_context only]'}"
                    ),
                    "prompt": _task_prompt(shard),
                    "expected_output": shard.get("output_path"),
                }
                if task != expected_task:
                    result.errors.append(f"{shard_prefix} task description is not deterministic")
        for category, owners in ownership.items():
            if len(owners) != 1:
                result.errors.append(f"{prefix} category {category!r} must be owned exactly once")
        if len(context_owners) != 1:
            result.errors.append(f"{prefix} must have exactly one source_context owner")
        recorded_ownership = paper.get("category_ownership")
        expected_ownership = {
            category: owners[0] for category, owners in ownership.items() if len(owners) == 1
        }
        if recorded_ownership != expected_ownership:
            result.errors.append(f"{prefix}.category_ownership is inconsistent")
        if len(context_owners) == 1 and paper.get("source_context_shard_id") != context_owners[0]:
            result.errors.append(f"{prefix}.source_context_shard_id is inconsistent")
    tasks = value.get("tasks")
    if not isinstance(tasks, list):
        result.errors.append("tasks must be an array")
    else:
        task_ids = {
            str(task.get("task_id"))
            for task in tasks
            if isinstance(task, Mapping) and _nonempty_string(task.get("task_id"))
        }
        if task_ids != expected_tasks or len(tasks) != len(expected_tasks):
            result.errors.append("tasks must contain exactly one task per shard")
        for index, task in enumerate(tasks):
            if not isinstance(task, Mapping):
                result.errors.append(f"tasks[{index}] must be an object")
            elif not _nonempty_string(task.get("prompt")):
                result.errors.append(f"tasks[{index}].prompt must be non-empty")
    history = value.get("revision_history")
    if not isinstance(history, list) or not history:
        result.errors.append("revision_history must be a non-empty array")
    elif not any(
        isinstance(entry, Mapping) and entry.get("revision") == revision for entry in history
    ):
        result.errors.append("revision_history must include the current revision")
    return result


def _load_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ExtractionPlanningError(f"cannot read {label}: {exc}") from exc
    if not isinstance(value, dict):
        raise ExtractionPlanningError(f"{label} must contain a JSON object")
    return value


def write_extraction_plan(
    project: AnalysisProject,
    inventory_path: Path | str,
    *,
    thresholds: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build and atomically persist a plan bound to approved Question artifacts."""
    root = Path(project.topic_dir)
    if (
        (root / SCHEMA_OPTIMIZATION_FILENAME).is_file()
        and not schema_lock_is_current(project)
    ):
        raise ExtractionPlanningError(
            "scaled extraction requires the current optimized schema to be explicitly locked"
        )
    collection_path = root / COLLECTION_SPEC_FILENAME
    outputs_path = root / PLANNED_OUTPUTS_FILENAME
    collection = _load_object(collection_path, COLLECTION_SPEC_FILENAME)
    outputs = _load_object(outputs_path, PLANNED_OUTPUTS_FILENAME)
    inventory = _load_object(
        Path(inventory_path).expanduser().resolve(),
        "paper inventory",
    )
    approval = project.approvals.get("question")
    if approval is None:
        raise ExtractionPlanningError(
            "extraction planning requires an approved Question checkpoint"
        )
    collection_hash = sha256_file(collection_path)
    outputs_hash = sha256_file(outputs_path)
    for name, digest in (
        (COLLECTION_SPEC_FILENAME, collection_hash),
        (PLANNED_OUTPUTS_FILENAME, outputs_hash),
    ):
        if approval.artifact_hashes.get(name) != digest:
            raise ExtractionPlanningError(f"{name} is not the current approved Question artifact")
    plan_path = root / EXTRACTION_PLAN_FILENAME
    previous: Mapping[str, Any] | None = None
    if plan_path.is_file():
        previous = _load_object(plan_path, EXTRACTION_PLAN_FILENAME)
    plan = build_extraction_plan(
        collection,
        outputs,
        inventory,
        collection_spec_sha256=collection_hash,
        planned_outputs_sha256=outputs_hash,
        thresholds=thresholds,
        project_id=project.project_id,
        project_revision=project.revision,
        previous_plan=previous,
    )
    atomic_write_json(plan_path, plan)
    return plan


def load_shard_outputs(directory: Path | str) -> list[dict[str, Any]]:
    """Load every JSON shard result from one private output directory."""
    root = Path(directory).expanduser().resolve()
    if not root.is_dir():
        raise ExtractionPlanningError(f"shard output directory not found: {root}")
    outputs: list[dict[str, Any]] = []
    for path in sorted(root.glob("*.json"), key=lambda item: item.name.casefold()):
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ExtractionPlanningError(f"cannot read shard output {path}: {exc}") from exc
        if not isinstance(value, dict):
            raise ExtractionPlanningError(f"shard output {path} must contain an object")
        outputs.append(value)
    return outputs


def _source_cards(output: Mapping[str, Any]) -> object:
    return output.get("source_cards", output.get("cards"))


def _stable_card_id(card: Mapping[str, Any]) -> str | None:
    for name in ("stable_id", "card_id", "claim_id", "finding_id"):
        value = card.get(name)
        if _nonempty_string(value):
            return str(value)
    return None


def _card_category(card: Mapping[str, Any]) -> str | None:
    if card.get("card_type") == "source_context":
        return "source_context"
    for container in (card, card.get("raw_payload"), card.get("data")):
        if not isinstance(container, Mapping):
            continue
        for name in ("owned_category", "category", "collection_category"):
            value = container.get(name)
            if _nonempty_string(value):
                return str(value)
    return None


def _conflict(code: str, message: str, **details: Any) -> dict[str, Any]:
    return {"code": code, "message": message, **details}


def merge_extraction_shards(
    plan: Mapping[str, Any],
    shard_outputs: Sequence[Mapping[str, Any]],
    *,
    collection_spec_sha256: str | None = None,
    planned_outputs_sha256: str | None = None,
    project_id: str | None = None,
    project_revision: int | None = None,
) -> dict[str, Any]:
    """Deterministically validate and merge all required extraction shards."""
    plan_validation = validate_extraction_plan(
        plan,
        collection_spec_sha256=collection_spec_sha256,
        planned_outputs_sha256=planned_outputs_sha256,
        project_id=project_id,
        project_revision=project_revision,
    )
    conflicts = [_conflict("invalid_or_stale_plan", error) for error in plan_validation.errors]
    expected: dict[str, Mapping[str, Any]] = {}
    paper_categories: dict[str, set[str]] = {}
    for paper in plan.get("papers", []):
        if not isinstance(paper, Mapping):
            continue
        paper_id = str(paper.get("paper_id", ""))
        paper_categories[paper_id] = set(plan.get("approved_categories", []))
        for shard in paper.get("shards", []):
            if isinstance(shard, Mapping) and _nonempty_string(shard.get("shard_id")):
                expected[str(shard["shard_id"])] = shard

    by_shard: dict[str, Mapping[str, Any]] = {}
    for index, output in enumerate(shard_outputs):
        if not isinstance(output, Mapping):
            conflicts.append(
                _conflict("invalid_shard_output", f"shard output {index} is not an object")
            )
            continue
        shard_id = output.get("shard_id")
        if not _nonempty_string(shard_id):
            conflicts.append(_conflict("missing_shard_id", f"shard output {index} has no shard_id"))
            continue
        shard_id = str(shard_id)
        if shard_id in by_shard:
            conflicts.append(
                _conflict(
                    "duplicate_shard_output",
                    f"multiple outputs were supplied for shard {shard_id}",
                    shard_id=shard_id,
                )
            )
            continue
        if shard_id not in expected:
            conflicts.append(
                _conflict(
                    "unexpected_shard",
                    f"output references unplanned shard {shard_id}",
                    shard_id=shard_id,
                )
            )
        by_shard[shard_id] = output

    missing_shards = sorted(set(expected) - set(by_shard))
    for shard_id in missing_shards:
        conflicts.append(
            _conflict(
                "missing_shard",
                f"required shard {shard_id} has no saved output",
                shard_id=shard_id,
            )
        )

    cards_by_id: dict[str, dict[str, Any]] = {}
    card_bytes: dict[str, bytes] = {}
    duplicate_count = 0
    input_card_count = 0
    successful_shards: list[str] = []
    completed_by_paper: dict[str, set[str]] = {paper_id: set() for paper_id in paper_categories}
    shard_card_counts: dict[str, int] = {}
    for shard_id in sorted(set(expected) & set(by_shard)):
        shard = expected[shard_id]
        output = by_shard[shard_id]
        paper_id = str(shard["paper_id"])
        namespace = str(shard["claim_id_namespace"])
        status = output.get("status")
        if status not in TERMINAL_SUCCESS_STATUSES or output.get("saved") is False:
            conflicts.append(
                _conflict(
                    "shard_not_saved",
                    f"shard {shard_id} is not in a terminal successful/saved state",
                    shard_id=shard_id,
                    status=status,
                )
            )
            continue
        successful_shards.append(shard_id)
        if output.get("schema_version") != EXTRACTION_SHARD_SCHEMA_VERSION:
            conflicts.append(
                _conflict(
                    "wrong_shard_schema",
                    f"shard {shard_id} schema_version is invalid",
                    shard_id=shard_id,
                )
            )
        if output.get("plan_id") != plan.get("plan_id"):
            conflicts.append(
                _conflict(
                    "wrong_plan",
                    f"shard {shard_id} belongs to a different plan",
                    shard_id=shard_id,
                )
            )
        if output.get("plan_revision") != plan.get("revision"):
            conflicts.append(
                _conflict(
                    "wrong_plan_revision",
                    f"shard {shard_id} belongs to a different plan revision",
                    shard_id=shard_id,
                )
            )
        if output.get("paper_id") != paper_id:
            conflicts.append(
                _conflict(
                    "wrong_paper",
                    f"shard {shard_id} output paper does not match {paper_id}",
                    shard_id=shard_id,
                )
            )
        if output.get("claim_id_namespace") != namespace:
            conflicts.append(
                _conflict(
                    "wrong_namespace",
                    f"shard {shard_id} output namespace is invalid",
                    shard_id=shard_id,
                )
            )
        completed = output.get(
            "completed_categories",
            output.get("owned_categories"),
        )
        if not isinstance(completed, list) or set(completed) != set(shard["owned_categories"]):
            conflicts.append(
                _conflict(
                    "category_accounting_mismatch",
                    f"shard {shard_id} did not explicitly complete every owned category",
                    shard_id=shard_id,
                    expected=shard["owned_categories"],
                    actual=completed,
                )
            )
        else:
            completed_by_paper[paper_id].update(str(item) for item in completed)
        completed_context = output.get("completed_source_context")
        if shard["owns_source_context"] and completed_context is not True:
            conflicts.append(
                _conflict(
                    "source_context_not_completed",
                    f"source-context owner {shard_id} did not complete source_context",
                    shard_id=shard_id,
                )
            )
        if not shard["owns_source_context"] and completed_context is True:
            conflicts.append(
                _conflict(
                    "wrong_source_context_owner",
                    f"non-owner shard {shard_id} claimed source_context completion",
                    shard_id=shard_id,
                )
            )
        cards = _source_cards(output)
        if not isinstance(cards, list) or not all(isinstance(card, Mapping) for card in cards):
            conflicts.append(
                _conflict(
                    "invalid_source_cards",
                    f"shard {shard_id} source_cards must be an array of objects",
                    shard_id=shard_id,
                )
            )
            continue
        shard_card_counts[shard_id] = len(cards)
        saw_source_context = False
        for card_index, card_value in enumerate(cards):
            card = dict(card_value)
            input_card_count += 1
            card_id = _stable_card_id(card)
            if card_id is None:
                conflicts.append(
                    _conflict(
                        "missing_stable_id",
                        f"shard {shard_id} card {card_index} has no stable ID",
                        shard_id=shard_id,
                    )
                )
                continue
            if card.get("paper_id") != paper_id:
                conflicts.append(
                    _conflict(
                        "wrong_card_paper",
                        f"card {card_id} has the wrong paper_id",
                        shard_id=shard_id,
                        stable_id=card_id,
                    )
                )
            if card.get("claim_id_namespace") != namespace or not card_id.startswith(
                f"{namespace}:"
            ):
                conflicts.append(
                    _conflict(
                        "wrong_card_namespace",
                        f"card {card_id} is outside shard {shard_id}'s namespace",
                        shard_id=shard_id,
                        stable_id=card_id,
                    )
                )
            category = _card_category(card)
            if category == "source_context":
                saw_source_context = True
                if not shard["owns_source_context"]:
                    conflicts.append(
                        _conflict(
                            "wrong_source_context_owner",
                            f"non-owner shard {shard_id} emitted source_context",
                            shard_id=shard_id,
                            stable_id=card_id,
                        )
                    )
            elif category not in shard["owned_categories"]:
                conflicts.append(
                    _conflict(
                        "wrong_category_owner",
                        f"shard {shard_id} emitted unowned category {category!r}",
                        shard_id=shard_id,
                        stable_id=card_id,
                        category=category,
                    )
                )
            encoded = _canonical_json(card)
            if card_id in cards_by_id:
                if card_bytes[card_id] == encoded:
                    duplicate_count += 1
                else:
                    conflicts.append(
                        _conflict(
                            "stable_id_conflict",
                            f"stable ID {card_id} has different payload or source data",
                            stable_id=card_id,
                            first_shard=cards_by_id[card_id].get("_merged_from_shard"),
                            second_shard=shard_id,
                        )
                    )
                continue
            card["_merged_from_shard"] = shard_id
            cards_by_id[card_id] = card
            card_bytes[card_id] = encoded
        if shard["owns_source_context"] and not saw_source_context:
            conflicts.append(
                _conflict(
                    "source_context_missing",
                    f"source-context owner {shard_id} emitted no source_context card",
                    shard_id=shard_id,
                )
            )

    category_coverage = {
        paper_id: {
            "expected": sorted(expected_categories, key=str.casefold),
            "completed": sorted(completed_by_paper[paper_id], key=str.casefold),
            "missing": sorted(
                expected_categories - completed_by_paper[paper_id],
                key=str.casefold,
            ),
        }
        for paper_id, expected_categories in sorted(paper_categories.items())
    }
    for paper_id, coverage in category_coverage.items():
        if coverage["missing"]:
            conflicts.append(
                _conflict(
                    "missing_category_coverage",
                    f"paper {paper_id} has uncompleted categories",
                    paper_id=paper_id,
                    categories=coverage["missing"],
                )
            )
    blocked = bool(conflicts)
    merged_cards = []
    if not blocked:
        for stable_id in sorted(cards_by_id, key=str.casefold):
            card = dict(cards_by_id[stable_id])
            card.pop("_merged_from_shard", None)
            merged_cards.append(card)
    return {
        "schema_version": EXTRACTION_MERGE_SCHEMA_VERSION,
        "status": "blocked" if blocked else "success",
        "plan_id": plan.get("plan_id"),
        "plan_revision": plan.get("revision"),
        "plan_sha256": plan.get("plan_sha256"),
        "source_cards": merged_cards,
        "coverage": {
            "required_shards": len(expected),
            "successful_shards": sorted(successful_shards),
            "missing_shards": missing_shards,
            "expected_categories_by_paper": category_coverage,
            "shard_card_counts": dict(sorted(shard_card_counts.items())),
        },
        "accounting": {
            "input_card_count": input_card_count,
            "merged_card_count": len(merged_cards),
            "exact_duplicates_removed": duplicate_count,
            "conflict_count": len(conflicts),
        },
        "conflicts": conflicts,
    }


def write_extraction_merge(
    project: AnalysisProject,
    shard_directory: Path | str,
) -> dict[str, Any]:
    """Validate current bindings, merge shard files, and atomically write the result."""
    root = Path(project.topic_dir)
    if (
        (root / SCHEMA_OPTIMIZATION_FILENAME).is_file()
        and not schema_lock_is_current(project)
    ):
        raise ExtractionPlanningError(
            "scaled extraction merge requires the current optimized schema lock"
        )
    plan = _load_object(root / EXTRACTION_PLAN_FILENAME, EXTRACTION_PLAN_FILENAME)
    outputs = load_shard_outputs(shard_directory)
    result = merge_extraction_shards(
        plan,
        outputs,
        collection_spec_sha256=sha256_file(root / COLLECTION_SPEC_FILENAME),
        planned_outputs_sha256=sha256_file(root / PLANNED_OUTPUTS_FILENAME),
        project_id=project.project_id,
        project_revision=project.revision,
    )
    atomic_write_json(root / EXTRACTION_MERGE_FILENAME, result)
    return result
