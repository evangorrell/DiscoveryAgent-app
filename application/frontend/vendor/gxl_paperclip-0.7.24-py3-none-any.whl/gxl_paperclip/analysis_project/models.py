"""Persistent state models for guided analysis projects."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

SCHEMA_VERSION = 1
STAGES = ("question", "evidence", "results")


def utc_now() -> str:
    """Return an ISO-8601 UTC timestamp with a ``Z`` suffix."""
    return (
        datetime.now(timezone.utc)  # noqa: UP017 -- package supports Python 3.8
        .isoformat(timespec="seconds")
        .replace("+00:00", "Z")
    )


@dataclass
class RepositoryRef:
    """The optional paper-repository revision associated with a project."""

    name: str
    branch: str = "main"
    sha: str | None = None

    @classmethod
    def from_dict(cls, value: object) -> RepositoryRef:
        if not isinstance(value, dict):
            raise ValueError("'repo' must be an object")
        name = value.get("name")
        branch = value.get("branch", "main")
        sha = value.get("sha")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("'repo.name' must be a non-empty string")
        if not isinstance(branch, str) or not branch.strip():
            raise ValueError("'repo.branch' must be a non-empty string")
        if sha is not None and not isinstance(sha, str):
            raise ValueError("'repo.sha' must be a string or null")
        return cls(name=name, branch=branch, sha=sha)


@dataclass
class Approval:
    """A human approval or stage freeze, tied to exact artifact bytes."""

    approved_at: str
    revision: int
    artifact_hashes: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, value: object, name: str) -> Approval:
        if not isinstance(value, dict):
            raise ValueError(f"'approvals.{name}' must be an object")
        approved_at = value.get("approved_at")
        revision = value.get("revision")
        hashes = value.get("artifact_hashes")
        if not isinstance(approved_at, str) or not approved_at:
            raise ValueError(f"'approvals.{name}.approved_at' must be a timestamp")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            raise ValueError(f"'approvals.{name}.revision' must be a positive integer")
        if not isinstance(hashes, dict) or not all(
            isinstance(key, str) and isinstance(digest, str) for key, digest in hashes.items()
        ):
            raise ValueError(f"'approvals.{name}.artifact_hashes' must map names to hashes")
        return cls(
            approved_at=approved_at,
            revision=revision,
            artifact_hashes=dict(hashes),
        )


@dataclass
class AnalysisProject:
    """Serializable state for one local guided meta-analysis."""

    project_id: str
    slug: str
    topic_dir: str
    question: str
    repo: RepositoryRef
    stage: str = "question"
    status: str = "awaiting_user"
    next_action: str = (
        "Ask the user; after explicit approval Claude runs "
        "python3 guided_analysis.py approve question"
    )
    schema_version: int = SCHEMA_VERSION
    revision: int = 1
    parent_id: str | None = None
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)
    approvals: dict[str, Approval] = field(default_factory=dict)
    artifact_hashes: dict[str, str] = field(default_factory=dict)
    legacy_import: bool = False
    approved_collection_schema_hash: str | None = None
    approved_pilot_plan_hash: str | None = None
    schema_registry_sha256: str | None = None
    extraction_schema_sha256: str | None = None
    schema_lock_sha256: str | None = None
    scaled_extraction_ready: bool = False
    results_revision: int = 1
    results_binding: dict[str, Any] = field(default_factory=dict)
    publications: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: object) -> AnalysisProject:
        if not isinstance(value, dict):
            raise ValueError("state root must be a JSON object")

        required_strings = ("project_id", "slug", "topic_dir", "question", "status")
        for key in required_strings:
            if not isinstance(value.get(key), str) or not value[key].strip():
                raise ValueError(f"'{key}' must be a non-empty string")

        stage = value.get("stage")
        if stage not in STAGES:
            raise ValueError(f"'stage' must be one of: {', '.join(STAGES)}")

        schema_version = value.get("schema_version")
        if schema_version != SCHEMA_VERSION:
            raise ValueError(
                f"unsupported schema_version {schema_version!r}; expected {SCHEMA_VERSION}"
            )

        revision = value.get("revision")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            raise ValueError("'revision' must be a positive integer")

        next_action = value.get("next_action")
        if not isinstance(next_action, str):
            raise ValueError("'next_action' must be a string")

        created_at = value.get("created_at")
        updated_at = value.get("updated_at")
        if not isinstance(created_at, str) or not created_at:
            raise ValueError("'created_at' must be a timestamp")
        if not isinstance(updated_at, str) or not updated_at:
            raise ValueError("'updated_at' must be a timestamp")

        parent_id = value.get("parent_id")
        if parent_id is not None and not isinstance(parent_id, str):
            raise ValueError("'parent_id' must be a string or null")

        raw_approvals = value.get("approvals", {})
        if not isinstance(raw_approvals, dict):
            raise ValueError("'approvals' must be an object")
        unknown_approvals = sorted(set(raw_approvals) - set(STAGES))
        if unknown_approvals:
            raise ValueError(
                f"unknown approval stage(s): {', '.join(str(name) for name in unknown_approvals)}"
            )
        approvals = {
            name: Approval.from_dict(approval, name) for name, approval in raw_approvals.items()
        }

        hashes = value.get("artifact_hashes", {})
        if not isinstance(hashes, dict) or not all(
            isinstance(key, str) and isinstance(digest, str) for key, digest in hashes.items()
        ):
            raise ValueError("'artifact_hashes' must map names to hashes")
        results_revision = value.get("results_revision", 1)
        if (
            not isinstance(results_revision, int)
            or isinstance(results_revision, bool)
            or results_revision < 1
        ):
            raise ValueError("'results_revision' must be a positive integer")
        results_binding = value.get("results_binding", {})
        if not isinstance(results_binding, dict):
            raise ValueError("'results_binding' must be an object")
        publications = value.get("publications", [])
        if not isinstance(publications, list) or not all(
            isinstance(publication, dict) for publication in publications
        ):
            raise ValueError("'publications' must be an array of objects")
        legacy_import = value.get("legacy_import", True)
        if not isinstance(legacy_import, bool):
            raise ValueError("'legacy_import' must be a boolean")
        approved_collection_schema_hash = value.get("approved_collection_schema_hash")
        if approved_collection_schema_hash is not None and not isinstance(
            approved_collection_schema_hash,
            str,
        ):
            raise ValueError("'approved_collection_schema_hash' must be a string or null")
        approved_pilot_plan_hash = value.get("approved_pilot_plan_hash")
        if approved_pilot_plan_hash is not None and not isinstance(
            approved_pilot_plan_hash,
            str,
        ):
            raise ValueError("'approved_pilot_plan_hash' must be a string or null")
        optional_schema_hashes: dict[str, str | None] = {}
        for name in (
            "schema_registry_sha256",
            "extraction_schema_sha256",
            "schema_lock_sha256",
        ):
            digest = value.get(name)
            if digest is not None and not isinstance(digest, str):
                raise ValueError(f"'{name}' must be a string or null")
            optional_schema_hashes[name] = digest
        scaled_extraction_ready = value.get("scaled_extraction_ready", False)
        if not isinstance(scaled_extraction_ready, bool):
            raise ValueError("'scaled_extraction_ready' must be a boolean")
        if scaled_extraction_ready and any(
            optional_schema_hashes[name] is None for name in optional_schema_hashes
        ):
            raise ValueError(
                "'scaled_extraction_ready' requires registry, schema, and lock hashes"
            )
        if stage in ("evidence", "results") and "question" not in approvals:
            raise ValueError(f"stage {stage!r} requires a question approval")
        if stage == "results" and "evidence" not in approvals:
            raise ValueError("stage 'results' requires an evidence approval")
        for approval_name, approval in approvals.items():
            for artifact, digest in approval.artifact_hashes.items():
                if hashes.get(artifact) != digest:
                    raise ValueError(
                        f"'artifact_hashes.{artifact}' does not match 'approvals.{approval_name}'"
                    )

        return cls(
            project_id=value["project_id"],
            slug=value["slug"],
            topic_dir=value["topic_dir"],
            question=value["question"],
            repo=RepositoryRef.from_dict(value.get("repo")),
            stage=stage,
            status=value["status"],
            next_action=next_action,
            schema_version=schema_version,
            revision=revision,
            parent_id=parent_id,
            created_at=created_at,
            updated_at=updated_at,
            approvals=approvals,
            artifact_hashes=dict(hashes),
            legacy_import=legacy_import,
            approved_collection_schema_hash=approved_collection_schema_hash,
            approved_pilot_plan_hash=approved_pilot_plan_hash,
            schema_registry_sha256=optional_schema_hashes["schema_registry_sha256"],
            extraction_schema_sha256=optional_schema_hashes["extraction_schema_sha256"],
            schema_lock_sha256=optional_schema_hashes["schema_lock_sha256"],
            scaled_extraction_ready=scaled_extraction_ready,
            results_revision=results_revision,
            results_binding=dict(results_binding),
            publications=[dict(publication) for publication in publications],
        )

    def summary(self) -> dict[str, Any]:
        """Return the stable, user-facing state summary."""
        return {
            "schema_version": self.schema_version,
            "project_id": self.project_id,
            "parent_id": self.parent_id,
            "slug": self.slug,
            "topic_dir": self.topic_dir,
            "question": self.question,
            "stage": self.stage,
            "status": self.status,
            "next_action": self.next_action,
            "revision": self.revision,
            "results_revision": self.results_revision,
            "results_binding": self.results_binding,
            "publications": self.publications,
            "approvals": sorted(self.approvals),
            "artifact_hashes": dict(sorted(self.artifact_hashes.items())),
            "legacy_import": self.legacy_import,
            "approved_collection_schema_hash": self.approved_collection_schema_hash,
            "approved_pilot_plan_hash": self.approved_pilot_plan_hash,
            "schema_registry_sha256": self.schema_registry_sha256,
            "extraction_schema_sha256": self.extraction_schema_sha256,
            "schema_lock_sha256": self.schema_lock_sha256,
            "scaled_extraction_ready": self.scaled_extraction_ready,
            "repo": asdict(self.repo),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
