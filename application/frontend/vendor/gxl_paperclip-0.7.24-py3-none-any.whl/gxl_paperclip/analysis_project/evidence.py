"""Deterministic evidence-stage review construction and source validation."""

from __future__ import annotations

import json
import os
import uuid
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

from gxl_paperclip.meta_analysis.cards import CARD_TYPES, normalize_finding_card
from gxl_paperclip.meta_analysis.export_verified import (
    normalize_verified_findings,
    validate_verified_findings,
)
from gxl_paperclip.meta_analysis.precision import (
    PrecisionDerivationError,
    derive_precision,
    has_usable_precision,
)

from .contracts import (
    COLLECTION_SPEC_FILENAME,
    EVIDENCE_PROPOSAL_FILENAME,
    HARMONIZATION_MAP_FILENAME,
    HARMONIZATION_QUEUE_FILENAME,
    PLANNED_OUTPUTS_FILENAME,
    collection_schema_hash,
    unresolved_material_mappings,
    validate_collection_spec,
    validate_evidence_proposal,
    validate_harmonization_map,
    validate_planned_outputs,
)
from .readiness import build_output_readiness
from .store import sha256_file

EVIDENCE_REVIEW_SCHEMA_VERSION = 1
EVIDENCE_REVIEW_FILENAME = "evidence_review.json"
LEGACY_REQUIRED_EVIDENCE_SOURCES = (
    "search_log.json",
    "effects.json",
    "study_characteristics.json",
    "quality_assessments.json",
)
GUIDED_REQUIRED_EVIDENCE_SOURCES = (
    "search_log.json",
    "verified_findings.json",
    COLLECTION_SPEC_FILENAME,
    PLANNED_OUTPUTS_FILENAME,
    HARMONIZATION_MAP_FILENAME,
)
# Backwards-compatible public name for the legacy compiler path.
REQUIRED_EVIDENCE_SOURCES = LEGACY_REQUIRED_EVIDENCE_SOURCES
OPTIONAL_PROTOCOL_SOURCE = "protocol.json"
DEFAULT_LANDMARK_SOURCE = "landmark_list.json"

# Conservative feasibility thresholds, not clinical decision thresholds.
MIN_PAIRWISE_INDEPENDENT_UNITS = 2
MIN_NETWORK_TREATMENTS = 3
MIN_NETWORK_INDEPENDENT_COMPARISONS = 3
MIN_META_REGRESSION_UNITS = 10
MIN_META_REGRESSION_UNITS_PER_COVARIATE = 10
LOW_MARGINAL_YIELD_THRESHOLD = 0.05

THRESHOLDS = {
    "pairwise_min_independent_units_per_stratum": {
        "value": MIN_PAIRWISE_INDEPENDENT_UNITS,
        "reason": "At least two independent units are required to combine effects.",
    },
    "network_min_treatments": {
        "value": MIN_NETWORK_TREATMENTS,
        "reason": "A network requires at least three distinct treatment nodes.",
    },
    "network_min_independent_comparisons": {
        "value": MIN_NETWORK_INDEPENDENT_COMPARISONS,
        "reason": "Three independent direct comparisons is the minimum structural screen.",
    },
    "meta_regression_min_independent_units": {
        "value": MIN_META_REGRESSION_UNITS,
        "reason": "Ten units is an explicit conservative feasibility floor.",
    },
    "meta_regression_min_units_per_covariate": {
        "value": MIN_META_REGRESSION_UNITS_PER_COVARIATE,
        "reason": "The screen requires ten independent units per requested covariate.",
    },
    "low_marginal_yield_rate": {
        "value": LOW_MARGINAL_YIELD_THRESHOLD,
        "reason": "A final-round inclusion yield at or below 5% is labelled low, not saturated.",
    },
}

_ANALYSIS_ALIASES = {
    "pairwise": "pairwise",
    "pairwise_meta_analysis": "pairwise",
    "pairwise meta-analysis": "pairwise",
    "network": "network",
    "network_meta_analysis": "network",
    "network meta-analysis": "network",
    "nma": "network",
    "meta_regression": "meta_regression",
    "meta-regression": "meta_regression",
    "meta regression": "meta_regression",
}


def _json_value(path: Path) -> object:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"{path.name} is corrupt JSON: {exc.msg} (line {exc.lineno}, column {exc.colno})"
        ) from exc
    except OSError as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc


def _object(value: object, name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{name} must contain a JSON object")
    return value


def _rows(value: object, name: str) -> list[dict[str, Any]]:
    if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
        raise ValueError(f"{name} must contain a JSON array of objects")
    return list(value)


def _label(value: object) -> str:
    if value is None:
        return "unspecified"
    if isinstance(value, str):
        normalized = value.strip()
        return normalized or "unspecified"
    return str(value)


def _sorted_counts(values: Iterable[object]) -> dict[str, int]:
    counts = Counter(_label(value) for value in values)
    return {key: counts[key] for key in sorted(counts, key=lambda item: item.casefold())}


def _valid_ci(effect: Mapping[str, Any]) -> bool:
    lower, upper = effect.get("ci_lower"), effect.get("ci_upper")
    return (
        isinstance(lower, (int, float))
        and not isinstance(lower, bool)
        and isinstance(upper, (int, float))
        and not isinstance(upper, bool)
        and float(lower) < float(upper)
    )


def _valid_se(effect: Mapping[str, Any]) -> bool:
    se = effect.get("se")
    return isinstance(se, (int, float)) and not isinstance(se, bool) and float(se) > 0


def _is_derived(effect: Mapping[str, Any]) -> bool:
    source = str(effect.get("precision_source") or "").strip().lower()
    return (
        effect.get("variance_estimated") is True
        or "derived" in source
        or isinstance(effect.get("derived_interval"), dict)
    )


def _source_timestamp(
    protocol: Mapping[str, Any] | None,
    search_log: Mapping[str, Any],
) -> str:
    """Choose a stable timestamp already present in source content."""
    for source in (search_log, protocol or {}):
        for key in ("generated_at", "updated_at", "search_date", "created_at"):
            value = source.get(key)
            if not isinstance(value, str) or not value.strip():
                continue
            timestamp = value.strip()
            if len(timestamp) == 10 and timestamp[4] == "-" and timestamp[7] == "-":
                return f"{timestamp}T00:00:00Z"
            return timestamp
    # The artifact remains byte-for-byte reproducible when sources omit a date.
    return "1970-01-01T00:00:00Z"


def _characteristic_lookup(
    characteristics: Sequence[Mapping[str, Any]],
) -> dict[str, Mapping[str, Any]]:
    lookup: dict[str, Mapping[str, Any]] = {}
    for row in characteristics:
        for key in ("paperclip_doc_id", "study_id", "independent_unit_id"):
            value = row.get(key)
            if isinstance(value, str) and value.strip():
                lookup[value.strip()] = row
    return lookup


def _linked_characteristic(
    effect: Mapping[str, Any],
    lookup: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    for key in ("paperclip_doc_id", "study_id", "independent_unit_id"):
        value = effect.get(key)
        if isinstance(value, str) and value.strip() in lookup:
            return lookup[value.strip()]
    return {}


def _effect_dimension(
    effect: Mapping[str, Any],
    linked: Mapping[str, Any],
    key: str,
) -> object:
    value = effect.get(key)
    return value if value not in (None, "") else linked.get(key)


def _requested_analyses(protocol: Mapping[str, Any] | None) -> dict[str, bool]:
    requested = {"pairwise": False, "network": False, "meta_regression": False}
    if not protocol:
        requested["pairwise"] = True
        return requested

    containers: list[object] = [
        protocol.get("requested_analyses"),
        protocol.get("analysis_types"),
        protocol.get("analysis_plan"),
        protocol.get("synthesis_plan"),
    ]
    saw_explicit = False
    for container in containers:
        if isinstance(container, str):
            container = [container]
        if isinstance(container, Sequence) and not isinstance(container, (str, bytes, bytearray)):
            for item in container:
                if not isinstance(item, str):
                    continue
                analysis = _ANALYSIS_ALIASES.get(item.strip().lower())
                if analysis:
                    requested[analysis] = True
                    saw_explicit = True
        elif isinstance(container, Mapping):
            for key, value in container.items():
                analysis = _ANALYSIS_ALIASES.get(str(key).strip().lower())
                if analysis and value not in (False, None, "", [], {}):
                    requested[analysis] = True
                    saw_explicit = True
    for key, analysis in (
        ("pairwise", "pairwise"),
        ("network", "network"),
        ("meta_regression", "meta_regression"),
    ):
        if key in protocol:
            saw_explicit = True
            requested[analysis] = protocol[key] not in (False, None, "", [], {})
    if not saw_explicit:
        requested["pairwise"] = True
    return requested


def _meta_regression_covariates(protocol: Mapping[str, Any] | None) -> list[str]:
    if not protocol:
        return []
    candidates: list[object] = [
        protocol.get("meta_regression_covariates"),
        protocol.get("moderators"),
    ]
    plan = protocol.get("analysis_plan")
    if isinstance(plan, Mapping):
        meta = plan.get("meta_regression")
        if isinstance(meta, Mapping):
            candidates.extend((meta.get("covariates"), meta.get("moderators")))
    values: list[str] = []
    for candidate in candidates:
        if isinstance(candidate, str):
            candidate = [candidate]
        if isinstance(candidate, Sequence) and not isinstance(candidate, (str, bytes, bytearray)):
            for value in candidate:
                if isinstance(value, str) and value.strip() and value.strip() not in values:
                    values.append(value.strip())
    return sorted(values, key=str.casefold)


def _landmark_rows(value: object | None) -> list[object]:
    if value is None:
        return []
    if isinstance(value, Mapping):
        for key in ("landmarks", "studies", "items"):
            if key in value:
                value = value[key]
                break
    if not isinstance(value, list):
        raise ValueError("landmark list must be an array or an object containing an array")
    return value


def _landmark_identifier(value: object) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, Mapping):
        for key in ("paperclip_doc_id", "doc_id", "study_id", "id", "title"):
            item = value.get(key)
            if isinstance(item, str) and item.strip():
                return item.strip()
    raise ValueError("every landmark must be a string or have an id/title field")


def _landmark_coverage(
    landmarks: object | None,
    effects: Sequence[Mapping[str, Any]],
    characteristics: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    requested = sorted(
        {_landmark_identifier(item) for item in _landmark_rows(landmarks)},
        key=str.casefold,
    )
    evidence_ids: set[str] = set()
    for row in [*effects, *characteristics]:
        for key in ("paperclip_doc_id", "doc_id", "study_id", "id", "title"):
            value = row.get(key)
            if isinstance(value, str) and value.strip():
                evidence_ids.add(value.strip().casefold())
    matched = [item for item in requested if item.casefold() in evidence_ids]
    missing = [item for item in requested if item.casefold() not in evidence_ids]
    return {
        "provided": len(requested),
        "matched": len(matched),
        "missing": len(missing),
        "matched_landmarks": matched,
        "missing_landmarks": missing,
        "matching_rule": "Exact case-insensitive match on explicit document/study id or title.",
    }


def _search_flow(search_log: Mapping[str, Any]) -> dict[str, Any]:
    queries = search_log.get("queries")
    query_rows = (
        [row for row in queries if isinstance(row, Mapping)] if isinstance(queries, list) else []
    )
    rounds = search_log.get("saturation_rounds")
    round_rows = (
        [row for row in rounds if isinstance(row, Mapping)] if isinstance(rounds, list) else []
    )
    evidence_flow = search_log.get("evidence_flow")
    return {
        "evidence_flow": {
            str(key): value
            for key, value in sorted(
                evidence_flow.items() if isinstance(evidence_flow, Mapping) else []
            )
        },
        "query_count": len(query_rows),
        "sources": sorted(
            {str(row["source"]) for row in query_rows if row.get("source") not in (None, "")},
            key=str.casefold,
        ),
        "waves": sorted(
            {
                row["wave"]
                for row in query_rows
                if isinstance(row.get("wave"), (int, float))
                and not isinstance(row.get("wave"), bool)
            }
        ),
        "saturation_round_count": len(round_rows),
        "last_saturation_decision": (round_rows[-1].get("decision") if round_rows else None),
    }


def _first_number(row: Mapping[str, Any], keys: Sequence[str]) -> float | None:
    for key in keys:
        value = row.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return float(value)
    return None


def _marginal_yield(search_log: Mapping[str, Any]) -> dict[str, Any]:
    rounds = search_log.get("saturation_rounds")
    rows = [row for row in rounds if isinstance(row, Mapping)] if isinstance(rounds, list) else []
    if not rows:
        return {
            "status": "unknown",
            "rate": None,
            "new_included": None,
            "records_screened": None,
            "round": None,
            "reason": "No numeric saturation round was supplied.",
        }
    latest = rows[-1]
    included = _first_number(
        latest,
        (
            "new_included",
            "new_inclusions",
            "new_eligible_studies",
            "papers_included",
        ),
    )
    screened = _first_number(
        latest,
        ("records_screened", "new_records_screened", "records_found", "new_records"),
    )
    if included is None or screened is None or screened <= 0:
        return {
            "status": "unknown",
            "rate": None,
            "new_included": included,
            "records_screened": screened,
            "round": latest.get("round", len(rows)),
            "reason": "The final round lacks a positive denominator and inclusion numerator.",
        }
    rate = included / screened
    status = "low" if rate <= LOW_MARGINAL_YIELD_THRESHOLD else "continuing"
    return {
        "status": status,
        "rate": rate,
        "new_included": included,
        "records_screened": screened,
        "round": latest.get("round", len(rows)),
        "reason": (
            f"Final-round yield is {'at or below' if status == 'low' else 'above'} "
            f"the explicit {LOW_MARGINAL_YIELD_THRESHOLD:.0%} threshold; "
            "this does not by itself prove saturation."
        ),
    }


def _quality_summary(
    characteristics: Sequence[Mapping[str, Any]],
    assessments: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    study_ids = {
        _label(row.get("paperclip_doc_id") or row.get("study_id")) for row in characteristics
    }
    study_ids.discard("unspecified")
    assessed_ids = {
        _label(row.get("paperclip_doc_id") or row.get("study_id")) for row in assessments
    }
    assessed_ids.discard("unspecified")
    return {
        "assessment_rows": len(assessments),
        "studies_with_characteristics": len(study_ids),
        "studies_with_quality_assessment": len(assessed_ids),
        "studies_missing_quality_assessment": sorted(study_ids - assessed_ids, key=str.casefold),
        "tools": _sorted_counts(row.get("tool") for row in assessments),
        "overall_ratings": _sorted_counts(row.get("overall") for row in assessments),
        "interpretation": (
            "Counts reproduce supplied labels; no rating hierarchy or clinical "
            "quality judgment is inferred."
        ),
    }


def _arm_readiness(effects: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    arm_fields = {
        "arm_1_events",
        "arm_1_denominator",
        "arm_2_events",
        "arm_2_denominator",
        "arm_1_mean",
        "arm_1_sd",
        "arm_1_n",
        "arm_2_mean",
        "arm_2_sd",
        "arm_2_n",
        "change_score_sd",
        "change_score_correlation",
        "variance_inputs",
        "variance_method",
    }
    ready: list[str] = []
    incomplete: list[dict[str, str]] = []
    for index, effect in enumerate(effects):
        if not any(field in effect and effect.get(field) is not None for field in arm_fields):
            continue
        effect_id = _label(effect.get("effect_id") or f"row-{index + 1}")
        try:
            derive_precision(effect)
        except PrecisionDerivationError as exc:
            incomplete.append({"effect_id": effect_id, "reason": str(exc)})
        else:
            ready.append(effect_id)
    return {
        "candidate_effects": len(ready) + len(incomplete),
        "ready": len(ready),
        "incomplete_or_ambiguous": len(incomplete),
        "ready_effect_ids": sorted(ready, key=str.casefold),
        "incomplete_effects": sorted(incomplete, key=lambda item: item["effect_id"].casefold()),
        "rule": "Ready only when one supported method has every required explicit input.",
    }


def _status(reason: str, status: str, **details: Any) -> dict[str, Any]:
    return {"status": status, "reason": reason, **details}


def _readiness(
    *,
    protocol: Mapping[str, Any] | None,
    effects: Sequence[Mapping[str, Any]],
    characteristics_lookup: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    requested = _requested_analyses(protocol)
    covariates = _meta_regression_covariates(protocol)
    pairwise_strata: dict[tuple[str, str, str, str], set[str]] = defaultdict(set)
    all_strata: dict[tuple[str, str, str, str], set[str]] = defaultdict(set)
    network_nodes: set[str] = set()
    network_units: set[str] = set()
    network_edges: set[tuple[str, str]] = set()

    for effect in effects:
        if effect.get("analysis_role") != "primary":
            continue
        unit = effect.get("independent_unit_id")
        if not isinstance(unit, str) or not unit.strip():
            continue
        linked = _linked_characteristic(effect, characteristics_lookup)
        stratum = (
            _label(effect.get("outcome_group")),
            _label(effect.get("effect_measure")),
            _label(_effect_dimension(effect, linked, "population")),
            _label(effect.get("timepoint")),
        )
        all_strata[stratum].add(unit.strip())
        if effect.get("comparative_effect") is True and has_usable_precision(effect):
            pairwise_strata[stratum].add(unit.strip())
            intervention = _effect_dimension(effect, linked, "intervention")
            comparator = _effect_dimension(effect, linked, "comparator")
            if (
                isinstance(intervention, str)
                and intervention.strip()
                and isinstance(comparator, str)
                and comparator.strip()
                and intervention.strip().casefold() != comparator.strip().casefold()
            ):
                left, right = sorted((intervention.strip(), comparator.strip()), key=str.casefold)
                network_nodes.update((left, right))
                network_units.add(unit.strip())
                network_edges.add((left, right))

    max_pairwise = max((len(units) for units in pairwise_strata.values()), default=0)
    max_all = max((len(units) for units in all_strata.values()), default=0)
    if max_pairwise >= MIN_PAIRWISE_INDEPENDENT_UNITS:
        pairwise = _status(
            "At least one exact outcome/measure/population/timepoint stratum meets "
            "the independent-unit threshold with comparative effects and precision.",
            "ready",
            max_independent_units_in_eligible_stratum=max_pairwise,
        )
    elif max_pairwise == 1:
        pairwise = _status(
            "Only one independent comparative effect with usable precision is "
            "available in any exact stratum.",
            "limited",
            max_independent_units_in_eligible_stratum=max_pairwise,
        )
    elif max_all >= MIN_PAIRWISE_INDEPENDENT_UNITS:
        pairwise = _status(
            "Effects exist, but comparative_effect and usable precision do not "
            "identify two eligible independent units in one exact stratum.",
            "limited",
            max_independent_units_in_eligible_stratum=0,
        )
    else:
        pairwise = _status(
            "No exact stratum has two independent primary effects.",
            "blocked",
            max_independent_units_in_eligible_stratum=0,
        )

    connected = _network_connected(network_nodes, network_edges)
    if (
        len(network_nodes) >= MIN_NETWORK_TREATMENTS
        and len(network_units) >= MIN_NETWORK_INDEPENDENT_COMPARISONS
        and connected
    ):
        network = _status(
            "The labelled direct-comparison graph meets the explicit structural floor.",
            "ready",
            treatments=len(network_nodes),
            independent_comparisons=len(network_units),
            connected=True,
        )
    elif len(network_nodes) >= 2 and network_units:
        network = _status(
            "Some labelled direct comparisons exist, but the treatment-count, "
            "comparison-count, or connectivity floor is not met.",
            "limited",
            treatments=len(network_nodes),
            independent_comparisons=len(network_units),
            connected=connected,
        )
    else:
        network = _status(
            "No usable labelled treatment-comparator network can be constructed.",
            "blocked",
            treatments=len(network_nodes),
            independent_comparisons=len(network_units),
            connected=connected,
        )

    required_units = max(
        MIN_META_REGRESSION_UNITS,
        len(covariates) * MIN_META_REGRESSION_UNITS_PER_COVARIATE,
    )
    if not covariates:
        meta_regression = _status(
            "No explicit meta-regression covariates were supplied in protocol.json.",
            "blocked",
            covariates=[],
            independent_units=max_pairwise,
            required_units=required_units,
        )
    elif max_pairwise >= required_units:
        meta_regression = _status(
            "An eligible exact stratum meets the explicit units-per-covariate floor.",
            "ready",
            covariates=covariates,
            independent_units=max_pairwise,
            required_units=required_units,
        )
    elif max_pairwise >= MIN_PAIRWISE_INDEPENDENT_UNITS:
        meta_regression = _status(
            "Covariates are explicit, but independent units are below the "
            "conservative units-per-covariate floor.",
            "limited",
            covariates=covariates,
            independent_units=max_pairwise,
            required_units=required_units,
        )
    else:
        meta_regression = _status(
            "Too few eligible independent comparative effects are available.",
            "blocked",
            covariates=covariates,
            independent_units=max_pairwise,
            required_units=required_units,
        )

    analyses = {
        "pairwise": {"requested": requested["pairwise"], **pairwise},
        "network": {"requested": requested["network"], **network},
        "meta_regression": {
            "requested": requested["meta_regression"],
            **meta_regression,
        },
    }
    requested_statuses = [value["status"] for value in analyses.values() if value["requested"]]
    overall = (
        "blocked"
        if "blocked" in requested_statuses
        else "limited"
        if "limited" in requested_statuses
        else "ready"
    )
    return {"status": overall, **analyses}


def _network_connected(
    nodes: set[str],
    edges: set[tuple[str, str]],
) -> bool:
    if not nodes:
        return False
    adjacency: dict[str, set[str]] = {node: set() for node in nodes}
    for left, right in edges:
        adjacency[left].add(right)
        adjacency[right].add(left)
    visited: set[str] = set()
    pending = [next(iter(sorted(nodes, key=str.casefold)))]
    while pending:
        node = pending.pop()
        if node in visited:
            continue
        visited.add(node)
        pending.extend(sorted(adjacency[node] - visited, key=str.casefold))
    return visited == nodes


def _blockers(
    *,
    readiness: Mapping[str, Any],
    missing_precision: list[str],
    missing_units: list[str],
    landmarks: Mapping[str, Any],
) -> list[dict[str, str]]:
    blockers: list[dict[str, str]] = []
    for analysis in ("pairwise", "network", "meta_regression"):
        value = readiness[analysis]
        if value["requested"] and value["status"] != "ready":
            blockers.append(
                {
                    "code": f"{analysis}_{value['status']}",
                    "reason": str(value["reason"]),
                }
            )
    if missing_units:
        blockers.append(
            {
                "code": "missing_independent_unit_id",
                "reason": f"{len(missing_units)} effect(s) lack an independent unit id.",
            }
        )
    if missing_precision:
        blockers.append(
            {
                "code": "missing_precision",
                "reason": f"{len(missing_precision)} effect(s) lack a complete CI or SE.",
            }
        )
    if landmarks["missing"]:
        blockers.append(
            {
                "code": "missing_landmarks",
                "reason": f"{landmarks['missing']} user-provided landmark(s) are unmatched.",
            }
        )
    return blockers


def _next_action(
    blockers: Sequence[Mapping[str, str]],
    arm_readiness: Mapping[str, Any],
) -> str:
    codes = {item["code"] for item in blockers}
    if "missing_independent_unit_id" in codes:
        return "Assign explicit independent_unit_id values, then refresh the evidence review."
    if "missing_precision" in codes and arm_readiness["ready"]:
        return (
            "Apply the supported deterministic precision derivations to ready arm inputs, "
            "then refresh the evidence review."
        )
    if "missing_precision" in codes:
        return (
            "Extract a reported CI/SE or complete one supported arm-input formula; "
            "do not impute missing precision."
        )
    if "missing_landmarks" in codes:
        return "Resolve unmatched landmarks explicitly, then refresh the evidence review."
    if blockers:
        return "Resolve the first requested-analysis blocker, then refresh the evidence review."
    return (
        "Review the deterministic summary with the user, then Claude runs "
        "python3 guided_analysis.py analyze only after an explicit answer."
    )


def _verified_rows(value: object) -> list[Mapping[str, Any]]:
    if isinstance(value, Mapping):
        value = value.get("findings")
    if not isinstance(value, list):
        return []
    return [
        normalize_finding_card(row)
        for row in value
        if isinstance(row, Mapping)
    ]


def _card_inventory(verified_findings: object) -> dict[str, Any]:
    rows = _verified_rows(verified_findings)
    assessments = [row for row in rows if row.get("card_type") == "assessment"]
    return {
        "total": len(rows),
        "by_card_type": {
            card_type: sum(row.get("card_type") == card_type for row in rows)
            for card_type in CARD_TYPES
        },
        "legacy_card_type_normalizations": {
            legacy_type: sum(row.get("legacy_card_type") == legacy_type for row in rows)
            for legacy_type in ("paper_context", "patient_group")
        },
        "assessment_provenance": {
            "total": len(assessments),
            "source_supported": sum(
                row.get("source_fact_status") == "explicit_source_support"
                for row in assessments
            ),
            "reviewer_judgment_only": sum(
                row.get("source_fact_status") == "reviewer_judgment"
                for row in assessments
            ),
            "with_explicit_provenance": sum(
                isinstance(row.get("assessment_provenance"), Mapping)
                for row in assessments
            ),
        },
    }


def _proposal_decision_summary(evidence_proposal: object | None) -> dict[str, Any]:
    rows = (
        evidence_proposal.get("rows")
        if isinstance(evidence_proposal, Mapping)
        else None
    )
    decisions = (
        [row for row in rows if isinstance(row, Mapping)]
        if isinstance(rows, list)
        else []
    )
    return {
        "total": len(decisions),
        "classifications": _sorted_counts(
            row.get("classification") for row in decisions
        ),
        "with_decision_provenance": sum(
            isinstance(row.get("decision_provenance"), Mapping)
            for row in decisions
        ),
        "assessors": _sorted_counts(
            row["decision_provenance"].get("assessor")
            for row in decisions
            if isinstance(row.get("decision_provenance"), Mapping)
        ),
        "policy": (
            "classifications, duplicate judgments, applicability, and readiness are "
            "reviewer/Claude assessments rather than source-reported facts"
        ),
    }


def _dynamic_legacy_views(
    verified_findings: object,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Build optional legacy summaries without narrowing the verified export."""
    effects: list[dict[str, Any]] = []
    characteristics: list[dict[str, Any]] = []
    assessments: list[dict[str, Any]] = []
    for finding in _verified_rows(verified_findings):
        payload = finding.get("raw_payload")
        if not isinstance(payload, Mapping):
            continue
        card_type = finding.get("card_type")
        enriched = {
            **payload,
            "claim_id": finding.get("claim_id"),
            "paperclip_doc_id": finding.get("paper_id"),
            "paperclip_lines": [
                location.get("lines")
                for location in finding.get("source_locations", [])
                if isinstance(location, Mapping)
            ],
        }
        if card_type == "finding" and (
            finding.get("record_type") == "effect"
            or payload.get("type") == "effect"
            or any(
            key in payload for key in ("effect_size", "estimate", "proportion")
            )
        ):
            effects.append(enriched)
        characteristic = payload.get("study_characteristics")
        if isinstance(characteristic, Mapping):
            characteristics.append({"paperclip_doc_id": finding.get("paper_id"), **characteristic})
        elif card_type == "source_context":
            data = payload.get("data")
            context = data if isinstance(data, Mapping) else payload
            characteristics.append(
                {"paperclip_doc_id": finding.get("paper_id"), **context}
            )
        assessment = payload.get("quality_assessment")
        if isinstance(assessment, Mapping):
            assessments.append({"paperclip_doc_id": finding.get("paper_id"), **assessment})
        elif card_type == "assessment":
            data = payload.get("data")
            judgment = data if isinstance(data, Mapping) else payload
            assessments.append(
                {
                    "paperclip_doc_id": finding.get("paper_id"),
                    **judgment,
                    "assessment_provenance": finding.get("assessment_provenance"),
                    "source_fact_status": finding.get("source_fact_status"),
                }
            )
    return effects, characteristics, assessments


def _legacy_output_readiness(readiness: Mapping[str, Any]) -> dict[str, Any]:
    outputs: list[dict[str, Any]] = []
    for name in ("pairwise", "network", "meta_regression"):
        value = readiness.get(name)
        if not isinstance(value, Mapping) or not value.get("requested"):
            continue
        outputs.append(
            {
                "output_id": name,
                "intent": name,
                "purpose": "Imported legacy protocol analysis",
                "priority": "legacy",
                "provisional_status": "legacy_import",
                "status": value.get("status"),
                "reason": value.get("reason"),
                "missing_requirements": [],
                "affected_strata": [],
                "recommended_next_action": (
                    "Proceed with the legacy pairwise path."
                    if value.get("status") == "ready"
                    else "Resolve the legacy readiness limitation before analysis."
                ),
                "rule": {
                    "id": f"legacy_{name}",
                    "label": "legacy compiler readiness",
                    "thresholds": THRESHOLDS,
                },
            }
        )
    return {"status": readiness.get("status", "blocked"), "outputs": outputs}


def _harmonization_summary(
    harmonization_map: Mapping[str, Any] | None,
    harmonization_queue: Mapping[str, Any] | None,
) -> dict[str, Any]:
    if not isinstance(harmonization_map, Mapping):
        blocker = {
            "code": "harmonization_map_missing",
            "reason": "A current harmonization_map.json is required before analysis.",
        }
        return {
            "status": "blocked",
            "coverage": {
                "total_original_labels": 0,
                "resolved_original_labels": 0,
                "unresolved_original_labels": 0,
                "rate": None,
            },
            "original_label_diversity": {"total": 0, "by_dimension": {}},
            "normalized_groups": [],
            "unresolved_material_decisions": [],
            "queued_unknown_labels": 0,
            "readiness_blockers": [blocker],
        }

    mapping_rows = [
        row for row in harmonization_map.get("mappings", []) if isinstance(row, Mapping)
    ]
    queue_rows = (
        [row for row in harmonization_queue.get("items", []) if isinstance(row, Mapping)]
        if isinstance(harmonization_queue, Mapping)
        else []
    )
    all_rows = [*mapping_rows, *queue_rows]
    original_by_dimension: dict[str, set[str]] = defaultdict(set)
    for row in all_rows:
        dimension = _label(row.get("dimension"))
        original = row.get("original_label")
        if isinstance(original, str) and original:
            original_by_dimension[dimension].add(original)

    labels_by_group: dict[str, set[str]] = defaultdict(set)
    for row in mapping_rows:
        normalized_id = row.get("normalized_id")
        original = row.get("original_label")
        if isinstance(normalized_id, str) and normalized_id and isinstance(original, str):
            labels_by_group[normalized_id].add(original)
    concepts = {
        str(row.get("normalized_id")): row
        for row in harmonization_map.get("normalized_concepts", [])
        if isinstance(row, Mapping) and row.get("normalized_id")
    }
    normalized_groups = [
        {
            "normalized_id": normalized_id,
            "preferred_label": concept.get("preferred_label"),
            "dimension": concept.get("dimension"),
            "original_label_count": len(labels_by_group.get(normalized_id, set())),
            "original_labels": sorted(labels_by_group.get(normalized_id, set()), key=str.casefold),
        }
        for normalized_id, concept in sorted(
            concepts.items(),
            key=lambda item: item[0].casefold(),
        )
    ]
    resolved = sum(
        row.get("decision_status") in {"automatic_obvious", "user_approved"}
        and isinstance(row.get("normalized_id"), str)
        and bool(str(row.get("normalized_id")).strip())
        for row in all_rows
    )
    total = len(all_rows)
    unresolved_material = unresolved_material_mappings(
        harmonization_map,
        harmonization_queue,
    )
    blockers = (
        [
            {
                "code": "unresolved_material_harmonization",
                "reason": (
                    f"{len(unresolved_material)} material label mapping decision(s) "
                    "remain unresolved."
                ),
            }
        ]
        if unresolved_material
        else []
    )
    return {
        "status": "blocked" if blockers else "ready",
        "coverage": {
            "total_original_labels": total,
            "resolved_original_labels": resolved,
            "unresolved_original_labels": total - resolved,
            "rate": resolved / total if total else 1.0,
        },
        "original_label_diversity": {
            "total": sum(len(labels) for labels in original_by_dimension.values()),
            "by_dimension": {
                dimension: {
                    "count": len(labels),
                    "labels": sorted(labels, key=str.casefold),
                }
                for dimension, labels in sorted(
                    original_by_dimension.items(),
                    key=lambda item: item[0].casefold(),
                )
            },
        },
        "normalized_groups": normalized_groups,
        "unresolved_material_decisions": unresolved_material,
        "queued_unknown_labels": len(queue_rows),
        "readiness_blockers": blockers,
    }


def build_evidence_review(
    *,
    search_log: Mapping[str, Any] | None = None,
    effects: Sequence[Mapping[str, Any]] = (),
    study_characteristics: Sequence[Mapping[str, Any]] = (),
    quality_assessments: Sequence[Mapping[str, Any]] = (),
    protocol: Mapping[str, Any] | None = None,
    landmark_list: object | None = None,
    source_hashes: Mapping[str, str] | None = None,
    landmark_list_source: str | None = None,
    generated_at: str | None = None,
    verified_findings: object | None = None,
    collection_spec: Mapping[str, Any] | None = None,
    planned_outputs: Mapping[str, Any] | None = None,
    evidence_proposal: Mapping[str, Any] | None = None,
    harmonization_map: Mapping[str, Any] | None = None,
    harmonization_queue: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a deterministic evidence review from already parsed artifacts."""
    search_log = search_log or {}
    if verified_findings is not None:
        verified_findings = normalize_verified_findings(verified_findings)
    if verified_findings is not None and not effects:
        dynamic_effects, dynamic_characteristics, dynamic_assessments = _dynamic_legacy_views(
            verified_findings
        )
        effects = dynamic_effects
        if not study_characteristics:
            study_characteristics = dynamic_characteristics
        if not quality_assessments:
            quality_assessments = dynamic_assessments
    characteristic_lookup = _characteristic_lookup(study_characteristics)
    linked = [_linked_characteristic(effect, characteristic_lookup) for effect in effects]
    independent: dict[str, list[str]] = defaultdict(list)
    missing_units: list[str] = []
    effect_ids: dict[str, list[str]] = defaultdict(list)
    for index, effect in enumerate(effects):
        effect_id = _label(effect.get("effect_id") or f"row-{index + 1}")
        effect_ids[effect_id].append(effect_id)
        unit = effect.get("independent_unit_id")
        if isinstance(unit, str) and unit.strip():
            independent[unit.strip()].append(effect_id)
        else:
            missing_units.append(effect_id)

    correlated_groups = [
        {
            "group_type": "shared_independent_unit",
            "group_id": unit,
            "effect_count": len(ids),
            "effect_ids": sorted(ids, key=str.casefold),
        }
        for unit, ids in sorted(independent.items(), key=lambda item: item[0].casefold())
        if len(ids) > 1
    ]
    duplicate_effect_ids = [
        {
            "group_type": "duplicate_effect_id",
            "group_id": effect_id,
            "effect_count": len(ids),
            "effect_ids": ids,
        }
        for effect_id, ids in sorted(effect_ids.items(), key=lambda item: item[0].casefold())
        if len(ids) > 1
    ]

    derived_ids: list[str] = []
    reported_ci_ids: list[str] = []
    reported_se_ids: list[str] = []
    missing_precision_ids: list[str] = []
    for index, effect in enumerate(effects):
        effect_id = _label(effect.get("effect_id") or f"row-{index + 1}")
        derived = _is_derived(effect)
        if derived and has_usable_precision(effect):
            derived_ids.append(effect_id)
        if not derived and _valid_ci(effect):
            reported_ci_ids.append(effect_id)
        if not derived and _valid_se(effect):
            reported_se_ids.append(effect_id)
        if not has_usable_precision(effect):
            missing_precision_ids.append(effect_id)

    arm_readiness = _arm_readiness(effects)
    landmark_coverage = _landmark_coverage(landmark_list, effects, study_characteristics)
    readiness = _readiness(
        protocol=protocol,
        effects=effects,
        characteristics_lookup=characteristic_lookup,
    )
    blockers = _blockers(
        readiness=readiness,
        missing_precision=missing_precision_ids,
        missing_units=missing_units,
        landmarks=landmark_coverage,
    )
    harmonization = _harmonization_summary(
        harmonization_map if verified_findings is not None else None,
        harmonization_queue,
    )
    if verified_findings is None:
        harmonization = {
            "status": "legacy_not_applicable",
            "coverage": None,
            "original_label_diversity": None,
            "normalized_groups": [],
            "unresolved_material_decisions": [],
            "queued_unknown_labels": 0,
            "readiness_blockers": [],
        }
    readiness_blockers = [*blockers, *harmonization["readiness_blockers"]]
    review: dict[str, Any] = {
        "schema_version": EVIDENCE_REVIEW_SCHEMA_VERSION,
        "generated_at": generated_at or _source_timestamp(protocol, search_log),
        "generator": "gxl_paperclip.analysis_project.evidence",
        "source_mode": "guided" if verified_findings is not None else "legacy_effects",
        "card_inventory": (
            _card_inventory(verified_findings)
            if verified_findings is not None
            else None
        ),
        "proposal_decisions": (
            _proposal_decision_summary(evidence_proposal)
            if verified_findings is not None
            else None
        ),
        "source_hashes": dict(sorted((source_hashes or {}).items())),
        "landmark_list_source": landmark_list_source,
        "thresholds": THRESHOLDS,
        "search_flow": _search_flow(search_log),
        "effect_counts": {
            "total": len(effects),
            "by_outcome": _sorted_counts(effect.get("outcome_group") for effect in effects),
            "by_measure": _sorted_counts(effect.get("effect_measure") for effect in effects),
            "by_population": _sorted_counts(
                _effect_dimension(effect, context, "population")
                for effect, context in zip(effects, linked, strict=True)
            ),
            "by_timepoint": _sorted_counts(effect.get("timepoint") for effect in effects),
        },
        "roles": _sorted_counts(effect.get("analysis_role") for effect in effects),
        "estimands": {
            "by_type": _sorted_counts(effect.get("estimand_type") for effect in effects),
            "comparative": sum(effect.get("comparative_effect") is True for effect in effects),
            "within_arm": sum(effect.get("estimand_type") == "within_arm" for effect in effects),
            "unspecified": sum(effect.get("estimand_type") in (None, "") for effect in effects),
        },
        "unique_independent_units": {
            "count": len(independent),
            "ids": sorted(independent, key=str.casefold),
            "effects_missing_unit": sorted(missing_units, key=str.casefold),
        },
        "duplicate_correlated_groups": correlated_groups + duplicate_effect_ids,
        "precision": {
            "reported_ci": len(reported_ci_ids),
            "reported_ci_effect_ids": sorted(reported_ci_ids, key=str.casefold),
            "reported_se": len(reported_se_ids),
            "reported_se_effect_ids": sorted(reported_se_ids, key=str.casefold),
            "derived_precision": len(derived_ids),
            "derived_precision_effect_ids": sorted(derived_ids, key=str.casefold),
            "missing_precision": len(missing_precision_ids),
            "missing_precision_effect_ids": sorted(missing_precision_ids, key=str.casefold),
        },
        "arm_input_readiness": arm_readiness,
        "source_quality_summary": _quality_summary(study_characteristics, quality_assessments),
        "landmark_coverage": landmark_coverage,
        "harmonization": harmonization,
        "readiness": readiness,
        "marginal_yield": _marginal_yield(search_log),
        "blockers": blockers,
        "readiness_blockers": readiness_blockers,
        "recommended_next_action": (
            "Resolve the material harmonization choices, update the fixed map, "
            "and refresh the evidence review."
            if harmonization["readiness_blockers"]
            else _next_action(blockers, arm_readiness)
        ),
    }
    if verified_findings is not None and planned_outputs is not None:
        dynamic = build_output_readiness(
            verified_findings=verified_findings,
            collection_spec=collection_spec,
            planned_outputs=planned_outputs,
            evidence_proposal=evidence_proposal,
        )
        review.update(dynamic)
        if harmonization["readiness_blockers"]:
            review["material_gaps"].append(
                {
                    "output_id": "harmonization",
                    "kind": "evidence",
                    "status": "blocked",
                    "reason": harmonization["readiness_blockers"][0]["reason"],
                    "missing_requirements": [
                        item["original_label"]
                        for item in harmonization["unresolved_material_decisions"]
                    ],
                    "recommended_next_action": review["recommended_next_action"],
                }
            )
        if dynamic["material_gaps"]:
            review["recommended_next_action"] = dynamic["material_gaps"][0][
                "recommended_next_action"
            ]
        if harmonization["readiness_blockers"]:
            review["recommended_next_action"] = (
                "Resolve the material harmonization choices, update the fixed map, "
                "and refresh the evidence review."
            )
    else:
        legacy_analysis = _legacy_output_readiness(readiness)
        review["analysis_readiness"] = legacy_analysis
        review["visualization_readiness"] = {"status": "ready", "outputs": []}
        review["material_gaps"] = [
            {
                "output_id": output["output_id"],
                "kind": "analysis",
                "status": output["status"],
                "reason": output["reason"],
                "missing_requirements": output["missing_requirements"],
                "recommended_next_action": output["recommended_next_action"],
            }
            for output in legacy_analysis["outputs"]
            if output["status"] != "ready"
        ]
    return review


def _atomic_json_write(path: Path, value: object) -> None:
    payload = json.dumps(value, indent=2, sort_keys=True) + "\n"
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def write_evidence_review(
    topic_dir: Path | str,
    *,
    landmark_list_path: Path | str | None = None,
) -> dict[str, Any]:
    """Load project artifacts, build the review, and atomically write it."""
    root = Path(topic_dir).expanduser().resolve()
    values: dict[str, object] = {}
    hashes: dict[str, str] = {}
    guided = (root / "verified_findings.json").is_file()
    required_sources = (
        GUIDED_REQUIRED_EVIDENCE_SOURCES if guided else LEGACY_REQUIRED_EVIDENCE_SOURCES
    )
    for name in required_sources:
        path = root / name
        if not path.is_file():
            raise ValueError(f"evidence review requires {path}")
        values[name] = _json_value(path)
        hashes[name] = sha256_file(path)

    evidence_proposal: dict[str, Any] | None = None
    harmonization_map: dict[str, Any] | None = None
    harmonization_queue: dict[str, Any] | None = None
    if guided:
        verified_errors = validate_verified_findings(values["verified_findings.json"])
        if verified_errors:
            raise ValueError("verified_findings.json: " + "; ".join(verified_errors))
        collection = _object(
            values[COLLECTION_SPEC_FILENAME],
            COLLECTION_SPEC_FILENAME,
        )
        collection_validation = validate_collection_spec(collection)
        if not collection_validation.ok:
            raise ValueError(
                f"{COLLECTION_SPEC_FILENAME}: " + "; ".join(collection_validation.errors)
            )
        planned = _object(
            values[PLANNED_OUTPUTS_FILENAME],
            PLANNED_OUTPUTS_FILENAME,
        )
        planned_validation = validate_planned_outputs(planned)
        if not planned_validation.ok:
            raise ValueError(f"{PLANNED_OUTPUTS_FILENAME}: " + "; ".join(planned_validation.errors))
        proposal_path = root / EVIDENCE_PROPOSAL_FILENAME
        if proposal_path.is_file():
            evidence_proposal = _object(
                _json_value(proposal_path),
                EVIDENCE_PROPOSAL_FILENAME,
            )
            proposal_validation = validate_evidence_proposal(
                evidence_proposal,
                values["verified_findings.json"],
            )
            if not proposal_validation.ok:
                raise ValueError(
                    f"{EVIDENCE_PROPOSAL_FILENAME}: " + "; ".join(proposal_validation.errors)
                )
            hashes[EVIDENCE_PROPOSAL_FILENAME] = sha256_file(proposal_path)
        map_path = root / HARMONIZATION_MAP_FILENAME
        harmonization_map = _object(
            values[HARMONIZATION_MAP_FILENAME],
            HARMONIZATION_MAP_FILENAME,
        )
        queue_path = root / HARMONIZATION_QUEUE_FILENAME
        if queue_path.is_file():
            harmonization_queue = _object(
                _json_value(queue_path),
                HARMONIZATION_QUEUE_FILENAME,
            )
            hashes[HARMONIZATION_QUEUE_FILENAME] = sha256_file(queue_path)
        map_validation = validate_harmonization_map(
            harmonization_map,
            collection_hash=collection_schema_hash(collection),
            verified_findings_sha256=hashes["verified_findings.json"],
            evidence_proposal_sha256=hashes.get(EVIDENCE_PROPOSAL_FILENAME),
            harmonization_queue=harmonization_queue,
            harmonization_queue_sha256=hashes.get(HARMONIZATION_QUEUE_FILENAME),
        )
        if not map_validation.ok:
            raise ValueError(
                f"{HARMONIZATION_MAP_FILENAME}: " + "; ".join(map_validation.errors)
            )
        hashes[HARMONIZATION_MAP_FILENAME] = sha256_file(map_path)

    protocol: dict[str, Any] | None = None
    protocol_path = root / OPTIONAL_PROTOCOL_SOURCE
    if protocol_path.is_file():
        protocol = _object(_json_value(protocol_path), OPTIONAL_PROTOCOL_SOURCE)
        hashes[OPTIONAL_PROTOCOL_SOURCE] = sha256_file(protocol_path)

    selected_landmarks: Path | None = None
    if landmark_list_path is not None:
        selected_landmarks = Path(landmark_list_path).expanduser().resolve()
    elif (root / DEFAULT_LANDMARK_SOURCE).is_file():
        selected_landmarks = root / DEFAULT_LANDMARK_SOURCE

    landmark_list: object | None = None
    landmark_source: str | None = None
    if selected_landmarks is not None:
        try:
            landmark_source = str(selected_landmarks.relative_to(root))
        except ValueError as exc:
            raise ValueError("landmark list must be inside the analysis project directory") from exc
        if not selected_landmarks.is_file():
            raise ValueError(f"landmark list not found: {selected_landmarks}")
        landmark_list = _json_value(selected_landmarks)
        hashes["landmark_list"] = sha256_file(selected_landmarks)

    review = build_evidence_review(
        search_log=_object(values["search_log.json"], "search_log.json"),
        effects=(() if guided else _rows(values["effects.json"], "effects.json")),
        study_characteristics=(
            ()
            if guided
            else _rows(
                values["study_characteristics.json"],
                "study_characteristics.json",
            )
        ),
        quality_assessments=(
            ()
            if guided
            else _rows(
                values["quality_assessments.json"],
                "quality_assessments.json",
            )
        ),
        protocol=protocol,
        landmark_list=landmark_list,
        source_hashes=hashes,
        landmark_list_source=landmark_source,
        verified_findings=values.get("verified_findings.json"),
        collection_spec=(
            _object(values[COLLECTION_SPEC_FILENAME], COLLECTION_SPEC_FILENAME) if guided else None
        ),
        planned_outputs=(
            _object(values[PLANNED_OUTPUTS_FILENAME], PLANNED_OUTPUTS_FILENAME) if guided else None
        ),
        evidence_proposal=evidence_proposal,
        harmonization_map=harmonization_map,
        harmonization_queue=harmonization_queue,
    )
    _atomic_json_write(root / EVIDENCE_REVIEW_FILENAME, review)
    return review


def validate_evidence_review_sources(
    topic_dir: Path | str,
    review: object,
) -> list[str]:
    """Validate that a review identifies and hashes every current source artifact."""
    if not isinstance(review, dict):
        return ["evidence review must be a JSON object"]
    errors: list[str] = []
    if review.get("schema_version") != EVIDENCE_REVIEW_SCHEMA_VERSION:
        errors.append(f"unsupported schema_version; expected {EVIDENCE_REVIEW_SCHEMA_VERSION}")
    if review.get("generator") != "gxl_paperclip.analysis_project.evidence":
        errors.append("review was not produced by the deterministic evidence builder")
    if not isinstance(review.get("generated_at"), str) or not review["generated_at"]:
        errors.append("generated_at must be a non-empty string")

    hashes = review.get("source_hashes")
    if not isinstance(hashes, dict):
        errors.append("source_hashes must be an object")
        return errors
    if not all(
        isinstance(name, str) and isinstance(digest, str) for name, digest in hashes.items()
    ):
        errors.append("source_hashes must map source names to SHA-256 strings")
        return errors
    root = Path(topic_dir).expanduser().resolve()
    source_mode = review.get("source_mode", "legacy_effects")
    guided = source_mode == "guided"
    if source_mode not in ("guided", "legacy_effects"):
        errors.append("source_mode must be 'guided' or 'legacy_effects'")
    expected_sources = list(
        GUIDED_REQUIRED_EVIDENCE_SOURCES if guided else LEGACY_REQUIRED_EVIDENCE_SOURCES
    )
    protocol_path = root / OPTIONAL_PROTOCOL_SOURCE
    if protocol_path.is_file():
        expected_sources.append(OPTIONAL_PROTOCOL_SOURCE)
    elif OPTIONAL_PROTOCOL_SOURCE in hashes:
        errors.append("protocol.json was removed after evidence review generation")
    proposal_path = root / EVIDENCE_PROPOSAL_FILENAME
    if guided and proposal_path.is_file():
        expected_sources.append(EVIDENCE_PROPOSAL_FILENAME)
    elif EVIDENCE_PROPOSAL_FILENAME in hashes:
        errors.append("evidence_proposal.json was removed after evidence review generation")
    queue_path = root / HARMONIZATION_QUEUE_FILENAME
    if guided and queue_path.is_file():
        expected_sources.append(HARMONIZATION_QUEUE_FILENAME)
    elif HARMONIZATION_QUEUE_FILENAME in hashes:
        errors.append("harmonization_queue.json was removed after evidence review generation")

    for name in expected_sources:
        expected_hash = hashes.get(name)
        path = root / name
        if not isinstance(expected_hash, str) or not expected_hash:
            errors.append(f"source_hashes is missing {name}")
        elif not path.is_file():
            errors.append(f"source artifact is missing: {name}")
        elif sha256_file(path) != expected_hash:
            errors.append(f"source artifact changed: {name}")

    landmark_source = review.get("landmark_list_source")
    if landmark_source is not None:
        if not isinstance(landmark_source, str) or not landmark_source:
            errors.append("landmark_list_source must be a non-empty relative path")
        else:
            candidate = (root / landmark_source).resolve()
            try:
                candidate.relative_to(root)
            except ValueError:
                errors.append("landmark_list_source points outside the analysis project")
            else:
                expected_hash = hashes.get("landmark_list")
                if not isinstance(expected_hash, str) or not expected_hash:
                    errors.append("source_hashes is missing landmark_list")
                elif not candidate.is_file():
                    errors.append("landmark list was removed after review generation")
                elif sha256_file(candidate) != expected_hash:
                    errors.append("landmark list changed after review generation")
    elif "landmark_list" in hashes:
        errors.append("landmark_list hash has no landmark_list_source")

    if errors:
        return errors
    try:
        protocol = (
            _object(_json_value(protocol_path), OPTIONAL_PROTOCOL_SOURCE)
            if protocol_path.is_file()
            else None
        )
        landmark_list = (
            _json_value((root / landmark_source).resolve())
            if isinstance(landmark_source, str)
            else None
        )
        if guided:
            verified = _json_value(root / "verified_findings.json")
            verified_errors = validate_verified_findings(verified)
            if verified_errors:
                raise ValueError("verified_findings.json: " + "; ".join(verified_errors))
            collection = _object(
                _json_value(root / COLLECTION_SPEC_FILENAME),
                COLLECTION_SPEC_FILENAME,
            )
            collection_validation = validate_collection_spec(collection)
            if not collection_validation.ok:
                raise ValueError(
                    f"{COLLECTION_SPEC_FILENAME}: " + "; ".join(collection_validation.errors)
                )
            planned = _object(
                _json_value(root / PLANNED_OUTPUTS_FILENAME),
                PLANNED_OUTPUTS_FILENAME,
            )
            planned_validation = validate_planned_outputs(planned)
            if not planned_validation.ok:
                raise ValueError(
                    f"{PLANNED_OUTPUTS_FILENAME}: " + "; ".join(planned_validation.errors)
                )
            proposal = (
                _object(
                    _json_value(proposal_path),
                    EVIDENCE_PROPOSAL_FILENAME,
                )
                if proposal_path.is_file()
                else None
            )
            if proposal is not None:
                proposal_validation = validate_evidence_proposal(proposal, verified)
                if not proposal_validation.ok:
                    raise ValueError(
                        f"{EVIDENCE_PROPOSAL_FILENAME}: " + "; ".join(proposal_validation.errors)
                    )
            harmonization_map = _object(
                _json_value(root / HARMONIZATION_MAP_FILENAME),
                HARMONIZATION_MAP_FILENAME,
            )
            harmonization_queue = (
                _object(
                    _json_value(queue_path),
                    HARMONIZATION_QUEUE_FILENAME,
                )
                if queue_path.is_file()
                else None
            )
            map_validation = validate_harmonization_map(
                harmonization_map,
                collection_hash=collection_schema_hash(collection),
                verified_findings_sha256=hashes["verified_findings.json"],
                evidence_proposal_sha256=hashes.get(EVIDENCE_PROPOSAL_FILENAME),
                harmonization_queue=harmonization_queue,
                harmonization_queue_sha256=hashes.get(HARMONIZATION_QUEUE_FILENAME),
            )
            if not map_validation.ok:
                raise ValueError(
                    f"{HARMONIZATION_MAP_FILENAME}: " + "; ".join(map_validation.errors)
                )
            rebuilt = build_evidence_review(
                search_log=_object(
                    _json_value(root / "search_log.json"),
                    "search_log.json",
                ),
                protocol=protocol,
                landmark_list=landmark_list,
                source_hashes=hashes,
                landmark_list_source=landmark_source,
                verified_findings=verified,
                collection_spec=collection,
                planned_outputs=planned,
                evidence_proposal=proposal,
                harmonization_map=harmonization_map,
                harmonization_queue=harmonization_queue,
            )
        else:
            rebuilt = build_evidence_review(
                search_log=_object(
                    _json_value(root / "search_log.json"),
                    "search_log.json",
                ),
                effects=_rows(_json_value(root / "effects.json"), "effects.json"),
                study_characteristics=_rows(
                    _json_value(root / "study_characteristics.json"),
                    "study_characteristics.json",
                ),
                quality_assessments=_rows(
                    _json_value(root / "quality_assessments.json"),
                    "quality_assessments.json",
                ),
                protocol=protocol,
                landmark_list=landmark_list,
                source_hashes=hashes,
                landmark_list_source=landmark_source,
            )
    except ValueError as exc:
        errors.append(f"cannot rebuild evidence review: {exc}")
    else:
        if review != rebuilt:
            errors.append(
                "review content does not match deterministic rebuild from current sources"
            )
    return errors
