"""Conservative, domain-agnostic readiness checks for desired outputs."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

from gxl_paperclip.meta_analysis.cards import normalize_finding_card

READINESS_STATUSES = ("ready", "limited", "blocked")
MIN_WEIGHTED_UNITS = 2
MIN_SUBGROUP_STRATA = 2
MIN_NETWORK_TREATMENTS = 3
MIN_NETWORK_COMPARISONS = 3
MIN_META_REGRESSION_UNITS = 10
MIN_TIMELINE_POINTS = 2
MIN_FLOW_STAGES = 2

READINESS_RULES: dict[str, dict[str, Any]] = {
    "weighted_effect": {
        "label": "weighted effect or forest output",
        "required_concepts": ["estimate", "precision", "independent_unit"],
        "thresholds": {"minimum_independent_units": MIN_WEIGHTED_UNITS},
    },
    "proportion": {
        "label": "response or proportion output",
        "required_concepts": ["proportion_or_events", "denominator_or_sample"],
        "thresholds": {"minimum_records": 1},
    },
    "survival": {
        "label": "survival comparison",
        "required_concepts": ["survival_outcome", "estimate", "timepoint_or_precision"],
        "thresholds": {"minimum_groups_for_comparison": 2},
    },
    "subgroup": {
        "label": "subgroup comparison",
        "required_concepts": ["estimate", "subgroup"],
        "thresholds": {"minimum_distinct_strata": MIN_SUBGROUP_STRATA},
    },
    "network": {
        "label": "network graph or ranking",
        "required_concepts": ["intervention", "comparator"],
        "thresholds": {
            "minimum_treatments": MIN_NETWORK_TREATMENTS,
            "minimum_comparisons": MIN_NETWORK_COMPARISONS,
            "connected_network_required": True,
        },
    },
    "meta_regression": {
        "label": "meta-regression or moderator scatter",
        "required_concepts": ["estimate", "precision", "moderator"],
        "thresholds": {"minimum_independent_units": MIN_META_REGRESSION_UNITS},
    },
    "timeline": {
        "label": "timeline",
        "required_concepts": ["time", "event_or_value"],
        "thresholds": {"minimum_points": MIN_TIMELINE_POINTS},
    },
    "flow": {
        "label": "analysis-unit or process flow",
        "required_concepts": ["stage", "count"],
        "thresholds": {"minimum_stages": MIN_FLOW_STAGES},
    },
    "quality_map": {
        "label": "evidence or quality map",
        "required_concepts": ["source", "quality"],
        "thresholds": {"minimum_records": 1},
    },
    "generic": {
        "label": "declared output",
        "required_concepts": [],
        "thresholds": {"minimum_records": 1},
    },
}

_INTENT_PATTERNS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("weighted_effect", ("forest", "weighted effect", "meta analysis", "pooled effect")),
    ("proportion", ("response", "proportion", "event rate", "prevalence")),
    ("survival", ("survival", "hazard", "kaplan", "progression free")),
    ("subgroup", ("subgroup", "stratified", "strata comparison")),
    ("network", ("network", "ranking", "league table")),
    ("meta_regression", ("meta regression", "moderator", "regression scatter")),
    ("timeline", ("timeline", "chronolog", "over time", "temporal")),
    ("flow", ("flow", "process sequence", "consort")),
    ("quality_map", ("quality map", "evidence map", "risk of bias", "evidence quality")),
)

_CONCEPT_ALIASES: dict[str, set[str]] = {
    "estimate": {
        "estimate",
        "effectsize",
        "effectestimate",
        "value",
        "proportion",
        "rate",
        "responserate",
        "accuracy",
        "score",
        "hazardratio",
        "riskratio",
        "oddsratio",
        "overallsurvival",
        "progressionfreesurvival",
        "medianduration",
        "mediansurvival",
    },
    "precision": {
        "precision",
        "se",
        "stderr",
        "standarderror",
        "variance",
        "cilower",
        "ciupper",
        "confidenceinterval",
        "confidencebounds",
    },
    "independent_unit": {
        "independentunitid",
        "analysisunitid",
        "unitid",
        "studyid",
        "trialid",
        "cohortid",
        "datasetid",
        "runid",
        "paperid",
    },
    "proportion_or_events": {
        "proportion",
        "rate",
        "responserate",
        "response",
        "events",
        "responders",
        "cases",
    },
    "denominator_or_sample": {
        "denominator",
        "samplesize",
        "participants",
        "patients",
        "n",
        "total",
        "evaluable",
    },
    "survival_outcome": {
        "survival",
        "overallsurvival",
        "progressionfreesurvival",
        "hazardratio",
        "mediansurvival",
        "duration",
    },
    "timepoint_or_precision": {
        "timepoint",
        "followup",
        "duration",
        "month",
        "year",
        "precision",
        "se",
        "cilower",
        "ciupper",
    },
    "subgroup": {
        "subgroup",
        "stratum",
        "population",
        "cohort",
        "indication",
        "benchmark",
        "model",
        "modelfamily",
    },
    "intervention": {
        "intervention",
        "treatment",
        "therapy",
        "product",
        "model",
        "method",
        "node",
    },
    "comparator": {
        "comparator",
        "control",
        "reference",
        "baseline",
        "versus",
        "target",
    },
    "moderator": {
        "moderator",
        "covariate",
        "age",
        "year",
        "dose",
        "followup",
        "modelsize",
        "datasetsize",
        "compute",
    },
    "time": {
        "time",
        "timepoint",
        "date",
        "year",
        "month",
        "followup",
        "duration",
        "timestamp",
    },
    "event_or_value": {
        "event",
        "milestone",
        "outcome",
        "value",
        "estimate",
        "count",
        "status",
    },
    "stage": {
        "stage",
        "step",
        "phase",
        "state",
        "process",
        "manufacturingstage",
    },
    "count": {
        "count",
        "n",
        "number",
        "total",
        "patients",
        "participants",
        "batches",
        "units",
    },
    "source": {"paperid", "studyid", "source", "citation", "documentid"},
    "quality": {
        "quality",
        "riskofbias",
        "bias",
        "assessment",
        "certainty",
        "grade",
        "overall",
        "tool",
        "evidencelevel",
    },
}


def _normalize(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", "", str(value).casefold())
    return text


def _flat(value: object, prefix: str = "") -> list[tuple[str, object]]:
    values: list[tuple[str, object]] = []
    if isinstance(value, Mapping):
        for key, item in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            values.append((path, item))
            values.extend(_flat(item, path))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            values.extend(_flat(item, f"{prefix}.{index}"))
    return values


def _alias_map(collection_spec: Mapping[str, Any] | None) -> dict[str, str]:
    aliases: dict[str, str] = {}
    if not isinstance(collection_spec, Mapping):
        return aliases
    raw = collection_spec.get("aliases")
    if not isinstance(raw, Mapping):
        return aliases
    for key, value in raw.items():
        canonical = _normalize(key)
        if isinstance(value, str):
            aliases[_normalize(key)] = _normalize(value)
            aliases[_normalize(value)] = _normalize(value)
        elif isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            aliases[canonical] = canonical
            for item in value:
                if isinstance(item, str):
                    aliases[_normalize(item)] = canonical
    return aliases


def _keys(item: Mapping[str, Any], aliases: Mapping[str, str]) -> set[str]:
    result: set[str] = {"paperid"} if item.get("paper_id") else set()
    for path, value in _flat(item.get("data", {})):
        if value in (None, "", [], {}):
            continue
        for part in path.split("."):
            normalized = _normalize(part)
            if normalized:
                result.add(normalized)
                result.add(aliases.get(normalized, normalized))
    return result


def _has_concept(
    item: Mapping[str, Any],
    concept: str,
    aliases: Mapping[str, str],
) -> bool:
    keys = _keys(item, aliases)
    normalized = aliases.get(_normalize(concept), _normalize(concept))
    candidates = {
        aliases.get(alias, alias) for alias in _CONCEPT_ALIASES.get(concept, {_normalize(concept)})
    }
    candidates.add(normalized)
    return any(
        key == candidate
        or len(candidate) > 2
        and len(key) > 2
        and (key.endswith(candidate) or candidate.endswith(key))
        for key in keys
        for candidate in candidates
    )


def _first_value(
    item: Mapping[str, Any],
    concept: str,
    aliases: Mapping[str, str],
) -> object | None:
    candidates = _CONCEPT_ALIASES.get(concept, {_normalize(concept)})
    for path, value in _flat(item.get("data", {})):
        key = aliases.get(_normalize(path.split(".")[-1]), _normalize(path.split(".")[-1]))
        if key in candidates and value not in (None, "", [], {}):
            return value
    return None


def _items(
    verified_findings: object,
    evidence_proposal: object | None,
) -> list[dict[str, Any]]:
    findings_value = (
        verified_findings.get("findings")
        if isinstance(verified_findings, Mapping)
        else verified_findings
    )
    findings = (
        [normalize_finding_card(row) for row in findings_value if isinstance(row, Mapping)]
        if isinstance(findings_value, list)
        else []
    )
    by_id = {
        str(row.get("finding_id") or row.get("claim_id")): row
        for row in findings
        if row.get("finding_id") or row.get("claim_id")
    }
    proposal_rows = (
        evidence_proposal.get("rows") if isinstance(evidence_proposal, Mapping) else None
    )
    if isinstance(proposal_rows, list):
        result: list[dict[str, Any]] = []
        for index, row in enumerate(proposal_rows):
            if not isinstance(row, Mapping):
                continue
            assembled = row.get("assembled_from")
            assembled_ids = [str(item) for item in assembled] if isinstance(assembled, list) else []
            paper_ids = sorted(
                {
                    str(by_id[item].get("paper_id"))
                    for item in assembled_ids
                    if item in by_id and by_id[item].get("paper_id")
                }
            )
            result.append(
                {
                    "id": str(row.get("proposal_id") or row.get("id") or f"row-{index + 1}"),
                    "paper_id": ",".join(paper_ids),
                    "classification": row.get("classification"),
                    "card_types": sorted(
                        {
                            str(by_id[item].get("card_type"))
                            for item in assembled_ids
                            if item in by_id and by_id[item].get("card_type")
                        }
                    ),
                    "source_fact_statuses": sorted(
                        {
                            str(by_id[item].get("source_fact_status"))
                            for item in assembled_ids
                            if item in by_id and by_id[item].get("source_fact_status")
                        }
                    ),
                    "data": row.get("data") if isinstance(row.get("data"), Mapping) else {},
                    "missing_fields": row.get("missing_fields", []),
                    "ambiguous_fields": row.get("ambiguous_fields", []),
                }
            )
        return result
    return [
        {
            "id": str(row.get("finding_id") or row.get("claim_id") or f"row-{index + 1}"),
            "paper_id": row.get("paper_id"),
            "classification": "selected",
            "card_types": [str(row.get("card_type") or "finding")],
            "source_fact_statuses": [str(row.get("source_fact_status") or "source_reported")],
            "data": row.get("raw_payload") if isinstance(row.get("raw_payload"), Mapping) else {},
            "missing_fields": row.get("missing_fields", row.get("missing", [])),
            "ambiguous_fields": row.get(
                "ambiguous_fields",
                row.get("ambiguities", row.get("ambiguity", [])),
            ),
        }
        for index, row in enumerate(findings)
    ]


def _intent(row: Mapping[str, Any]) -> tuple[str, str]:
    value = str(row.get("intent") or row.get("type") or row.get("kind") or row.get("id") or "")
    normalized = re.sub(r"[_-]+", " ", value.casefold())
    for rule_id, patterns in _INTENT_PATTERNS:
        if any(pattern in normalized for pattern in patterns):
            return value, rule_id
    return value, "generic"


def _requirements(row: Mapping[str, Any]) -> list[str]:
    result: list[str] = []
    raw = row.get("required_data")
    if not isinstance(raw, list):
        return result
    for item in raw:
        if isinstance(item, str) and item.strip():
            result.append(item.strip())
        elif isinstance(item, Mapping):
            value = item.get("field") or item.get("concept") or item.get("name")
            if isinstance(value, str) and value.strip():
                result.append(value.strip())
    return result


def _affected_strata(
    items: Sequence[Mapping[str, Any]],
    aliases: Mapping[str, str],
) -> list[str]:
    values: set[str] = set()
    for item in items:
        for concept in ("subgroup", "time", "intervention", "comparator"):
            value = _first_value(item, concept, aliases)
            if isinstance(value, (str, int, float)) and str(value).strip():
                values.add(str(value))
    return sorted(values, key=str.casefold)


def _base_status(
    eligible: Sequence[Mapping[str, Any]],
    missing_requirements: list[str],
) -> str:
    if not eligible:
        return "blocked"
    return "limited" if missing_requirements else "ready"


def _reviewer_only_assessment(item: Mapping[str, Any]) -> bool:
    return (
        set(item.get("card_types", [])) == {"assessment"}
        and "explicit_source_support" not in item.get("source_fact_statuses", [])
    )


def _network_connected(
    nodes: set[str],
    edges: set[tuple[str, str]],
) -> bool:
    if not nodes:
        return False
    adjacency: dict[str, set[str]] = {node: set() for node in nodes}
    for left, right in edges:
        adjacency[left].add(right)
        adjacency[right].add(left)
    visited: set[str] = set()
    pending = [min(nodes, key=str.casefold)]
    while pending:
        node = pending.pop()
        if node in visited:
            continue
        visited.add(node)
        pending.extend(adjacency[node] - visited)
    return visited == nodes


def _rule_status(
    rule_id: str,
    items: Sequence[Mapping[str, Any]],
    aliases: Mapping[str, str],
    missing_requirements: list[str],
) -> tuple[str, str, list[str]]:
    eligible = [
        item for item in items if item.get("classification") in ("selected", "descriptive", None)
    ]
    source_evidence = [
        item
        for item in eligible
        if not _reviewer_only_assessment(item)
    ]
    analysis_items = [
        item
        for item in source_evidence
        if item.get("classification") in ("selected", None)
    ]
    affected = _affected_strata(eligible, aliases)
    if rule_id == "weighted_effect":
        candidates = [
            item
            for item in analysis_items
            if _has_concept(item, "estimate", aliases) and _has_concept(item, "precision", aliases)
        ]
        units = {
            str(
                _first_value(item, "independent_unit", aliases)
                or item.get("paper_id")
                or item["id"]
            )
            for item in candidates
        }
        if len(units) >= MIN_WEIGHTED_UNITS and not missing_requirements:
            return "ready", "At least two independent estimates have explicit precision.", affected
        if candidates or analysis_items:
            return (
                "limited",
                "Effects are available, but fewer than two independent "
                "estimates have complete precision.",
                affected,
            )
        return "blocked", "No selectable estimate with explicit precision is available.", affected
    if rule_id == "proportion":
        candidates = [
            item
            for item in source_evidence
            if _has_concept(item, "proportion_or_events", aliases)
            and _has_concept(item, "denominator_or_sample", aliases)
        ]
        if candidates and not missing_requirements:
            return (
                "ready",
                "At least one response/proportion record has a denominator or sample.",
                affected,
            )
        if source_evidence:
            return (
                "limited",
                "Response-like values exist but denominator/sample support is incomplete.",
                affected,
            )
        return "blocked", "No response or proportion evidence is available.", affected
    if rule_id == "survival":
        candidates = [
            item
            for item in source_evidence
            if _has_concept(item, "survival_outcome", aliases)
            and _has_concept(item, "estimate", aliases)
        ]
        groups = {
            str(_first_value(item, "subgroup", aliases) or item.get("paper_id") or item["id"])
            for item in candidates
        }
        if len(groups) >= 2 and not missing_requirements:
            return (
                "ready",
                "Survival estimates cover at least two explicit comparison groups.",
                affected,
            )
        if candidates:
            return (
                "limited",
                "Survival evidence is descriptive or covers only one explicit group.",
                affected,
            )
        return "blocked", "No usable survival estimate is available.", affected
    if rule_id == "subgroup":
        candidates = [
            item
            for item in source_evidence
            if _has_concept(item, "estimate", aliases) and _has_concept(item, "subgroup", aliases)
        ]
        strata = {
            str(_first_value(item, "subgroup", aliases))
            for item in candidates
            if _first_value(item, "subgroup", aliases) is not None
        }
        if len(strata) >= MIN_SUBGROUP_STRATA and not missing_requirements:
            return "ready", "At least two explicit strata have comparable outcomes.", sorted(strata)
        if candidates:
            return (
                "limited",
                "Subgroup evidence exists but fewer than two comparable strata are explicit.",
                sorted(strata),
            )
        return "blocked", "No estimate is linked to an explicit subgroup or stratum.", affected
    if rule_id == "network":
        edges: set[tuple[str, str]] = set()
        nodes: set[str] = set()
        for item in analysis_items:
            left = _first_value(item, "intervention", aliases)
            right = _first_value(item, "comparator", aliases)
            if left is None or right is None or str(left).casefold() == str(right).casefold():
                continue
            left_label, right_label = sorted(
                (str(left), str(right)),
                key=str.casefold,
            )
            edge = (left_label, right_label)
            edges.add(edge)
            nodes.update(edge)
        if (
            len(nodes) >= MIN_NETWORK_TREATMENTS
            and len(edges) >= MIN_NETWORK_COMPARISONS
            and _network_connected(nodes, edges)
            and not missing_requirements
        ):
            return (
                "ready",
                "The direct-comparison graph meets the conservative structural floor.",
                sorted(nodes),
            )
        if edges:
            return (
                "limited",
                "A comparison graph exists but has fewer than three treatments or comparisons.",
                sorted(nodes),
            )
        return "blocked", "No explicit intervention-comparator edges are available.", affected
    if rule_id == "meta_regression":
        candidates = [
            item
            for item in analysis_items
            if all(
                _has_concept(item, concept, aliases)
                for concept in ("estimate", "precision", "moderator")
            )
        ]
        units = {
            str(
                _first_value(item, "independent_unit", aliases)
                or item.get("paper_id")
                or item["id"]
            )
            for item in candidates
        }
        if len(units) >= MIN_META_REGRESSION_UNITS and not missing_requirements:
            return (
                "ready",
                "Ten independent estimates include precision and an explicit moderator.",
                affected,
            )
        if candidates:
            return (
                "limited",
                "Moderator data exist but remain below the conservative ten-unit floor.",
                affected,
            )
        return "blocked", "No selectable estimates combine precision with a moderator.", affected
    if rule_id == "timeline":
        candidates = [
            item
            for item in source_evidence
            if _has_concept(item, "time", aliases) and _has_concept(item, "event_or_value", aliases)
        ]
        if len(candidates) >= MIN_TIMELINE_POINTS and not missing_requirements:
            return "ready", "At least two dated/timed evidence points are available.", affected
        if candidates:
            return "limited", "Only one usable dated/timed evidence point is available.", affected
        return "blocked", "No evidence combines a time marker with an event or value.", affected
    if rule_id == "flow":
        candidates = [
            item
            for item in source_evidence
            if _has_concept(item, "stage", aliases) and _has_concept(item, "count", aliases)
        ]
        stages = {
            str(_first_value(item, "stage", aliases))
            for item in candidates
            if _first_value(item, "stage", aliases) is not None
        }
        if len(stages) >= MIN_FLOW_STAGES and not missing_requirements:
            return "ready", "At least two named stages have explicit counts.", sorted(stages)
        if candidates:
            return (
                "limited",
                "Flow evidence exists but fewer than two named stages have counts.",
                sorted(stages),
            )
        return "blocked", "No stage-count records are available for a flow.", affected
    if rule_id == "quality_map":
        candidates = [item for item in eligible if _has_concept(item, "quality", aliases)]
        if candidates and not missing_requirements:
            return (
                "ready",
                "At least one source has an explicit quality or evidence assessment.",
                affected,
            )
        if eligible:
            return (
                "limited",
                "Sources are available but quality/evidence fields are incomplete.",
                affected,
            )
        return "blocked", "No source-level evidence is available.", affected

    status = _base_status(source_evidence, missing_requirements)
    if status == "ready":
        return "ready", "All explicitly declared data requirements are represented.", affected
    if status == "limited":
        return (
            "limited",
            "Some evidence exists, but declared data requirements are missing.",
            affected,
        )
    return "blocked", "No evidence is available for this declared output.", affected


def _next_action(status: str, missing: Sequence[str], rule_id: str) -> str:
    if status == "ready":
        return "Proceed using the approved analysis specification and retain provenance."
    if missing:
        return "Resolve or explicitly accept the missing requirement(s): " + ", ".join(missing)
    if status == "limited":
        return (
            f"Use a descriptive/limited {READINESS_RULES[rule_id]['label']} "
            "or collect more evidence."
        )
    return f"Collect evidence required for the planned {READINESS_RULES[rule_id]['label']}."


def _evaluate_outputs(
    rows: object,
    items: Sequence[Mapping[str, Any]],
    aliases: Mapping[str, str],
) -> dict[str, Any]:
    output_rows = (
        [row for row in rows if isinstance(row, Mapping)] if isinstance(rows, list) else []
    )
    results: list[dict[str, Any]] = []
    for index, row in enumerate(output_rows):
        intent, rule_id = _intent(row)
        required = _requirements(row)
        requirement_items = (
            items
            if rule_id == "quality_map"
            else [
                item
                for item in items
                if not _reviewer_only_assessment(item)
            ]
        )
        missing = [
            requirement
            for requirement in required
            if not any(_has_concept(item, requirement, aliases) for item in requirement_items)
        ]
        for required_concept in READINESS_RULES[rule_id]["required_concepts"]:
            if not any(
                _has_concept(item, required_concept, aliases)
                for item in requirement_items
            ):
                label = required_concept.replace("_", " ")
                if label not in missing:
                    missing.append(label)
        status, reason, affected = _rule_status(
            rule_id,
            items,
            aliases,
            missing,
        )
        results.append(
            {
                "output_id": str(row.get("id") or row.get("output_id") or f"output-{index + 1}"),
                "intent": intent,
                "purpose": row.get("purpose"),
                "priority": row.get("priority"),
                "provisional_status": row.get(
                    "provisional_status",
                    row.get("provisional"),
                ),
                "status": status,
                "reason": reason,
                "missing_requirements": sorted(set(missing), key=str.casefold),
                "affected_strata": affected,
                "recommended_next_action": _next_action(status, missing, rule_id),
                "rule": {
                    "id": rule_id,
                    **READINESS_RULES[rule_id],
                },
            }
        )
    statuses = [item["status"] for item in results]
    overall = (
        "blocked" if "blocked" in statuses else "limited" if "limited" in statuses else "ready"
    )
    return {"status": overall, "outputs": results}


def build_output_readiness(
    *,
    verified_findings: object,
    collection_spec: Mapping[str, Any] | None,
    planned_outputs: Mapping[str, Any],
    evidence_proposal: object | None = None,
) -> dict[str, Any]:
    """Evaluate every user-desired analysis and visualization."""
    aliases = _alias_map(collection_spec)
    items = _items(verified_findings, evidence_proposal)
    analyses = _evaluate_outputs(planned_outputs.get("analyses"), items, aliases)
    visualizations = _evaluate_outputs(
        planned_outputs.get("visualizations"),
        items,
        aliases,
    )
    gaps = [
        {
            "output_id": output["output_id"],
            "kind": kind,
            "status": output["status"],
            "reason": output["reason"],
            "missing_requirements": output["missing_requirements"],
            "recommended_next_action": output["recommended_next_action"],
        }
        for kind, section in (
            ("analysis", analyses),
            ("visualization", visualizations),
        )
        for output in section["outputs"]
        if output["status"] != "ready"
    ]
    return {
        "analysis_readiness": analyses,
        "visualization_readiness": visualizations,
        "material_gaps": gaps,
        "rule_metadata": {
            "rules": READINESS_RULES,
            "principle": (
                "Conservative feasibility screens use explicit fields and collection aliases; "
                "they do not infer missing values or impose topic-specific columns."
            ),
        },
    }
