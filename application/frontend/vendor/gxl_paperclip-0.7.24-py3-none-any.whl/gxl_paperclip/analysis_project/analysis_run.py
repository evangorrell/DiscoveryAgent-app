"""Validation and local execution for managed analysis bundles.

This runner is a reproducibility guard around trusted, locally authored code.
It is intentionally not described as a security sandbox: static import checks,
fixed paths, hash checks, and post-run evidence verification reduce accidental
or obvious misuse but do not isolate the process from the host.
"""

from __future__ import annotations

import ast
import json
import os
import re
import shutil
import subprocess
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from gxl_paperclip.meta_analysis.analysis_contracts import (
    ANALYSIS_TYPES,
    validate_analysis_file,
)

from .contracts import ANALYSIS_INPUTS_FILENAME, validate_analysis_inputs
from .models import AnalysisProject, utc_now
from .store import sha256_file

ANALYSIS_DIRECTORY = "analysis"
SPEC_FILENAME = "analysis_spec.json"
METHODS_FILENAME = "methods.md"
RUNTIME_FILENAME = "runtime.json"
DIAGNOSTICS_FILENAME = "diagnostics.json"
EXECUTION_FILENAME = "execution.json"
RESULTS_FILENAME = "analysis.json"
RUN_SCHEMA_VERSION = 1
DEFAULT_TIMEOUT_SECONDS = 300
MAX_TIMEOUT_SECONDS = 3600

SAFE_STDLIB_IMPORTS = frozenset(
    {
        "__future__",
        "collections",
        "csv",
        "dataclasses",
        "decimal",
        "fractions",
        "functools",
        "hashlib",
        "itertools",
        "json",
        "math",
        "operator",
        "pathlib",
        "random",
        "statistics",
        "typing",
    }
)
BLOCKED_IMPORTS = frozenset(
    {
        "aiohttp",
        "asyncio",
        "ctypes",
        "ftplib",
        "http",
        "httpx",
        "importlib",
        "multiprocessing",
        "os",
        "requests",
        "resource",
        "shutil",
        "signal",
        "smtplib",
        "socket",
        "subprocess",
        "sys",
        "tempfile",
        "urllib",
    }
)
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class AnalysisRunError(RuntimeError):
    """Actionable managed-analysis validation or execution failure."""


@dataclass
class BundleValidation:
    """Preflight validation report for one managed bundle."""

    topic_dir: str
    analysis_dir: str
    analysis_type: str | None = None
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    plan: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "topic_dir": self.topic_dir,
            "analysis_dir": self.analysis_dir,
            "analysis_type": self.analysis_type,
            "errors": self.errors,
            "warnings": self.warnings,
            "plan": self.plan,
        }


def _load_object(path: Path, errors: list[str]) -> dict[str, Any]:
    if not path.is_file():
        errors.append(f"missing managed-analysis artifact: {path.name}")
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"cannot read {path.name}: {exc}")
        return {}
    if not isinstance(value, dict):
        errors.append(f"{path.name} must contain a JSON object")
        return {}
    return value


def _safe_relative(
    root: Path,
    value: object,
    label: str,
    errors: list[str],
    *,
    suffixes: Sequence[str] = (),
) -> Path | None:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{label} must be a non-empty relative path")
        return None
    relative = Path(value)
    if relative.is_absolute():
        errors.append(f"{label} must be relative")
        return None
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError:
        errors.append(f"{label} points outside {root}")
        return None
    if suffixes and candidate.suffix.lower() not in suffixes:
        errors.append(f"{label} must use one of: {', '.join(suffixes)}")
    return candidate


def _approved_evidence_hashes(project: AnalysisProject, errors: list[str]) -> dict[str, str]:
    approval = project.approvals.get("evidence")
    if project.stage != "results" or approval is None:
        errors.append(
            "managed analysis requires the results stage and an approved evidence checkpoint"
        )
        return {}
    hashes = dict(approval.artifact_hashes)
    review_path = Path(project.topic_dir) / "evidence_review.json"
    if not review_path.is_file():
        errors.append("approved evidence_review.json is missing")
        return hashes
    if hashes.get("evidence_review.json") != sha256_file(review_path):
        errors.append("evidence_review.json changed after evidence approval")
        return hashes
    try:
        review = json.loads(review_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"cannot read approved evidence_review.json: {exc}")
        return hashes
    source_hashes = review.get("source_hashes") if isinstance(review, dict) else None
    if not isinstance(source_hashes, dict):
        errors.append("approved evidence review has no source_hashes object")
        return hashes
    for name, digest in source_hashes.items():
        if isinstance(name, str) and isinstance(digest, str):
            if name == "landmark_list":
                landmark_source = review.get("landmark_list_source")
                if isinstance(landmark_source, str) and landmark_source:
                    hashes[landmark_source] = digest
            else:
                hashes[name] = digest
    return hashes


def _normalize_inputs(spec: Mapping[str, Any], errors: list[str]) -> list[dict[str, str]]:
    value = spec.get("inputs")
    normalized: list[dict[str, str]] = []
    if isinstance(value, Mapping):
        for name, declaration in value.items():
            if isinstance(declaration, str):
                normalized.append({"name": str(name), "path": str(name), "sha256": declaration})
            elif isinstance(declaration, Mapping):
                normalized.append(
                    {
                        "name": str(name),
                        "path": str(declaration.get("path", name)),
                        "sha256": str(declaration.get("sha256", "")),
                    }
                )
            else:
                errors.append(f"analysis_spec.inputs.{name} has an invalid declaration")
    elif isinstance(value, list):
        for index, declaration in enumerate(value):
            if not isinstance(declaration, Mapping):
                errors.append(f"analysis_spec.inputs[{index}] must be an object")
                continue
            normalized.append(
                {
                    "name": str(declaration.get("name", declaration.get("path", ""))),
                    "path": str(declaration.get("path", "")),
                    "sha256": str(declaration.get("sha256", "")),
                }
            )
    else:
        errors.append("analysis_spec.inputs must be an object or array")
    if not normalized:
        errors.append("analysis_spec.inputs must declare at least one approved evidence input")
    return normalized


def _resolve_input(topic: Path, analysis_dir: Path, value: str) -> Path:
    relative = Path(value)
    from_analysis = (analysis_dir / relative).resolve()
    if from_analysis.is_file() or ".." in relative.parts:
        return from_analysis
    return (topic / relative).resolve()


def _package_declarations(
    runtime: Mapping[str, Any], errors: list[str]
) -> list[dict[str, str | None]]:
    value = runtime.get("packages")
    if not isinstance(value, list):
        errors.append("runtime.packages must be an array (empty for stdlib-only code)")
        return []
    packages: list[dict[str, str | None]] = []
    for index, item in enumerate(value):
        if isinstance(item, str) and item.strip():
            packages.append(
                {"name": item.strip(), "import": item.strip().replace("-", "_"), "version": None}
            )
            continue
        if not isinstance(item, Mapping):
            errors.append(f"runtime.packages[{index}] must be a string or object")
            continue
        name = item.get("name")
        import_name = item.get("import", name)
        version = item.get("version")
        if not isinstance(name, str) or not name.strip():
            errors.append(f"runtime.packages[{index}].name must be a non-empty string")
            continue
        if not isinstance(import_name, str) or not import_name.strip():
            errors.append(f"runtime.packages[{index}].import must be a non-empty string")
            continue
        if version is not None and not isinstance(version, str):
            errors.append(f"runtime.packages[{index}].version must be a string or null")
            continue
        packages.append({"name": name.strip(), "import": import_name.strip(), "version": version})
    return packages


def _python_imports(path: Path, errors: list[str]) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (OSError, SyntaxError) as exc:
        errors.append(f"cannot parse {path.name}: {exc}")
        return set()
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module.split(".", 1)[0])
        elif isinstance(node, ast.Call):
            name = node.func.id if isinstance(node.func, ast.Name) else None
            if name in {"__import__", "eval", "exec", "compile"}:
                errors.append(f"{path.name}: dynamic code/import call {name}() is blocked")
            if (
                isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "os"
                and node.func.attr in {"system", "popen", "spawnl", "spawnv"}
            ):
                errors.append(f"{path.name}: process-launch call os.{node.func.attr}() is blocked")
    return imports


def _validate_imports(
    language: str,
    paths: Sequence[Path],
    runtime: Mapping[str, Any],
    packages: Sequence[Mapping[str, str | None]],
    errors: list[str],
) -> None:
    allowed_value = runtime.get("allowed_imports", [])
    if not isinstance(allowed_value, list) or not all(
        isinstance(item, str) and item.strip() for item in allowed_value
    ):
        errors.append("runtime.allowed_imports must be a string array")
        return
    allowed = {str(item).split(".", 1)[0] for item in allowed_value}
    allowed.update(str(item["import"]).split(".", 1)[0] for item in packages)
    if language == "python":
        for path in paths:
            imports = _python_imports(path, errors)
            blocked = sorted(imports & BLOCKED_IMPORTS)
            if blocked:
                errors.append(f"{path.name}: blocked process/network/system imports: {blocked}")
            undeclared = sorted(imports - SAFE_STDLIB_IMPORTS - allowed - BLOCKED_IMPORTS)
            if undeclared:
                errors.append(
                    f"{path.name}: imports are not allowlisted in runtime.json: {undeclared}"
                )
    else:
        declared = {str(item["name"]) for item in packages}
        pattern = re.compile(r"(?:library|require|requireNamespace)\s*\(\s*['\"]?([A-Za-z0-9.]+)")
        for path in paths:
            try:
                imports = set(pattern.findall(path.read_text(encoding="utf-8")))
            except OSError as exc:
                errors.append(f"cannot read {path.name}: {exc}")
                continue
            undeclared = sorted(imports - declared)
            if undeclared:
                errors.append(f"{path.name}: R packages are not declared: {undeclared}")


def _resolve_executable(value: object, language: str, errors: list[str]) -> str | None:
    if not isinstance(value, str) or not value.strip():
        errors.append("runtime.executable must name a local Python or R executable")
        return None
    candidate = value.strip()
    resolved = (
        str(Path(candidate).expanduser().resolve())
        if Path(candidate).expanduser().is_absolute()
        else shutil.which(candidate)
    )
    if not resolved or not Path(resolved).is_file():
        guidance = (
            "Select an installed Python executable in runtime.json; dependencies are not "
            "installed automatically."
            if language == "python"
            else "Install R separately and declare an existing Rscript executable in runtime.json."
        )
        errors.append(f"runtime executable {candidate!r} was not found. {guidance}")
        return None
    basename = Path(resolved).name.lower()
    if language == "python" and "python" not in basename:
        errors.append("runtime.executable must be a Python executable for language=python")
    if language == "r" and "rscript" not in basename:
        errors.append("runtime.executable must be Rscript for language=r")
    return resolved


def _check_packages(
    language: str,
    executable: str,
    packages: Sequence[Mapping[str, str | None]],
    errors: list[str],
) -> dict[str, str]:
    if not packages:
        return {}
    if language == "python":
        probe = (
            "import importlib.metadata as m,importlib.util as u,json,sys;"
            "p=json.loads(sys.argv[1]);r={};missing=[];"
            "\nfor x in p:\n"
            " i=x['import'];n=x['name'];"
            "\n if u.find_spec(i) is None: missing.append(i)"
            "\n else:\n"
            "  try:r[n]=m.version(n)\n"
            "  except m.PackageNotFoundError:r[n]='unknown'"
            "\nprint(json.dumps({'versions':r,'missing':missing},sort_keys=True))"
        )
        command = [executable, "-c", probe, json.dumps(packages)]
    else:
        names = [str(item["name"]) for item in packages]
        quoted = ",".join(json.dumps(name) for name in names)
        probe = (
            f"p<-c({quoted});m<-p[!vapply(p,requireNamespace,logical(1),quietly=TRUE)];"
            "if(length(m)){cat(paste(m,collapse=','));quit(status=2)};"
            "cat(paste(vapply(p,function(x)as.character(packageVersion(x)),character(1)),collapse=','))"
        )
        command = [executable, "-e", probe]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        errors.append(f"could not inspect declared runtime packages: {exc}")
        return {}
    if result.returncode != 0:
        missing = result.stdout.strip() or result.stderr.strip() or "unknown package"
        errors.append(
            f"declared runtime package is unavailable ({missing}). "
            "Install it in the declared local runtime or choose another runtime; "
            "Paperclip does not install dependencies."
        )
        return {}
    if language == "r":
        versions = result.stdout.strip().split(",")
        return {
            str(item["name"]): versions[index] if index < len(versions) else "unknown"
            for index, item in enumerate(packages)
        }
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        errors.append("Python runtime package probe returned invalid output")
        return {}
    missing = payload.get("missing", [])
    if missing:
        errors.append(
            f"declared Python imports are unavailable: {missing}. Install them in "
            "the declared local runtime; Paperclip does not install dependencies."
        )
    versions = payload.get("versions", {})
    for package in packages:
        expected = package.get("version")
        actual = versions.get(package["name"])
        if expected and actual != expected:
            errors.append(
                f"runtime package {package['name']} version is {actual!r}, expected {expected!r}"
            )
    return {str(key): str(value) for key, value in versions.items()}


def validate_bundle(
    project: AnalysisProject,
    *,
    check_runtime: bool = True,
) -> BundleValidation:
    """Validate bundle files, frozen inputs, source policy, and local runtime."""
    topic = Path(project.topic_dir).expanduser().resolve()
    analysis_dir = topic / ANALYSIS_DIRECTORY
    report = BundleValidation(str(topic), str(analysis_dir))
    if not analysis_dir.is_dir():
        report.errors.append(f"missing managed analysis directory: {analysis_dir}")
        return report
    spec_path = analysis_dir / SPEC_FILENAME
    runtime_path = analysis_dir / RUNTIME_FILENAME
    methods_path = analysis_dir / METHODS_FILENAME
    spec = _load_object(spec_path, report.errors)
    runtime = _load_object(runtime_path, report.errors)
    if not methods_path.is_file():
        report.errors.append(f"missing managed-analysis artifact: {METHODS_FILENAME}")
        methods = ""
    else:
        try:
            methods = methods_path.read_text(encoding="utf-8")
        except OSError as exc:
            report.errors.append(f"cannot read {METHODS_FILENAME}: {exc}")
            methods = ""
        if not methods.strip():
            report.errors.append("methods.md must not be empty")

    if spec.get("schema_version") != RUN_SCHEMA_VERSION:
        report.errors.append(f"analysis_spec.schema_version must be {RUN_SCHEMA_VERSION}")
    analysis_type = spec.get("analysis_type", spec.get("type"))
    if not isinstance(analysis_type, str) or analysis_type not in ANALYSIS_TYPES:
        report.errors.append(
            "analysis_spec.analysis_type must be one of: " + ", ".join(ANALYSIS_TYPES)
        )
        analysis_type = None
    report.analysis_type = analysis_type
    finalized = spec.get("finalized") is True or spec.get("status") in {
        "final",
        "finalized",
        "approved",
    }
    if not finalized:
        report.errors.append("analysis_spec.json must be finalized before execution")

    approved = _approved_evidence_hashes(project, report.errors)
    frozen_evidence: list[dict[str, str]] = []
    for name, digest in sorted(approved.items()):
        candidate = (topic / name).resolve()
        try:
            candidate.relative_to(topic)
        except ValueError:
            report.errors.append(f"approved evidence path points outside the topic: {name}")
            continue
        if not _SHA256_RE.fullmatch(digest):
            report.errors.append(f"approved evidence has an invalid SHA-256 for {name}")
        elif not candidate.is_file():
            report.errors.append(f"approved evidence artifact is missing: {name}")
        else:
            actual = sha256_file(candidate)
            if actual != digest:
                report.errors.append(f"approved evidence artifact changed: {name}")
            frozen_evidence.append({"path": name, "sha256": actual})
    inputs = _normalize_inputs(spec, report.errors)
    resolved_inputs: list[dict[str, str]] = []
    for index, declaration in enumerate(inputs):
        path = _resolve_input(topic, analysis_dir, declaration["path"])
        try:
            relative = str(path.relative_to(topic))
        except ValueError:
            report.errors.append(
                f"analysis_spec.inputs[{index}] points outside the topic directory"
            )
            continue
        expected = declaration["sha256"]
        if not _SHA256_RE.fullmatch(expected):
            report.errors.append(
                f"analysis_spec.inputs[{index}].sha256 must be a lowercase SHA-256"
            )
            continue
        approved_hash = approved.get(relative)
        is_dynamic_inputs = not project.legacy_import and relative == ANALYSIS_INPUTS_FILENAME
        if approved_hash is None and not is_dynamic_inputs:
            report.errors.append(
                f"analysis input {relative} is not in the approved evidence source map"
            )
            continue
        if approved_hash is not None and approved_hash != expected:
            report.errors.append(f"analysis input {relative} hash does not match approved evidence")
        if not path.is_file():
            report.errors.append(f"analysis input is missing: {relative}")
            continue
        actual = sha256_file(path)
        if actual != expected:
            report.errors.append(f"analysis input changed after specification: {relative}")
        resolved_inputs.append({"path": relative, "sha256": actual})
    if project.legacy_import:
        if not any(item["path"] == "effects.json" for item in resolved_inputs):
            report.errors.append("analysis_spec.inputs must include approved effects.json")
    else:
        guided_sources = {
            "verified_findings.json",
            "evidence_proposal.json",
            ANALYSIS_INPUTS_FILENAME,
        }
        if not any(item["path"] in guided_sources for item in resolved_inputs):
            report.errors.append(
                "analysis_spec.inputs must include verified findings, evidence "
                "proposal, or validated analysis_inputs.json"
            )
        dynamic_input = next(
            (item for item in resolved_inputs if item["path"] == ANALYSIS_INPUTS_FILENAME),
            None,
        )
        if dynamic_input is not None:
            try:
                analysis_inputs = json.loads(
                    (topic / ANALYSIS_INPUTS_FILENAME).read_text(encoding="utf-8")
                )
                verified_findings = json.loads(
                    (topic / "verified_findings.json").read_text(encoding="utf-8")
                )
            except (OSError, json.JSONDecodeError) as exc:
                report.errors.append(f"cannot validate {ANALYSIS_INPUTS_FILENAME}: {exc}")
            else:
                validation = validate_analysis_inputs(
                    analysis_inputs,
                    verified_findings,
                    analysis_spec=spec,
                )
                report.errors.extend(
                    f"{ANALYSIS_INPUTS_FILENAME}: {error}" for error in validation.errors
                )

    if runtime.get("schema_version") != RUN_SCHEMA_VERSION:
        report.errors.append(f"runtime.schema_version must be {RUN_SCHEMA_VERSION}")
    language_value = runtime.get("language")
    language = str(language_value).strip().lower() if isinstance(language_value, str) else ""
    if language not in {"python", "r"}:
        report.errors.append("runtime.language must be 'python' or 'r'")
    source_value = runtime.get("entrypoint", runtime.get("source"))
    suffixes = (".py",) if language == "python" else (".r", ".R")
    source = _safe_relative(
        analysis_dir,
        source_value,
        "runtime.entrypoint",
        report.errors,
        suffixes=suffixes,
    )
    if source is not None and not source.is_file():
        report.errors.append(f"runtime entrypoint is missing: {source.name}")
    source_hash = runtime.get("source_sha256")
    if not isinstance(source_hash, str) or not _SHA256_RE.fullmatch(source_hash):
        report.errors.append("runtime.source_sha256 must be a lowercase SHA-256")
    elif source is not None and source.is_file() and sha256_file(source) != source_hash:
        report.errors.append("runtime.source_sha256 does not match the analysis source")

    tests_value = runtime.get("tests", spec.get("tests"))
    if not isinstance(tests_value, list) or not tests_value:
        report.errors.append("runtime.tests must declare at least one local test script")
        tests_value = []
    tests: list[Path] = []
    for index, value in enumerate(tests_value):
        test = _safe_relative(
            analysis_dir,
            value,
            f"runtime.tests[{index}]",
            report.errors,
            suffixes=suffixes,
        )
        if test is not None:
            if not test.is_file():
                report.errors.append(f"declared analysis test is missing: {test.name}")
            else:
                tests.append(test)

    outputs = spec.get("outputs", {})
    if not isinstance(outputs, Mapping):
        report.errors.append("analysis_spec.outputs must be an object")
        outputs = {}
    analysis_output = outputs.get("analysis", spec.get("output", RESULTS_FILENAME))
    diagnostics_output = outputs.get("diagnostics", DIAGNOSTICS_FILENAME)
    if analysis_output != RESULTS_FILENAME:
        report.errors.append(f"analysis output path must be {RESULTS_FILENAME!r}")
    if diagnostics_output != DIAGNOSTICS_FILENAME:
        report.errors.append(f"diagnostics output path must be {DIAGNOSTICS_FILENAME!r}")

    timeout = runtime.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS)
    if (
        not isinstance(timeout, int)
        or isinstance(timeout, bool)
        or not 1 <= timeout <= MAX_TIMEOUT_SECONDS
    ):
        report.errors.append(
            f"runtime.timeout_seconds must be an integer from 1 to {MAX_TIMEOUT_SECONDS}"
        )
        timeout = DEFAULT_TIMEOUT_SECONDS
    seed = runtime.get("seed", spec.get("seed", 20260730))
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        report.errors.append("runtime.seed must be a non-negative integer")
        seed = 20260730

    packages = _package_declarations(runtime, report.errors)
    executable = _resolve_executable(runtime.get("executable"), language, report.errors)
    code_paths = ([source] if source is not None and source.is_file() else []) + tests
    _validate_imports(language, code_paths, runtime, packages, report.errors)
    installed_versions: dict[str, str] = {}
    if check_runtime and executable:
        installed_versions = _check_packages(language, executable, packages, report.errors)

    examples = runtime.get("examples", [])
    if examples:
        if not isinstance(examples, list):
            report.errors.append("runtime.examples must be an array")
        else:
            spec_hash = sha256_file(spec_path) if spec_path.is_file() else ""
            if runtime.get("analysis_spec_sha256") != spec_hash:
                report.errors.append(
                    "runtime.analysis_spec_sha256 must freeze the finalized spec before examples"
                )
            for example in examples:
                if not isinstance(example, Mapping) or not isinstance(example.get("id"), str):
                    report.errors.append("runtime examples require an id")
                    continue
                if "deviations" not in example:
                    report.errors.append(
                        f"runtime example {example.get('id')!r} must record deviations"
                    )
                if str(example["id"]) not in methods:
                    report.errors.append(
                        f"methods.md must record selected example {example['id']!r}"
                    )

    report.plan = {
        "language": language,
        "executable": executable,
        "entrypoint": (str(source.relative_to(analysis_dir)) if source is not None else None),
        "tests": [str(path.relative_to(analysis_dir)) for path in tests],
        "inputs": resolved_inputs,
        "frozen_evidence": frozen_evidence,
        "outputs": [RESULTS_FILENAME, DIAGNOSTICS_FILENAME, EXECUTION_FILENAME],
        "timeout_seconds": timeout,
        "seed": seed,
        "packages": packages,
        "installed_package_versions": installed_versions,
        "source_sha256": sha256_file(source) if source is not None and source.is_file() else None,
        "test_sha256": {str(path.relative_to(analysis_dir)): sha256_file(path) for path in tests},
        "analysis_spec_sha256": sha256_file(spec_path) if spec_path.is_file() else None,
        "runtime_sha256": sha256_file(runtime_path) if runtime_path.is_file() else None,
        "methods_sha256": sha256_file(methods_path) if methods_path.is_file() else None,
    }
    return report


def _atomic_json(path: Path, value: object) -> None:
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _copy_atomic(source: Path, target: Path) -> None:
    temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
    shutil.copyfile(source, temporary)
    os.replace(temporary, target)


def _current_hashes(
    topic: Path, declarations: Sequence[Mapping[str, str]]
) -> dict[str, str | None]:
    return {
        declaration["path"]: (
            sha256_file(topic / declaration["path"])
            if (topic / declaration["path"]).is_file()
            else None
        )
        for declaration in declarations
    }


def execute_analysis(
    project: AnalysisProject,
    *,
    dry_run: bool = False,
    timeout_seconds: int | None = None,
) -> dict[str, Any]:
    """Preflight and optionally execute the declared local analysis and tests."""
    validation = validate_bundle(project, check_runtime=True)
    if not validation.ok:
        raise AnalysisRunError("; ".join(validation.errors))
    plan = dict(validation.plan)
    if timeout_seconds is not None:
        if not 1 <= timeout_seconds <= MAX_TIMEOUT_SECONDS:
            raise AnalysisRunError(f"timeout must be from 1 to {MAX_TIMEOUT_SECONDS} seconds")
        plan["timeout_seconds"] = timeout_seconds
    if dry_run:
        return {
            "ok": True,
            "dry_run": True,
            "message": "Managed analysis preflight passed; no code was executed.",
            "validation": validation.to_dict(),
        }

    topic = Path(project.topic_dir).resolve()
    analysis_dir = topic / ANALYSIS_DIRECTORY
    frozen_evidence = plan["frozen_evidence"]
    before = _current_hashes(topic, frozen_evidence)
    output = analysis_dir / RESULTS_FILENAME
    output.unlink(missing_ok=True)
    executable = str(plan["executable"])
    language = str(plan["language"])
    commands: list[list[str]] = []
    for test in plan["tests"]:
        commands.append([executable, "-B", test] if language == "python" else [executable, test])
    entrypoint = str(plan["entrypoint"])
    commands.append(
        [executable, "-B", entrypoint] if language == "python" else [executable, entrypoint]
    )
    env = os.environ.copy()
    seed = str(plan["seed"])
    env.update(
        {
            "PAPERCLIP_ANALYSIS_SEED": seed,
            "PYTHONHASHSEED": seed,
            "RNG_SEED": seed,
            "OMP_NUM_THREADS": "1",
            "OPENBLAS_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
        }
    )
    started = utc_now()
    started_clock = time.monotonic()
    stdout_parts: list[str] = []
    stderr_parts: list[str] = []
    command_records: list[dict[str, Any]] = []
    status = "success"
    failure: str | None = None
    for command_index, command in enumerate(commands):
        if command_index == len(commands) - 1:
            # Tests cannot satisfy the production output obligation.
            output.unlink(missing_ok=True)
        remaining = int(plan["timeout_seconds"] - (time.monotonic() - started_clock))
        if remaining <= 0:
            status = "timeout"
            failure = f"analysis exceeded the {plan['timeout_seconds']} second timeout"
            break
        try:
            result = subprocess.run(
                command,
                cwd=analysis_dir,
                env=env,
                capture_output=True,
                text=True,
                timeout=remaining,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            timeout_stdout = exc.stdout or ""
            timeout_stderr = exc.stderr or ""
            stdout_parts.append(
                timeout_stdout.decode(errors="replace")
                if isinstance(timeout_stdout, bytes)
                else timeout_stdout
            )
            stderr_parts.append(
                timeout_stderr.decode(errors="replace")
                if isinstance(timeout_stderr, bytes)
                else timeout_stderr
            )
            status = "timeout"
            failure = f"analysis exceeded the {plan['timeout_seconds']} second timeout"
            break
        except OSError as exc:
            status = "failed"
            failure = f"could not invoke local runtime: {exc}"
            break
        stdout_parts.append(result.stdout)
        stderr_parts.append(result.stderr)
        command_records.append({"argv": command, "returncode": result.returncode})
        if result.returncode != 0:
            status = "failed"
            failure = (
                f"{command[-1]} exited with status {result.returncode}; "
                "inspect analysis/execution.json stderr"
            )
            break

    after = _current_hashes(topic, frozen_evidence)
    mutated = {
        name: {"before": before.get(name), "after": after.get(name)}
        for name in before
        if before.get(name) != after.get(name)
    }
    if mutated:
        status = "evidence_mutated"
        failure = "analysis code mutated frozen evidence: " + ", ".join(sorted(mutated))

    stdout = "".join(stdout_parts)
    stderr = "".join(stderr_parts)
    output_hash: str | None = None
    contract: dict[str, Any] | None = None
    if status == "success":
        if not output.is_file():
            status = "failed"
            failure = f"analysis did not create {RESULTS_FILENAME}"
        else:
            effects = topic / "effects.json" if project.legacy_import else None
            report = validate_analysis_file(
                output,
                effects,
                expected_type=validation.analysis_type,
            )
            contract = report.to_dict()
            if not report.ok:
                status = "invalid_output"
                failure = "analysis output contract failed: " + "; ".join(report.errors)
            else:
                output_hash = sha256_file(output)
                _copy_atomic(output, topic / RESULTS_FILENAME)

    diagnostics = {
        "schema_version": RUN_SCHEMA_VERSION,
        "status": "pass" if status == "success" else "fail",
        "analysis_type": validation.analysis_type,
        "contract": contract,
        "frozen_evidence_mutations": mutated,
        "runtime_packages": plan["installed_package_versions"],
    }
    _atomic_json(analysis_dir / DIAGNOSTICS_FILENAME, diagnostics)
    execution = {
        "schema_version": RUN_SCHEMA_VERSION,
        "status": status,
        "started_at": started,
        "completed_at": utc_now(),
        "duration_seconds": round(time.monotonic() - started_clock, 6),
        "local_execution": True,
        "security_model": (
            "Trusted local author with static import checks and post-run hash verification; "
            "not a security sandbox."
        ),
        "seed": plan["seed"],
        "timeout_seconds": plan["timeout_seconds"],
        "cwd": str(analysis_dir),
        "commands": command_records,
        "analysis_type": validation.analysis_type,
        "analysis_spec_sha256": plan["analysis_spec_sha256"],
        "runtime_sha256": plan["runtime_sha256"],
        "methods_sha256": plan["methods_sha256"],
        "source_sha256": plan["source_sha256"],
        "test_sha256": plan["test_sha256"],
        "input_hashes_before": before,
        "input_hashes_after": after,
        "output_path": RESULTS_FILENAME,
        "analysis_sha256": output_hash,
        "diagnostics_sha256": sha256_file(analysis_dir / DIAGNOSTICS_FILENAME),
        "stdout": stdout,
        "stderr": stderr,
        "failure": failure,
    }
    _atomic_json(analysis_dir / EXECUTION_FILENAME, execution)
    if status != "success":
        raise AnalysisRunError(failure or f"analysis execution ended with status {status}")
    return {
        "ok": True,
        "dry_run": False,
        "message": "Managed analysis completed and output contract passed.",
        "analysis_type": validation.analysis_type,
        "analysis_sha256": output_hash,
        "execution_sha256": sha256_file(analysis_dir / EXECUTION_FILENAME),
        "diagnostics_sha256": execution["diagnostics_sha256"],
        "execution": execution,
    }


def validate_current_execution(project: AnalysisProject) -> dict[str, Any]:
    """Validate that code, evidence, manifests, and both result copies are current."""
    validation = validate_bundle(project, check_runtime=False)
    errors = list(validation.errors)
    topic = Path(project.topic_dir).resolve()
    analysis_dir = topic / ANALYSIS_DIRECTORY
    execution_path = analysis_dir / EXECUTION_FILENAME
    execution = _load_object(execution_path, errors)
    if execution.get("status") != "success":
        errors.append("analysis/execution.json does not record a successful execution")
    plan = validation.plan
    expected_fields = {
        "analysis_spec_sha256": plan.get("analysis_spec_sha256"),
        "runtime_sha256": plan.get("runtime_sha256"),
        "methods_sha256": plan.get("methods_sha256"),
        "source_sha256": plan.get("source_sha256"),
    }
    for name, expected in expected_fields.items():
        if execution.get(name) != expected:
            errors.append(f"analysis execution is stale: {name} changed")
    if execution.get("test_sha256") != plan.get("test_sha256"):
        errors.append("analysis execution is stale: declared tests changed")
    current_inputs = {item["path"]: item["sha256"] for item in plan.get("frozen_evidence", [])}
    if execution.get("input_hashes_after") != current_inputs:
        errors.append("analysis execution is stale: approved inputs changed")

    nested = analysis_dir / RESULTS_FILENAME
    root_result = topic / RESULTS_FILENAME
    recorded_output = execution.get("analysis_sha256")
    if not isinstance(recorded_output, str) or not _SHA256_RE.fullmatch(recorded_output):
        errors.append("analysis execution has no valid analysis_sha256")
    else:
        for path in (nested, root_result):
            if not path.is_file():
                errors.append(f"current managed result is missing: {path}")
            elif sha256_file(path) != recorded_output:
                errors.append(f"analysis execution is stale: {path.name} hash changed")
    contract = (
        validate_analysis_file(
            nested,
            topic / "effects.json" if project.legacy_import else None,
            expected_type=validation.analysis_type,
        )
        if nested.is_file()
        else None
    )
    if contract is not None and not contract.ok:
        errors.extend(f"analysis contract: {error}" for error in contract.errors)
    return {
        "ok": not errors,
        "errors": errors,
        "analysis_type": validation.analysis_type,
        "analysis_sha256": recorded_output,
        "execution_sha256": (sha256_file(execution_path) if execution_path.is_file() else None),
        "contract": contract.to_dict() if contract is not None else None,
    }
