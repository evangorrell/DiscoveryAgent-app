"""Lifecycle transitions and deterministic artifact gates."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from gxl_paperclip.meta_analysis.export_verified import validate_verified_findings

from .contracts import (
    ANALYSIS_INPUTS_FILENAME,
    COLLECTION_SPEC_FILENAME,
    EVIDENCE_PROPOSAL_FILENAME,
    HARMONIZATION_MAP_FILENAME,
    HARMONIZATION_QUEUE_FILENAME,
    PLANNED_OUTPUTS_FILENAME,
    collection_schema_hash,
    mark_pilot_needs_rerun,
    record_pilot_summary,
    validate_collection_spec,
    validate_evidence_proposal,
    validate_harmonization_map,
    validate_planned_outputs,
)
from .evidence import EVIDENCE_REVIEW_FILENAME, validate_evidence_review_sources
from .models import STAGES, AnalysisProject, Approval, utc_now
from .schema_optimization import (
    EXTRACTION_SCHEMA_FILENAME,
    SCHEMA_LOCK_FILENAME,
    SCHEMA_OBSERVATIONS_FILENAME,
    SCHEMA_OPTIMIZATION_FILENAME,
)
from .store import atomic_copy_file, atomic_write_json, sha256_file

LEGACY_QUESTION_ARTIFACTS = ("protocol_draft.json", "source_readiness.json")
QUESTION_ARTIFACTS = (
    *LEGACY_QUESTION_ARTIFACTS,
    COLLECTION_SPEC_FILENAME,
    PLANNED_OUTPUTS_FILENAME,
)
LEGACY_EVIDENCE_ARTIFACTS = (EVIDENCE_REVIEW_FILENAME, "effects.json")
EVIDENCE_ARTIFACTS = (
    EVIDENCE_REVIEW_FILENAME,
    "verified_findings.json",
    EVIDENCE_PROPOSAL_FILENAME,
    HARMONIZATION_MAP_FILENAME,
)
RESULTS_QA_ARTIFACTS = (
    "data_qa.json",
    "report_spec.json",
    "index.html",
    "render_qa.json",
)
PASSING_QA_ARTIFACTS = ("data_qa.json", "render_qa.json")

# Stable upload order. Optional artifacts are included only when they exist.
PUBLISH_ARTIFACTS = (
    "protocol_draft.json",
    "source_readiness.json",
    COLLECTION_SPEC_FILENAME,
    PLANNED_OUTPUTS_FILENAME,
    SCHEMA_OPTIMIZATION_FILENAME,
    EXTRACTION_SCHEMA_FILENAME,
    SCHEMA_LOCK_FILENAME,
    SCHEMA_OBSERVATIONS_FILENAME,
    "extraction_plan.json",
    "extraction_merge.json",
    "protocol.json",
    "verified_findings.json",
    EVIDENCE_PROPOSAL_FILENAME,
    HARMONIZATION_MAP_FILENAME,
    HARMONIZATION_QUEUE_FILENAME,
    ANALYSIS_INPUTS_FILENAME,
    "effects.json",
    EVIDENCE_REVIEW_FILENAME,
    "contexts.json",
    "study_characteristics.json",
    "quality_assessments.json",
    "analysis/analysis_spec.json",
    "analysis/methods.md",
    "analysis/runtime.json",
    "analysis/execution.json",
    "analysis/diagnostics.json",
    "analysis.json",
    "synthesis.json",
    "search_log.json",
    "extraction_audit.json",
    "data_qa.json",
    "prisma_checklist.json",
    "report_spec.json",
    "dashboard_spec.json",
    "index.html",
    "render_qa.json",
    "card_direct.jpg",
)


def question_artifacts(project: AnalysisProject) -> tuple[str, ...]:
    """Return the question contract for guided or explicit legacy imports."""
    return LEGACY_QUESTION_ARTIFACTS if project.legacy_import else QUESTION_ARTIFACTS


def evidence_artifacts(project: AnalysisProject) -> tuple[str, ...]:
    """Return the evidence contract for guided or explicit legacy imports."""
    return LEGACY_EVIDENCE_ARTIFACTS if project.legacy_import else EVIDENCE_ARTIFACTS


@dataclass
class GateReport:
    """Machine- and human-readable result of an artifact checkpoint."""

    stage: str
    required: list[str]
    hashes: dict[str, str] = field(default_factory=dict)
    missing: list[str] = field(default_factory=list)
    invalid: dict[str, str] = field(default_factory=dict)
    changed: dict[str, dict[str, str | None]] = field(default_factory=dict)
    gate_failures: dict[str, str] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not (self.missing or self.invalid or self.changed or self.gate_failures)

    @property
    def blockers(self) -> list[str]:
        blockers = [f"missing artifact: {name}" for name in self.missing]
        blockers.extend(
            f"invalid artifact {name}: {reason}" for name, reason in self.invalid.items()
        )
        blockers.extend(f"artifact changed since approval: {name}" for name in self.changed)
        blockers.extend(
            f"gate failed for {name}: {reason}" for name, reason in self.gate_failures.items()
        )
        return blockers

    def to_dict(self) -> dict[str, Any]:
        return {
            "stage": self.stage,
            "ok": self.ok,
            "required": self.required,
            "hashes": dict(sorted(self.hashes.items())),
            "missing": self.missing,
            "invalid": self.invalid,
            "changed": self.changed,
            "gate_failures": self.gate_failures,
            "blockers": self.blockers,
        }


def _load_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate_harmonization_artifact(
    project: AnalysisProject,
    root: Path,
    parsed: object,
) -> str | None:
    collection_path = root / COLLECTION_SPEC_FILENAME
    verified_path = root / "verified_findings.json"
    proposal_path = root / EVIDENCE_PROPOSAL_FILENAME
    queue_path = root / HARMONIZATION_QUEUE_FILENAME
    try:
        collection = _load_json(collection_path)
        if not isinstance(collection, Mapping):
            raise ValueError(f"{COLLECTION_SPEC_FILENAME} must contain an object")
        collection_hash = collection_schema_hash(collection)
        verified_hash = sha256_file(verified_path)
        proposal_hash = sha256_file(proposal_path) if proposal_path.is_file() else None
        queue = _load_json(queue_path) if queue_path.is_file() else None
        queue_hash = sha256_file(queue_path) if queue_path.is_file() else None
    except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
        return f"cannot validate harmonization source bindings: {exc}"
    validation = validate_harmonization_map(
        parsed,
        collection_hash=collection_hash,
        verified_findings_sha256=verified_hash,
        evidence_proposal_sha256=proposal_hash,
        harmonization_queue=queue,
        harmonization_queue_sha256=queue_hash,
        final=True,
    )
    return "; ".join(validation.errors) if not validation.ok else None


def validate_artifacts(
    project: AnalysisProject,
    required: Iterable[str],
    *,
    stage: str,
    snapshot: dict[str, str] | None = None,
    passing_qa: Iterable[str] = (),
) -> GateReport:
    """Validate required files, contracts, hashes, and explicit QA statuses."""
    names = list(required)
    report = GateReport(stage=stage, required=names)
    root = Path(project.topic_dir)
    passing = set(passing_qa)

    for name in names:
        path = root / name
        if not path.is_file():
            report.missing.append(name)
            continue
        try:
            report.hashes[name] = sha256_file(path)
        except OSError as exc:
            report.invalid[name] = str(exc)
            continue

        parsed: object | None = None
        if path.suffix.lower() == ".json":
            try:
                parsed = _load_json(path)
            except (json.JSONDecodeError, OSError) as exc:
                report.invalid[name] = str(exc)
                continue

        if name in passing:
            if not isinstance(parsed, dict):
                report.gate_failures[name] = "QA report must be a JSON object"
            elif str(parsed.get("status", "")).lower() != "pass":
                actual = parsed.get("status", "missing")
                report.gate_failures[name] = f"status is {actual!r}, expected 'pass'"

        if name == EVIDENCE_REVIEW_FILENAME:
            source_errors = validate_evidence_review_sources(root, parsed)
            if source_errors:
                report.gate_failures[name] = "; ".join(source_errors)
            elif not project.legacy_import and isinstance(parsed, dict):
                for readiness_name in (
                    "analysis_readiness",
                    "visualization_readiness",
                ):
                    readiness = parsed.get(readiness_name)
                    if not isinstance(readiness, dict) or not isinstance(
                        readiness.get("outputs"),
                        list,
                    ):
                        report.gate_failures[name] = f"{readiness_name} is missing or invalid"
                        break
        elif name == COLLECTION_SPEC_FILENAME:
            validation = validate_collection_spec(parsed)
            if not validation.ok:
                report.gate_failures[name] = "; ".join(validation.errors)
        elif name == PLANNED_OUTPUTS_FILENAME:
            validation = validate_planned_outputs(parsed)
            if not validation.ok:
                report.gate_failures[name] = "; ".join(validation.errors)
        elif name == "verified_findings.json":
            errors = validate_verified_findings(parsed)
            if errors:
                report.gate_failures[name] = "; ".join(errors)
        elif name == EVIDENCE_PROPOSAL_FILENAME:
            verified_path = root / "verified_findings.json"
            try:
                verified = _load_json(verified_path)
            except (OSError, json.JSONDecodeError) as exc:
                report.gate_failures[name] = (
                    f"cannot validate proposal without verified findings: {exc}"
                )
            else:
                validation = validate_evidence_proposal(parsed, verified)
                if not validation.ok:
                    report.gate_failures[name] = "; ".join(validation.errors)
        elif name == HARMONIZATION_MAP_FILENAME:
            error = _validate_harmonization_artifact(project, root, parsed)
            if error:
                report.gate_failures[name] = error

    for name, expected in (snapshot or {}).items():
        actual = report.hashes.get(name)
        if actual != expected:
            report.changed[name] = {"expected": expected, "actual": actual}
    return report


def _merge_reports(stage: str, reports: Iterable[GateReport]) -> GateReport:
    reports = list(reports)
    merged = GateReport(
        stage=stage,
        required=list(dict.fromkeys(name for report in reports for name in report.required)),
    )
    for report in reports:
        merged.hashes.update(report.hashes)
        merged.missing.extend(name for name in report.missing if name not in merged.missing)
        merged.invalid.update(report.invalid)
        merged.changed.update(report.changed)
        merged.gate_failures.update(report.gate_failures)
    return merged


def validate_frozen_artifacts(project: AnalysisProject) -> GateReport:
    """Check that every approved/frozen artifact still matches its snapshot."""
    reports = [
        validate_artifacts(
            project,
            approval.artifact_hashes,
            stage=name,
            snapshot=approval.artifact_hashes,
        )
        for name, approval in project.approvals.items()
        if name in ("question", "evidence")
    ]
    return _merge_reports(project.stage, reports)


def _validate_results_qa(project: AnalysisProject, current: GateReport) -> None:
    root = Path(project.topic_dir)
    managed_result_present = (root / "analysis").is_dir() or (root / "analysis.json").is_file()
    if managed_result_present:
        # Lazy imports avoid report/lifecycle import cycles and runtime checks at import.
        from .analysis_run import validate_current_execution

        execution = validate_current_execution(project)
        if not execution["ok"]:
            current.gate_failures["analysis_execution"] = "; ".join(execution["errors"])
        data_qa_path = root / "data_qa.json"
        if data_qa_path.is_file():
            try:
                data_qa = _load_json(data_qa_path)
            except (OSError, json.JSONDecodeError):
                data_qa = None
            if isinstance(data_qa, dict):
                if data_qa.get("analysis_execution_sha256") != execution.get("execution_sha256"):
                    current.gate_failures["data_qa.json"] = (
                        "analysis_execution_sha256 does not match the current execution"
                    )
                elif data_qa.get("analysis_sha256") != execution.get("analysis_sha256"):
                    current.gate_failures["data_qa.json"] = (
                        "analysis_sha256 does not match the current managed result"
                    )

    from .report import validate_report_spec_file

    spec = validate_report_spec_file(root)
    if not spec.ok:
        current.gate_failures["report_spec.json"] = "; ".join(spec.errors)

    render_qa_path = root / "render_qa.json"
    if not render_qa_path.is_file():
        return
    try:
        render_qa = _load_json(render_qa_path)
    except (OSError, json.JSONDecodeError):
        render_qa = None
    if not isinstance(render_qa, dict):
        return
    expected_render_hashes = {
        "index_sha256": root / "index.html",
        "report_spec_sha256": root / "report_spec.json",
        "data_qa_sha256": root / "data_qa.json",
    }
    if (root / "dashboard_spec.json").is_file():
        expected_render_hashes["dashboard_spec_sha256"] = root / "dashboard_spec.json"
    if (root / "synthesis.json").is_file():
        expected_render_hashes["synthesis_sha256"] = root / "synthesis.json"
    for field_name, artifact_path in expected_render_hashes.items():
        if artifact_path.is_file() and render_qa.get(field_name) != sha256_file(artifact_path):
            current.gate_failures["render_qa.json"] = (
                f"{field_name} does not match the current report artifact"
            )
            break


def review_gate(project: AnalysisProject, stage: str | None = None) -> GateReport:
    """Review the requested checkpoint without mutating project state."""
    target = stage or project.stage
    if target not in STAGES:
        raise ValueError(f"Unknown stage {target!r}")

    frozen = validate_frozen_artifacts(project)
    if target == "question":
        current = validate_artifacts(
            project,
            question_artifacts(project),
            stage=target,
        )
    elif target == "evidence":
        current = validate_artifacts(
            project,
            evidence_artifacts(project),
            stage=target,
        )
    else:
        current = validate_artifacts(
            project,
            RESULTS_QA_ARTIFACTS,
            stage=target,
            passing_qa=PASSING_QA_ARTIFACTS,
        )
        _validate_results_qa(project, current)
    return _merge_reports(target, (frozen, current))


def _load_collection_spec(root: Path) -> dict[str, Any]:
    path = root / COLLECTION_SPEC_FILENAME
    try:
        value = _load_json(path)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read {COLLECTION_SPEC_FILENAME}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{COLLECTION_SPEC_FILENAME} must contain an object")
    return value


def _pilot_plan_hash(root: Path, spec: Mapping[str, Any]) -> str:
    """Bind the pilot to collection semantics and approved output/scope intent."""
    digest = hashlib.sha256()
    digest.update(collection_schema_hash(spec).encode("ascii"))
    for name in (PLANNED_OUTPUTS_FILENAME, "protocol_draft.json"):
        digest.update(b"\0")
        digest.update(sha256_file(root / name).encode("ascii"))
    return digest.hexdigest()


def _prepare_collection_approval(
    project: AnalysisProject,
    root: Path,
) -> None:
    """Invalidate a stale pilot before snapshotting a new approved plan."""
    if project.legacy_import:
        return
    spec = _load_collection_spec(root)
    current_plan_hash = _pilot_plan_hash(root, spec)
    if project.approved_pilot_plan_hash == current_plan_hash:
        return
    mark_pilot_needs_rerun(
        spec,
        reason=(
            "Material collection schema or approved output scope changed; "
            "rerun the representative pilot after this approval."
        ),
        recorded_at=utc_now(),
    )
    atomic_write_json(root / COLLECTION_SPEC_FILENAME, spec)


def approve_question(project: AnalysisProject) -> tuple[AnalysisProject, GateReport, bool]:
    """Snapshot question artifacts and advance from question to evidence."""
    root = Path(project.topic_dir)
    # Explicitly promote a reopened legacy project only when both guided
    # question contracts are present. No legacy evidence approval is reused.
    if project.legacy_import and all(
        (root / name).is_file() for name in (COLLECTION_SPEC_FILENAME, PLANNED_OUTPUTS_FILENAME)
    ):
        project.legacy_import = False
    if not project.legacy_import and (root / COLLECTION_SPEC_FILENAME).is_file():
        try:
            _prepare_collection_approval(project, root)
        except (OSError, TypeError, ValueError):
            # The ordinary artifact validator below reports the actionable error.
            pass

    report = validate_artifacts(
        project,
        question_artifacts(project),
        stage="question",
    )
    previous = project.approvals.get("question")
    canonical = root / "protocol.json"
    draft = root / "protocol_draft.json"
    if previous and canonical.is_file():
        report.required.append("protocol.json")
        report.hashes["protocol.json"] = sha256_file(canonical)
        if report.hashes["protocol.json"] != report.hashes.get("protocol_draft.json"):
            report.changed["protocol.json"] = {
                "expected": report.hashes.get("protocol_draft.json"),
                "actual": report.hashes["protocol.json"],
            }
        if previous.artifact_hashes == report.hashes and report.ok:
            return project, report, False
    if project.stage != "question":
        report.gate_failures["state"] = (
            f"project is at {project.stage!r}; Claude must run "
            "'python3 guided_analysis.py revise question' first"
        )
        return project, report, False
    if not report.ok:
        return project, report, False

    try:
        atomic_copy_file(draft, canonical)
        report.required.append("protocol.json")
        report.hashes["protocol.json"] = sha256_file(canonical)
    except OSError as exc:
        report.invalid["protocol.json"] = f"could not materialize approved protocol: {exc}"
        return project, report, False

    approval = Approval(
        approved_at=utc_now(),
        revision=project.revision,
        artifact_hashes=dict(report.hashes),
    )
    project.approvals["question"] = approval
    project.artifact_hashes.update(report.hashes)
    if not project.legacy_import:
        spec = _load_collection_spec(root)
        project.approved_collection_schema_hash = collection_schema_hash(spec)
        project.approved_pilot_plan_hash = _pilot_plan_hash(root, spec)
    project.stage = "evidence"
    project.status = "evidence_in_progress"
    project.next_action = (
        "iterate evidence_review.json, ask the user, then Claude runs "
        "python3 guided_analysis.py analyze only after an explicit answer"
    )
    return project, report, True


def complete_collection_pilot(
    project: AnalysisProject,
    summary: Mapping[str, Any],
) -> tuple[AnalysisProject, GateReport, bool]:
    """Record a passing representative pilot for the exact approved plan."""
    report = GateReport(stage="evidence", required=[COLLECTION_SPEC_FILENAME])
    if project.legacy_import:
        report.gate_failures[COLLECTION_SPEC_FILENAME] = (
            "legacy imports do not use the guided collection pilot"
        )
        return project, report, False
    if project.stage != "evidence" or "question" not in project.approvals:
        report.gate_failures["state"] = (
            "a collection pilot can be completed only after question approval and before analysis"
        )
        return project, report, False

    root = Path(project.topic_dir)
    try:
        spec = _load_collection_spec(root)
        schema_hash = collection_schema_hash(spec)
    except (OSError, TypeError, ValueError) as exc:
        report.invalid[COLLECTION_SPEC_FILENAME] = str(exc)
        return project, report, False
    if schema_hash != project.approved_collection_schema_hash:
        report.gate_failures[COLLECTION_SPEC_FILENAME] = (
            "material collection schema changed after question approval; "
            "revise and reapprove Question before rerunning the pilot"
        )
        return project, report, False
    try:
        current_plan_hash = _pilot_plan_hash(root, spec)
    except OSError as exc:
        report.invalid[COLLECTION_SPEC_FILENAME] = str(exc)
        return project, report, False
    if current_plan_hash != project.approved_pilot_plan_hash:
        report.gate_failures[COLLECTION_SPEC_FILENAME] = (
            "planned outputs or question scope changed after approval; revise "
            "and reapprove Question before rerunning the pilot"
        )
        return project, report, False
    if (
        spec.get("pilot_status") == "ready_for_scale"
        and spec.get("pilot_schema_hash") == schema_hash
        and spec.get("pilot_summary") == dict(summary)
    ):
        report.hashes[COLLECTION_SPEC_FILENAME] = sha256_file(root / COLLECTION_SPEC_FILENAME)
        return project, report, False

    validation = record_pilot_summary(
        spec,
        summary,
        recorded_at=utc_now(),
    )
    if not validation.ok:
        report.gate_failures[COLLECTION_SPEC_FILENAME] = "; ".join(validation.errors)
        return project, report, False
    try:
        atomic_write_json(root / COLLECTION_SPEC_FILENAME, spec)
        digest = sha256_file(root / COLLECTION_SPEC_FILENAME)
    except OSError as exc:
        report.invalid[COLLECTION_SPEC_FILENAME] = str(exc)
        return project, report, False
    report.hashes[COLLECTION_SPEC_FILENAME] = digest
    question_approval = project.approvals["question"]
    question_approval.artifact_hashes[COLLECTION_SPEC_FILENAME] = digest
    project.artifact_hashes[COLLECTION_SPEC_FILENAME] = digest
    _invalidate_schema_lock(project)
    project.status = "evidence_in_progress"
    project.next_action = (
        "finish verification, evidence proposal, harmonization, and readiness "
        "review before asking whether to analyze"
    )
    return project, report, True


def _invalidate_schema_lock(project: AnalysisProject) -> None:
    """Clear scaled-extraction readiness without deleting its audit artifacts."""
    project.schema_registry_sha256 = None
    project.extraction_schema_sha256 = None
    project.schema_lock_sha256 = None
    project.scaled_extraction_ready = False


def freeze_evidence(project: AnalysisProject) -> tuple[AnalysisProject, GateReport, bool]:
    """Validate evidence, freeze its hashes, and advance to results."""
    frozen = validate_frozen_artifacts(project)
    evidence = validate_artifacts(
        project,
        evidence_artifacts(project),
        stage="evidence",
    )
    report = _merge_reports("evidence", (frozen, evidence))
    if not project.legacy_import:
        root = Path(project.topic_dir)
        try:
            spec = _load_collection_spec(root)
        except ValueError as exc:
            report.gate_failures[COLLECTION_SPEC_FILENAME] = str(exc)
        else:
            collection_validation = validate_collection_spec(spec)
            if not collection_validation.ok:
                report.gate_failures[COLLECTION_SPEC_FILENAME] = "; ".join(
                    collection_validation.errors
                )
            elif spec.get("pilot_status") != "ready_for_scale":
                report.gate_failures[COLLECTION_SPEC_FILENAME] = (
                    "pilot_status must be ready_for_scale before analysis"
                )
            elif collection_schema_hash(spec) != project.approved_collection_schema_hash:
                report.gate_failures[COLLECTION_SPEC_FILENAME] = (
                    "the ready pilot is not bound to the latest approved collection schema"
                )
            else:
                try:
                    current_plan_hash = _pilot_plan_hash(root, spec)
                except OSError as exc:
                    report.gate_failures[COLLECTION_SPEC_FILENAME] = str(exc)
                else:
                    if current_plan_hash != project.approved_pilot_plan_hash:
                        report.gate_failures[COLLECTION_SPEC_FILENAME] = (
                            "the ready pilot is not bound to the latest approved "
                            "question and planned outputs"
                        )

    previous = project.approvals.get("evidence")
    if previous and previous.artifact_hashes == evidence.hashes and report.ok:
        return project, report, False
    if project.stage != "evidence":
        report.gate_failures["state"] = (
            f"project is at {project.stage!r}; evidence can only be analyzed from 'evidence'"
        )
        return project, report, False
    if "question" not in project.approvals:
        report.gate_failures["question"] = "question checkpoint has not been approved"
    if not report.ok:
        return project, report, False

    approval = Approval(
        approved_at=utc_now(),
        revision=project.revision,
        artifact_hashes=dict(evidence.hashes),
    )
    project.approvals["evidence"] = approval
    project.artifact_hashes.update(evidence.hashes)
    project.stage = "results"
    project.status = "results_analysis_pending"
    project.next_action = "Claude runs python3 guided_analysis.py run"
    from .report import build_results_binding

    project.results_binding = build_results_binding(
        project,
        reason="Evidence approved; results stage opened.",
    )
    return project, report, True


def revise_project(project: AnalysisProject, stage: str, question: str | None = None) -> None:
    """Increment the revision and invalidate approvals at and below ``stage``."""
    if stage not in STAGES:
        raise ValueError(f"Unknown stage {stage!r}")
    if STAGES.index(stage) > STAGES.index(project.stage):
        raise ValueError(
            f"Cannot revise future stage {stage!r} while project is at {project.stage!r}"
        )
    if question is not None:
        if stage != "question":
            raise ValueError("--question can only be used when revising the question stage")
        if not question.strip():
            raise ValueError("Question cannot be empty")
        project.question = question.strip()

    first = STAGES.index(stage)
    invalidated = set(STAGES[first:])
    for name in list(project.approvals):
        if name in invalidated:
            approval = project.approvals.pop(name)
            for artifact in list(approval.artifact_hashes):
                project.artifact_hashes.pop(artifact, None)

    project.revision += 1
    project.stage = stage
    if stage == "question":
        _invalidate_schema_lock(project)
        project.status = "awaiting_user"
        project.next_action = (
            "Ask the user; after explicit approval Claude runs "
            "python3 guided_analysis.py approve question"
        )
        project.results_binding = {}
    elif stage == "evidence":
        project.status = "evidence_in_progress"
        project.next_action = (
            "iterate evidence_review.json, ask the user, then Claude runs "
            "python3 guided_analysis.py analyze only after an explicit answer"
        )
        project.results_binding = {}
    else:
        project.status = "results_revision_in_progress"
        project.next_action = "revise report artifacts, run QA, preview, then explicitly publish"


def _declared_analysis_sources(root: Path) -> list[str]:
    runtime_path = root / "analysis" / "runtime.json"
    if not runtime_path.is_file():
        return []
    try:
        runtime = _load_json(runtime_path)
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(runtime, dict):
        return []
    declared_sources = [runtime.get("entrypoint")]
    tests = runtime.get("tests")
    if isinstance(tests, list):
        declared_sources.extend(tests)
    names: list[str] = []
    for declared in declared_sources:
        if not isinstance(declared, str) or not declared:
            continue
        candidate = (root / "analysis" / declared).resolve()
        try:
            relative = candidate.relative_to(root.resolve())
        except ValueError:
            continue
        name = relative.as_posix()
        if name not in names:
            names.append(name)
    return names


def validate_publish(project: AnalysisProject) -> tuple[GateReport, list[dict[str, Any]]]:
    """Validate the current results revision and build its exact upload inventory."""
    report = review_gate(project, "results")
    if project.stage != "results":
        report.gate_failures["state"] = (
            f"project is at {project.stage!r}; run analysis before publishing"
        )
    from .analysis_run import validate_current_execution
    from .report import validate_results_binding

    execution = validate_current_execution(project)
    if not execution["ok"]:
        report.gate_failures["analysis_execution"] = "; ".join(execution["errors"])
    binding_errors = validate_results_binding(project, execution)
    if binding_errors:
        report.gate_failures["results_revision"] = "; ".join(binding_errors)

    inventory: list[dict[str, Any]] = []
    root = Path(project.topic_dir)
    publish_artifacts = list(PUBLISH_ARTIFACTS)
    for name in _declared_analysis_sources(root):
        if name not in publish_artifacts:
            publish_artifacts.append(name)
    for name in publish_artifacts:
        path = root / name
        if path.is_file():
            inventory.append(
                {
                    "path": name,
                    "sha256": sha256_file(path),
                    "size_bytes": path.stat().st_size,
                }
            )
    return report, inventory
