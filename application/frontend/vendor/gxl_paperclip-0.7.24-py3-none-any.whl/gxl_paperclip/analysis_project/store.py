"""Atomic persistence and artifact hashing for analysis projects."""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from pathlib import Path

from .models import AnalysisProject, utc_now

STATE_FILENAME = "analysis_project.json"


class AnalysisStateError(RuntimeError):
    """Base class for actionable local-state failures."""


class MissingAnalysisState(AnalysisStateError):
    """The requested project state or active pointer does not exist."""


class CorruptAnalysisState(AnalysisStateError):
    """The requested project state exists but cannot be trusted."""


def config_dir() -> Path:
    """Resolve the config directory at call time so test/env overrides work."""
    configured = os.getenv("PAPERCLIP_CONFIG_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    return (Path.home() / ".paperclip").resolve()


def analyses_dir() -> Path:
    return config_dir() / "analyses"


def active_pointer() -> Path:
    return analyses_dir() / ".active"


def state_path(topic_dir: Path | str) -> Path:
    path = Path(topic_dir).expanduser()
    if path.name == STATE_FILENAME:
        return path.resolve()
    return (path / STATE_FILENAME).resolve()


def sha256_file(path: Path | str) -> str:
    """Compute the SHA-256 digest of a regular file."""
    target = Path(path)
    if not target.is_file():
        raise FileNotFoundError(str(target))
    digest = hashlib.sha256()
    with target.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_write(path: Path, content: str) -> None:
    """Write text through a sibling temp file and atomically replace ``path``."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temp.open("x", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def atomic_copy_file(source: Path | str, target: Path | str) -> None:
    """Atomically copy exact file bytes to a target path."""
    source_path = Path(source)
    target_path = Path(target)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    temp = target_path.with_name(f".{target_path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with source_path.open("rb") as source_handle, temp.open("xb") as target_handle:
            for chunk in iter(lambda: source_handle.read(1024 * 1024), b""):
                target_handle.write(chunk)
            target_handle.flush()
            os.fsync(target_handle.fileno())
        os.replace(temp, target_path)
    finally:
        temp.unlink(missing_ok=True)


def atomic_write_json(path: Path | str, value: object) -> None:
    """Atomically write canonical, human-readable JSON."""
    _atomic_write(
        Path(path),
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
    )


class AnalysisProjectStore:
    """Load and save project state and the process-independent active pointer."""

    def load(self, topic_dir: Path | str) -> AnalysisProject:
        path = state_path(topic_dir)
        if not path.exists():
            raise MissingAnalysisState(
                f"No analysis project at {path.parent}. "
                "Claude must run 'python3 guided_analysis.py start <slug> "
                "--dir <path> --question <text>'."
            )
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise CorruptAnalysisState(
                f"Analysis state is corrupt JSON at {path}: {exc.msg} "
                f"(line {exc.lineno}, column {exc.colno})."
            ) from exc
        except OSError as exc:
            raise CorruptAnalysisState(f"Cannot read analysis state at {path}: {exc}.") from exc
        try:
            project = AnalysisProject.from_dict(raw)
        except ValueError as exc:
            raise CorruptAnalysisState(f"Invalid analysis state at {path}: {exc}.") from exc
        if Path(project.topic_dir).expanduser().resolve() != path.parent:
            raise CorruptAnalysisState(
                f"Invalid analysis state at {path}: 'topic_dir' points to "
                f"{project.topic_dir}, not {path.parent}."
            )
        return project

    def save(self, project: AnalysisProject, *, touch: bool = True) -> Path:
        topic_dir = Path(project.topic_dir).expanduser().resolve()
        project.topic_dir = str(topic_dir)
        if touch:
            project.updated_at = utc_now()
        path = topic_dir / STATE_FILENAME
        payload = json.dumps(project.to_dict(), indent=2, sort_keys=True) + "\n"
        try:
            _atomic_write(path, payload)
        except OSError as exc:
            raise AnalysisStateError(f"Cannot save analysis state at {path}: {exc}.") from exc
        return path

    def set_active(self, topic_dir: Path | str) -> Path:
        topic = Path(topic_dir).expanduser().resolve()
        pointer = active_pointer()
        try:
            _atomic_write(pointer, f"{topic}\n")
        except OSError as exc:
            raise AnalysisStateError(f"Cannot update active analysis pointer: {exc}.") from exc
        return pointer

    def active_topic_dir(self) -> Path:
        pointer = active_pointer()
        if not pointer.exists():
            raise MissingAnalysisState(
                "No active analysis project. Claude must use "
                "'python3 guided_analysis.py start' or "
                "'python3 guided_analysis.py resume <path>'."
            )
        try:
            value = pointer.read_text(encoding="utf-8").strip()
        except OSError as exc:
            raise CorruptAnalysisState(f"Cannot read active analysis pointer: {exc}.") from exc
        if not value:
            raise CorruptAnalysisState(
                f"Active analysis pointer is empty at {pointer}. "
                "Claude must run 'python3 guided_analysis.py resume <path>' to repair it."
            )
        topic = Path(value).expanduser()
        if not topic.is_absolute():
            raise CorruptAnalysisState(
                f"Active analysis pointer must contain an absolute path: {pointer}."
            )
        return topic.resolve()

    def load_active(self) -> AnalysisProject:
        return self.load(self.active_topic_dir())
