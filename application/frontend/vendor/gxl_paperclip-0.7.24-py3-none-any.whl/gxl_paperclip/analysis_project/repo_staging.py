"""Stage locked structured extraction values before repo verification."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping, Sequence
from copy import deepcopy
from pathlib import Path
from typing import Any

from .models import AnalysisProject, utc_now
from .schema_optimization import (
    EXTRACTION_SCHEMA_FILENAME,
    FALLBACK_CLAIM_SCHEMA_FILENAME,
    SCHEMA_OPTIMIZATION_FILENAME,
    canonical_lines,
    canonical_sha256,
    schema_lock_is_current,
)
from .store import atomic_write_json, sha256_file

REPO_STAGING_FILENAME = "repo_staging.json"
REPO_STAGING_SCHEMA_VERSION = 1
_RESERVED_OUTPUT_KEYS = {
    "document_id",
    "source_notes",
    "extractor_notes",
    "ambiguities",
    "missing_visual_evidence",
}


class RepoStagingError(RuntimeError):
    """Raised when extraction output is unsafe to add to a repo."""


def _load_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RepoStagingError(f"cannot read {label}: {exc}") from exc
    if not isinstance(value, dict):
        raise RepoStagingError(f"{label} must contain one JSON object")
    return value


def _parse_task_output(task: Mapping[str, Any], prefix: str) -> dict[str, Any]:
    result = task.get("result")
    if not isinstance(result, Mapping):
        raise RepoStagingError(f"{prefix}.result must be an object")
    raw = result.get("output")
    if isinstance(raw, Mapping):
        output = dict(raw)
    elif isinstance(raw, str):
        try:
            output = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RepoStagingError(f"{prefix}.result.output is not valid JSON: {exc}") from exc
    else:
        raise RepoStagingError(f"{prefix}.result.output must be structured JSON")
    if not isinstance(output, dict):
        raise RepoStagingError(f"{prefix}.result.output must contain one JSON object")
    return output


def _validate_locations(
    value: object,
    *,
    prefix: str,
    included_paths: set[str],
    errors: list[str],
) -> list[dict[str, str]]:
    if not isinstance(value, list) or not value:
        errors.append(f"{prefix} must be a non-empty array")
        return []
    result: list[dict[str, str]] = []
    for index, location in enumerate(value):
        item_prefix = f"{prefix}[{index}]"
        if not isinstance(location, Mapping):
            errors.append(f"{item_prefix} must be an object")
            continue
        path = str(location.get("path") or "").strip()
        lines = location.get("lines")
        if not path:
            errors.append(f"{item_prefix}.path must be non-empty")
        elif path not in included_paths:
            errors.append(f"{item_prefix}.path was not included in the evidence packet")
        if not canonical_lines(lines):
            errors.append(f"{item_prefix}.lines must use canonical L# or L#-L# notation")
        if path and canonical_lines(lines):
            result.append({"path": path, "lines": str(lines)})
    return result


def _valid_primitive(value: object, value_type: str) -> bool:
    if value_type == "string" or value_type == "categorical":
        return isinstance(value, str) and bool(value.strip())
    if value_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if value_type == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if value_type == "boolean":
        return isinstance(value, bool)
    return False


def _reported_number_words(as_reported: str) -> list[float]:
    units = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
        "ten": 10,
        "eleven": 11,
        "twelve": 12,
        "thirteen": 13,
        "fourteen": 14,
        "fifteen": 15,
        "sixteen": 16,
        "seventeen": 17,
        "eighteen": 18,
        "nineteen": 19,
    }
    tens = {
        "twenty": 20,
        "thirty": 30,
        "forty": 40,
        "fifty": 50,
        "sixty": 60,
        "seventy": 70,
        "eighty": 80,
        "ninety": 90,
    }
    values: list[float] = []
    total = 0
    current = 0
    active = False

    def flush() -> None:
        nonlocal total, current, active
        if active:
            values.append(float(total + current))
        total = 0
        current = 0
        active = False

    for word in re.findall(r"[A-Za-z]+", as_reported.lower().replace("-", " ")):
        if word in units:
            current += units[word]
            active = True
        elif word in tens:
            current += tens[word]
            active = True
        elif word == "hundred" and active:
            current = max(1, current) * 100
        elif word == "thousand" and active:
            total += max(1, current) * 1000
            current = 0
        elif word == "and" and active:
            continue
        else:
            flush()
    flush()
    return values


def _numeric_matches_reported(value: int | float, as_reported: str) -> bool:
    """Require numeric normalization to remain anchored to reported content."""
    candidates = _reported_number_words(as_reported)
    for token in re.findall(
        r"(?<![A-Za-z0-9.])[-+]?\d[\d,]*(?:\.\d+)?",
        as_reported,
    ):
        try:
            candidates.append(float(token.replace(",", "")))
        except ValueError:
            continue
    normalized = float(value)
    return any(
        abs(candidate - normalized) <= max(1e-9, abs(normalized) * 1e-9)
        or abs(candidate - normalized * 100) <= max(1e-9, abs(normalized * 100) * 1e-9)
        or abs(candidate * 100 - normalized) <= max(1e-9, abs(normalized) * 1e-9)
        for candidate in candidates
    )


def _source_paths(value: object) -> set[str]:
    paths: set[str] = set()
    if isinstance(value, Mapping):
        locations = value.get("source_locations")
        if isinstance(locations, list):
            for location in locations:
                if isinstance(location, Mapping) and location.get("path"):
                    paths.add(str(location["path"]))
        for item in value.values():
            paths.update(_source_paths(item))
    elif isinstance(value, list):
        for item in value:
            paths.update(_source_paths(item))
    return paths


def _validate_sourced_value(
    value: object,
    field: Mapping[str, Any],
    *,
    prefix: str,
    included_paths: set[str],
    errors: list[str],
) -> list[dict[str, str]]:
    if not isinstance(value, Mapping):
        errors.append(f"{prefix} must be a sourced-value object")
        return []
    value_type = str(field.get("value_type") or "")
    if not _valid_primitive(value.get("value"), value_type):
        errors.append(f"{prefix}.value has invalid {value_type} type")
    as_reported = value.get("as_reported")
    if value_type != "boolean" and (
        not isinstance(as_reported, str) or not as_reported.strip()
    ):
        errors.append(f"{prefix}.as_reported must preserve source wording")
    elif (
        value_type in {"integer", "number"}
        and isinstance(value.get("value"), (int, float))
        and not isinstance(value.get("value"), bool)
        and isinstance(as_reported, str)
        and not _numeric_matches_reported(value["value"], as_reported)
    ):
        errors.append(
            f"{prefix}.value must match a number in as_reported "
            "(percent/proportion conversion is allowed)"
        )
    locations = _validate_locations(
        value.get("source_locations"),
        prefix=f"{prefix}.source_locations",
        included_paths=included_paths,
        errors=errors,
    )
    if value_type == "categorical":
        options = {
            str(option.get("id"))
            for option in field.get("options") or []
            if isinstance(option, Mapping)
        }
        selected = value.get("value")
        if selected not in options:
            errors.append(f"{prefix}.value is not a locked categorical option")
        if selected == "other":
            detail = value.get("other_detail")
            if not isinstance(detail, Mapping):
                errors.append(f"{prefix}.other_detail is required for 'other'")
            else:
                if not isinstance(detail.get("value"), str) or not detail["value"].strip():
                    errors.append(f"{prefix}.other_detail.value must be non-empty")
                _validate_locations(
                    detail.get("source_locations"),
                    prefix=f"{prefix}.other_detail.source_locations",
                    included_paths=included_paths,
                    errors=errors,
                )
    return locations


def validate_extraction_document(
    output: object,
    registry: Mapping[str, Any],
    *,
    included_paths: Sequence[str],
) -> list[str]:
    """Validate generated-schema invariants again before repo staging."""
    errors: list[str] = []
    if not isinstance(output, Mapping):
        return ["extraction output must be an object"]
    document_id = output.get("document_id")
    if not isinstance(document_id, str) or not document_id.strip():
        errors.append("document_id must be non-empty")
    else:
        expected_prefix = f"/papers/{document_id}/"
        for path in sorted(_source_paths(output)):
            if not path.startswith(expected_prefix):
                errors.append(
                    f"source path {path!r} does not belong to document {document_id}"
                )
    fields = [
        field
        for field in registry.get("fields") or []
        if isinstance(field, Mapping)
    ]
    categories = sorted({str(field.get("category")) for field in fields})
    allowed_keys = _RESERVED_OUTPUT_KEYS | set(categories)
    unexpected = sorted(str(key) for key in output if key not in allowed_keys)
    if unexpected:
        errors.append("unexpected output properties: " + ", ".join(unexpected))
    packet_paths = {str(path) for path in included_paths}
    for category in categories:
        records = output.get(category)
        if not isinstance(records, list):
            errors.append(f"{category} must be an array")
            continue
        category_fields = {
            str(field.get("id")): field
            for field in fields
            if field.get("category") == category
        }
        required_fields = {
            field_id
            for field_id, field in category_fields.items()
            if field.get("required") is True
        }
        for record_index, record in enumerate(records):
            prefix = f"{category}[{record_index}]"
            if not isinstance(record, Mapping):
                errors.append(f"{prefix} must be an object")
                continue
            record_id = record.get("record_id")
            if not isinstance(record_id, str) or not record_id.strip():
                errors.append(f"{prefix}.record_id must be non-empty")
            data = record.get("data")
            if not isinstance(data, Mapping):
                errors.append(f"{prefix}.data must be an object")
                continue
            missing = sorted(required_fields - set(data))
            if missing:
                errors.append(f"{prefix}.data is missing: {', '.join(missing)}")
            unknown = sorted(str(key) for key in data if key not in category_fields)
            if unknown:
                errors.append(f"{prefix}.data has unknown fields: {', '.join(unknown)}")
            for field_id, sourced_value in data.items():
                field = category_fields.get(str(field_id))
                if field is not None:
                    _validate_sourced_value(
                        sourced_value,
                        field,
                        prefix=f"{prefix}.data.{field_id}",
                        included_paths=packet_paths,
                        errors=errors,
                    )
    for name in ("source_notes", "extractor_notes", "ambiguities", "missing_visual_evidence"):
        if not isinstance(output.get(name), list):
            errors.append(f"{name} must be an array")
    for index, note in enumerate(output.get("source_notes") or []):
        prefix = f"source_notes[{index}]"
        if not isinstance(note, Mapping) or not str(note.get("note") or "").strip():
            errors.append(f"{prefix}.note must be non-empty")
            continue
        _validate_locations(
            note.get("source_locations"),
            prefix=f"{prefix}.source_locations",
            included_paths=packet_paths,
            errors=errors,
        )
    return errors


def _claim_lines(locations: Sequence[Mapping[str, str]]) -> str:
    """Keep the legacy line field while preserving path-aware locations."""
    return ",".join(str(location["lines"]) for location in locations)


def _make_claim(
    *,
    document_id: str,
    category: str,
    record_id: str,
    field_id: str,
    sourced_value: Mapping[str, Any],
    task: Mapping[str, Any],
    project: AnalysisProject,
) -> dict[str, Any]:
    locations = deepcopy(list(sourced_value["source_locations"]))
    content_hashes = task.get("content_hashes")
    if not isinstance(content_hashes, Mapping):
        content_hashes = {}
    location_provenance = [
        {
            **location,
            "content_sha256": content_hashes.get(location["path"]),
        }
        for location in locations
    ]
    claim = {
        "type": "finding",
        "card_id": "",
        "record_type": category,
        "paper_id": document_id,
        "source_locations": locations,
        "data": {
            "extraction_record_id": record_id,
            "field_id": field_id,
            "sourced_value": deepcopy(dict(sourced_value)),
            "source_provenance": location_provenance,
        },
        "schema_lock_sha256": project.schema_lock_sha256,
        "extraction_schema_sha256": project.extraction_schema_sha256,
        "evidence_packet_sha256": task.get("evidence_packet_sha256"),
    }
    claim["card_id"] = "xclm_" + canonical_sha256(claim)[:24]
    return {
        "claim_id": claim["card_id"],
        "claim": claim,
        "lines": _claim_lines(locations),
        "source_locations": locations,
    }


def build_repo_staging(
    project: AnalysisProject,
    manifests: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Flatten successful structured outputs without mutating a repo."""
    if not schema_lock_is_current(project):
        raise RepoStagingError("a current locked extraction schema is required")
    registry = _load_object(
        Path(project.topic_dir) / SCHEMA_OPTIMIZATION_FILENAME,
        SCHEMA_OPTIMIZATION_FILENAME,
    )
    extraction_schema = _load_object(
        Path(project.topic_dir) / EXTRACTION_SCHEMA_FILENAME,
        EXTRACTION_SCHEMA_FILENAME,
    )
    map_schema_sha256 = canonical_sha256(extraction_schema)
    fallback_claim_schema = _load_object(
        Path(project.topic_dir) / FALLBACK_CLAIM_SCHEMA_FILENAME,
        FALLBACK_CLAIM_SCHEMA_FILENAME,
    )
    fallback_schema_sha256 = canonical_sha256(fallback_claim_schema)
    category_fields: dict[str, list[str]] = {}
    for field in registry.get("fields") or []:
        if isinstance(field, Mapping):
            category_fields.setdefault(str(field["category"]), []).append(str(field["id"]))

    normalized_manifests: list[Mapping[str, Any]] = []
    fallback_papers: dict[str, dict[str, Any]] = {}
    fallback_failures: list[dict[str, Any]] = []
    fallback_sources: list[dict[str, Any]] = []
    for manifest_index, manifest in enumerate(manifests):
        inputs = manifest.get("inputs")
        worker = inputs.get("worker") if isinstance(inputs, Mapping) else None
        if worker != "exhaustive-extraction":
            normalized_manifests.append(manifest)
            continue
        provenance = manifest.get("provenance")
        if not isinstance(provenance, Mapping):
            raise RepoStagingError(
                f"manifest[{manifest_index}].provenance must be an object"
            )
        if provenance.get("claim_schema_sha256") != fallback_schema_sha256:
            raise RepoStagingError(
                f"manifest[{manifest_index}] used a different exhaustive fallback schema"
            )
        tasks = manifest.get("tasks")
        if not isinstance(tasks, list):
            raise RepoStagingError(f"manifest[{manifest_index}].tasks must be an array")
        fallback_sources.append(
            {
                "map_id": manifest.get("map_id"),
                "run_id": manifest.get("run_id"),
                "model_provider_id": provenance.get("model_provider_id"),
                "claim_schema_sha256": provenance.get("claim_schema_sha256"),
                "agent_config_sha256": provenance.get("agent_config_sha256"),
                "code_revision": provenance.get("code_revision"),
            }
        )
        for task_index, task in enumerate(tasks):
            if not isinstance(task, Mapping):
                fallback_failures.append(
                    {
                        "manifest_index": manifest_index,
                        "task_index": task_index,
                        "status": "invalid_task",
                    }
                )
                continue
            if task.get("status") != "success":
                fallback_failures.append(
                    {
                        "manifest_index": manifest_index,
                        "task_index": task_index,
                        "document_id": task.get("document_id"),
                        "status": task.get("status"),
                        "fallback_reason": task.get("fallback_reason"),
                    }
                )
                continue
            wrapper = _parse_task_output(
                task,
                f"manifest[{manifest_index}].tasks[{task_index}]",
            )
            document_id = str(wrapper.get("document_id") or "").strip()
            if not document_id:
                raise RepoStagingError(
                    f"manifest[{manifest_index}].tasks[{task_index}] has no document_id"
                )
            paper = fallback_papers.setdefault(
                document_id,
                {
                    "document_id": document_id,
                    **{category: [] for category in category_fields},
                    "source_notes": [],
                    "extractor_notes": [],
                    "ambiguities": [],
                    "missing_visual_evidence": [],
                    "_record_keys": {},
                    "_source_paths": set(),
                    "_task_ids": [],
                },
            )
            paper["_task_ids"].append(task.get("task_id"))
            claims = wrapper.get("claims")
            if not isinstance(claims, list):
                raise RepoStagingError(
                    f"fallback output for {document_id} must contain a claims array"
                )
            for claim_index, claim_item in enumerate(claims):
                if not isinstance(claim_item, Mapping):
                    raise RepoStagingError(
                        f"fallback {document_id} claim[{claim_index}] must be an object"
                    )
                claim = claim_item.get("claim")
                if not isinstance(claim, Mapping):
                    raise RepoStagingError(
                        f"fallback {document_id} claim[{claim_index}].claim must be an object"
                    )
                category = str(claim.get("category") or "")
                record = claim.get("record")
                if category not in category_fields or not isinstance(record, Mapping):
                    raise RepoStagingError(
                        f"fallback {document_id} claim[{claim_index}] does not conform "
                        "to a locked category record"
                    )
                record_id = str(record.get("record_id") or "")
                key = (category, record_id)
                prior = paper["_record_keys"].get(key)
                if prior is not None and prior != record:
                    raise RepoStagingError(
                        f"fallback {document_id} has conflicting record {category}/{record_id}"
                    )
                if prior is None:
                    copied_record = deepcopy(dict(record))
                    paper[category].append(copied_record)
                    paper["_record_keys"][key] = copied_record
                    paper["_source_paths"].update(_source_paths(copied_record))
            coverage = wrapper.get("coverage")
            notes = (
                str(coverage.get("notes") or "").strip()
                if isinstance(coverage, Mapping)
                else ""
            )
            if notes:
                paper["extractor_notes"].append(
                    {"kind": "extractor_judgment", "note": notes}
                )

    if fallback_papers or fallback_failures:
        synthetic_tasks: list[dict[str, Any]] = []
        for document_id, paper in sorted(fallback_papers.items()):
            source_paths = sorted(paper.pop("_source_paths"))
            task_ids = paper.pop("_task_ids")
            paper.pop("_record_keys")
            synthetic_tasks.append(
                {
                    "task_id": "fallback:" + ",".join(
                        str(task_id) for task_id in task_ids if task_id
                    ),
                    "document_id": document_id,
                    "status": "success",
                    "validation_status": "success",
                    "persistence_status": "not_applicable",
                    "evidence_packet_sha256": None,
                    "content_hashes": {},
                    "evidence_packet": {"included_paths": source_paths},
                    "result": {"output": json.dumps(paper, ensure_ascii=False)},
                    "source_worker": "exhaustive-extraction",
                }
            )
        synthetic_tasks.extend(
            {
                **failure,
                "validation_status": "failed",
                "source_worker": "exhaustive-extraction",
            }
            for failure in fallback_failures
        )
        normalized_manifests.append(
            {
                "map_id": "merged-exhaustive-fallback",
                "run_id": "merged-exhaustive-fallback",
                "inputs": {"worker": "structured-extraction"},
                "provenance": {
                    "model_provider_id": "exhaustive-fallback",
                    "output_schema_sha256": map_schema_sha256,
                    "agent_config_sha256": None,
                    "code_revision": None,
                },
                "tasks": synthetic_tasks,
                "fallback_sources": fallback_sources,
            }
        )
    manifests = normalized_manifests

    staged_papers: list[dict[str, Any]] = []
    blockers: list[dict[str, Any]] = []
    manifest_provenance: list[dict[str, Any]] = []
    seen_documents: set[str] = set()
    for manifest_index, manifest in enumerate(manifests):
        inputs = manifest.get("inputs")
        provenance = manifest.get("provenance")
        tasks = manifest.get("tasks")
        if not isinstance(inputs, Mapping) or inputs.get("worker") != "structured-extraction":
            raise RepoStagingError(f"manifest[{manifest_index}] is not a structured-extraction map")
        if not isinstance(provenance, Mapping):
            raise RepoStagingError(f"manifest[{manifest_index}].provenance must be an object")
        if provenance.get("output_schema_sha256") != map_schema_sha256:
            raise RepoStagingError(
                f"manifest[{manifest_index}] used a different extraction schema"
            )
        if not isinstance(tasks, list):
            raise RepoStagingError(f"manifest[{manifest_index}].tasks must be an array")
        manifest_provenance.append(
            {
                "map_id": manifest.get("map_id"),
                "run_id": manifest.get("run_id"),
                "model_provider_id": provenance.get("model_provider_id"),
                "output_schema_sha256": provenance.get("output_schema_sha256"),
                "agent_config_sha256": provenance.get("agent_config_sha256"),
                "code_revision": provenance.get("code_revision"),
            }
        )
        for task_index, task_value in enumerate(tasks):
            if not isinstance(task_value, Mapping):
                blockers.append(
                    {
                        "manifest_index": manifest_index,
                        "task_index": task_index,
                        "reason": "task_not_object",
                    }
                )
                continue
            task = task_value
            status = str(task.get("status") or "")
            validation_status = str(task.get("validation_status") or "")
            if status != "success" or validation_status != "success":
                blockers.append(
                    {
                        "manifest_index": manifest_index,
                        "task_index": task_index,
                        "document_id": task.get("document_id"),
                        "status": status,
                        "validation_status": validation_status,
                        "fallback_reason": task.get("fallback_reason")
                        or (task.get("result") or {}).get("fallback_reason")
                        if isinstance(task.get("result"), Mapping)
                        else None,
                    }
                )
                continue
            output = _parse_task_output(
                task,
                f"manifest[{manifest_index}].tasks[{task_index}]",
            )
            document_id = str(output.get("document_id") or "").strip()
            if document_id in seen_documents:
                raise RepoStagingError(
                    f"document {document_id} appears more than once; select one durable extraction"
                )
            included_paths = task.get("included_paths")
            if not isinstance(included_paths, list):
                packet = task.get("evidence_packet")
                result = task.get("result")
                if not isinstance(packet, Mapping):
                    packet = (
                        result.get("evidence_packet")
                        if isinstance(result, Mapping)
                        else None
                    )
                included_paths = (
                    packet.get("included_paths")
                    if isinstance(packet, Mapping)
                    else []
                )
            validation_errors = validate_extraction_document(
                output,
                registry,
                included_paths=included_paths,
            )
            if validation_errors:
                raise RepoStagingError(
                    f"{document_id or f'task {task_index}'} failed repo-stage validation: "
                    + "; ".join(validation_errors)
                )
            seen_documents.add(document_id)
            claims: list[dict[str, Any]] = []
            for category, field_ids in sorted(category_fields.items()):
                for record in output.get(category) or []:
                    record_id = str(record["record_id"])
                    for field_id in field_ids:
                        sourced_value = record["data"].get(field_id)
                        if sourced_value is None:
                            continue
                        claims.append(
                            _make_claim(
                                document_id=document_id,
                                category=category,
                                record_id=record_id,
                                field_id=field_id,
                                sourced_value=sourced_value,
                                task=task,
                                project=project,
                            )
                        )
            for note_index, source_note in enumerate(output.get("source_notes") or []):
                locations = deepcopy(source_note["source_locations"])
                claim = {
                    "type": "source_context",
                    "card_id": "",
                    "record_type": "source_note",
                    "paper_id": document_id,
                    "source_locations": locations,
                    "data": {
                        "extraction_record_id": f"source_note_{note_index + 1}",
                        "note": source_note["note"],
                    },
                    "schema_lock_sha256": project.schema_lock_sha256,
                    "extraction_schema_sha256": project.extraction_schema_sha256,
                }
                claim["card_id"] = "xclm_" + canonical_sha256(claim)[:24]
                claims.append(
                    {
                        "claim_id": claim["card_id"],
                        "claim": claim,
                        "lines": _claim_lines(locations),
                        "source_locations": locations,
                    }
                )
            staged_papers.append(
                {
                    "document_id": document_id,
                    "task_id": task.get("task_id"),
                    "evidence_packet_sha256": task.get("evidence_packet_sha256"),
                    "claims": claims,
                    "claim_count": len(claims),
                    "extractor_notes": deepcopy(output.get("extractor_notes") or []),
                    "ambiguities": deepcopy(output.get("ambiguities") or []),
                    "missing_visual_evidence": deepcopy(
                        output.get("missing_visual_evidence") or []
                    ),
                }
            )

    staged_papers.sort(key=lambda item: item["document_id"])
    blockers.sort(
        key=lambda item: (int(item.get("manifest_index", 0)), int(item.get("task_index", 0)))
    )
    return {
        "schema_version": REPO_STAGING_SCHEMA_VERSION,
        "generated_at": utc_now(),
        "schema_lock_sha256": project.schema_lock_sha256,
        "extraction_schema_sha256": project.extraction_schema_sha256,
        "map_output_schema_sha256": map_schema_sha256,
        "manifests": manifest_provenance,
        "papers": staged_papers,
        "paper_count": len(staged_papers),
        "claim_count": sum(paper["claim_count"] for paper in staged_papers),
        "blockers": blockers,
        "ready_to_add": bool(staged_papers) and not blockers,
        "next_step": (
            "repo-add"
            if staged_papers and not blockers
            else "rerun fallback_required or failed papers before repo-add"
        ),
    }


def write_repo_staging(
    project: AnalysisProject,
    manifests: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], bool]:
    artifact = build_repo_staging(project, manifests)
    path = Path(project.topic_dir) / REPO_STAGING_FILENAME
    existing = _load_object(path, REPO_STAGING_FILENAME) if path.is_file() else None
    unchanged = False
    if existing is not None:
        comparable_existing = {**existing, "generated_at": None}
        comparable_artifact = {**artifact, "generated_at": None}
        unchanged = comparable_existing == comparable_artifact
        if unchanged:
            artifact = existing
    if not unchanged:
        atomic_write_json(path, artifact)
    return artifact, not unchanged


def validate_repo_staging(
    project: AnalysisProject,
    artifact: Mapping[str, Any],
) -> list[str]:
    errors: list[str] = []
    if not schema_lock_is_current(project):
        errors.append("the project schema lock is stale")
    if artifact.get("schema_version") != REPO_STAGING_SCHEMA_VERSION:
        errors.append(f"schema_version must equal {REPO_STAGING_SCHEMA_VERSION}")
    if artifact.get("schema_lock_sha256") != project.schema_lock_sha256:
        errors.append("schema_lock_sha256 does not match the project")
    if artifact.get("extraction_schema_sha256") != project.extraction_schema_sha256:
        errors.append("extraction_schema_sha256 does not match the project")
    if artifact.get("blockers"):
        errors.append("repo staging still contains extraction blockers")
    if artifact.get("ready_to_add") is not True:
        errors.append("repo staging is not ready to add")
    if not isinstance(artifact.get("papers"), list) or not artifact.get("papers"):
        errors.append("repo staging contains no papers")
    return errors


def apply_repo_staging(
    project: AnalysisProject,
    *,
    repo_name: str | None = None,
) -> dict[str, Any]:
    """Add staged claims; verification remains a separate repo commit."""
    path = Path(project.topic_dir) / REPO_STAGING_FILENAME
    artifact = _load_object(path, REPO_STAGING_FILENAME)
    errors = validate_repo_staging(project, artifact)
    if errors:
        raise RepoStagingError("; ".join(errors))

    from gxl_paperclip.cli import repo as repo_api

    if repo_name:
        repo_api.checkout_repo(repo_name)
    added_claims = 0
    papers = artifact["papers"]
    repo_api.add_papers([str(paper["document_id"]) for paper in papers])
    for paper in papers:
        document_id = str(paper["document_id"])
        for item in paper["claims"]:
            repo_api.annotate_paper(
                document_id,
                json.dumps(
                    item["claim"],
                    sort_keys=True,
                    separators=(",", ":"),
                    ensure_ascii=False,
                ),
                lines=[item["lines"]],
                source_locations=item["source_locations"],
            )
            added_claims += 1
    return {
        "repo_staging_sha256": sha256_file(path),
        "papers_added": len(papers),
        "claims_added": added_claims,
        "next_step": "paperclip repo commit -m '<message>'",
    }
