"""Locked, domain-agnostic structured-extraction schema contracts."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .contracts import (
    COLLECTION_SPEC_FILENAME,
    PLANNED_OUTPUTS_FILENAME,
    collection_schema_hash,
    validate_collection_spec,
    validate_planned_outputs,
)
from .models import AnalysisProject
from .store import atomic_write_json, sha256_file

SCHEMA_OPTIMIZATION_SCHEMA_VERSION = 1
EXTRACTION_SCHEMA_DRAFT = "http://json-schema.org/draft-07/schema#"
SCHEMA_LOCK_SCHEMA_VERSION = 1
SCHEMA_OBSERVATIONS_SCHEMA_VERSION = 1

SCHEMA_OPTIMIZATION_FILENAME = "schema_optimization.json"
EXTRACTION_SCHEMA_FILENAME = "extraction_schema.json"
FALLBACK_CLAIM_SCHEMA_FILENAME = "fallback_claim_schema.json"
SCHEMA_LOCK_FILENAME = "schema_lock.json"
SCHEMA_OBSERVATIONS_FILENAME = "schema_observations.json"

VALUE_TYPES = frozenset({"string", "integer", "number", "boolean", "categorical"})
DECISION_ACTORS = frozenset({"user", "claude"})
_IDENTIFIER_RE = re.compile(r"^[a-z][a-z0-9_]*$")
_LINES_RE = re.compile(r"^L([1-9][0-9]*)(?:-L([1-9][0-9]*))?$")
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class SchemaOptimizationError(RuntimeError):
    """An actionable schema optimization, locking, or observation failure."""


@dataclass
class SchemaOptimizationValidation:
    """Deterministic validation result for schema optimization artifacts."""

    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "errors": self.errors, "warnings": self.warnings}


def canonical_json(value: object) -> bytes:
    """Encode JSON deterministically for semantic hashes and stable IDs."""
    return json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def canonical_sha256(value: object) -> str:
    """Hash a JSON-compatible value using canonical JSON encoding."""
    return hashlib.sha256(canonical_json(value)).hexdigest()


def canonical_lines(value: object) -> bool:
    """Return whether ``value`` is one canonical Paperclip line or range."""
    if not isinstance(value, str):
        return False
    match = _LINES_RE.fullmatch(value)
    if match is None:
        return False
    start = int(match.group(1))
    end = int(match.group(2)) if match.group(2) is not None else start
    return end >= start


def _nonempty_string(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _valid_sha256(value: object) -> bool:
    return isinstance(value, str) and _SHA256_RE.fullmatch(value) is not None


def _is_sequence(value: object) -> bool:
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray))


def _validate_source_location(
    value: object,
    prefix: str,
    errors: list[str],
) -> None:
    if not isinstance(value, Mapping):
        errors.append(f"{prefix} must be an object")
        return
    if not _nonempty_string(value.get("path")):
        errors.append(f"{prefix}.path must be a non-empty string")
    if not canonical_lines(value.get("lines")):
        errors.append(f"{prefix}.lines must use canonical L# or L#-L# notation")


def _validate_source_locations(
    value: object,
    prefix: str,
    errors: list[str],
    *,
    required: bool = True,
) -> None:
    if not isinstance(value, list) or required and not value:
        qualifier = "a non-empty" if required else "an"
        errors.append(f"{prefix} must be {qualifier} array")
        return
    for index, location in enumerate(value):
        _validate_source_location(location, f"{prefix}[{index}]", errors)


def _validate_decision_provenance(
    value: object,
    prefix: str,
    errors: list[str],
) -> None:
    if not isinstance(value, Mapping) or not value:
        errors.append(f"{prefix} must be a non-empty object")
        return
    actor = value.get("actor")
    if actor not in DECISION_ACTORS:
        errors.append(f"{prefix}.actor must be 'user' or 'claude'")
    decision = value.get("decision") or value.get("rationale") or value.get("reason")
    if not _nonempty_string(decision):
        errors.append(f"{prefix} must record a non-empty decision or rationale")


def _validate_source_example(
    value: object,
    prefix: str,
    errors: list[str],
) -> None:
    if not isinstance(value, Mapping):
        errors.append(f"{prefix} must be an object")
        return
    reported = value.get("as_reported", value.get("text"))
    if not _nonempty_string(reported):
        errors.append(f"{prefix}.as_reported must preserve non-empty original wording")
    if "source_locations" in value:
        _validate_source_locations(
            value.get("source_locations"),
            f"{prefix}.source_locations",
            errors,
        )
    else:
        _validate_source_location(value, prefix, errors)


def _validate_option(
    value: object,
    prefix: str,
    errors: list[str],
) -> str | None:
    if not isinstance(value, Mapping):
        errors.append(f"{prefix} must be an object")
        return None
    option_id = value.get("id")
    if not _nonempty_string(option_id) or _IDENTIFIER_RE.fullmatch(str(option_id)) is None:
        errors.append(f"{prefix}.id must be a lowercase snake_case identifier")
        option_id = None
    if not _nonempty_string(value.get("label")):
        errors.append(f"{prefix}.label must be a non-empty string")
    if not _nonempty_string(value.get("definition")):
        errors.append(f"{prefix}.definition must be a non-empty string")
    aliases = value.get("aliases")
    if not isinstance(aliases, list) or not all(_nonempty_string(alias) for alias in aliases):
        errors.append(f"{prefix}.aliases must be an array of non-empty strings")
    elif len({str(alias).casefold() for alias in aliases}) != len(aliases):
        errors.append(f"{prefix}.aliases must be unique ignoring case")
    examples = value.get("source_examples")
    if not isinstance(examples, list):
        errors.append(f"{prefix}.source_examples must be an array")
    else:
        for index, example in enumerate(examples):
            _validate_source_example(example, f"{prefix}.source_examples[{index}]", errors)
    _validate_decision_provenance(
        value.get("decision_provenance"),
        f"{prefix}.decision_provenance",
        errors,
    )
    return str(option_id) if option_id is not None else None


def _validate_field(
    value: object,
    prefix: str,
    errors: list[str],
) -> tuple[str | None, str | None]:
    if not isinstance(value, Mapping):
        errors.append(f"{prefix} must be an object")
        return None, None
    field_id = value.get("id")
    if not _nonempty_string(field_id) or _IDENTIFIER_RE.fullmatch(str(field_id)) is None:
        errors.append(f"{prefix}.id must be a lowercase snake_case identifier")
        field_id = None
    category = value.get("category")
    if not _nonempty_string(category) or _IDENTIFIER_RE.fullmatch(str(category)) is None:
        errors.append(f"{prefix}.category must be a lowercase snake_case identifier")
        category = None
    if not _nonempty_string(value.get("label")):
        errors.append(f"{prefix}.label must be a non-empty string")
    if not _nonempty_string(value.get("definition")):
        errors.append(f"{prefix}.definition must be a non-empty string")
    value_type = value.get("value_type")
    if value_type not in VALUE_TYPES:
        errors.append(f"{prefix}.value_type must be one of: {', '.join(sorted(VALUE_TYPES))}")
    if not isinstance(value.get("required"), bool):
        errors.append(f"{prefix}.required must be a boolean")
    _validate_decision_provenance(
        value.get("decision_provenance"),
        f"{prefix}.decision_provenance",
        errors,
    )
    options = value.get("options")
    if value_type == "categorical":
        if not isinstance(options, list) or not options:
            errors.append(f"{prefix}.options must be a non-empty array for categorical fields")
        else:
            option_ids: list[str] = []
            labels: list[str] = []
            canonical_tokens: dict[str, str] = {}
            for index, option in enumerate(options):
                option_id = _validate_option(option, f"{prefix}.options[{index}]", errors)
                if option_id is not None:
                    option_ids.append(option_id)
                if isinstance(option, Mapping) and _nonempty_string(option.get("label")):
                    labels.append(str(option["label"]).casefold())
                if isinstance(option, Mapping):
                    tokens = [option.get("id"), option.get("label")]
                    aliases = option.get("aliases")
                    if isinstance(aliases, list):
                        tokens.extend(aliases)
                    for token in tokens:
                        if not _nonempty_string(token):
                            continue
                        normalized_token = str(token).casefold()
                        owner = canonical_tokens.get(normalized_token)
                        current_owner = str(option.get("id", index))
                        if owner is not None and owner != current_owner:
                            errors.append(
                                f"{prefix}.options alias/label {token!r} is ambiguous "
                                f"between {owner!r} and {current_owner!r}"
                            )
                        else:
                            canonical_tokens[normalized_token] = current_owner
            if len(option_ids) != len(set(option_ids)):
                errors.append(f"{prefix}.options must have unique ids")
            if len(labels) != len(set(labels)):
                errors.append(f"{prefix}.options must have unique labels ignoring case")
            if option_ids.count("other") != 1:
                errors.append(f"{prefix}.options must contain exactly one 'other' option")
    elif options not in (None, []):
        errors.append(f"{prefix}.options is only valid for categorical fields")
    return (
        str(field_id) if field_id is not None else None,
        str(category) if category is not None else None,
    )


def _validate_bindings(
    value: object,
    errors: list[str],
    *,
    expected: Mapping[str, Any] | None = None,
) -> None:
    prefix = "bindings"
    if not isinstance(value, Mapping):
        errors.append("bindings must be an object")
        return
    if not _nonempty_string(value.get("project_id")):
        errors.append("bindings.project_id must be a non-empty string")
    revision = value.get("project_revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        errors.append("bindings.project_revision must be a positive integer")
    for name in (
        "question_approval_sha256",
        "collection_spec_sha256",
        "collection_schema_sha256",
        "planned_outputs_sha256",
        "pilot_summary_sha256",
    ):
        if not _valid_sha256(value.get(name)):
            errors.append(f"bindings.{name} must be a lowercase SHA-256")
    if expected is not None:
        for name, expected_value in expected.items():
            if value.get(name) != expected_value:
                errors.append(f"{prefix}.{name} does not match the approved pilot inputs")


def validate_schema_optimization(
    value: object,
    *,
    expected_bindings: Mapping[str, Any] | None = None,
) -> SchemaOptimizationValidation:
    """Validate the complete optimized field registry and audit history."""
    result = SchemaOptimizationValidation()
    if not isinstance(value, Mapping):
        result.errors.append(f"{SCHEMA_OPTIMIZATION_FILENAME} must contain an object")
        return result
    if value.get("schema_version") != SCHEMA_OPTIMIZATION_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {SCHEMA_OPTIMIZATION_SCHEMA_VERSION}")
    version = value.get("version")
    if not (
        isinstance(version, int)
        and not isinstance(version, bool)
        and version >= 1
        or _nonempty_string(version)
    ):
        result.errors.append("version must be a positive integer or non-empty string")
    revision = value.get("revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        result.errors.append("revision must be a positive integer")
        revision = None
    input_hash = value.get("optimization_input_sha256")
    if not _valid_sha256(input_hash):
        result.errors.append("optimization_input_sha256 must be a lowercase SHA-256")
    else:
        expected_input_hash = canonical_sha256(_normalized_candidate(value))
        if input_hash != expected_input_hash:
            result.errors.append(
                "optimization_input_sha256 does not match the optimized registry input"
            )

    fields = value.get("fields")
    field_ids: list[str] = []
    category_ids: set[str] = set()
    if not isinstance(fields, list) or not fields:
        result.errors.append("fields must be a non-empty array")
    else:
        for index, field_value in enumerate(fields):
            field_id, category = _validate_field(
                field_value,
                f"fields[{index}]",
                result.errors,
            )
            if field_id is not None:
                field_ids.append(field_id)
            if category is not None:
                category_ids.add(category)
        if len(field_ids) != len(set(field_ids)):
            result.errors.append("fields must have unique ids")
    if category_ids & {
        "document_id",
        "source_notes",
        "extractor_notes",
        "ambiguities",
        "missing_visual_evidence",
    }:
        result.errors.append("field categories collide with reserved paper-level properties")

    decisions = value.get("decision_log")
    if not isinstance(decisions, list) or not decisions:
        result.errors.append("decision_log must be a non-empty array")
    else:
        decision_ids: list[str] = []
        for index, decision in enumerate(decisions):
            prefix = f"decision_log[{index}]"
            if not isinstance(decision, Mapping):
                result.errors.append(f"{prefix} must be an object")
                continue
            identifier = decision.get("id")
            if not _nonempty_string(identifier):
                result.errors.append(f"{prefix}.id must be a non-empty string")
            else:
                decision_ids.append(str(identifier))
            _validate_decision_provenance(decision, prefix, result.errors)
        if len(decision_ids) != len(set(decision_ids)):
            result.errors.append("decision_log ids must be unique")

    observations = value.get("observations")
    if not isinstance(observations, list):
        result.errors.append("observations must be an array")
    else:
        for index, observation in enumerate(observations):
            prefix = f"observations[{index}]"
            if not isinstance(observation, Mapping):
                result.errors.append(f"{prefix} must be an object")
                continue
            if not _nonempty_string(observation.get("observation", observation.get("summary"))):
                result.errors.append(f"{prefix} must include a non-empty observation")
            if "source_locations" in observation:
                _validate_source_locations(
                    observation.get("source_locations"),
                    f"{prefix}.source_locations",
                    result.errors,
                )

    history = value.get("revision_history")
    if not isinstance(history, list) or not history:
        result.errors.append("revision_history must be a non-empty array")
    else:
        history_revisions: list[int] = []
        for index, entry in enumerate(history):
            prefix = f"revision_history[{index}]"
            if not isinstance(entry, Mapping):
                result.errors.append(f"{prefix} must be an object")
                continue
            entry_revision = entry.get("revision")
            if (
                not isinstance(entry_revision, int)
                or isinstance(entry_revision, bool)
                or entry_revision < 1
            ):
                result.errors.append(f"{prefix}.revision must be a positive integer")
            else:
                history_revisions.append(entry_revision)
            if not _valid_sha256(entry.get("optimization_input_sha256")):
                result.errors.append(
                    f"{prefix}.optimization_input_sha256 must be a lowercase SHA-256"
                )
            if not _nonempty_string(entry.get("reason")):
                result.errors.append(f"{prefix}.reason must be a non-empty string")
            _validate_decision_provenance(
                entry.get("decision_provenance"),
                f"{prefix}.decision_provenance",
                result.errors,
            )
        if len(history_revisions) != len(set(history_revisions)):
            result.errors.append("revision_history revisions must be unique")
        if revision is not None and history_revisions != list(range(1, revision + 1)):
            result.errors.append(
                "revision_history must contain every revision from 1 through revision"
            )
        if (
            history
            and isinstance(history[-1], Mapping)
            and history[-1].get("optimization_input_sha256") != input_hash
        ):
            result.errors.append(
                "revision_history current entry does not match optimization_input_sha256"
            )
    _validate_bindings(value.get("bindings"), result.errors, expected=expected_bindings)
    return result


def _normalized_provenance(value: object, *, default_decision: str) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return {str(key): deepcopy(item) for key, item in value.items()}
    return {"actor": "claude", "decision": default_decision}


def _normalized_candidate(candidate: Mapping[str, Any]) -> dict[str, Any]:
    payload = {
        str(key): deepcopy(value)
        for key, value in candidate.items()
        if key
        not in {
            "schema_version",
            "revision",
            "revision_history",
            "bindings",
            "optimization_input_sha256",
            "registry_sha256",
            "revision_reason",
            "revision_provenance",
        }
    }
    payload.setdefault("version", 1)
    payload.setdefault("decision_log", [])
    payload.setdefault("observations", [])
    fields = payload.get("fields")
    if isinstance(fields, list):
        normalized_fields: list[object] = []
        for field_value in fields:
            if not isinstance(field_value, Mapping):
                normalized_fields.append(deepcopy(field_value))
                continue
            normalized = {str(key): deepcopy(value) for key, value in field_value.items()}
            value_type = normalized.get("value_type")
            if value_type in {"numeric", "numerical", "float"}:
                normalized["value_type"] = "number"
            elif value_type == "int":
                normalized["value_type"] = "integer"
            options = normalized.get("options")
            if isinstance(options, list):
                normalized["options"] = sorted(
                    [deepcopy(option) for option in options],
                    key=lambda option: (
                        str(option.get("id", "")).casefold()
                        if isinstance(option, Mapping)
                        else canonical_json(option)
                    ),
                )
            normalized_fields.append(normalized)
        payload["fields"] = sorted(
            normalized_fields,
            key=lambda field_value: (
                str(field_value.get("category", "")).casefold(),
                str(field_value.get("id", "")).casefold(),
            )
            if isinstance(field_value, Mapping)
            else ("", canonical_sha256(field_value)),
        )
    return payload


def build_schema_optimization(
    candidate: Mapping[str, Any],
    *,
    bindings: Mapping[str, Any],
    previous: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a deterministic revisioned registry from an authored candidate."""
    if not isinstance(candidate, Mapping):
        raise SchemaOptimizationError("schema optimization input must contain an object")
    payload = _normalized_candidate(candidate)
    input_hash = canonical_sha256(payload)
    normalized_bindings = {str(key): deepcopy(value) for key, value in bindings.items()}
    if (
        isinstance(previous, Mapping)
        and previous.get("optimization_input_sha256") == input_hash
        and previous.get("bindings") == normalized_bindings
    ):
        validation = validate_schema_optimization(
            previous,
            expected_bindings=normalized_bindings,
        )
        if validation.ok:
            return deepcopy(dict(previous))

    revision = 1
    history: list[dict[str, Any]] = []
    if isinstance(previous, Mapping):
        previous_revision = previous.get("revision")
        if isinstance(previous_revision, int) and not isinstance(previous_revision, bool):
            revision = previous_revision + 1
        previous_history = previous.get("revision_history")
        if isinstance(previous_history, list):
            history = [
                deepcopy(dict(entry)) for entry in previous_history if isinstance(entry, Mapping)
            ]
    reason = candidate.get("revision_reason")
    if not _nonempty_string(reason):
        reason = "initial optimization" if revision == 1 else "optimized schema input changed"
    provenance = _normalized_provenance(
        candidate.get("revision_provenance"),
        default_decision=(
            "Created optimized extraction schema"
            if revision == 1
            else "Revised optimized extraction schema"
        ),
    )
    history.append(
        {
            "revision": revision,
            "optimization_input_sha256": input_hash,
            "reason": str(reason).strip(),
            "decision_provenance": provenance,
        }
    )
    artifact = {
        "schema_version": SCHEMA_OPTIMIZATION_SCHEMA_VERSION,
        **payload,
        "revision": revision,
        "revision_history": history,
        "optimization_input_sha256": input_hash,
        "bindings": normalized_bindings,
    }
    validation = validate_schema_optimization(
        artifact,
        expected_bindings=normalized_bindings,
    )
    if not validation.ok:
        raise SchemaOptimizationError("; ".join(validation.errors))
    return artifact


def _source_location_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["path", "lines"],
        "properties": {
            "path": {"type": "string", "minLength": 1},
            "lines": {
                "type": "string",
                "pattern": r"^L[1-9][0-9]*(?:-L[1-9][0-9]*)?$",
                "description": "Exact canonical Paperclip line or inclusive line range.",
            },
        },
    }


def _sourced_value_schema(field_definition: Mapping[str, Any]) -> dict[str, Any]:
    value_type = str(field_definition["value_type"])
    value_schema: dict[str, Any]
    if value_type == "categorical":
        options = field_definition["options"]
        value_schema = {
            "type": "string",
            "enum": [str(option["id"]) for option in options],
            "description": "Canonical option id; preserve source wording in as_reported.",
        }
    else:
        value_schema = {"type": value_type}
    required = ["value", "source_locations"]
    if value_type != "boolean":
        required.append("as_reported")
    properties: dict[str, Any] = {
        "value": value_schema,
        "source_locations": {
            "type": "array",
            "minItems": 1,
            "items": {"$ref": "#/definitions/source_location"},
        },
        "as_reported": {
            "type": "string",
            "minLength": 1,
            "description": "Exact wording or numeric representation reported by the source.",
        },
    }
    result: dict[str, Any] = {
        "type": "object",
        "additionalProperties": False,
        "required": required,
        "properties": properties,
        "description": str(field_definition["definition"]),
    }
    if value_type == "categorical":
        properties["other_detail"] = {
            "$ref": "#/definitions/sourced_string",
            "description": (
                "Original unknown label mapped to 'other', with its own exact source location."
            ),
        }
        result["allOf"] = [
            {
                "if": {
                    "properties": {"value": {"const": "other"}},
                    "required": ["value"],
                },
                "then": {"required": ["other_detail"]},
            }
        ]
    return result


def generate_extraction_schema(registry: Mapping[str, Any]) -> dict[str, Any]:
    """Generate a complete deterministic paper-level Draft-07 JSON Schema."""
    validation = validate_schema_optimization(registry)
    if not validation.ok:
        raise SchemaOptimizationError("; ".join(validation.errors))
    fields = [field_value for field_value in registry["fields"] if isinstance(field_value, Mapping)]
    category_names = sorted(
        {str(field_value["category"]) for field_value in fields},
        key=str.casefold,
    )
    properties: dict[str, Any] = {
        "document_id": {
            "type": "string",
            "minLength": 1,
            "description": "Stable Paperclip document identifier.",
        },
        "source_notes": {
            "type": "array",
            "items": {"$ref": "#/definitions/source_note"},
        },
        "extractor_notes": {
            "type": "array",
            "items": {"$ref": "#/definitions/extractor_note"},
        },
        "ambiguities": {
            "type": "array",
            "items": {"$ref": "#/definitions/ambiguity"},
        },
        "missing_visual_evidence": {
            "type": "array",
            "items": {"$ref": "#/definitions/missing_visual_evidence"},
        },
    }
    required = [
        "document_id",
        *category_names,
        "source_notes",
        "extractor_notes",
        "ambiguities",
        "missing_visual_evidence",
    ]
    for category in category_names:
        category_fields = sorted(
            [field_value for field_value in fields if field_value["category"] == category],
            key=lambda field_value: str(field_value["id"]).casefold(),
        )
        data_properties = {
            str(field_value["id"]): _sourced_value_schema(field_value)
            for field_value in category_fields
        }
        data_required = [
            str(field_value["id"])
            for field_value in category_fields
            if field_value["required"] is True
        ]
        record = {
            "type": "object",
            "additionalProperties": False,
            "required": ["record_id", "data"],
            "properties": {
                "record_id": {
                    "type": "string",
                    "minLength": 1,
                    "pattern": r"^[A-Za-z0-9][A-Za-z0-9._:/-]*$",
                    "description": (
                        "Stable within-document record id; reuse it when rerunning extraction."
                    ),
                },
                "data": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": data_required,
                    "properties": data_properties,
                },
            },
        }
        properties[category] = {"type": "array", "items": record}

    return {
        "$schema": EXTRACTION_SCHEMA_DRAFT,
        "$id": (
            "https://paperclip.gxl.ai/schemas/structured-extraction/"
            f"{registry['optimization_input_sha256']}.json"
        ),
        "title": "Locked paper-level structured extraction",
        "description": (
            "Generated from the optimized registry. Every reported value carries its own "
            "exact source path and canonical line range; extractor notes are judgments, "
            "not source verification claims."
        ),
        "type": "object",
        "additionalProperties": False,
        "required": required,
        "properties": properties,
        "definitions": {
            "source_location": _source_location_schema(),
            "sourced_string": {
                "type": "object",
                "additionalProperties": False,
                "required": ["value", "as_reported", "source_locations"],
                "properties": {
                    "value": {"type": "string", "minLength": 1},
                    "as_reported": {"type": "string", "minLength": 1},
                    "source_locations": {
                        "type": "array",
                        "minItems": 1,
                        "items": {"$ref": "#/definitions/source_location"},
                    },
                },
            },
            "source_note": {
                "type": "object",
                "additionalProperties": False,
                "required": ["note", "source_locations"],
                "properties": {
                    "note": {"type": "string", "minLength": 1},
                    "source_locations": {
                        "type": "array",
                        "minItems": 1,
                        "items": {"$ref": "#/definitions/source_location"},
                    },
                },
            },
            "extractor_note": {
                "type": "object",
                "additionalProperties": False,
                "required": ["kind", "note"],
                "properties": {
                    "kind": {"const": "extractor_judgment"},
                    "note": {
                        "type": "string",
                        "minLength": 1,
                        "description": (
                            "Explicit non-source extractor judgment; must not claim "
                            "verification or source support."
                        ),
                    },
                },
            },
            "ambiguity": {
                "type": "object",
                "additionalProperties": False,
                "required": ["description", "affected_fields"],
                "properties": {
                    "description": {"type": "string", "minLength": 1},
                    "affected_fields": {
                        "type": "array",
                        "minItems": 1,
                        "items": {"type": "string", "minLength": 1},
                    },
                    "source_locations": {
                        "type": "array",
                        "minItems": 1,
                        "items": {"$ref": "#/definitions/source_location"},
                    },
                },
            },
            "missing_visual_evidence": {
                "type": "object",
                "additionalProperties": False,
                "required": ["description", "source_locations"],
                "properties": {
                    "description": {"type": "string", "minLength": 1},
                    "source_locations": {
                        "type": "array",
                        "minItems": 1,
                        "items": {"$ref": "#/definitions/source_location"},
                    },
                },
            },
        },
        "x-schema-optimization": {
            "schema_version": registry["schema_version"],
            "version": registry["version"],
            "revision": registry["revision"],
            "optimization_input_sha256": registry["optimization_input_sha256"],
            "bindings": deepcopy(registry["bindings"]),
        },
    }


build_extraction_schema = generate_extraction_schema


def generate_fallback_claim_schema(registry: Mapping[str, Any]) -> dict[str, Any]:
    """Project the locked paper schema into exhaustive-worker record claims."""
    paper_schema = generate_extraction_schema(registry)
    categories = sorted(
        key
        for key in paper_schema["properties"]
        if key
        not in {
            "document_id",
            "source_notes",
            "extractor_notes",
            "ambiguities",
            "missing_visual_evidence",
        }
    )
    return {
        "$schema": EXTRACTION_SCHEMA_DRAFT,
        "$id": paper_schema["$id"].replace(".json", "/fallback-claim.json"),
        "title": "Locked exhaustive fallback record",
        "description": (
            "One category-scoped record from the locked paper extraction schema. "
            "A deterministic merge reconstructs the complete paper object."
        ),
        "oneOf": [
            {
                "type": "object",
                "additionalProperties": False,
                "required": ["category", "record"],
                "properties": {
                    "category": {"const": category},
                    "record": deepcopy(
                        paper_schema["properties"][category]["items"]
                    ),
                },
            }
            for category in categories
        ],
        "definitions": deepcopy(paper_schema["definitions"]),
        "x-parent-extraction-schema-id": paper_schema["$id"],
        "x-schema-optimization": deepcopy(paper_schema["x-schema-optimization"]),
    }


def _load_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SchemaOptimizationError(f"cannot read {label}: {exc}") from exc
    if not isinstance(value, dict):
        raise SchemaOptimizationError(f"{label} must contain a JSON object")
    return value


def current_schema_bindings(
    project: AnalysisProject,
    *,
    require_passing_pilot: bool = True,
) -> dict[str, Any]:
    """Build exact bindings to approved inputs and the current pilot state."""
    approval = project.approvals.get("question")
    if approval is None:
        raise SchemaOptimizationError(
            "schema optimization requires an approved Question checkpoint"
        )
    root = Path(project.topic_dir)
    collection_path = root / COLLECTION_SPEC_FILENAME
    outputs_path = root / PLANNED_OUTPUTS_FILENAME
    collection = _load_object(collection_path, COLLECTION_SPEC_FILENAME)
    outputs = _load_object(outputs_path, PLANNED_OUTPUTS_FILENAME)
    collection_validation = validate_collection_spec(collection)
    if not collection_validation.ok:
        raise SchemaOptimizationError(
            f"{COLLECTION_SPEC_FILENAME}: " + "; ".join(collection_validation.errors)
        )
    output_validation = validate_planned_outputs(outputs)
    if not output_validation.ok:
        raise SchemaOptimizationError(
            f"{PLANNED_OUTPUTS_FILENAME}: " + "; ".join(output_validation.errors)
        )
    collection_file_hash = sha256_file(collection_path)
    outputs_hash = sha256_file(outputs_path)
    for name, digest in (
        (COLLECTION_SPEC_FILENAME, collection_file_hash),
        (PLANNED_OUTPUTS_FILENAME, outputs_hash),
    ):
        if approval.artifact_hashes.get(name) != digest:
            raise SchemaOptimizationError(f"{name} is not the current approved Question artifact")
    material_hash = collection_schema_hash(collection)
    pilot_ready = collection.get("pilot_status") == "ready_for_scale"
    if require_passing_pilot and not pilot_ready:
        raise SchemaOptimizationError(
            "collection pilot must pass with pilot_status 'ready_for_scale'"
        )
    if require_passing_pilot and collection.get("pilot_schema_hash") != material_hash:
        raise SchemaOptimizationError(
            "passing pilot is not bound to the approved material collection schema"
        )
    pilot_summary = collection.get("pilot_summary")
    if require_passing_pilot and not isinstance(pilot_summary, Mapping):
        raise SchemaOptimizationError("passing pilot summary is missing")
    pilot_binding = (
        pilot_summary
        if pilot_ready and isinstance(pilot_summary, Mapping)
        else {
            "pilot_status": collection.get("pilot_status"),
            "pilot_schema_hash": collection.get("pilot_schema_hash"),
        }
    )
    return {
        "project_id": project.project_id,
        "project_revision": project.revision,
        "question_approval_sha256": canonical_sha256(approval.artifact_hashes),
        "collection_spec_sha256": collection_file_hash,
        "collection_schema_sha256": material_hash,
        "planned_outputs_sha256": outputs_hash,
        "pilot_summary_sha256": canonical_sha256(pilot_binding),
    }


def optimize_extraction_schema(
    project: AnalysisProject,
    candidate: Mapping[str, Any] | Path | str,
) -> tuple[dict[str, Any], dict[str, Any], bool]:
    """Validate, revision, and persist the registry and generated schema."""
    root = Path(project.topic_dir)
    if isinstance(candidate, (Path, str)):
        candidate_value = _load_object(
            Path(candidate).expanduser().resolve(),
            "schema optimization input",
        )
    elif isinstance(candidate, Mapping):
        candidate_value = dict(candidate)
    else:
        raise SchemaOptimizationError("schema optimization input must contain an object")
    bindings = current_schema_bindings(project, require_passing_pilot=False)
    registry_path = root / SCHEMA_OPTIMIZATION_FILENAME
    previous = (
        _load_object(registry_path, SCHEMA_OPTIMIZATION_FILENAME)
        if registry_path.is_file()
        else None
    )
    registry = build_schema_optimization(
        candidate_value,
        bindings=bindings,
        previous=previous,
    )
    extraction_schema = generate_extraction_schema(registry)
    fallback_claim_schema = generate_fallback_claim_schema(registry)
    unchanged = previous == registry
    schema_path = root / EXTRACTION_SCHEMA_FILENAME
    fallback_path = root / FALLBACK_CLAIM_SCHEMA_FILENAME
    if unchanged and schema_path.is_file():
        current_schema = _load_object(schema_path, EXTRACTION_SCHEMA_FILENAME)
        unchanged = current_schema == extraction_schema
    if unchanged and fallback_path.is_file():
        current_fallback = _load_object(
            fallback_path,
            FALLBACK_CLAIM_SCHEMA_FILENAME,
        )
        unchanged = current_fallback == fallback_claim_schema
    if not unchanged:
        atomic_write_json(registry_path, registry)
        atomic_write_json(schema_path, extraction_schema)
        atomic_write_json(fallback_path, fallback_claim_schema)
    elif not schema_path.is_file():
        atomic_write_json(schema_path, extraction_schema)
        atomic_write_json(fallback_path, fallback_claim_schema)
        unchanged = False
    elif not fallback_path.is_file():
        atomic_write_json(fallback_path, fallback_claim_schema)
        unchanged = False
    registry_hash = sha256_file(registry_path)
    schema_hash = sha256_file(schema_path)
    lock_still_current = (
        project.schema_registry_sha256 == registry_hash
        and project.extraction_schema_sha256 == schema_hash
        and schema_lock_is_current(project)
    )
    if not lock_still_current:
        project.schema_registry_sha256 = None
        project.extraction_schema_sha256 = None
        project.schema_lock_sha256 = None
        project.scaled_extraction_ready = False
    return registry, extraction_schema, not unchanged


write_schema_optimization = optimize_extraction_schema


def _lock_payload(lock: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): deepcopy(value) for key, value in lock.items() if key != "lock_content_sha256"
    }


def validate_schema_lock(
    value: object,
    *,
    project: AnalysisProject | None = None,
) -> SchemaOptimizationValidation:
    """Validate lock integrity and, when supplied, current project bindings."""
    result = SchemaOptimizationValidation()
    if not isinstance(value, Mapping):
        result.errors.append(f"{SCHEMA_LOCK_FILENAME} must contain an object")
        return result
    if value.get("schema_version") != SCHEMA_LOCK_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {SCHEMA_LOCK_SCHEMA_VERSION}")
    if value.get("status") != "locked":
        result.errors.append("status must be 'locked'")
    for name in (
        "schema_registry_sha256",
        "extraction_schema_sha256",
        "fallback_claim_schema_sha256",
    ):
        if not _valid_sha256(value.get(name)):
            result.errors.append(f"{name} must be a lowercase SHA-256")
    if value.get("lock_content_sha256") != canonical_sha256(_lock_payload(value)):
        result.errors.append("lock_content_sha256 does not match the lock payload")
    _validate_bindings(value.get("bindings"), result.errors)
    if project is not None:
        if value.get("project_id") != project.project_id:
            result.errors.append("lock project_id does not match the project")
        if value.get("project_revision") != project.revision:
            result.errors.append("lock project_revision does not match the project revision")
        try:
            bindings = current_schema_bindings(project)
        except SchemaOptimizationError as exc:
            result.errors.append(str(exc))
        else:
            if value.get("bindings") != bindings:
                result.errors.append("lock bindings do not match approved pilot inputs")
    return result


def schema_lock_is_current(project: AnalysisProject) -> bool:
    """Return whether state, files, generated schema, and approved inputs agree."""
    if not project.scaled_extraction_ready:
        return False
    if not all(
        (
            _valid_sha256(project.schema_registry_sha256),
            _valid_sha256(project.extraction_schema_sha256),
            _valid_sha256(project.schema_lock_sha256),
        )
    ):
        return False
    root = Path(project.topic_dir)
    registry_path = root / SCHEMA_OPTIMIZATION_FILENAME
    schema_path = root / EXTRACTION_SCHEMA_FILENAME
    fallback_path = root / FALLBACK_CLAIM_SCHEMA_FILENAME
    lock_path = root / SCHEMA_LOCK_FILENAME
    if not all(
        path.is_file()
        for path in (registry_path, schema_path, fallback_path, lock_path)
    ):
        return False
    try:
        if sha256_file(registry_path) != project.schema_registry_sha256:
            return False
        if sha256_file(schema_path) != project.extraction_schema_sha256:
            return False
        if sha256_file(lock_path) != project.schema_lock_sha256:
            return False
        registry = _load_object(registry_path, SCHEMA_OPTIMIZATION_FILENAME)
        extraction_schema = _load_object(schema_path, EXTRACTION_SCHEMA_FILENAME)
        fallback_schema = _load_object(
            fallback_path,
            FALLBACK_CLAIM_SCHEMA_FILENAME,
        )
        lock = _load_object(lock_path, SCHEMA_LOCK_FILENAME)
        bindings = current_schema_bindings(project)
    except (OSError, SchemaOptimizationError):
        return False
    if not validate_schema_optimization(
        registry,
        expected_bindings=bindings,
    ).ok:
        return False
    if extraction_schema != generate_extraction_schema(registry):
        return False
    if fallback_schema != generate_fallback_claim_schema(registry):
        return False
    if not validate_schema_lock(lock, project=project).ok:
        return False
    return (
        lock.get("schema_registry_sha256") == project.schema_registry_sha256
        and lock.get("extraction_schema_sha256") == project.extraction_schema_sha256
        and lock.get("fallback_claim_schema_sha256")
        == sha256_file(fallback_path)
    )


def lock_extraction_schema(
    project: AnalysisProject,
) -> tuple[dict[str, Any], bool]:
    """Lock the exact validated registry/schema bytes for scaled extraction."""
    root = Path(project.topic_dir)
    registry_path = root / SCHEMA_OPTIMIZATION_FILENAME
    schema_path = root / EXTRACTION_SCHEMA_FILENAME
    fallback_path = root / FALLBACK_CLAIM_SCHEMA_FILENAME
    registry = _load_object(registry_path, SCHEMA_OPTIMIZATION_FILENAME)
    extraction_schema = _load_object(schema_path, EXTRACTION_SCHEMA_FILENAME)
    fallback_schema = _load_object(
        fallback_path,
        FALLBACK_CLAIM_SCHEMA_FILENAME,
    )
    bindings = current_schema_bindings(project)
    validation = validate_schema_optimization(
        registry,
        expected_bindings=bindings,
    )
    if not validation.ok:
        raise SchemaOptimizationError("; ".join(validation.errors))
    expected_schema = generate_extraction_schema(registry)
    if extraction_schema != expected_schema:
        raise SchemaOptimizationError(
            f"{EXTRACTION_SCHEMA_FILENAME} is stale or was modified; rerun schema-optimize"
        )
    if fallback_schema != generate_fallback_claim_schema(registry):
        raise SchemaOptimizationError(
            f"{FALLBACK_CLAIM_SCHEMA_FILENAME} is stale or was modified; "
            "rerun schema-optimize"
        )
    registry_hash = sha256_file(registry_path)
    schema_hash = sha256_file(schema_path)
    fallback_hash = sha256_file(fallback_path)
    payload: dict[str, Any] = {
        "schema_version": SCHEMA_LOCK_SCHEMA_VERSION,
        "status": "locked",
        "project_id": project.project_id,
        "project_revision": project.revision,
        "registry_revision": registry["revision"],
        "schema_registry_sha256": registry_hash,
        "extraction_schema_sha256": schema_hash,
        "fallback_claim_schema_sha256": fallback_hash,
        "bindings": deepcopy(bindings),
        "observation_policy": {
            "unknown_categorical_option": "map_to_other_and_log",
            "locked_schema_mutation": "forbidden",
            "revision_requires_new_pilot_and_lock": True,
        },
    }
    payload["lock_content_sha256"] = canonical_sha256(payload)
    lock_path = root / SCHEMA_LOCK_FILENAME
    existing = _load_object(lock_path, SCHEMA_LOCK_FILENAME) if lock_path.is_file() else None
    changed = existing != payload
    if changed:
        atomic_write_json(lock_path, payload)
    lock_file_hash = sha256_file(lock_path)
    state_changed = (
        project.schema_registry_sha256 != registry_hash
        or project.extraction_schema_sha256 != schema_hash
        or project.schema_lock_sha256 != lock_file_hash
        or not project.scaled_extraction_ready
    )
    project.schema_registry_sha256 = registry_hash
    project.extraction_schema_sha256 = schema_hash
    project.schema_lock_sha256 = lock_file_hash
    project.scaled_extraction_ready = True
    return payload, changed or state_changed


lock_schema = lock_extraction_schema


def scaled_extraction_readiness(project: AnalysisProject) -> SchemaOptimizationValidation:
    """Return a deterministic readiness result for locked scaled extraction."""
    result = SchemaOptimizationValidation()
    if not schema_lock_is_current(project):
        result.errors.append(
            "scaled extraction requires a current locked optimized schema; "
            "run schema-optimize and schema-lock after a passing pilot"
        )
    return result


def _observation_identity(value: Mapping[str, Any]) -> str:
    return canonical_sha256(
        {
            "document_id": value.get("document_id"),
            "field_id": value.get("field_id"),
            "as_reported": value.get("as_reported"),
            "source_locations": value.get("source_locations"),
        }
    )


def validate_schema_observations(
    value: object,
    *,
    lock_sha256: str | None = None,
    extraction_schema_sha256: str | None = None,
) -> SchemaOptimizationValidation:
    """Validate the append-only unknown-option observation contract."""
    result = SchemaOptimizationValidation()
    if not isinstance(value, Mapping):
        result.errors.append(f"{SCHEMA_OBSERVATIONS_FILENAME} must contain an object")
        return result
    if value.get("schema_version") != SCHEMA_OBSERVATIONS_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {SCHEMA_OBSERVATIONS_SCHEMA_VERSION}")
    for name, expected in (
        ("schema_lock_sha256", lock_sha256),
        ("extraction_schema_sha256", extraction_schema_sha256),
    ):
        if not _valid_sha256(value.get(name)):
            result.errors.append(f"{name} must be a lowercase SHA-256")
        elif expected is not None and value.get(name) != expected:
            result.errors.append(f"{name} does not match the current locked schema")
    observations = value.get("observations")
    if not isinstance(observations, list):
        result.errors.append("observations must be an array")
        return result
    identities: list[str] = []
    for index, observation in enumerate(observations):
        prefix = f"observations[{index}]"
        if not isinstance(observation, Mapping):
            result.errors.append(f"{prefix} must be an object")
            continue
        if not _nonempty_string(observation.get("observation_id")):
            result.errors.append(f"{prefix}.observation_id must be a non-empty string")
        elif observation["observation_id"] != f"unknown_{_observation_identity(observation)[:20]}":
            result.errors.append(f"{prefix}.observation_id is not deterministic")
        for name in ("document_id", "field_id", "as_reported"):
            if not _nonempty_string(observation.get(name)):
                result.errors.append(f"{prefix}.{name} must be a non-empty string")
        if observation.get("selected_option_id") != "other":
            result.errors.append(f"{prefix}.selected_option_id must be 'other'")
        _validate_source_locations(
            observation.get("source_locations"),
            f"{prefix}.source_locations",
            result.errors,
        )
        identities.append(str(observation.get("observation_id")))
    if len(identities) != len(set(identities)):
        result.errors.append("observations must not contain duplicate observation_ids")
    return result


def log_unknown_schema_observation(
    project: AnalysisProject,
    *,
    document_id: str,
    field_id: str,
    as_reported: str,
    source_locations: Sequence[Mapping[str, str]],
) -> tuple[dict[str, Any], bool]:
    """Map one unknown categorical label to ``other`` and log it separately."""
    if not schema_lock_is_current(project):
        raise SchemaOptimizationError(
            "unknown options can be logged only against a current locked schema"
        )
    root = Path(project.topic_dir)
    registry = _load_object(
        root / SCHEMA_OPTIMIZATION_FILENAME,
        SCHEMA_OPTIMIZATION_FILENAME,
    )
    fields = {
        str(field_value["id"]): field_value
        for field_value in registry["fields"]
        if isinstance(field_value, Mapping) and _nonempty_string(field_value.get("id"))
    }
    field_value = fields.get(field_id)
    if field_value is None:
        raise SchemaOptimizationError(f"unknown optimized field {field_id!r}")
    if field_value.get("value_type") != "categorical":
        raise SchemaOptimizationError(f"field {field_id!r} is not categorical")
    known_labels: set[str] = set()
    for option in field_value.get("options", []):
        if not isinstance(option, Mapping):
            continue
        labels = [option.get("id"), option.get("label")]
        aliases = option.get("aliases")
        if isinstance(aliases, list):
            labels.extend(aliases)
        known_labels.update(str(label).casefold() for label in labels if _nonempty_string(label))
    if as_reported.strip().casefold() in known_labels:
        raise SchemaOptimizationError(
            f"{as_reported!r} is already a canonical option or alias for {field_id!r}"
        )
    observation: dict[str, Any] = {
        "document_id": document_id.strip(),
        "field_id": field_id,
        "as_reported": as_reported.strip(),
        "selected_option_id": "other",
        "source_locations": [
            {"path": str(location.get("path", "")), "lines": str(location.get("lines", ""))}
            for location in source_locations
        ],
    }
    observation["observation_id"] = f"unknown_{_observation_identity(observation)[:20]}"
    path = root / SCHEMA_OBSERVATIONS_FILENAME
    if path.is_file():
        artifact = _load_object(path, SCHEMA_OBSERVATIONS_FILENAME)
        validation = validate_schema_observations(
            artifact,
            lock_sha256=project.schema_lock_sha256,
            extraction_schema_sha256=project.extraction_schema_sha256,
        )
        if not validation.ok:
            raise SchemaOptimizationError("; ".join(validation.errors))
    else:
        artifact = {
            "schema_version": SCHEMA_OBSERVATIONS_SCHEMA_VERSION,
            "schema_lock_sha256": project.schema_lock_sha256,
            "extraction_schema_sha256": project.extraction_schema_sha256,
            "observations": [],
        }
    existing = {
        item.get("observation_id") for item in artifact["observations"] if isinstance(item, Mapping)
    }
    changed = observation["observation_id"] not in existing
    if changed:
        artifact["observations"].append(observation)
        artifact["observations"] = sorted(
            artifact["observations"],
            key=lambda item: str(item.get("observation_id", "")),
        )
        validation = validate_schema_observations(
            artifact,
            lock_sha256=project.schema_lock_sha256,
            extraction_schema_sha256=project.extraction_schema_sha256,
        )
        if not validation.ok:
            raise SchemaOptimizationError("; ".join(validation.errors))
        atomic_write_json(path, artifact)
    return artifact, changed


record_unknown_option_observation = log_unknown_schema_observation
