"""Dynamic guided-analysis artifact contracts.

The contracts in this module deliberately validate only the small, universal
envelopes needed by the lifecycle. Project-specific extraction fields and
analysis inputs remain data, not Python schema.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from gxl_paperclip.meta_analysis.cards import (
    CARD_TYPES,
    LEGACY_CARD_TYPE_ALIASES,
    normalize_card_type,
    normalize_finding_card,
)

COLLECTION_SPEC_SCHEMA_VERSION = 1
PLANNED_OUTPUTS_SCHEMA_VERSION = 1
EVIDENCE_PROPOSAL_SCHEMA_VERSION = 1
ANALYSIS_INPUTS_SCHEMA_VERSION = 1
HARMONIZATION_MAP_SCHEMA_VERSION = 1
HARMONIZATION_QUEUE_SCHEMA_VERSION = 1

COLLECTION_SPEC_FILENAME = "collection_spec.json"
PLANNED_OUTPUTS_FILENAME = "planned_outputs.json"
EVIDENCE_PROPOSAL_FILENAME = "evidence_proposal.json"
ANALYSIS_INPUTS_FILENAME = "analysis_inputs.json"
HARMONIZATION_MAP_FILENAME = "harmonization_map.json"
HARMONIZATION_QUEUE_FILENAME = "harmonization_queue.json"

PILOT_STATUSES = frozenset({"not_run", "needs_rerun", "running", "failed", "ready_for_scale"})
PROPOSAL_CLASSIFICATIONS = frozenset(
    {"selected", "descriptive", "duplicate", "excluded", "unresolved"}
)
HARMONIZATION_DECISION_STATUSES = frozenset(
    {"automatic_obvious", "user_approved", "unresolved"}
)
HARMONIZATION_RELATIONS = frozenset(
    {"exact", "alias", "broader_than", "narrower_than", "part_of", "related_to", "distinct"}
)
HARMONIZATION_HIERARCHY_RELATIONS = frozenset(
    {"broader_than", "narrower_than", "part_of", "related_to"}
)
HARMONIZATION_REVISION_TYPES = frozenset(
    {"initial", "mechanical_alias", "material_meaning"}
)
_PILOT_METADATA_KEYS = frozenset(
    {
        "pilot_status",
        "pilot_schema_hash",
        "pilot_summary",
        "pilot_revision_history",
    }
)


@dataclass
class ContractValidation:
    """A compact validation result shared by guided artifact contracts."""

    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


def _nonempty_string(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _valid_version(value: object) -> bool:
    return (
        isinstance(value, int)
        and not isinstance(value, bool)
        and value >= 1
        or _nonempty_string(value)
    )


def _named_collection(value: object) -> bool:
    if isinstance(value, Mapping):
        return bool(value) and all(_nonempty_string(key) for key in value)
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)) or not value:
        return False
    for item in value:
        if isinstance(item, str) and item.strip():
            continue
        if not isinstance(item, Mapping):
            return False
        if not any(_nonempty_string(item.get(key)) for key in ("id", "name", "field", "key")):
            return False
    return True


def _string_choices(value: object) -> bool:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)) or not value:
        return False
    return all(_nonempty_string(item) for item in value) and len(
        {str(item).strip() for item in value}
    ) == len(value)


def _declared_card_types(wrapper: Mapping[str, Any]) -> dict[str, object]:
    value = wrapper.get("card_types") or wrapper.get("types")
    if isinstance(value, Mapping):
        return {str(key): details for key, details in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        result: dict[str, object] = {}
        for item in value:
            if isinstance(item, str):
                result[item] = item
            elif isinstance(item, Mapping):
                name = item.get("type") or item.get("id") or item.get("name")
                if isinstance(name, str):
                    result[name] = item
        return result
    return {}


def _without_mechanical_aliases(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            str(key): _without_mechanical_aliases(item)
            for key, item in value.items()
            if key not in {"aliases", "obvious_aliases"}
        }
    if isinstance(value, list):
        return [_without_mechanical_aliases(item) for item in value]
    return value


def collection_schema_payload(spec: Mapping[str, Any]) -> dict[str, Any]:
    """Return the material, pilot-independent collection definition."""
    return {
        str(key): _without_mechanical_aliases(value)
        for key, value in spec.items()
        if key not in _PILOT_METADATA_KEYS
        and key not in {"aliases", "rationale"}
    }


def collection_schema_hash(spec: Mapping[str, Any]) -> str:
    """Hash material collection semantics with canonical JSON encoding."""
    encoded = json.dumps(
        collection_schema_payload(spec),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _passing_component(value: object) -> bool:
    if value is True:
        return True
    if not isinstance(value, Mapping):
        return False
    if value.get("passed") is True:
        return True
    return str(value.get("status", "")).strip().lower() in {
        "pass",
        "passed",
        "acceptable",
        "agreed",
    }


def validate_pilot_summary(summary: object) -> ContractValidation:
    """Validate the universal pilot report without imposing domain fields."""
    result = ContractValidation()
    if not isinstance(summary, Mapping):
        result.errors.append("pilot_summary must be an object")
        return result
    for key in ("papers", "coverage", "ambiguities", "validation", "independent_agreement"):
        if key not in summary:
            result.errors.append(f"pilot_summary is missing {key!r}")
    papers = summary.get("papers")
    if not (
        isinstance(papers, int)
        and not isinstance(papers, bool)
        and papers > 0
        or isinstance(papers, Sequence)
        and not isinstance(papers, (str, bytes, bytearray))
        and bool(papers)
    ):
        result.errors.append("pilot_summary.papers must be a positive count or non-empty array")
    if summary.get("coverage") in (None, "", [], {}):
        result.errors.append("pilot_summary.coverage must describe pilot coverage")
    if "ambiguities" in summary and not isinstance(summary.get("ambiguities"), (list, dict)):
        result.errors.append("pilot_summary.ambiguities must be an array or object")
    if "validation" in summary and not _passing_component(summary.get("validation")):
        result.errors.append("pilot_summary.validation must record a passing result")
    if "independent_agreement" in summary and not _passing_component(
        summary.get("independent_agreement")
    ):
        result.errors.append("pilot_summary.independent_agreement must record a passing result")
    return result


def validate_collection_spec(value: object) -> ContractValidation:
    """Validate a dynamic collection plan and its current pilot binding."""
    result = ContractValidation()
    if not isinstance(value, Mapping):
        result.errors.append("collection_spec.json must contain an object")
        return result
    if value.get("schema_version") != COLLECTION_SPEC_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {COLLECTION_SPEC_SCHEMA_VERSION}")
    if not _valid_version(value.get("version")):
        result.errors.append("version must be a positive integer or non-empty string")
    if not _nonempty_string(value.get("rationale")):
        result.errors.append("rationale must be a non-empty string")

    wrapper = value.get("record_wrapper") or value.get("universal_wrapper") or value.get("wrapper")
    if not isinstance(wrapper, Mapping) or not wrapper:
        result.errors.append("record_wrapper must define the universal card envelope")
    else:
        wrapper_text = json.dumps(wrapper, sort_keys=True).casefold()
        wrapper_concepts = {
            "card type": ("card_type", "card type", '"type"'),
            "record type": ("record_type", "record type", "category"),
            "paper id": ("paper_id", "paper id", "document_id"),
            "source locations/lines": (
                "source_locations",
                "source locations",
                "source_lines",
                "source lines",
            ),
            "payload": ("payload", "raw_payload", "data"),
        }
        for concept, labels in wrapper_concepts.items():
            if not any(label in wrapper_text for label in labels):
                result.errors.append(f"record_wrapper must define universal {concept}")
        declared = _declared_card_types(wrapper)
        normalized_card_types = [normalize_card_type(name) for name in declared]
        normalized_declared = {
            card_type for card_type in normalized_card_types if card_type is not None
        }
        if (
            normalized_declared != set(CARD_TYPES)
            or any(card_type is None for card_type in normalized_card_types)
        ):
            result.errors.append(
                "record_wrapper.card_types must define exactly: " + ", ".join(CARD_TYPES)
            )
        legacy_names = set(declared) & set(LEGACY_CARD_TYPE_ALIASES)
        if legacy_names:
            result.errors.append(
                "new collection specs must use universal card types, not legacy aliases: "
                + ", ".join(sorted(legacy_names))
            )
        analysis_unit = declared.get("analysis_unit")
        analysis_unit_text = json.dumps(analysis_unit, sort_keys=True).casefold()
        for concept in ("unit_type", "count", "relationship", "data"):
            if concept not in analysis_unit_text:
                result.errors.append(
                    f"record_wrapper.card_types.analysis_unit must describe dynamic {concept}"
                )
        assessment = declared.get("assessment")
        assessment_text = json.dumps(assessment, sort_keys=True).casefold()
        assessment_concepts = {
            "judgment": ("judgment", "reviewer", "claude"),
            "provenance": ("provenance", "assessor"),
            "source support": ("source support", "source_support", "source-supported"),
        }
        for concept, labels in assessment_concepts.items():
            if not any(label in assessment_text for label in labels):
                result.errors.append(
                    f"record_wrapper.card_types.assessment must describe {concept}"
                )
    if not _named_collection(value.get("categories")):
        result.errors.append("categories must be a non-empty named collection")
    if not _named_collection(value.get("fields")):
        result.errors.append("fields must be a non-empty named collection")
    if not _named_collection(value.get("definitions")):
        result.errors.append("definitions must be a non-empty named collection")
    aliases = value.get("aliases")
    if not isinstance(aliases, Mapping):
        result.errors.append("aliases must be an object (use {} when none are needed)")
    provisional = value.get("provisional_normalizations")
    if not isinstance(provisional, Mapping):
        result.errors.append(
            "provisional_normalizations must be an object (use {} when none are needed)"
        )
    if not _string_choices(value.get("missing_status_choices")):
        result.errors.append("missing_status_choices must be a non-empty array of unique strings")

    history = value.get("pilot_revision_history")
    if not isinstance(history, list) or not all(isinstance(item, Mapping) for item in history):
        result.errors.append("pilot_revision_history must be an array of objects")
    status = value.get("pilot_status")
    if status not in PILOT_STATUSES:
        result.errors.append("pilot_status must be one of: " + ", ".join(sorted(PILOT_STATUSES)))
    if status == "ready_for_scale":
        try:
            current_hash = collection_schema_hash(value)
        except (TypeError, ValueError) as exc:
            result.errors.append(f"material collection definition is not canonical JSON: {exc}")
        else:
            if value.get("pilot_schema_hash") != current_hash:
                result.errors.append(
                    "pilot_schema_hash does not match the current material collection schema"
                )
        result.errors.extend(validate_pilot_summary(value.get("pilot_summary")).errors)
    return result


def mark_pilot_needs_rerun(
    spec: dict[str, Any],
    *,
    reason: str,
    recorded_at: str,
) -> str:
    """Mark a material collection definition as requiring a fresh pilot."""
    schema_hash = collection_schema_hash(spec)
    spec["pilot_status"] = "needs_rerun"
    spec.pop("pilot_summary", None)
    history = spec.setdefault("pilot_revision_history", [])
    if not isinstance(history, list):
        raise ValueError("pilot_revision_history must be an array")
    entry = {
        "schema_hash": schema_hash,
        "status": "needs_rerun",
        "reason": reason,
        "recorded_at": recorded_at,
    }
    if not history or history[-1] != entry:
        history.append(entry)
    return schema_hash


def record_pilot_summary(
    spec: dict[str, Any],
    summary: Mapping[str, Any],
    *,
    recorded_at: str,
) -> ContractValidation:
    """Bind a passing pilot summary to the exact current material schema."""
    result = validate_pilot_summary(summary)
    if not result.ok:
        return result
    schema_hash = collection_schema_hash(spec)
    spec["pilot_schema_hash"] = schema_hash
    spec["pilot_summary"] = dict(summary)
    spec["pilot_status"] = "ready_for_scale"
    history = spec.setdefault("pilot_revision_history", [])
    if not isinstance(history, list):
        return ContractValidation(errors=["pilot_revision_history must be an array"])
    history.append(
        {
            "schema_hash": schema_hash,
            "status": "ready_for_scale",
            "recorded_at": recorded_at,
            "summary": dict(summary),
        }
    )
    return validate_collection_spec(spec)


def _output_rows(value: object, key: str, errors: list[str]) -> list[Mapping[str, Any]]:
    rows = value.get(key) if isinstance(value, Mapping) else None
    if not isinstance(rows, list) or not all(isinstance(row, Mapping) for row in rows):
        errors.append(f"{key} must be an array of objects")
        return []
    return rows


def _output_id(row: Mapping[str, Any]) -> object:
    return row.get("id") or row.get("output_id")


def validate_planned_outputs(value: object) -> ContractValidation:
    """Validate user intent for analyses and visualizations."""
    result = ContractValidation()
    if not isinstance(value, Mapping):
        result.errors.append("planned_outputs.json must contain an object")
        return result
    if value.get("schema_version") != PLANNED_OUTPUTS_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {PLANNED_OUTPUTS_SCHEMA_VERSION}")
    if not _valid_version(value.get("version")):
        result.errors.append("version must be a positive integer or non-empty string")
    rows: list[tuple[str, Mapping[str, Any]]] = []
    for key in ("analyses", "visualizations"):
        rows.extend((key, row) for row in _output_rows(value, key, result.errors))
    if not rows:
        result.errors.append("at least one desired analysis or visualization is required")
    seen: set[str] = set()
    for container, row in rows:
        identifier = _output_id(row)
        prefix = f"{container}[{identifier!r}]"
        if not _nonempty_string(identifier):
            result.errors.append(f"{prefix} requires a non-empty id")
        elif str(identifier) in seen:
            result.errors.append(f"duplicate desired output id {identifier!r}")
        else:
            seen.add(str(identifier))
        intent = row.get("intent") or row.get("type") or row.get("kind")
        if not _nonempty_string(intent):
            result.errors.append(f"{prefix} requires a non-empty intent/type")
        if not _nonempty_string(row.get("purpose")):
            result.errors.append(f"{prefix} requires a non-empty purpose")
        required = row.get("required_data")
        if not isinstance(required, list) or not all(
            _nonempty_string(item)
            or isinstance(item, Mapping)
            and _nonempty_string(item.get("field") or item.get("concept") or item.get("name"))
            for item in required
        ):
            result.errors.append(f"{prefix}.required_data must be an array of named requirements")
        provisional = row.get("provisional_status", row.get("provisional"))
        if not (isinstance(provisional, bool) or _nonempty_string(provisional)):
            result.errors.append(f"{prefix} requires a provisional_status")
        priority = row.get("priority")
        if not (
            isinstance(priority, int)
            and not isinstance(priority, bool)
            and priority >= 1
            or _nonempty_string(priority)
        ):
            result.errors.append(f"{prefix} requires a positive or named priority")
    return result


def _finding_rows(value: object) -> list[Mapping[str, Any]]:
    if isinstance(value, Mapping):
        value = value.get("findings")
    if not isinstance(value, list):
        return []
    return [
        normalize_finding_card(item)
        for item in value
        if isinstance(item, Mapping)
    ]


def _finding_id(row: Mapping[str, Any]) -> str | None:
    value = row.get("finding_id") or row.get("claim_id")
    return str(value) if _nonempty_string(value) else None


def _path_value(
    value: object,
    path: str,
    *,
    root_prefix: str,
) -> tuple[bool, object]:
    current = value
    normalized = path.removeprefix("$.").removeprefix(root_prefix)
    if not normalized:
        return True, current
    for part in normalized.split("."):
        if isinstance(current, Mapping) and part in current:
            current = current[part]
        elif isinstance(current, list) and part.isdigit() and int(part) < len(current):
            current = current[int(part)]
        else:
            return False, None
    return True, current


def _trace_entries(value: object) -> list[Mapping[str, Any]]:
    if isinstance(value, list):
        return [entry for entry in value if isinstance(entry, Mapping)]
    if isinstance(value, Mapping):
        entries: list[Mapping[str, Any]] = []
        for target, details in value.items():
            if isinstance(details, Mapping):
                entries.append({"target": target, **details})
        return entries
    return []


def _validate_traceability(
    row: Mapping[str, Any],
    findings: Mapping[str, Mapping[str, Any]],
    prefix: str,
) -> list[str]:
    errors: list[str] = []
    traceability = row.get("traceability")
    if traceability is None:
        return errors
    entries = _trace_entries(traceability)
    if not entries and traceability not in ([], {}):
        return [f"{prefix}.traceability must be an array or object"]
    for index, entry in enumerate(entries):
        location = f"{prefix}.traceability[{index}]"
        claim_id = entry.get("claim_id") or entry.get("finding_id")
        source_path = entry.get("source_path") or entry.get("source")
        target_path = entry.get("target_path") or entry.get("target") or entry.get("data_path")
        if not all(_nonempty_string(item) for item in (claim_id, source_path, target_path)):
            errors.append(f"{location} requires claim_id, source_path, and target_path")
            continue
        source = findings.get(str(claim_id))
        if source is None:
            errors.append(f"{location} references unknown claim {claim_id!r}")
            continue
        source_payload = source.get("raw_payload")
        source_ok, source_value = _path_value(
            source_payload,
            str(source_path),
            root_prefix="raw_payload.",
        )
        target_ok, target_value = _path_value(
            row.get("data"),
            str(target_path),
            root_prefix="data.",
        )
        if not source_ok:
            errors.append(f"{location}.source_path does not exist")
        if not target_ok:
            errors.append(f"{location}.target_path does not exist")
        if source_ok and target_ok and source_value != target_value:
            errors.append(f"{location} copied value does not match its verified source")
    return errors


def validate_evidence_proposal(
    value: object,
    verified_findings: object,
) -> ContractValidation:
    """Validate Claude's dynamic evidence classification and full coverage."""
    result = ContractValidation()
    if not isinstance(value, Mapping):
        result.errors.append("evidence_proposal.json must contain an object")
        return result
    if value.get("schema_version") != EVIDENCE_PROPOSAL_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {EVIDENCE_PROPOSAL_SCHEMA_VERSION}")
    findings_list = _finding_rows(verified_findings)
    findings: dict[str, Mapping[str, Any]] = {}
    for finding in findings_list:
        identifier = _finding_id(finding)
        if identifier:
            findings[identifier] = finding
    if not findings:
        result.errors.append("verified_findings contains no findings with stable ids")

    rows = value.get("rows")
    if not isinstance(rows, list) or not all(isinstance(row, Mapping) for row in rows):
        result.errors.append("rows must be an array of objects")
        return result
    covered: set[str] = set()
    row_ids: set[str] = set()
    for index, row in enumerate(rows):
        row_id = row.get("proposal_id") or row.get("id") or f"row-{index + 1}"
        prefix = f"rows[{row_id!r}]"
        if not _nonempty_string(row_id):
            result.errors.append(f"{prefix} requires a stable proposal_id")
        elif str(row_id) in row_ids:
            result.errors.append(f"duplicate proposal row id {row_id!r}")
        else:
            row_ids.add(str(row_id))
        assembled = row.get("assembled_from")
        if (
            not isinstance(assembled, list)
            or not assembled
            or not all(_nonempty_string(item) for item in assembled)
        ):
            result.errors.append(f"{prefix}.assembled_from must contain verified claim ids")
            assembled = []
        for claim_id in assembled:
            if str(claim_id) not in findings:
                result.errors.append(
                    f"{prefix}.assembled_from references unknown claim {claim_id!r}"
                )
            else:
                covered.add(str(claim_id))
        if row.get("classification") not in PROPOSAL_CLASSIFICATIONS:
            result.errors.append(
                f"{prefix}.classification must be selected, descriptive, duplicate, "
                "excluded, or unresolved"
            )
        if not _nonempty_string(row.get("use")):
            result.errors.append(f"{prefix}.use must be a non-empty string")
        if not _nonempty_string(row.get("reason")):
            result.errors.append(f"{prefix}.reason must be a non-empty string")
        decision_provenance = row.get("decision_provenance")
        if not isinstance(decision_provenance, Mapping):
            result.errors.append(
                f"{prefix}.decision_provenance must preserve reviewer/Claude provenance"
            )
        else:
            if not _nonempty_string(decision_provenance.get("assessor")):
                result.errors.append(
                    f"{prefix}.decision_provenance.assessor must be a non-empty string"
                )
            basis = (
                decision_provenance.get("basis")
                or decision_provenance.get("method")
                or decision_provenance.get("rationale")
            )
            if not _nonempty_string(basis):
                result.errors.append(
                    f"{prefix}.decision_provenance requires a basis, method, or rationale"
                )
        if not isinstance(row.get("data"), Mapping):
            result.errors.append(f"{prefix}.data must be an object")
        for key in ("missing_fields", "ambiguous_fields"):
            if not isinstance(row.get(key), list):
                result.errors.append(f"{prefix}.{key} must be an array")
        if not isinstance(row.get("relationships"), (list, dict)):
            result.errors.append(f"{prefix}.relationships must be an array or object")
        result.errors.extend(_validate_traceability(row, findings, prefix))

    missing = sorted(set(findings) - covered)
    if missing:
        result.errors.append(
            "verified findings are missing a proposal classification: " + ", ".join(missing)
        )
    return result


def _schema_type_matches(value: object, expected: object) -> bool:
    expected_types = [expected] if isinstance(expected, str) else expected
    if not isinstance(expected_types, list):
        return True
    checks = {
        "object": lambda item: isinstance(item, Mapping),
        "array": lambda item: isinstance(item, list),
        "string": lambda item: isinstance(item, str),
        "number": lambda item: isinstance(item, (int, float)) and not isinstance(item, bool),
        "integer": lambda item: isinstance(item, int) and not isinstance(item, bool),
        "boolean": lambda item: isinstance(item, bool),
        "null": lambda item: item is None,
    }
    return any(checks.get(str(kind), lambda _item: True)(value) for kind in expected_types)


def _validate_declared_input_schema(
    data: Mapping[str, Any],
    schema: object,
    prefix: str,
) -> list[str]:
    """Apply the small JSON-schema subset needed for approved input contracts."""
    if not isinstance(schema, Mapping):
        return []
    errors: list[str] = []
    required = schema.get("required")
    if isinstance(required, list):
        for field_name in required:
            if isinstance(field_name, str) and field_name not in data:
                errors.append(f"{prefix}.data is missing analysis-required {field_name!r}")
    properties = schema.get("properties")
    if isinstance(properties, Mapping):
        for field_name, rules in properties.items():
            if field_name not in data or not isinstance(rules, Mapping):
                continue
            if not _schema_type_matches(data[field_name], rules.get("type")):
                errors.append(f"{prefix}.data.{field_name} has invalid declared type")
    return errors


def validate_analysis_inputs(
    value: object,
    verified_findings: object,
    *,
    analysis_spec: object | None = None,
) -> ContractValidation:
    """Validate dynamic analysis rows against universal provenance only."""
    result = ContractValidation()
    if not isinstance(value, Mapping):
        result.errors.append("analysis_inputs.json must contain an object")
        return result
    if value.get("schema_version") != ANALYSIS_INPUTS_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {ANALYSIS_INPUTS_SCHEMA_VERSION}")
    findings = {
        identifier: row
        for row in _finding_rows(verified_findings)
        if (identifier := _finding_id(row)) is not None
    }
    rows = value.get("rows", value.get("inputs"))
    if not isinstance(rows, list) or not all(isinstance(row, Mapping) for row in rows):
        result.errors.append("rows must be an array of objects")
        return result
    input_schema: object = None
    if isinstance(analysis_spec, Mapping):
        input_schema = analysis_spec.get("input_schema")
    ids: set[str] = set()
    for index, row in enumerate(rows):
        input_id = row.get("input_id") or row.get("id")
        prefix = f"rows[{input_id or index + 1!r}]"
        if not _nonempty_string(input_id):
            result.errors.append(f"{prefix} requires a stable input_id")
        elif str(input_id) in ids:
            result.errors.append(f"duplicate analysis input id {input_id!r}")
        else:
            ids.add(str(input_id))
        assembled = row.get("assembled_from")
        if (
            not isinstance(assembled, list)
            or not assembled
            or not all(_nonempty_string(item) for item in assembled)
        ):
            result.errors.append(f"{prefix}.assembled_from must contain verified claim ids")
        else:
            for claim_id in assembled:
                if str(claim_id) not in findings:
                    result.errors.append(
                        f"{prefix}.assembled_from references unknown claim {claim_id!r}"
                    )
        data = row.get("data")
        if not isinstance(data, Mapping):
            result.errors.append(f"{prefix}.data must be an object")
        else:
            result.errors.extend(_validate_declared_input_schema(data, input_schema, prefix))
        if "relationships" in row and not isinstance(row["relationships"], (list, dict)):
            result.errors.append(f"{prefix}.relationships must be an array or object")
        result.errors.extend(_validate_traceability(row, findings, prefix))
    return result


def _sha256_string(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def _material_impact(
    value: object,
    prefix: str,
    errors: list[str],
) -> Mapping[str, Any] | None:
    if not isinstance(value, Mapping):
        errors.append(f"{prefix}.material_impact must be an object")
        return None
    if not isinstance(value.get("is_material"), bool):
        errors.append(f"{prefix}.material_impact.is_material must be a boolean")
    if not isinstance(value.get("pilot_rerun_required"), bool):
        errors.append(
            f"{prefix}.material_impact.pilot_rerun_required must be a boolean"
        )
    outputs = value.get("affected_outputs")
    if not isinstance(outputs, list) or not all(_nonempty_string(item) for item in outputs):
        errors.append(
            f"{prefix}.material_impact.affected_outputs must be an array of strings"
        )
    if value.get("is_material") is True and not _nonempty_string(value.get("description")):
        errors.append(
            f"{prefix}.material_impact.description is required for a material decision"
        )
    if value.get("is_material") is False and value.get("pilot_rerun_required") is True:
        errors.append(
            f"{prefix}.material_impact cannot require a pilot rerun when is_material is false"
        )
    return value


def _source_examples(value: object, prefix: str, errors: list[str]) -> None:
    if not isinstance(value, list) or not all(isinstance(item, Mapping) for item in value):
        errors.append(f"{prefix}.source_examples must be an array of objects")
        return
    for index, example in enumerate(value):
        if not any(
            _nonempty_string(example.get(key))
            for key in ("finding_id", "paper_id", "source_id")
        ):
            errors.append(
                f"{prefix}.source_examples[{index}] requires a finding_id, paper_id, or source_id"
            )


def _validate_revision_envelope(
    value: Mapping[str, Any],
    *,
    filename: str,
    errors: list[str],
) -> None:
    if not _valid_version(value.get("version")):
        errors.append("version must be a positive integer or non-empty string")
    revision = value.get("revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        errors.append("revision must be a positive integer")
    history = value.get("revision_history")
    if not isinstance(history, list) or not history:
        errors.append("revision_history must be a non-empty array of objects")
        return
    seen: set[int] = set()
    for index, entry in enumerate(history):
        prefix = f"revision_history[{index}]"
        if not isinstance(entry, Mapping):
            errors.append(f"{prefix} must be an object")
            continue
        entry_revision = entry.get("revision")
        if (
            not isinstance(entry_revision, int)
            or isinstance(entry_revision, bool)
            or entry_revision < 1
        ):
            errors.append(f"{prefix}.revision must be a positive integer")
        elif entry_revision in seen:
            errors.append(f"{prefix}.revision is duplicated")
        else:
            seen.add(entry_revision)
        if entry.get("change_type") not in HARMONIZATION_REVISION_TYPES:
            errors.append(
                f"{prefix}.change_type must be one of: "
                + ", ".join(sorted(HARMONIZATION_REVISION_TYPES))
            )
        if not _nonempty_string(entry.get("recorded_at")):
            errors.append(f"{prefix}.recorded_at must be a non-empty timestamp")
        if not _nonempty_string(entry.get("rationale")):
            errors.append(f"{prefix}.rationale must be a non-empty string")
    if isinstance(revision, int) and revision not in seen:
        errors.append(f"{filename} revision_history must include current revision {revision}")


def _validate_source_hashes(
    value: Mapping[str, Any],
    *,
    collection_hash: str | None,
    verified_findings_sha256: str | None,
    evidence_proposal_sha256: str | None,
    errors: list[str],
) -> None:
    bindings = (
        ("collection_schema_hash", collection_hash),
        ("verified_findings_sha256", verified_findings_sha256),
    )
    for field_name, expected in bindings:
        actual = value.get(field_name)
        if not _sha256_string(actual):
            errors.append(f"{field_name} must be a lowercase SHA-256 string")
        elif expected is not None and actual != expected:
            errors.append(f"{field_name} does not match the current source artifact")
    actual_proposal = value.get("evidence_proposal_sha256")
    if evidence_proposal_sha256 is None:
        if actual_proposal not in (None, ""):
            errors.append(
                "evidence_proposal_sha256 is present but evidence_proposal.json is absent"
            )
    elif not _sha256_string(actual_proposal):
        errors.append(
            "evidence_proposal_sha256 must bind the current evidence_proposal.json"
        )
    elif actual_proposal != evidence_proposal_sha256:
        errors.append(
            "evidence_proposal_sha256 does not match the current source artifact"
        )


def _concept_rows(
    value: object,
    errors: list[str],
) -> tuple[list[Mapping[str, Any]], set[str]]:
    if not isinstance(value, list) or not all(isinstance(item, Mapping) for item in value):
        errors.append("normalized_concepts must be an array of objects")
        return [], set()
    rows = list(value)
    identifiers: set[str] = set()
    for index, row in enumerate(rows):
        identifier = row.get("normalized_id")
        prefix = f"normalized_concepts[{identifier or index + 1!r}]"
        if not _nonempty_string(identifier):
            errors.append(f"{prefix}.normalized_id must be a non-empty string")
        elif str(identifier) in identifiers:
            errors.append(f"duplicate normalized_id {identifier!r}")
        else:
            identifiers.add(str(identifier))
        if not _nonempty_string(row.get("dimension")):
            errors.append(f"{prefix}.dimension must be a non-empty string")
        if not _nonempty_string(row.get("preferred_label")):
            errors.append(f"{prefix}.preferred_label must be a non-empty string")
        attributes = row.get("attributes")
        if not isinstance(attributes, Mapping):
            errors.append(f"{prefix}.attributes must be an object")
        applies_to = row.get("applies_to_card_types")
        if applies_to is not None:
            if not isinstance(applies_to, list) or not applies_to:
                errors.append(f"{prefix}.applies_to_card_types must be a non-empty array")
            else:
                normalized_types = [normalize_card_type(item) for item in applies_to]
                if any(item is None for item in normalized_types):
                    errors.append(
                        f"{prefix}.applies_to_card_types contains an unknown card type"
                    )
                if any(
                    isinstance(item, str) and item in LEGACY_CARD_TYPE_ALIASES
                    for item in applies_to
                ):
                    errors.append(
                        f"{prefix}.applies_to_card_types must use canonical card types"
                    )
        relationships = row.get("relationships")
        if not isinstance(relationships, list) or not all(
            isinstance(item, Mapping) for item in relationships
        ):
            errors.append(f"{prefix}.relationships must be an array of objects")
    for index, row in enumerate(rows):
        identifier = row.get("normalized_id")
        for relation_index, relation in enumerate(row.get("relationships", [])):
            if not isinstance(relation, Mapping):
                continue
            prefix = (
                f"normalized_concepts[{identifier or index + 1!r}]"
                f".relationships[{relation_index}]"
            )
            if relation.get("type") not in HARMONIZATION_HIERARCHY_RELATIONS:
                errors.append(
                    f"{prefix}.type must be one of: "
                    + ", ".join(sorted(HARMONIZATION_HIERARCHY_RELATIONS))
                )
            target = relation.get("target_normalized_id")
            if not _nonempty_string(target) or str(target) not in identifiers:
                errors.append(f"{prefix}.target_normalized_id must reference a known concept")
            elif target == identifier:
                errors.append(f"{prefix} cannot reference its own normalized concept")
    return rows, identifiers


def _validate_mapping_rows(
    value: object,
    *,
    key: str,
    known_concepts: set[str],
    errors: list[str],
) -> list[Mapping[str, Any]]:
    if not isinstance(value, list) or not all(isinstance(item, Mapping) for item in value):
        errors.append(f"{key} must be an array of objects")
        return []
    rows = list(value)
    identifiers: set[str] = set()
    originals: set[tuple[str, str]] = set()
    id_field = "queue_id" if key == "items" else "mapping_id"
    for index, row in enumerate(rows):
        identifier = row.get(id_field)
        prefix = f"{key}[{identifier or index + 1!r}]"
        if not _nonempty_string(identifier):
            errors.append(f"{prefix}.{id_field} must be a non-empty string")
        elif str(identifier) in identifiers:
            errors.append(f"duplicate {id_field} {identifier!r}")
        else:
            identifiers.add(str(identifier))
        dimension = row.get("dimension")
        original_label = row.get("original_label")
        if not _nonempty_string(dimension):
            errors.append(f"{prefix}.dimension must be a non-empty string")
        if not _nonempty_string(original_label):
            errors.append(f"{prefix}.original_label must preserve a non-empty source label")
        elif _nonempty_string(dimension):
            original_key = (str(dimension).casefold(), str(original_label))
            if original_key in originals:
                errors.append(
                    f"{prefix} duplicates original label {original_label!r} in dimension "
                    f"{dimension!r}"
                )
            originals.add(original_key)
        status = row.get("decision_status")
        if status not in HARMONIZATION_DECISION_STATUSES:
            errors.append(
                f"{prefix}.decision_status must be one of: "
                + ", ".join(sorted(HARMONIZATION_DECISION_STATUSES))
            )
        normalized_id = row.get("normalized_id")
        if status == "unresolved":
            if normalized_id not in (None, ""):
                errors.append(f"{prefix}.normalized_id must be null while unresolved")
        elif not _nonempty_string(normalized_id):
            errors.append(f"{prefix}.normalized_id is required for a resolved decision")
        elif known_concepts and str(normalized_id) not in known_concepts:
            errors.append(f"{prefix}.normalized_id must reference a known normalized concept")
        relation = row.get("relation")
        if relation not in HARMONIZATION_RELATIONS:
            errors.append(
                f"{prefix}.relation must be one of: "
                + ", ".join(sorted(HARMONIZATION_RELATIONS))
            )
        impact = _material_impact(row.get("material_impact"), prefix, errors)
        if (
            status == "automatic_obvious"
            and (
                relation not in {"exact", "alias"}
                or isinstance(impact, Mapping)
                and impact.get("is_material") is not False
            )
        ):
            errors.append(
                f"{prefix}.automatic_obvious is only valid for a non-material exact/alias mapping"
            )
        if not _nonempty_string(row.get("rationale")):
            errors.append(f"{prefix}.rationale must be a non-empty string")
        _source_examples(row.get("source_examples"), prefix, errors)
    return rows


def unresolved_material_mappings(
    harmonization_map: object,
    harmonization_queue: object | None = None,
) -> list[dict[str, Any]]:
    """Return material source labels that still require a human decision."""
    unresolved: list[dict[str, Any]] = []
    containers = (
        (
            "map",
            harmonization_map.get("mappings")
            if isinstance(harmonization_map, Mapping)
            else [],
        ),
        (
            "queue",
            harmonization_queue.get("items")
            if isinstance(harmonization_queue, Mapping)
            else [],
        ),
    )
    for source, rows in containers:
        if not isinstance(rows, list):
            continue
        for row in rows:
            impact = row.get("material_impact") if isinstance(row, Mapping) else None
            if (
                isinstance(row, Mapping)
                and row.get("decision_status") == "unresolved"
                and isinstance(impact, Mapping)
                and impact.get("is_material") is True
            ):
                unresolved.append(
                    {
                        "source": source,
                        "id": row.get("mapping_id") or row.get("queue_id"),
                        "dimension": row.get("dimension"),
                        "original_label": row.get("original_label"),
                        "affected_outputs": impact.get("affected_outputs", []),
                        "description": impact.get("description"),
                    }
                )
    return unresolved


def validate_harmonization_queue(
    value: object,
    *,
    collection_hash: str | None = None,
    verified_findings_sha256: str | None = None,
    evidence_proposal_sha256: str | None = None,
    known_concepts: set[str] | None = None,
) -> ContractValidation:
    """Validate queued unknown source labels and their current evidence binding."""
    result = ContractValidation()
    if not isinstance(value, Mapping):
        result.errors.append("harmonization_queue.json must contain an object")
        return result
    if value.get("schema_version") != HARMONIZATION_QUEUE_SCHEMA_VERSION:
        result.errors.append(
            f"schema_version must equal {HARMONIZATION_QUEUE_SCHEMA_VERSION}"
        )
    _validate_revision_envelope(
        value,
        filename=HARMONIZATION_QUEUE_FILENAME,
        errors=result.errors,
    )
    _validate_source_hashes(
        value,
        collection_hash=collection_hash,
        verified_findings_sha256=verified_findings_sha256,
        evidence_proposal_sha256=evidence_proposal_sha256,
        errors=result.errors,
    )
    _validate_mapping_rows(
        value.get("items"),
        key="items",
        known_concepts=known_concepts or set(),
        errors=result.errors,
    )
    return result


def validate_harmonization_map(
    value: object,
    *,
    collection_hash: str | None = None,
    verified_findings_sha256: str | None = None,
    evidence_proposal_sha256: str | None = None,
    harmonization_queue: object | None = None,
    harmonization_queue_sha256: str | None = None,
    final: bool = False,
) -> ContractValidation:
    """Validate the reproducible original-label to normalized-ID decision map."""
    result = ContractValidation()
    if not isinstance(value, Mapping):
        result.errors.append("harmonization_map.json must contain an object")
        return result
    if value.get("schema_version") != HARMONIZATION_MAP_SCHEMA_VERSION:
        result.errors.append(f"schema_version must equal {HARMONIZATION_MAP_SCHEMA_VERSION}")
    _validate_revision_envelope(
        value,
        filename=HARMONIZATION_MAP_FILENAME,
        errors=result.errors,
    )
    _validate_source_hashes(
        value,
        collection_hash=collection_hash,
        verified_findings_sha256=verified_findings_sha256,
        evidence_proposal_sha256=evidence_proposal_sha256,
        errors=result.errors,
    )
    _concepts, concept_ids = _concept_rows(value.get("normalized_concepts"), result.errors)
    _validate_mapping_rows(
        value.get("mappings"),
        key="mappings",
        known_concepts=concept_ids,
        errors=result.errors,
    )
    queue_binding = value.get("harmonization_queue_sha256")
    if harmonization_queue_sha256 is None:
        if queue_binding not in (None, ""):
            result.errors.append(
                "harmonization_queue_sha256 is present but harmonization_queue.json is absent"
            )
    elif not _sha256_string(queue_binding):
        result.errors.append(
            "harmonization_queue_sha256 must bind the current harmonization_queue.json"
        )
    elif queue_binding != harmonization_queue_sha256:
        result.errors.append(
            "harmonization_queue_sha256 does not match the current harmonization queue"
        )
    if harmonization_queue is not None:
        queue_validation = validate_harmonization_queue(
            harmonization_queue,
            collection_hash=collection_hash,
            verified_findings_sha256=verified_findings_sha256,
            evidence_proposal_sha256=evidence_proposal_sha256,
            known_concepts=concept_ids,
        )
        result.errors.extend(
            f"{HARMONIZATION_QUEUE_FILENAME}: {error}"
            for error in queue_validation.errors
        )
    if final:
        unresolved = unresolved_material_mappings(value, harmonization_queue)
        if unresolved:
            labels = ", ".join(
                f"{item['dimension']}={item['original_label']}" for item in unresolved
            )
            result.errors.append(
                "material harmonization decisions remain unresolved: " + labels
            )
    return result


def _mapping_key(row: Mapping[str, Any]) -> tuple[str, str]:
    return (
        str(row.get("dimension", "")).casefold(),
        str(row.get("original_label", "")),
    )


def _material_mapping(row: Mapping[str, Any] | None) -> bool:
    if row is None:
        return False
    impact = row.get("material_impact")
    return (
        isinstance(impact, Mapping)
        and (
            impact.get("is_material") is True
            or impact.get("pilot_rerun_required") is True
        )
        or row.get("relation") not in {"exact", "alias"}
    )


def harmonization_change_requires_pilot(
    previous: Mapping[str, Any],
    current: Mapping[str, Any],
) -> bool:
    """Distinguish mechanical alias maintenance from changed collection meaning."""
    previous_concepts = {
        str(row.get("normalized_id")): row
        for row in previous.get("normalized_concepts", [])
        if isinstance(row, Mapping) and _nonempty_string(row.get("normalized_id"))
    }
    current_concepts = {
        str(row.get("normalized_id")): row
        for row in current.get("normalized_concepts", [])
        if isinstance(row, Mapping) and _nonempty_string(row.get("normalized_id"))
    }
    if set(previous_concepts) != set(current_concepts):
        return True
    semantic_fields = ("dimension", "attributes", "relationships")
    for identifier in previous_concepts:
        if any(
            previous_concepts[identifier].get(field_name)
            != current_concepts[identifier].get(field_name)
            for field_name in semantic_fields
        ):
            return True

    previous_mappings = {
        _mapping_key(row): row
        for row in previous.get("mappings", [])
        if isinstance(row, Mapping)
    }
    current_mappings = {
        _mapping_key(row): row
        for row in current.get("mappings", [])
        if isinstance(row, Mapping)
    }
    for key in set(previous_mappings) | set(current_mappings):
        before = previous_mappings.get(key)
        after = current_mappings.get(key)
        if before is None or after is None:
            if _material_mapping(before or after):
                return True
            continue
        if before.get("normalized_id") != after.get("normalized_id"):
            return True
        if before.get("relation") != after.get("relation"):
            return True
        if _material_mapping(before) or _material_mapping(after):
            if before.get("decision_status") != after.get("decision_status"):
                return True
            before_impact = before.get("material_impact")
            after_impact = after.get("material_impact")
            before_semantics = (
                before_impact.get("is_material"),
                before_impact.get("pilot_rerun_required"),
            ) if isinstance(before_impact, Mapping) else None
            after_semantics = (
                after_impact.get("is_material"),
                after_impact.get("pilot_rerun_required"),
            ) if isinstance(after_impact, Mapping) else None
            if before_semantics != after_semantics:
                return True
    return False


def invalidate_pilot_for_harmonization_change(
    collection_spec: dict[str, Any],
    previous: Mapping[str, Any],
    current: Mapping[str, Any],
    *,
    reason: str,
    recorded_at: str,
) -> bool:
    """Use the existing pilot invalidation for a material mapping revision."""
    if not harmonization_change_requires_pilot(previous, current):
        return False
    mark_pilot_needs_rerun(
        collection_spec,
        reason=reason,
        recorded_at=recorded_at,
    )
    return True


def resolve_harmonized_label(
    harmonization_map: Mapping[str, Any],
    *,
    dimension: str,
    original_label: str,
) -> str | None:
    """Apply only an explicit approved/obvious mapping; never infer a new alias."""
    wanted = (dimension.casefold(), original_label)
    for row in harmonization_map.get("mappings", []):
        if (
            isinstance(row, Mapping)
            and _mapping_key(row) == wanted
            and row.get("decision_status") in {"automatic_obvious", "user_approved"}
            and _nonempty_string(row.get("normalized_id"))
        ):
            return str(row["normalized_id"])
    return None
