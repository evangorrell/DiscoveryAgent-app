"""Report contracts, revision archives, and publication state bindings."""

from __future__ import annotations

import json
import os
import shutil
import uuid
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .analysis_run import validate_current_execution
from .models import AnalysisProject, utc_now
from .store import sha256_file

REPORT_SPEC_FILENAME = "report_spec.json"
REPORT_SPEC_SCHEMA_VERSION = 1
PUBLISH_MANIFEST_FILENAME = "publish_manifest.json"
REVISION_DIRECTORY = "revisions"

RESULTS_REVISION_ARTIFACTS = (
    "analysis/analysis_spec.json",
    "analysis/methods.md",
    "analysis/runtime.json",
    "analysis/execution.json",
    "analysis/diagnostics.json",
    "analysis/analysis.json",
    "analysis.json",
    "synthesis.json",
    REPORT_SPEC_FILENAME,
    "dashboard_spec.json",
    "index.html",
    "data_qa.json",
    "render_qa.json",
)

REPORT_ARTIFACTS = (
    "synthesis.json",
    REPORT_SPEC_FILENAME,
    "dashboard_spec.json",
    "index.html",
    "data_qa.json",
    "render_qa.json",
)


class ReportStateError(RuntimeError):
    """An actionable report contract or revision-state failure."""


@dataclass
class ReportSpecValidation:
    """Validation result for the agent-authored report specification."""

    path: str
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "path": self.path, "errors": self.errors}


def _is_nonempty_string(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _string_list(value: object) -> bool:
    return (
        isinstance(value, list) and bool(value) and all(_is_nonempty_string(item) for item in value)
    )


def validate_report_spec(
    value: object,
    *,
    path: str = REPORT_SPEC_FILENAME,
) -> ReportSpecValidation:
    """Validate the stable report-spec contract without third-party dependencies."""
    report = ReportSpecValidation(path=path)
    if not isinstance(value, Mapping):
        report.errors.append("report_spec root must be a JSON object")
        return report
    allowed_fields = {
        "schema_version",
        "audience",
        "tldr",
        "section_order",
        "labels",
        "figure_inventory",
        "visibility",
        "provenance_notes",
    }
    unknown_fields = sorted(str(name) for name in set(value) - allowed_fields)
    if unknown_fields:
        report.errors.append(f"unknown report_spec fields: {', '.join(unknown_fields)}")
    if value.get("schema_version") != REPORT_SPEC_SCHEMA_VERSION:
        report.errors.append(f"schema_version must be {REPORT_SPEC_SCHEMA_VERSION}")
    if not _is_nonempty_string(value.get("audience")):
        report.errors.append("audience must be a non-empty string")
    tldr = value.get("tldr")
    if not (_is_nonempty_string(tldr) or _string_list(tldr)):
        report.errors.append("tldr must be a non-empty string or non-empty string array")
    if not _string_list(value.get("section_order")):
        report.errors.append("section_order must be a non-empty string array")
    elif len(set(value["section_order"])) != len(value["section_order"]):
        report.errors.append("section_order entries must be unique")
    labels = value.get("labels")
    if (
        not isinstance(labels, Mapping)
        or not labels
        or not all(
            _is_nonempty_string(key) and _is_nonempty_string(label) for key, label in labels.items()
        )
    ):
        report.errors.append("labels must map non-empty identifiers to display strings")
    figures = value.get("figure_inventory")
    if not isinstance(figures, list):
        report.errors.append("figure_inventory must be an array")
    else:
        figure_ids: list[str] = []
        for index, figure in enumerate(figures):
            if not isinstance(figure, Mapping):
                report.errors.append(f"figure_inventory[{index}] must be an object")
                continue
            unknown_figure_fields = sorted(
                str(name) for name in set(figure) - {"id", "label", "source_artifacts", "visible"}
            )
            if unknown_figure_fields:
                report.errors.append(
                    f"figure_inventory[{index}] has unknown fields: "
                    + ", ".join(unknown_figure_fields)
                )
            identifier = figure.get("id")
            if not _is_nonempty_string(identifier):
                report.errors.append(f"figure_inventory[{index}].id must be non-empty")
            else:
                figure_ids.append(str(identifier))
            if not _is_nonempty_string(figure.get("label")):
                report.errors.append(f"figure_inventory[{index}].label must be non-empty")
            if not _string_list(figure.get("source_artifacts")):
                report.errors.append(
                    f"figure_inventory[{index}].source_artifacts must be a non-empty string array"
                )
            if not isinstance(figure.get("visible"), bool):
                report.errors.append(f"figure_inventory[{index}].visible must be boolean")
        if len(set(figure_ids)) != len(figure_ids):
            report.errors.append("figure_inventory ids must be unique")
    visibility = value.get("visibility")
    if (
        not isinstance(visibility, Mapping)
        or not visibility
        or not all(
            _is_nonempty_string(key) and isinstance(visible, bool)
            for key, visible in visibility.items()
        )
    ):
        report.errors.append("visibility must map non-empty identifiers to booleans")
    notes = value.get("provenance_notes")
    if not (_is_nonempty_string(notes) or _string_list(notes)):
        report.errors.append(
            "provenance_notes must be a non-empty string or non-empty string array"
        )
    return report


def validate_report_spec_file(topic_dir: Path | str) -> ReportSpecValidation:
    """Read and validate ``report_spec.json`` from a project directory."""
    path = Path(topic_dir) / REPORT_SPEC_FILENAME
    if not path.is_file():
        return ReportSpecValidation(str(path), [f"missing report artifact: {REPORT_SPEC_FILENAME}"])
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return ReportSpecValidation(str(path), [f"cannot read report_spec.json: {exc}"])
    return validate_report_spec(value, path=str(path))


def artifact_hashes(
    topic_dir: Path | str,
    artifacts: Sequence[str] = RESULTS_REVISION_ARTIFACTS,
) -> dict[str, str]:
    """Hash the selected regular files that currently exist."""
    root = Path(topic_dir)
    return {name: sha256_file(root / name) for name in artifacts if (root / name).is_file()}


def diff_artifact_hashes(
    before: Mapping[str, str],
    after: Mapping[str, str],
) -> dict[str, list[str]]:
    """Return a deterministic added/modified/removed artifact summary."""
    before_names = set(before)
    after_names = set(after)
    return {
        "added": sorted(after_names - before_names),
        "modified": sorted(
            name for name in before_names & after_names if before[name] != after[name]
        ),
        "removed": sorted(before_names - after_names),
        "unchanged": sorted(
            name for name in before_names & after_names if before[name] == after[name]
        ),
    }


def _atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def archive_results_revision(project: AnalysisProject, reason: str) -> dict[str, Any]:
    """Archive the current results artifacts once, without overwriting history."""
    normalized_reason = reason.strip()
    if not normalized_reason:
        raise ReportStateError("A non-empty --reason is required for a results revision.")
    root = Path(project.topic_dir).resolve()
    destination = root / REVISION_DIRECTORY / f"results-v{project.results_revision}"
    if destination.exists():
        raise ReportStateError(
            f"Results revision archive already exists and will not be overwritten: {destination}"
        )
    hashes = artifact_hashes(root)
    created = False
    try:
        try:
            destination.mkdir(parents=True, exist_ok=False)
        except FileExistsError as exc:
            raise ReportStateError(
                "Results revision archive appeared concurrently and will not be "
                f"overwritten: {destination}"
            ) from exc
        created = True
        inventory: list[dict[str, Any]] = []
        for name, digest in hashes.items():
            source = root / name
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            inventory.append(
                {
                    "path": name,
                    "sha256": digest,
                    "size_bytes": source.stat().st_size,
                }
            )
        manifest = {
            "schema_version": 1,
            "results_revision": project.results_revision,
            "project_revision": project.revision,
            "archived_at": utc_now(),
            "reason": normalized_reason,
            "artifacts": inventory,
            "artifact_hashes": hashes,
            "results_binding": dict(project.results_binding),
        }
        _atomic_json(destination / "archive_manifest.json", manifest)
    except Exception:
        if created:
            shutil.rmtree(destination, ignore_errors=True)
        raise
    return {
        "archive": str(destination),
        "results_revision": project.results_revision,
        "reason": normalized_reason,
        "artifact_hashes": hashes,
        "artifacts": inventory,
    }


def build_results_binding(
    project: AnalysisProject,
    *,
    reason: str,
) -> dict[str, Any]:
    """Bind the current results revision to evidence and managed execution hashes."""
    evidence = project.approvals.get("evidence")
    execution = validate_current_execution(project) if project.stage == "results" else {}
    return {
        "results_revision": project.results_revision,
        "bound_at": utc_now(),
        "reason": reason,
        "evidence_hashes": dict(evidence.artifact_hashes) if evidence else {},
        "analysis_sha256": execution.get("analysis_sha256") if execution.get("ok") else None,
        "analysis_execution_sha256": (
            execution.get("execution_sha256") if execution.get("ok") else None
        ),
    }


def validate_results_binding(
    project: AnalysisProject,
    execution: Mapping[str, Any] | None = None,
) -> list[str]:
    """Check that state binding names this revision, evidence, and execution."""
    binding = project.results_binding
    errors: list[str] = []
    if binding.get("results_revision") != project.results_revision:
        errors.append("results binding does not match the current results revision")
    evidence = project.approvals.get("evidence")
    expected_evidence = dict(evidence.artifact_hashes) if evidence else {}
    if binding.get("evidence_hashes") != expected_evidence:
        errors.append("results binding does not match the current evidence approval")
    current = dict(execution or validate_current_execution(project))
    if not current.get("ok"):
        errors.extend(f"managed analysis execution: {error}" for error in current.get("errors", []))
        return errors
    if binding.get("analysis_sha256") != current.get("analysis_sha256"):
        errors.append("results binding analysis_sha256 is stale")
    if binding.get("analysis_execution_sha256") != current.get("execution_sha256"):
        errors.append("results binding analysis_execution_sha256 is stale")
    return errors


def _latest_archive_hashes(project: AnalysisProject) -> dict[str, str]:
    if project.results_revision <= 1:
        return {}
    manifest_path = (
        Path(project.topic_dir)
        / REVISION_DIRECTORY
        / f"results-v{project.results_revision - 1}"
        / "archive_manifest.json"
    )
    if not manifest_path.is_file():
        return {}
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    hashes = manifest.get("artifact_hashes") if isinstance(manifest, Mapping) else None
    return (
        {str(name): str(digest) for name, digest in hashes.items()}
        if isinstance(hashes, Mapping)
        else {}
    )


def report_status(project: AnalysisProject) -> dict[str, Any]:
    """Return report validation, revision diff, and current execution binding."""
    from .lifecycle import review_gate

    current = artifact_hashes(project.topic_dir)
    baseline = _latest_archive_hashes(project)
    execution = (
        validate_current_execution(project)
        if project.stage == "results"
        else {
            "ok": False,
            "errors": ["project is not in the results stage"],
        }
    )
    spec = validate_report_spec_file(project.topic_dir)
    binding_errors = validate_results_binding(project, execution)
    qa_gate = review_gate(project, "results")
    return {
        "ok": bool(
            project.stage == "results"
            and execution.get("ok")
            and spec.ok
            and not binding_errors
            and qa_gate.ok
        ),
        "results_revision": project.results_revision,
        "results_binding": dict(project.results_binding),
        "binding_errors": binding_errors,
        "execution": execution,
        "qa_gate": qa_gate.to_dict(),
        "report_spec": spec.to_dict(),
        "artifact_hashes": current,
        "diff_summary": diff_artifact_hashes(baseline, current),
        "baseline_revision": project.results_revision - 1 if baseline else None,
        "publications": list(project.publications),
    }


def publication_for_revision(project: AnalysisProject) -> dict[str, Any] | None:
    """Return the publication record for the current results revision, if any."""
    for publication in reversed(project.publications):
        if publication.get("results_revision") == project.results_revision:
            return publication
    return None


def build_publish_manifest(
    project: AnalysisProject,
    inventory: Sequence[Mapping[str, Any]],
    *,
    status: str,
    upload_results: Sequence[Mapping[str, Any]] = (),
) -> dict[str, Any]:
    """Build the versioned publication manifest."""
    destination = f"analyses/{project.slug}/v{project.results_revision}"
    return {
        "schema_version": 1,
        "project_id": project.project_id,
        "slug": project.slug,
        "project_revision": project.revision,
        "results_revision": project.results_revision,
        "destination": destination,
        "status": status,
        "recorded_at": utc_now(),
        "results_binding": dict(project.results_binding),
        "artifact_hashes": {str(item["path"]): str(item["sha256"]) for item in inventory},
        "artifacts": [dict(item) for item in inventory],
        "uploads": [dict(item) for item in upload_results],
    }


def write_publish_manifest(project: AnalysisProject, manifest: Mapping[str, Any]) -> Path:
    """Atomically persist the publication manifest in the project directory."""
    path = Path(project.topic_dir) / PUBLISH_MANIFEST_FILENAME
    _atomic_json(path, dict(manifest))
    return path
