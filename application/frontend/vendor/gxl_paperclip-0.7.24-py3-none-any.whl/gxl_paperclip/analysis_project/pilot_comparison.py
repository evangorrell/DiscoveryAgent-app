"""Deterministic pilot comparison for structured and exhaustive extraction."""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from .models import utc_now
from .store import atomic_write_json

PILOT_COMPARISON_FILENAME = "pilot_comparison.json"
PILOT_COMPARISON_SCHEMA_VERSION = 1


class PilotComparisonError(RuntimeError):
    """Raised when pilot manifests cannot be compared safely."""


def _output(task: Mapping[str, Any], label: str) -> dict[str, Any]:
    result = task.get("result")
    if not isinstance(result, Mapping):
        raise PilotComparisonError(f"{label}.result must be an object")
    raw = result.get("output")
    if isinstance(raw, Mapping):
        value = dict(raw)
    elif isinstance(raw, str):
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise PilotComparisonError(f"{label}.result.output is invalid JSON") from exc
    else:
        raise PilotComparisonError(f"{label}.result.output must be JSON")
    if not isinstance(value, dict):
        raise PilotComparisonError(f"{label}.result.output must be an object")
    return value


def _paper_values(paper: Mapping[str, Any]) -> dict[tuple[str, str, str, str], dict]:
    document_id = str(paper.get("document_id") or "")
    values: dict[tuple[str, str, str, str], dict] = {}
    reserved = {
        "document_id",
        "source_notes",
        "extractor_notes",
        "ambiguities",
        "missing_visual_evidence",
    }
    for category, records in paper.items():
        if category in reserved or not isinstance(records, list):
            continue
        for record in records:
            if not isinstance(record, Mapping):
                continue
            record_id = str(record.get("record_id") or "")
            data = record.get("data")
            if not record_id or not isinstance(data, Mapping):
                continue
            for field_id, sourced_value in data.items():
                if isinstance(sourced_value, Mapping):
                    values[(document_id, str(category), record_id, str(field_id))] = dict(
                        sourced_value
                    )
    return values


def _manifest_values(
    manifests: Sequence[Mapping[str, Any]],
    *,
    worker: str,
) -> tuple[dict[tuple[str, str, str, str], dict], dict[str, Any]]:
    values: dict[tuple[str, str, str, str], dict] = {}
    total_tasks = 0
    successful_tasks = 0
    fallback_tasks = 0
    runtime_ms = 0.0
    model_calls = 0
    for manifest_index, manifest in enumerate(manifests):
        inputs = manifest.get("inputs")
        if not isinstance(inputs, Mapping) or inputs.get("worker") != worker:
            raise PilotComparisonError(
                f"manifest[{manifest_index}] must use worker {worker}"
            )
        tasks = manifest.get("tasks")
        if not isinstance(tasks, list):
            raise PilotComparisonError(f"manifest[{manifest_index}].tasks must be an array")
        for task_index, task in enumerate(tasks):
            if not isinstance(task, Mapping):
                continue
            total_tasks += 1
            if task.get("status") == "fallback_required":
                fallback_tasks += 1
            if task.get("status") != "success":
                continue
            successful_tasks += 1
            result = task.get("result")
            if isinstance(result, Mapping):
                runtime_ms += float(result.get("time_ms") or 0)
                model_calls += int(result.get("model_call_count") or 1)
            output = _output(
                task,
                f"manifest[{manifest_index}].tasks[{task_index}]",
            )
            if worker == "structured-extraction":
                paper_values = _paper_values(output)
            else:
                document_id = str(output.get("document_id") or "")
                paper = {"document_id": document_id}
                for item in output.get("claims") or []:
                    if not isinstance(item, Mapping):
                        continue
                    claim = item.get("claim")
                    if not isinstance(claim, Mapping):
                        continue
                    category = str(claim.get("category") or "")
                    record = claim.get("record")
                    if category and isinstance(record, Mapping):
                        paper.setdefault(category, []).append(dict(record))
                paper_values = _paper_values(paper)
            for key, value in paper_values.items():
                prior = values.get(key)
                if prior is not None and prior != value:
                    raise PilotComparisonError(
                        "conflicting pilot value for " + "/".join(key)
                    )
                values[key] = value
    return values, {
        "tasks": total_tasks,
        "successful_tasks": successful_tasks,
        "fallback_tasks": fallback_tasks,
        "runtime_seconds": round(runtime_ms / 1000, 3),
        "model_calls": model_calls,
        "fallback_rate": (
            round(fallback_tasks / total_tasks, 6) if total_tasks else None
        ),
    }


def _location_set(value: Mapping[str, Any]) -> set[tuple[str, str]]:
    return {
        (str(location.get("path") or ""), str(location.get("lines") or ""))
        for location in value.get("source_locations") or []
        if isinstance(location, Mapping)
    }


def _semantic_counters(
    values: Mapping[tuple[str, str, str, str], Mapping[str, Any]],
) -> tuple[Counter, Counter, Counter]:
    fields: Counter = Counter()
    normalized_values: Counter = Counter()
    located_values: Counter = Counter()
    for (document_id, category, _record_id, field_id), sourced in values.items():
        field_key = (document_id, category, field_id)
        value_key = (
            *field_key,
            json.dumps(
                sourced.get("value"),
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                default=str,
            ),
        )
        location_key = (
            *value_key,
            tuple(sorted(_location_set(sourced))),
        )
        fields[field_key] += 1
        normalized_values[value_key] += 1
        located_values[location_key] += 1
    return fields, normalized_values, located_values


def compare_pilot_manifests(
    structured_manifests: Sequence[Mapping[str, Any]],
    exhaustive_manifests: Sequence[Mapping[str, Any]],
    *,
    structured_verifier_pass_rate: float | None = None,
    exhaustive_verifier_pass_rate: float | None = None,
) -> dict[str, Any]:
    """Compare the new worker to the exhaustive reference by stable field key."""
    structured, structured_run = _manifest_values(
        structured_manifests,
        worker="structured-extraction",
    )
    exhaustive, exhaustive_run = _manifest_values(
        exhaustive_manifests,
        worker="exhaustive-extraction",
    )
    reference_keys = set(exhaustive)
    structured_keys = set(structured)
    exact_id_matches = reference_keys & structured_keys
    exact_id_value_matches = {
        key
        for key in exact_id_matches
        if structured[key].get("value") == exhaustive[key].get("value")
    }
    exact_id_location_matches = {
        key
        for key in exact_id_value_matches
        if _location_set(structured[key]) == _location_set(exhaustive[key])
    }
    structured_fields, structured_values, structured_locations = _semantic_counters(
        structured
    )
    reference_fields, reference_values, reference_locations = _semantic_counters(
        exhaustive
    )
    field_matches = sum((structured_fields & reference_fields).values())
    value_matches = sum((structured_values & reference_values).values())
    location_matches = sum((structured_locations & reference_locations).values())

    def ratio(numerator: int, denominator: int) -> float | None:
        return round(numerator / denominator, 6) if denominator else None

    field_recall = ratio(field_matches, sum(reference_fields.values()))
    value_agreement = ratio(value_matches, field_matches)
    source_location_agreement = ratio(location_matches, value_matches)
    exact_record_id_field_recall = ratio(
        len(exact_id_matches),
        len(reference_keys),
    )
    material_differences = [
        {
            "document_id": key[0],
            "category": key[1],
            "field_id": key[2],
            "reference_count": count,
            "structured_count": structured_fields.get(key, 0),
            "kind": "field_instance_count_difference",
        }
        for key, count in sorted(reference_fields.items())
        if structured_fields.get(key, 0) < count
    ]
    if value_matches < field_matches:
        material_differences.append(
            {
                "kind": "normalized_value_disagreement",
                "field_instances_compared": field_matches,
                "matching_values": value_matches,
            }
        )
    if location_matches < value_matches:
        material_differences.append(
            {
                "kind": "source_location_disagreement",
                "matching_values": value_matches,
                "matching_source_locations": location_matches,
            }
        )
    if len(exact_id_matches) < len(reference_keys):
        material_differences.append(
            {
                "kind": "record_id_disagreement",
                "reference_fields": len(reference_keys),
                "exact_record_id_matches": len(exact_id_matches),
            }
        )
    return {
        "schema_version": PILOT_COMPARISON_SCHEMA_VERSION,
        "generated_at": utc_now(),
        "status": "pass" if not material_differences else "review_required",
        "reference_worker": "exhaustive-extraction",
        "structured_worker": "structured-extraction",
        "field_recall": field_recall,
        "value_agreement": value_agreement,
        "source_location_agreement": source_location_agreement,
        "exact_record_id_field_recall": exact_record_id_field_recall,
        "verifier_pass_rate": {
            "structured": structured_verifier_pass_rate,
            "exhaustive": exhaustive_verifier_pass_rate,
        },
        "runtime_seconds": {
            "structured": structured_run["runtime_seconds"],
            "exhaustive": exhaustive_run["runtime_seconds"],
        },
        "model_calls": {
            "structured": structured_run["model_calls"],
            "exhaustive": exhaustive_run["model_calls"],
        },
        "fallback_rate": structured_run["fallback_rate"],
        "counts": {
            "structured_fields": len(structured_keys),
            "exhaustive_reference_fields": len(reference_keys),
            "matched_fields": field_matches,
            "value_matches": value_matches,
            "source_location_matches": location_matches,
            "exact_record_id_matches": len(exact_id_matches),
            "exact_record_id_value_matches": len(exact_id_value_matches),
            "exact_record_id_location_matches": len(exact_id_location_matches),
        },
        "run_accounting": {
            "structured": structured_run,
            "exhaustive": exhaustive_run,
        },
        "material_differences": material_differences,
    }


def write_pilot_comparison(
    topic_dir: Path | str,
    structured_manifests: Sequence[Mapping[str, Any]],
    exhaustive_manifests: Sequence[Mapping[str, Any]],
    **kwargs: Any,
) -> dict[str, Any]:
    artifact = compare_pilot_manifests(
        structured_manifests,
        exhaustive_manifests,
        **kwargs,
    )
    atomic_write_json(Path(topic_dir) / PILOT_COMPARISON_FILENAME, artifact)
    return artifact
